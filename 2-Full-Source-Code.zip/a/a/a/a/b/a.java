package a.a.a.a.b;

import android.os.IInterface;

/* loaded from: classes.dex */
public interface a extends IInterface {
}
