package a.a.a.a;

import android.animation.Animator;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.os.StrictMode;
import android.text.TextUtils;
import android.transition.Transition;
import android.transition.TransitionValues;
import android.util.AttributeSet;
import android.util.Base64;
import android.util.Log;
import android.util.Property;
import android.util.TypedValue;
import android.util.Xml;
import android.view.ActionMode;
import android.view.InflateException;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.widget.PopupWindow;
import android.widget.TextView;
import b.a.p.m0;
import b.a.p.q0;
import b.d.c;
import b.d.f.b;
import b.d.i.a;
import b.d.l.d;
import b.g.f;
import b.j.c.s;
import b.j.c.t;
import b.k.a.a.e;
import c.d.a.a.e1.u;
import c.d.a.a.g1.k.h;
import c.d.a.a.l0;
import c.d.a.a.m1.c0;
import c.d.a.a.m1.m;
import java.io.EOFException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    public static Method f0a;

    /* renamed from: b, reason: collision with root package name */
    public static boolean f1b;

    /* renamed from: c, reason: collision with root package name */
    public static Method f2c;

    /* renamed from: d, reason: collision with root package name */
    public static boolean f3d;
    public static Field e;
    public static boolean f;

    public static float a(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i, float f2) {
        return !a(xmlPullParser, str) ? f2 : typedArray.getFloat(i, f2);
    }

    public static int a(int i) {
        if (i >= 0) {
            return i;
        }
        throw new IllegalArgumentException();
    }

    public static int a(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i, int i2) {
        return !a(xmlPullParser, str) ? i2 : typedArray.getColor(i, i2);
    }

    public static int a(Drawable drawable) {
        if (Build.VERSION.SDK_INT >= 23) {
            return drawable.getLayoutDirection();
        }
        if (!f1b) {
            try {
                Method declaredMethod = Drawable.class.getDeclaredMethod("getLayoutDirection", new Class[0]);
                f0a = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (NoSuchMethodException e2) {
                Log.i("DrawableCompat", "Failed to retrieve getLayoutDirection() method", e2);
            }
            f1b = true;
        }
        Method method = f0a;
        if (method != null) {
            try {
                return ((Integer) method.invoke(drawable, new Object[0])).intValue();
            } catch (Exception e3) {
                Log.i("DrawableCompat", "Failed to invoke getLayoutDirection() via reflection", e3);
                f0a = null;
            }
        }
        return 0;
    }

    public static int a(t.w wVar, s sVar, View view, View view2, t.l lVar, boolean z) {
        if (lVar.d() == 0 || wVar.a() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z) {
            return Math.abs(lVar.j(view) - lVar.j(view2)) + 1;
        }
        return Math.min(sVar.g(), sVar.a(view2) - sVar.d(view));
    }

    public static int a(t.w wVar, s sVar, View view, View view2, t.l lVar, boolean z, boolean z2) {
        if (lVar.d() == 0 || wVar.a() == 0 || view == null || view2 == null) {
            return 0;
        }
        int max = z2 ? Math.max(0, (wVar.a() - Math.max(lVar.j(view), lVar.j(view2))) - 1) : Math.max(0, Math.min(lVar.j(view), lVar.j(view2)));
        if (z) {
            return Math.round((max * (Math.abs(sVar.a(view2) - sVar.d(view)) / (Math.abs(lVar.j(view) - lVar.j(view2)) + 1))) + (sVar.f() - sVar.d(view)));
        }
        return max;
    }

    public static int a(c.d.a.a.m1.t tVar) {
        int i = 0;
        while (tVar.a() != 0) {
            int l = tVar.l();
            i += l;
            if (l != 255) {
                return i;
            }
        }
        return -1;
    }

    public static Animator a(View view, TransitionValues transitionValues, int i, int i2, float f2, float f3, float f4, float f5, TimeInterpolator timeInterpolator, Transition transition) {
        float translationX = view.getTranslationX();
        float translationY = view.getTranslationY();
        if (((int[]) transitionValues.view.getTag(f.transitionPosition)) != null) {
            f2 = (r2[0] - i) + translationX;
            f3 = (r2[1] - i2) + translationY;
        }
        int round = Math.round(f2 - translationX) + i;
        int round2 = Math.round(f3 - translationY) + i2;
        view.setTranslationX(f2);
        view.setTranslationY(f3);
        if (f2 == f4 && f3 == f5) {
            return null;
        }
        Path path = new Path();
        path.moveTo(f2, f3);
        path.lineTo(f4, f5);
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, (Property<View, Float>) View.TRANSLATION_X, (Property<View, Float>) View.TRANSLATION_Y, path);
        b.g.m.a aVar = new b.g.m.a(view, transitionValues.view, round, round2, translationX, translationY);
        transition.addListener(aVar);
        ofFloat.addListener(aVar);
        ofFloat.addPauseListener(aVar);
        ofFloat.setInterpolator(timeInterpolator);
        return ofFloat;
    }

    public static Keyframe a(Keyframe keyframe, float f2) {
        return keyframe.getType() == Float.TYPE ? Keyframe.ofFloat(f2) : keyframe.getType() == Integer.TYPE ? Keyframe.ofInt(f2) : Keyframe.ofObject(f2);
    }

    public static ColorStateList a(Resources resources, XmlPullParser xmlPullParser, Resources.Theme theme) {
        int next;
        AttributeSet asAttributeSet = Xml.asAttributeSet(xmlPullParser);
        do {
            next = xmlPullParser.next();
            if (next == 2) {
                break;
            }
        } while (next != 1);
        if (next == 2) {
            return a(resources, xmlPullParser, asAttributeSet, theme);
        }
        throw new XmlPullParserException("No start tag found");
    }

    public static TypedArray a(Resources resources, Resources.Theme theme, AttributeSet attributeSet, int[] iArr) {
        return theme == null ? resources.obtainAttributes(attributeSet, iArr) : theme.obtainStyledAttributes(attributeSet, iArr, 0, 0);
    }

    public static ActionMode.Callback a(TextView textView, ActionMode.Callback callback) {
        int i = Build.VERSION.SDK_INT;
        return (i < 26 || i > 27 || (callback instanceof d)) ? callback : new d(callback, textView);
    }

    public static InputConnection a(InputConnection inputConnection, EditorInfo editorInfo, View view) {
        if (inputConnection != null && editorInfo.hintText == null) {
            ViewParent parent = view.getParent();
            while (true) {
                if (!(parent instanceof View)) {
                    break;
                }
                if (parent instanceof q0) {
                    editorInfo.hintText = ((q0) parent).a();
                    break;
                }
                parent = parent.getParent();
            }
        }
        return inputConnection;
    }

    public static u a(c.d.a.a.m1.t tVar, boolean z, boolean z2) {
        if (z) {
            a(3, tVar, false);
        }
        String b2 = tVar.b((int) tVar.f());
        int length = b2.length() + 11;
        long f2 = tVar.f();
        String[] strArr = new String[(int) f2];
        int i = length + 4;
        for (int i2 = 0; i2 < f2; i2++) {
            strArr[i2] = tVar.b((int) tVar.f());
            i = i + 4 + strArr[i2].length();
        }
        if (z2 && (tVar.l() & 1) == 0) {
            throw new l0("framing bit expected to be set");
        }
        return new u(b2, strArr, i + 1);
    }

    public static String a(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i) {
        if (a(xmlPullParser, str)) {
            return typedArray.getString(i);
        }
        return null;
    }

    public static ByteBuffer a(Context context, CancellationSignal cancellationSignal, Uri uri) {
        try {
            ParcelFileDescriptor openFileDescriptor = context.getContentResolver().openFileDescriptor(uri, "r", cancellationSignal);
            if (openFileDescriptor == null) {
                if (openFileDescriptor != null) {
                    openFileDescriptor.close();
                }
                return null;
            }
            try {
                FileInputStream fileInputStream = new FileInputStream(openFileDescriptor.getFileDescriptor());
                try {
                    FileChannel channel = fileInputStream.getChannel();
                    MappedByteBuffer map = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                    fileInputStream.close();
                    openFileDescriptor.close();
                    return map;
                } finally {
                }
            } finally {
            }
        } catch (IOException unused) {
            return null;
        }
    }

    public static List<byte[]> a(String[] strArr) {
        ArrayList arrayList = new ArrayList();
        for (String str : strArr) {
            arrayList.add(Base64.decode(str, 0));
        }
        return arrayList;
    }

    public static void a(long j, c.d.a.a.m1.t tVar, c.d.a.a.e1.s[] sVarArr) {
        while (true) {
            if (tVar.a() <= 1) {
                return;
            }
            int a2 = a(tVar);
            int a3 = a(tVar);
            int i = tVar.f2479b + a3;
            if (a3 == -1 || a3 > tVar.a()) {
                Log.w("CeaUtil", "Skipping remainder of malformed SEI NAL unit.");
                i = tVar.f2480c;
            } else if (a2 == 4 && a3 >= 8) {
                int l = tVar.l();
                int q = tVar.q();
                int c2 = q == 49 ? tVar.c() : 0;
                int l2 = tVar.l();
                if (q == 47) {
                    tVar.f(1);
                }
                boolean z = l == 181 && (q == 49 || q == 47) && l2 == 3;
                if (q == 49) {
                    z &= c2 == 1195456820;
                }
                if (z) {
                    b(j, tVar, sVarArr);
                }
            }
            tVar.e(i);
        }
    }

    public static void a(Drawable drawable, int i) {
        drawable.setTint(i);
    }

    public static void a(Drawable drawable, ColorStateList colorStateList) {
        drawable.setTintList(colorStateList);
    }

    public static void a(Drawable drawable, PorterDuff.Mode mode) {
        drawable.setTintMode(mode);
    }

    public static void a(MediaFormat mediaFormat, String str, int i) {
        if (i != -1) {
            mediaFormat.setInteger(str, i);
        }
    }

    public static void a(MediaFormat mediaFormat, List<byte[]> list) {
        for (int i = 0; i < list.size(); i++) {
            mediaFormat.setByteBuffer(c.a.b.a.a.a("csd-", i), ByteBuffer.wrap(list.get(i)));
        }
    }

    public static void a(PopupWindow popupWindow, int i) {
        if (Build.VERSION.SDK_INT >= 23) {
            popupWindow.setWindowLayoutType(i);
            return;
        }
        if (!f3d) {
            try {
                Method declaredMethod = PopupWindow.class.getDeclaredMethod("setWindowLayoutType", Integer.TYPE);
                f2c = declaredMethod;
                declaredMethod.setAccessible(true);
            } catch (Exception unused) {
            }
            f3d = true;
        }
        Method method = f2c;
        if (method != null) {
            try {
                method.invoke(popupWindow, Integer.valueOf(i));
            } catch (Exception unused2) {
            }
        }
    }

    public static void a(PopupWindow popupWindow, boolean z) {
        if (Build.VERSION.SDK_INT >= 23) {
            popupWindow.setOverlapAnchor(z);
            return;
        }
        if (!f) {
            try {
                Field declaredField = PopupWindow.class.getDeclaredField("mOverlapAnchor");
                e = declaredField;
                declaredField.setAccessible(true);
            } catch (NoSuchFieldException e2) {
                Log.i("PopupWindowCompatApi21", "Could not fetch mOverlapAnchor field from PopupWindow", e2);
            }
            f = true;
        }
        Field field = e;
        if (field != null) {
            try {
                field.set(popupWindow, Boolean.valueOf(z));
            } catch (IllegalAccessException e3) {
                Log.i("PopupWindowCompatApi21", "Could not set overlap anchor field in PopupWindow", e3);
            }
        }
    }

    public static void a(TextView textView, int i) {
        a(i);
        if (Build.VERSION.SDK_INT >= 28) {
            textView.setFirstBaselineToTopHeight(i);
            return;
        }
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int i2 = textView.getIncludeFontPadding() ? fontMetricsInt.top : fontMetricsInt.ascent;
        if (i > Math.abs(i2)) {
            textView.setPadding(textView.getPaddingLeft(), i - (-i2), textView.getPaddingRight(), textView.getPaddingBottom());
        }
    }

    public static void a(XmlPullParser xmlPullParser) {
        int i = 1;
        while (i > 0) {
            int next = xmlPullParser.next();
            if (next == 2) {
                i++;
            } else if (next == 3) {
                i--;
            }
        }
    }

    public static boolean a(int i, c.d.a.a.m1.t tVar, boolean z) {
        if (tVar.a() < 7) {
            if (z) {
                return false;
            }
            StringBuilder a2 = c.a.b.a.a.a("too short header: ");
            a2.append(tVar.a());
            throw new l0(a2.toString());
        }
        if (tVar.l() != i) {
            if (z) {
                return false;
            }
            StringBuilder a3 = c.a.b.a.a.a("expected header type ");
            a3.append(Integer.toHexString(i));
            throw new l0(a3.toString());
        }
        if (tVar.l() == 118 && tVar.l() == 111 && tVar.l() == 114 && tVar.l() == 98 && tVar.l() == 105 && tVar.l() == 115) {
            return true;
        }
        if (z) {
            return false;
        }
        throw new l0("expected characters 'vorbis'");
    }

    public static boolean a(Context context) {
        return Build.VERSION.SDK_INT < 23 || context.checkCallingOrSelfPermission("android.permission.READ_EXTERNAL_STORAGE") == 0;
    }

    public static boolean a(ViewGroup viewGroup, View view) {
        while (view != null) {
            if (view == viewGroup) {
                return true;
            }
            Object parent = view.getParent();
            if (!(parent instanceof View)) {
                return false;
            }
            view = (View) parent;
        }
        return false;
    }

    public static boolean a(XmlPullParser xmlPullParser, String str) {
        return xmlPullParser.getAttributeValue("http://schemas.android.com/apk/res/android", str) != null;
    }

    public static boolean a(b[] bVarArr, b[] bVarArr2) {
        if (bVarArr == null || bVarArr2 == null || bVarArr.length != bVarArr2.length) {
            return false;
        }
        for (int i = 0; i < bVarArr.length; i++) {
            if (bVarArr[i].f550a != bVarArr2[i].f550a || bVarArr[i].f551b.length != bVarArr2[i].f551b.length) {
                return false;
            }
        }
        return true;
    }

    public static byte[] a(UUID uuid, UUID[] uuidArr, byte[] bArr) {
        int length = (bArr != null ? bArr.length : 0) + 32;
        if (uuidArr != null) {
            length += (uuidArr.length * 16) + 4;
        }
        ByteBuffer allocate = ByteBuffer.allocate(length);
        allocate.putInt(length);
        allocate.putInt(1886614376);
        allocate.putInt(uuidArr != null ? 16777216 : 0);
        allocate.putLong(uuid.getMostSignificantBits());
        allocate.putLong(uuid.getLeastSignificantBits());
        if (uuidArr != null) {
            allocate.putInt(uuidArr.length);
            for (UUID uuid2 : uuidArr) {
                allocate.putLong(uuid2.getMostSignificantBits());
                allocate.putLong(uuid2.getLeastSignificantBits());
            }
        }
        if (bArr != null && bArr.length != 0) {
            allocate.putInt(bArr.length);
            allocate.put(bArr);
        }
        return allocate.array();
    }

    public static float[] a(float[] fArr, int i, int i2) {
        if (i > i2) {
            throw new IllegalArgumentException();
        }
        int length = fArr.length;
        if (i < 0 || i > length) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int i3 = i2 - i;
        int min = Math.min(i3, length - i);
        float[] fArr2 = new float[i3];
        System.arraycopy(fArr, i, fArr2, 0, min);
        return fArr2;
    }

    public static b[] a(b[] bVarArr) {
        if (bVarArr == null) {
            return null;
        }
        b[] bVarArr2 = new b[bVarArr.length];
        for (int i = 0; i < bVarArr.length; i++) {
            bVarArr2[i] = new b(bVarArr[i]);
        }
        return bVarArr2;
    }

    public static int b(int i) {
        int i2 = 0;
        while (i > 0) {
            i2++;
            i >>>= 1;
        }
        return i2;
    }

    public static int b(TypedArray typedArray, XmlPullParser xmlPullParser, String str, int i, int i2) {
        return !a(xmlPullParser, str) ? i2 : typedArray.getInt(i, i2);
    }

    public static int b(t.w wVar, s sVar, View view, View view2, t.l lVar, boolean z) {
        if (lVar.d() == 0 || wVar.a() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z) {
            return wVar.a();
        }
        return (int) (((sVar.a(view2) - sVar.d(view)) / (Math.abs(lVar.j(view) - lVar.j(view2)) + 1)) * wVar.a());
    }

    public static Path b(String str) {
        Path path = new Path();
        b[] a2 = a(str);
        if (a2 == null) {
            return null;
        }
        try {
            b.a(a2, path);
            return path;
        } catch (RuntimeException e2) {
            throw new RuntimeException(c.a.b.a.a.a("Error in parsing ", str), e2);
        }
    }

    public static Drawable b(Drawable drawable) {
        return (Build.VERSION.SDK_INT < 23 && !(drawable instanceof b.d.f.i.a)) ? new b.d.f.i.d(drawable) : drawable;
    }

    public static File b(Context context) {
        File cacheDir = context.getCacheDir();
        if (cacheDir == null) {
            return null;
        }
        StringBuilder a2 = c.a.b.a.a.a(".font");
        a2.append(Process.myPid());
        a2.append("-");
        a2.append(Process.myTid());
        a2.append("-");
        String sb = a2.toString();
        for (int i = 0; i < 100; i++) {
            File file = new File(cacheDir, c.a.b.a.a.a(sb, i));
            if (file.createNewFile()) {
                return file;
            }
        }
        return null;
    }

    public static void b(long j, c.d.a.a.m1.t tVar, c.d.a.a.e1.s[] sVarArr) {
        int l = tVar.l();
        if ((l & 64) != 0) {
            tVar.f(1);
            int i = (l & 31) * 3;
            int i2 = tVar.f2479b;
            for (c.d.a.a.e1.s sVar : sVarArr) {
                tVar.e(i2);
                sVar.a(tVar, i);
                sVar.a(j, 1, i, 0, null);
            }
        }
    }

    public static void b(TextView textView, int i) {
        a(i);
        Paint.FontMetricsInt fontMetricsInt = textView.getPaint().getFontMetricsInt();
        int i2 = textView.getIncludeFontPadding() ? fontMetricsInt.bottom : fontMetricsInt.descent;
        if (i > Math.abs(i2)) {
            textView.setPadding(textView.getPaddingLeft(), textView.getPaddingTop(), textView.getPaddingRight(), i - i2);
        }
    }

    public static void c(TextView textView, int i) {
        a(i);
        if (i != textView.getPaint().getFontMetricsInt(null)) {
            textView.setLineSpacing(i - r0, 1.0f);
        }
    }

    public static boolean c(int i) {
        return i >= 28 && i <= 31;
    }

    public static m.a b(c.d.a.a.m1.t tVar) {
        tVar.f(1);
        int n = tVar.n();
        long j = tVar.f2479b + n;
        int i = n / 18;
        long[] jArr = new long[i];
        long[] jArr2 = new long[i];
        int i2 = 0;
        while (true) {
            if (i2 >= i) {
                break;
            }
            long i3 = tVar.i();
            if (i3 == -1) {
                jArr = Arrays.copyOf(jArr, i2);
                jArr2 = Arrays.copyOf(jArr2, i2);
                break;
            }
            jArr[i2] = i3;
            jArr2[i2] = tVar.i();
            tVar.f(2);
            i2++;
        }
        tVar.f((int) (j - tVar.f2479b));
        return new m.a(jArr, jArr2);
    }

    public static boolean a(File file, Resources resources, int i) {
        InputStream inputStream;
        try {
            inputStream = resources.openRawResource(i);
        } catch (Throwable th) {
            th = th;
            inputStream = null;
        }
        try {
            boolean a2 = a(file, inputStream);
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException unused) {
                }
            }
            return a2;
        } catch (Throwable th2) {
            th = th2;
            if (inputStream != null) {
                try {
                    inputStream.close();
                } catch (IOException unused2) {
                }
            }
            throw th;
        }
    }

    public static boolean a(File file, InputStream inputStream) {
        FileOutputStream fileOutputStream;
        StrictMode.ThreadPolicy allowThreadDiskWrites = StrictMode.allowThreadDiskWrites();
        FileOutputStream fileOutputStream2 = null;
        try {
            try {
                fileOutputStream = new FileOutputStream(file, false);
            } catch (IOException e2) {
                e = e2;
            }
        } catch (Throwable th) {
            th = th;
        }
        try {
            byte[] bArr = new byte[1024];
            while (true) {
                int read = inputStream.read(bArr);
                if (read == -1) {
                    break;
                }
                fileOutputStream.write(bArr, 0, read);
            }
            try {
                fileOutputStream.close();
            } catch (IOException unused) {
            }
            StrictMode.setThreadPolicy(allowThreadDiskWrites);
            return true;
        } catch (IOException e3) {
            e = e3;
            fileOutputStream2 = fileOutputStream;
            Log.e("TypefaceCompatUtil", "Error copying resource contents to temp file: " + e.getMessage());
            if (fileOutputStream2 != null) {
                try {
                    fileOutputStream2.close();
                } catch (IOException unused2) {
                }
            }
            StrictMode.setThreadPolicy(allowThreadDiskWrites);
            return false;
        } catch (Throwable th2) {
            th = th2;
            fileOutputStream2 = fileOutputStream;
            if (fileOutputStream2 != null) {
                try {
                    fileOutputStream2.close();
                } catch (IOException unused3) {
                }
            }
            StrictMode.setThreadPolicy(allowThreadDiskWrites);
            throw th;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:0x033d, code lost:
    
        if (r2.hasNext() == false) goto L180;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x033f, code lost:
    
        r1[r3] = (android.animation.Animator) r2.next();
        r3 = r3 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x034b, code lost:
    
        if (r28 != 0) goto L171;
     */
    /* JADX WARN: Code restructure failed: missing block: B:15:0x034d, code lost:
    
        r27.playTogether(r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0351, code lost:
    
        r27.playSequentially(r1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0354, code lost:
    
        return r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:7:0x032a, code lost:
    
        if (r27 == null) goto L172;
     */
    /* JADX WARN: Code restructure failed: missing block: B:8:0x032c, code lost:
    
        if (r13 == null) goto L172;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x032e, code lost:
    
        r1 = new android.animation.Animator[r13.size()];
        r2 = r13.iterator();
        r3 = 0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0303  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static android.animation.Animator a(android.content.Context r22, android.content.res.Resources r23, android.content.res.Resources.Theme r24, org.xmlpull.v1.XmlPullParser r25, android.util.AttributeSet r26, android.animation.AnimatorSet r27, int r28, float r29) {
        /*
            Method dump skipped, instructions count: 853
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a.a.a.a.a.a(android.content.Context, android.content.res.Resources, android.content.res.Resources$Theme, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.animation.AnimatorSet, int, float):android.animation.Animator");
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0082  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00c3  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00d5  */
    /* JADX WARN: Type inference failed for: r8v17, types: [java.lang.Object[], java.lang.Object] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static android.content.res.ColorStateList a(android.content.res.Resources r17, org.xmlpull.v1.XmlPullParser r18, android.util.AttributeSet r19, android.content.res.Resources.Theme r20) {
        /*
            Method dump skipped, instructions count: 293
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a.a.a.a.a.a(android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):android.content.res.ColorStateList");
    }

    /* JADX WARN: Code restructure failed: missing block: B:55:0x008b, code lost:
    
        if (r13 == false) goto L42;
     */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0048  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0098 A[Catch: NumberFormatException -> 0x00ba, LOOP:3: B:29:0x006d->B:40:0x0098, LOOP_END, TryCatch #0 {NumberFormatException -> 0x00ba, blocks: (B:26:0x005a, B:29:0x006d, B:31:0x0073, B:36:0x0081, B:40:0x0098, B:44:0x009d, B:49:0x00ad, B:61:0x00b2), top: B:25:0x005a }] */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0097 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x009d A[Catch: NumberFormatException -> 0x00ba, TryCatch #0 {NumberFormatException -> 0x00ba, blocks: (B:26:0x005a, B:29:0x006d, B:31:0x0073, B:36:0x0081, B:40:0x0098, B:44:0x009d, B:49:0x00ad, B:61:0x00b2), top: B:25:0x005a }] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00ac  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00ad A[Catch: NumberFormatException -> 0x00ba, TryCatch #0 {NumberFormatException -> 0x00ba, blocks: (B:26:0x005a, B:29:0x006d, B:31:0x0073, B:36:0x0081, B:40:0x0098, B:44:0x009d, B:49:0x00ad, B:61:0x00b2), top: B:25:0x005a }] */
    /* JADX WARN: Removed duplicated region for block: B:71:0x00d7 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static b.d.f.b[] a(java.lang.String r16) {
        /*
            Method dump skipped, instructions count: 272
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: a.a.a.a.a.a(java.lang.String):b.d.f.b[]");
    }

    public static b.d.e.b.a a(TypedArray typedArray, XmlPullParser xmlPullParser, Resources.Theme theme, String str, int i, int i2) {
        b.d.e.b.a aVar;
        if (a(xmlPullParser, str)) {
            TypedValue typedValue = new TypedValue();
            typedArray.getValue(i, typedValue);
            int i3 = typedValue.type;
            if (i3 >= 28 && i3 <= 31) {
                return new b.d.e.b.a(null, null, typedValue.data);
            }
            try {
                aVar = b.d.e.b.a.a(typedArray.getResources(), typedArray.getResourceId(i, 0), theme);
            } catch (Exception e2) {
                Log.e("ComplexColorCompat", "Failed to inflate ComplexColor.", e2);
                aVar = null;
            }
            if (aVar != null) {
                return aVar;
            }
        }
        return new b.d.e.b.a(null, null, i2);
    }

    public static PropertyValuesHolder a(TypedArray typedArray, int i, int i2, int i3, String str) {
        PropertyValuesHolder ofInt;
        PropertyValuesHolder ofObject;
        TypedValue peekValue = typedArray.peekValue(i2);
        boolean z = peekValue != null;
        int i4 = z ? peekValue.type : 0;
        TypedValue peekValue2 = typedArray.peekValue(i3);
        boolean z2 = peekValue2 != null;
        int i5 = z2 ? peekValue2.type : 0;
        if (i == 4) {
            i = ((z && c(i4)) || (z2 && c(i5))) ? 3 : 0;
        }
        boolean z3 = i == 0;
        PropertyValuesHolder propertyValuesHolder = null;
        if (i != 2) {
            e eVar = i == 3 ? e.f898a : null;
            if (z3) {
                if (z) {
                    float dimension = i4 == 5 ? typedArray.getDimension(i2, 0.0f) : typedArray.getFloat(i2, 0.0f);
                    if (z2) {
                        ofInt = PropertyValuesHolder.ofFloat(str, dimension, i5 == 5 ? typedArray.getDimension(i3, 0.0f) : typedArray.getFloat(i3, 0.0f));
                    } else {
                        ofInt = PropertyValuesHolder.ofFloat(str, dimension);
                    }
                } else {
                    ofInt = PropertyValuesHolder.ofFloat(str, i5 == 5 ? typedArray.getDimension(i3, 0.0f) : typedArray.getFloat(i3, 0.0f));
                }
            } else {
                if (!z) {
                    if (z2) {
                        ofInt = PropertyValuesHolder.ofInt(str, i5 == 5 ? (int) typedArray.getDimension(i3, 0.0f) : c(i5) ? typedArray.getColor(i3, 0) : typedArray.getInt(i3, 0));
                    }
                    if (propertyValuesHolder == null && eVar != null) {
                        propertyValuesHolder.setEvaluator(eVar);
                        return propertyValuesHolder;
                    }
                }
                int dimension2 = i4 == 5 ? (int) typedArray.getDimension(i2, 0.0f) : c(i4) ? typedArray.getColor(i2, 0) : typedArray.getInt(i2, 0);
                if (z2) {
                    ofInt = PropertyValuesHolder.ofInt(str, dimension2, i5 == 5 ? (int) typedArray.getDimension(i3, 0.0f) : c(i5) ? typedArray.getColor(i3, 0) : typedArray.getInt(i3, 0));
                } else {
                    ofInt = PropertyValuesHolder.ofInt(str, dimension2);
                }
            }
            propertyValuesHolder = ofInt;
            return propertyValuesHolder == null ? propertyValuesHolder : propertyValuesHolder;
        }
        String string = typedArray.getString(i2);
        String string2 = typedArray.getString(i3);
        b[] a2 = a(string);
        b[] a3 = a(string2);
        if (a2 == null && a3 == null) {
            return null;
        }
        if (a2 == null) {
            if (a3 != null) {
                return PropertyValuesHolder.ofObject(str, new b.k.a.a.d(), a3);
            }
            return null;
        }
        b.k.a.a.d dVar = new b.k.a.a.d();
        if (a3 == null) {
            ofObject = PropertyValuesHolder.ofObject(str, dVar, a2);
        } else {
            if (!a(a2, a3)) {
                throw new InflateException(" Can't morph from " + string + " to " + string2);
            }
            ofObject = PropertyValuesHolder.ofObject(str, dVar, a2, a3);
        }
        return ofObject;
    }

    /* JADX WARN: Code restructure failed: missing block: B:24:0x0065, code lost:
    
        if (r8 != 2) goto L15;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0076, code lost:
    
        if (r3 != false) goto L31;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static b.d.i.a.C0017a a(android.widget.TextView r8) {
        /*
            int r0 = android.os.Build.VERSION.SDK_INT
            r1 = 28
            if (r0 < r1) goto L10
            b.d.i.a$a r0 = new b.d.i.a$a
            android.text.PrecomputedText$Params r8 = r8.getTextMetricsParams()
            r0.<init>(r8)
            return r0
        L10:
            android.text.TextPaint r0 = new android.text.TextPaint
            android.text.TextPaint r2 = r8.getPaint()
            r0.<init>(r2)
            int r2 = android.os.Build.VERSION.SDK_INT
            r3 = 0
            r4 = 23
            r5 = 1
            if (r2 < r4) goto L24
            r2 = 1
            r6 = 1
            goto L26
        L24:
            r2 = 0
            r6 = 0
        L26:
            android.text.TextDirectionHeuristic r7 = android.text.TextDirectionHeuristics.FIRSTSTRONG_LTR
            int r7 = android.os.Build.VERSION.SDK_INT
            if (r7 < r4) goto L34
            int r2 = r8.getBreakStrategy()
            int r6 = r8.getHyphenationFrequency()
        L34:
            android.text.method.TransformationMethod r4 = r8.getTransformationMethod()
            boolean r4 = r4 instanceof android.text.method.PasswordTransformationMethod
            if (r4 == 0) goto L3f
        L3c:
            android.text.TextDirectionHeuristic r8 = android.text.TextDirectionHeuristics.LTR
            goto L86
        L3f:
            int r4 = android.os.Build.VERSION.SDK_INT
            if (r4 < r1) goto L68
            int r1 = r8.getInputType()
            r1 = r1 & 15
            r4 = 3
            if (r1 != r4) goto L68
            java.util.Locale r8 = r8.getTextLocale()
            android.icu.text.DecimalFormatSymbols r8 = android.icu.text.DecimalFormatSymbols.getInstance(r8)
            java.lang.String[] r8 = r8.getDigitStrings()
            r8 = r8[r3]
            int r8 = r8.codePointAt(r3)
            byte r8 = java.lang.Character.getDirectionality(r8)
            if (r8 == r5) goto L7e
            r1 = 2
            if (r8 != r1) goto L3c
            goto L7e
        L68:
            int r1 = r8.getLayoutDirection()
            if (r1 != r5) goto L6f
            r3 = 1
        L6f:
            int r8 = r8.getTextDirection()
            switch(r8) {
                case 2: goto L81;
                case 3: goto L3c;
                case 4: goto L7e;
                case 5: goto L7b;
                case 6: goto L84;
                case 7: goto L78;
                default: goto L76;
            }
        L76:
            if (r3 == 0) goto L84
        L78:
            android.text.TextDirectionHeuristic r8 = android.text.TextDirectionHeuristics.FIRSTSTRONG_RTL
            goto L86
        L7b:
            android.text.TextDirectionHeuristic r8 = android.text.TextDirectionHeuristics.LOCALE
            goto L86
        L7e:
            android.text.TextDirectionHeuristic r8 = android.text.TextDirectionHeuristics.RTL
            goto L86
        L81:
            android.text.TextDirectionHeuristic r8 = android.text.TextDirectionHeuristics.ANYRTL_LTR
            goto L86
        L84:
            android.text.TextDirectionHeuristic r8 = android.text.TextDirectionHeuristics.FIRSTSTRONG_LTR
        L86:
            b.d.i.a$a r1 = new b.d.i.a$a
            r1.<init>(r0, r8, r2, r6)
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: a.a.a.a.a.a(android.widget.TextView):b.d.i.a$a");
    }

    public static ValueAnimator a(Context context, Resources resources, Resources.Theme theme, AttributeSet attributeSet, ValueAnimator valueAnimator, float f2, XmlPullParser xmlPullParser) {
        ValueAnimator valueAnimator2;
        TypedArray typedArray;
        TypedArray typedArray2;
        ValueAnimator valueAnimator3;
        TypedArray a2 = a(resources, theme, attributeSet, b.k.a.a.a.g);
        TypedArray a3 = a(resources, theme, attributeSet, b.k.a.a.a.k);
        ValueAnimator valueAnimator4 = valueAnimator == null ? new ValueAnimator() : valueAnimator;
        long b2 = b(a2, xmlPullParser, "duration", 1, 300);
        int i = 0;
        long b3 = b(a2, xmlPullParser, "startOffset", 2, 0);
        int b4 = b(a2, xmlPullParser, "valueType", 7, 4);
        if (a(xmlPullParser, "valueFrom") && a(xmlPullParser, "valueTo")) {
            if (b4 == 4) {
                TypedValue peekValue = a2.peekValue(5);
                boolean z = peekValue != null;
                int i2 = z ? peekValue.type : 0;
                TypedValue peekValue2 = a2.peekValue(6);
                boolean z2 = peekValue2 != null;
                b4 = ((z && c(i2)) || (z2 && c(z2 ? peekValue2.type : 0))) ? 3 : 0;
            }
            PropertyValuesHolder a4 = a(a2, b4, 5, 6, "");
            if (a4 != null) {
                valueAnimator4.setValues(a4);
            }
        }
        valueAnimator4.setDuration(b2);
        valueAnimator4.setStartDelay(b3);
        valueAnimator4.setRepeatCount(b(a2, xmlPullParser, "repeatCount", 3, 0));
        valueAnimator4.setRepeatMode(b(a2, xmlPullParser, "repeatMode", 4, 1));
        if (a3 != null) {
            ObjectAnimator objectAnimator = (ObjectAnimator) valueAnimator4;
            String a5 = a(a3, xmlPullParser, "pathData", 1);
            if (a5 != null) {
                String a6 = a(a3, xmlPullParser, "propertyXName", 2);
                String a7 = a(a3, xmlPullParser, "propertyYName", 3);
                if (a6 == null && a7 == null) {
                    throw new InflateException(a3.getPositionDescription() + " propertyXName or propertyYName is needed for PathData");
                }
                Path b5 = b(a5);
                float f3 = 0.5f * f2;
                PathMeasure pathMeasure = new PathMeasure(b5, false);
                ArrayList arrayList = new ArrayList();
                arrayList.add(Float.valueOf(0.0f));
                float f4 = 0.0f;
                do {
                    f4 += pathMeasure.getLength();
                    arrayList.add(Float.valueOf(f4));
                } while (pathMeasure.nextContour());
                PathMeasure pathMeasure2 = new PathMeasure(b5, false);
                int min = Math.min(100, ((int) (f4 / f3)) + 1);
                float[] fArr = new float[min];
                float[] fArr2 = new float[min];
                float[] fArr3 = new float[2];
                float f5 = f4 / (min - 1);
                valueAnimator2 = valueAnimator4;
                typedArray = a2;
                int i3 = 0;
                float f6 = 0.0f;
                while (true) {
                    if (i >= min) {
                        break;
                    }
                    int i4 = min;
                    pathMeasure2.getPosTan(f6 - ((Float) arrayList.get(i3)).floatValue(), fArr3, null);
                    fArr[i] = fArr3[0];
                    fArr2[i] = fArr3[1];
                    f6 += f5;
                    int i5 = i3 + 1;
                    if (i5 < arrayList.size() && f6 > ((Float) arrayList.get(i5)).floatValue()) {
                        pathMeasure2.nextContour();
                        i3 = i5;
                    }
                    i++;
                    min = i4;
                }
                PropertyValuesHolder ofFloat = a6 != null ? PropertyValuesHolder.ofFloat(a6, fArr) : null;
                PropertyValuesHolder ofFloat2 = a7 != null ? PropertyValuesHolder.ofFloat(a7, fArr2) : null;
                if (ofFloat == null) {
                    i = 0;
                    objectAnimator.setValues(ofFloat2);
                } else {
                    i = 0;
                    if (ofFloat2 == null) {
                        objectAnimator.setValues(ofFloat);
                    } else {
                        objectAnimator.setValues(ofFloat, ofFloat2);
                    }
                }
            } else {
                valueAnimator2 = valueAnimator4;
                typedArray = a2;
                objectAnimator.setPropertyName(a(a3, xmlPullParser, "propertyName", 0));
            }
        } else {
            valueAnimator2 = valueAnimator4;
            typedArray = a2;
        }
        if (a(xmlPullParser, "interpolator")) {
            typedArray2 = typedArray;
            i = typedArray2.getResourceId(i, i);
        } else {
            typedArray2 = typedArray;
        }
        if (i > 0) {
            valueAnimator3 = valueAnimator2;
            valueAnimator3.setInterpolator(AnimationUtils.loadInterpolator(context, i));
        } else {
            valueAnimator3 = valueAnimator2;
        }
        typedArray2.recycle();
        if (a3 != null) {
            a3.recycle();
        }
        return valueAnimator3;
    }

    public static b.d.e.b.b a(XmlPullParser xmlPullParser, Resources resources) {
        int next;
        do {
            next = xmlPullParser.next();
            if (next == 2) {
                break;
            }
        } while (next != 1);
        if (next == 2) {
            xmlPullParser.require(2, null, "font-family");
            if (xmlPullParser.getName().equals("font-family")) {
                TypedArray obtainAttributes = resources.obtainAttributes(Xml.asAttributeSet(xmlPullParser), c.FontFamily);
                String string = obtainAttributes.getString(c.FontFamily_fontProviderAuthority);
                String string2 = obtainAttributes.getString(c.FontFamily_fontProviderPackage);
                String string3 = obtainAttributes.getString(c.FontFamily_fontProviderQuery);
                int resourceId = obtainAttributes.getResourceId(c.FontFamily_fontProviderCerts, 0);
                int integer = obtainAttributes.getInteger(c.FontFamily_fontProviderFetchStrategy, 1);
                int integer2 = obtainAttributes.getInteger(c.FontFamily_fontProviderFetchTimeout, 500);
                obtainAttributes.recycle();
                if (string != null && string2 != null && string3 != null) {
                    while (xmlPullParser.next() != 3) {
                        a(xmlPullParser);
                    }
                    return new b.d.e.b.e(new b.d.h.a(string, string2, string3, a(resources, resourceId)), integer, integer2);
                }
                ArrayList arrayList = new ArrayList();
                while (xmlPullParser.next() != 3) {
                    if (xmlPullParser.getEventType() == 2) {
                        if (xmlPullParser.getName().equals("font")) {
                            TypedArray obtainAttributes2 = resources.obtainAttributes(Xml.asAttributeSet(xmlPullParser), c.FontFamilyFont);
                            int i = obtainAttributes2.getInt(obtainAttributes2.hasValue(c.FontFamilyFont_fontWeight) ? c.FontFamilyFont_fontWeight : c.FontFamilyFont_android_fontWeight, 400);
                            boolean z = 1 == obtainAttributes2.getInt(obtainAttributes2.hasValue(c.FontFamilyFont_fontStyle) ? c.FontFamilyFont_fontStyle : c.FontFamilyFont_android_fontStyle, 0);
                            int i2 = obtainAttributes2.hasValue(c.FontFamilyFont_ttcIndex) ? c.FontFamilyFont_ttcIndex : c.FontFamilyFont_android_ttcIndex;
                            String string4 = obtainAttributes2.getString(obtainAttributes2.hasValue(c.FontFamilyFont_fontVariationSettings) ? c.FontFamilyFont_fontVariationSettings : c.FontFamilyFont_android_fontVariationSettings);
                            int i3 = obtainAttributes2.getInt(i2, 0);
                            int i4 = obtainAttributes2.hasValue(c.FontFamilyFont_font) ? c.FontFamilyFont_font : c.FontFamilyFont_android_font;
                            int resourceId2 = obtainAttributes2.getResourceId(i4, 0);
                            String string5 = obtainAttributes2.getString(i4);
                            obtainAttributes2.recycle();
                            while (xmlPullParser.next() != 3) {
                                a(xmlPullParser);
                            }
                            arrayList.add(new b.d.e.b.d(string5, i, z, string4, i3, resourceId2));
                        } else {
                            a(xmlPullParser);
                        }
                    }
                }
                if (arrayList.isEmpty()) {
                    return null;
                }
                return new b.d.e.b.c((b.d.e.b.d[]) arrayList.toArray(new b.d.e.b.d[arrayList.size()]));
            }
            a(xmlPullParser);
            return null;
        }
        throw new XmlPullParserException("No start tag found");
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0074 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0075  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static java.util.UUID a(byte[] r9) {
        /*
            c.d.a.a.m1.t r0 = new c.d.a.a.m1.t
            r0.<init>(r9)
            int r9 = r0.f2480c
            r1 = 32
            r2 = 0
            if (r9 >= r1) goto Ld
            goto L5d
        Ld:
            r9 = 0
            r0.e(r9)
            int r1 = r0.c()
            int r3 = r0.a()
            int r3 = r3 + 4
            if (r1 == r3) goto L1e
            goto L5d
        L1e:
            int r1 = r0.c()
            r3 = 1886614376(0x70737368, float:3.013775E29)
            if (r1 == r3) goto L28
            goto L5d
        L28:
            int r1 = r0.c()
            int r1 = r1 >> 24
            r1 = r1 & 255(0xff, float:3.57E-43)
            r3 = 1
            if (r1 <= r3) goto L3b
            java.lang.String r9 = "Unsupported pssh version: "
            java.lang.String r0 = "PsshAtomUtil"
            c.a.b.a.a.a(r9, r1, r0)
            goto L5d
        L3b:
            java.util.UUID r4 = new java.util.UUID
            long r5 = r0.i()
            long r7 = r0.i()
            r4.<init>(r5, r7)
            if (r1 != r3) goto L53
            int r3 = r0.o()
            int r3 = r3 * 16
            r0.f(r3)
        L53:
            int r3 = r0.o()
            int r5 = r0.a()
            if (r3 == r5) goto L5f
        L5d:
            r9 = r2
            goto L72
        L5f:
            byte[] r5 = new byte[r3]
            byte[] r6 = r0.f2478a
            int r7 = r0.f2479b
            java.lang.System.arraycopy(r6, r7, r5, r9, r3)
            int r9 = r0.f2479b
            int r9 = r9 + r3
            r0.f2479b = r9
            c.d.a.a.e1.c0.h r9 = new c.d.a.a.e1.c0.h
            r9.<init>(r4, r1, r5)
        L72:
            if (r9 != 0) goto L75
            return r2
        L75:
            java.util.UUID r9 = r9.f1436a
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: a.a.a.a.a.a(byte[]):java.util.UUID");
    }

    public static c.d.a.a.e1.g0.b a(c.d.a.a.e1.e eVar) {
        c.d.a.a.e1.g0.c a2;
        byte[] bArr;
        if (eVar == null) {
            throw null;
        }
        c.d.a.a.m1.t tVar = new c.d.a.a.m1.t(16);
        if (c.d.a.a.e1.g0.c.a(eVar, tVar).f1645a != 1380533830) {
            return null;
        }
        eVar.a(tVar.f2478a, 0, 4, false);
        tVar.e(0);
        int c2 = tVar.c();
        if (c2 != 1463899717) {
            Log.e("WavHeaderReader", "Unsupported RIFF format: " + c2);
            return null;
        }
        while (true) {
            a2 = c.d.a.a.e1.g0.c.a(eVar, tVar);
            if (a2.f1645a == 1718449184) {
                break;
            }
            eVar.a((int) a2.f1646b, false);
        }
        c.d.a.a.m1.e.b(a2.f1646b >= 16);
        eVar.a(tVar.f2478a, 0, 16, false);
        tVar.e(0);
        int h = tVar.h();
        int h2 = tVar.h();
        int g = tVar.g();
        int g2 = tVar.g();
        int h3 = tVar.h();
        int h4 = tVar.h();
        int i = ((int) a2.f1646b) - 16;
        if (i > 0) {
            byte[] bArr2 = new byte[i];
            eVar.a(bArr2, 0, i, false);
            bArr = bArr2;
        } else {
            bArr = c0.f;
        }
        return new c.d.a.a.e1.g0.b(h, h2, g, g2, h3, h4, bArr);
    }

    public static c.d.a.a.g1.a a(c.d.a.a.e1.e eVar, boolean z) {
        h.a aVar = z ? null : h.f1770b;
        c.d.a.a.m1.t tVar = new c.d.a.a.m1.t(10);
        c.d.a.a.g1.a aVar2 = null;
        int i = 0;
        while (true) {
            try {
                eVar.a(tVar.f2478a, 0, 10, false);
                tVar.e(0);
                if (tVar.n() != 4801587) {
                    break;
                }
                tVar.f(3);
                int k = tVar.k();
                int i2 = k + 10;
                if (aVar2 == null) {
                    byte[] bArr = new byte[i2];
                    System.arraycopy(tVar.f2478a, 0, bArr, 0, 10);
                    eVar.a(bArr, 10, k, false);
                    aVar2 = new h(aVar).a(bArr, i2);
                } else {
                    eVar.a(k, false);
                }
                i += i2;
            } catch (EOFException unused) {
            }
        }
        eVar.f = 0;
        eVar.a(i, false);
        if (aVar2 == null || aVar2.f1737b.length == 0) {
            return null;
        }
        return aVar2;
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x003a A[EDGE_INSN: B:10:0x003a->B:11:0x003a BREAK  A[LOOP:0: B:2:0x0001->B:9:0x0038], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0038 A[LOOP:0: B:2:0x0001->B:9:0x0038, LOOP_END] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static int a(c.d.a.a.e1.e r9, byte[] r10, int r11, int r12) {
        /*
            r0 = 0
        L1:
            if (r0 >= r12) goto L3a
            int r1 = r11 + r0
            int r5 = r12 - r0
            r9.b(r5)
            int r2 = r9.g
            int r4 = r9.f
            int r2 = r2 - r4
            r8 = -1
            if (r2 != 0) goto L25
            byte[] r3 = r9.e
            r6 = 0
            r7 = 1
            r2 = r9
            int r2 = r2.a(r3, r4, r5, r6, r7)
            if (r2 != r8) goto L1f
            r2 = -1
            goto L35
        L1f:
            int r3 = r9.g
            int r3 = r3 + r2
            r9.g = r3
            goto L29
        L25:
            int r2 = java.lang.Math.min(r5, r2)
        L29:
            byte[] r3 = r9.e
            int r4 = r9.f
            java.lang.System.arraycopy(r3, r4, r10, r1, r2)
            int r1 = r9.f
            int r1 = r1 + r2
            r9.f = r1
        L35:
            if (r2 != r8) goto L38
            goto L3a
        L38:
            int r0 = r0 + r2
            goto L1
        L3a:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: a.a.a.a.a.a(c.d.a.a.e1.e, byte[], int, int):int");
    }

    public static ArrayList<c.c.a.a.h.b> a(ArrayList<c.c.a.a.h.b> arrayList, File file, c.c.a.a.i.a aVar) {
        try {
            for (File file2 : file.listFiles(aVar)) {
                if (file2.canRead()) {
                    c.c.a.a.h.b bVar = new c.c.a.a.h.b();
                    bVar.f1151b = file2.getName();
                    bVar.f1153d = file2.isDirectory();
                    bVar.f1152c = file2.getAbsolutePath();
                    bVar.f = file2.lastModified();
                    arrayList.add(bVar);
                }
            }
            Collections.sort(arrayList);
            return arrayList;
        } catch (NullPointerException e2) {
            e2.printStackTrace();
            return new ArrayList<>();
        }
    }

    public static List<List<byte[]>> a(Resources resources, int i) {
        if (i == 0) {
            return Collections.emptyList();
        }
        TypedArray obtainTypedArray = resources.obtainTypedArray(i);
        try {
            if (obtainTypedArray.length() == 0) {
                return Collections.emptyList();
            }
            ArrayList arrayList = new ArrayList();
            if (obtainTypedArray.getType(0) == 1) {
                for (int i2 = 0; i2 < obtainTypedArray.length(); i2++) {
                    int resourceId = obtainTypedArray.getResourceId(i2, 0);
                    if (resourceId != 0) {
                        arrayList.add(a(resources.getStringArray(resourceId)));
                    }
                }
            } else {
                arrayList.add(a(resources.getStringArray(i)));
            }
            return arrayList;
        } finally {
            obtainTypedArray.recycle();
        }
    }

    public static long a(c.d.a.a.m1.t tVar, int i, int i2) {
        tVar.e(i);
        if (tVar.a() < 5) {
            return -9223372036854775807L;
        }
        int c2 = tVar.c();
        if ((8388608 & c2) != 0 || ((2096896 & c2) >> 8) != i2) {
            return -9223372036854775807L;
        }
        if (((c2 & 32) != 0) && tVar.l() >= 7 && tVar.a() >= 7) {
            if ((tVar.l() & 16) == 16) {
                System.arraycopy(tVar.f2478a, tVar.f2479b, new byte[6], 0, 6);
                tVar.f2479b += 6;
                return ((r0[0] & 255) << 25) | ((r0[1] & 255) << 17) | ((r0[2] & 255) << 9) | ((r0[3] & 255) << 1) | ((r0[4] & 255) >> 7);
            }
        }
        return -9223372036854775807L;
    }

    public static void a(TextView textView, b.d.i.a aVar) {
        a.C0017a a2 = a(textView);
        if (aVar == null) {
            throw null;
        }
        if (!a2.a(null)) {
            throw new IllegalArgumentException("Given text can not be applied to TextView.");
        }
        textView.setText(aVar);
    }

    public static void a(View view, CharSequence charSequence) {
        if (Build.VERSION.SDK_INT >= 26) {
            view.setTooltipText(charSequence);
            return;
        }
        m0 m0Var = m0.k;
        if (m0Var != null && m0Var.f434b == view) {
            m0.a((m0) null);
        }
        if (!TextUtils.isEmpty(charSequence)) {
            new m0(view, charSequence);
            return;
        }
        m0 m0Var2 = m0.l;
        if (m0Var2 != null && m0Var2.f434b == view) {
            m0Var2.b();
        }
        view.setOnLongClickListener(null);
        view.setLongClickable(false);
        view.setOnHoverListener(null);
    }
}
