package a.a.a.b;

import a.a.a.b.a;
import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;

@SuppressLint({"BanParcelableUsage"})
/* loaded from: classes.dex */
public class b implements Parcelable {
    public static final Parcelable.Creator<b> CREATOR = new a();

    /* renamed from: b, reason: collision with root package name */
    public final Handler f5b = null;

    /* renamed from: c, reason: collision with root package name */
    public a.a.a.b.a f6c;

    /* loaded from: classes.dex */
    public static class a implements Parcelable.Creator<b> {
        @Override // android.os.Parcelable.Creator
        public b createFromParcel(Parcel parcel) {
            return new b(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public b[] newArray(int i) {
            return new b[i];
        }
    }

    /* renamed from: a.a.a.b.b$b, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class BinderC0002b extends a.AbstractBinderC0000a {
        public BinderC0002b() {
        }

        @Override // a.a.a.b.a
        public void a(int i, Bundle bundle) {
            b bVar = b.this;
            Handler handler = bVar.f5b;
            if (handler != null) {
                handler.post(new c(i, bundle));
            } else {
                bVar.a(i, bundle);
            }
        }
    }

    /* loaded from: classes.dex */
    public class c implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public final int f8b;

        /* renamed from: c, reason: collision with root package name */
        public final Bundle f9c;

        public c(int i, Bundle bundle) {
            this.f8b = i;
            this.f9c = bundle;
        }

        @Override // java.lang.Runnable
        public void run() {
            b.this.a(this.f8b, this.f9c);
        }
    }

    public b(Parcel parcel) {
        this.f6c = a.AbstractBinderC0000a.a(parcel.readStrongBinder());
    }

    public void a(int i, Bundle bundle) {
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        synchronized (this) {
            if (this.f6c == null) {
                this.f6c = new BinderC0002b();
            }
            parcel.writeStrongBinder(this.f6c.asBinder());
        }
    }
}
