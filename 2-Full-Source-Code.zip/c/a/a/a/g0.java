package c.a.a.a;

import android.os.Bundle;
import c.a.a.a.f;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public final class g0 implements Callable<Void> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ g f956a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ h f957b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ c f958c;

    public g0(c cVar, g gVar, h hVar) {
        this.f958c = cVar;
        this.f956a = gVar;
        this.f957b = hVar;
    }

    @Override // java.util.concurrent.Callable
    public final /* synthetic */ Void call() {
        int b2;
        String str;
        c cVar = this.f958c;
        g gVar = this.f956a;
        h hVar = this.f957b;
        if (cVar == null) {
            throw null;
        }
        String str2 = gVar.f955a;
        try {
            String valueOf = String.valueOf(str2);
            c.d.a.b.a.a.b.a("BillingClient", valueOf.length() != 0 ? "Consuming purchase with token: ".concat(valueOf) : new String("Consuming purchase with token: "));
            if (cVar.l) {
                c.d.a.b.a.a.a aVar = cVar.f;
                String packageName = cVar.e.getPackageName();
                boolean z = cVar.l;
                String str3 = cVar.f932b;
                Bundle bundle = new Bundle();
                if (z) {
                    bundle.putString("playBillingLibraryVersion", str3);
                }
                Bundle b3 = aVar.b(9, packageName, str2, bundle);
                b2 = b3.getInt("RESPONSE_CODE");
                str = c.d.a.b.a.a.b.b(b3, "BillingClient");
            } else {
                b2 = cVar.f.b(3, cVar.e.getPackageName(), str2);
                str = "";
            }
            f.a a2 = f.a();
            a2.f951a = b2;
            a2.f952b = str;
            f a3 = a2.a();
            cVar.a(b2 == 0 ? new j0(hVar, a3, str2) : new i0(b2, hVar, a3, str2));
        } catch (Exception e) {
            cVar.a(new k0(e, hVar, str2));
        }
        return null;
    }
}
