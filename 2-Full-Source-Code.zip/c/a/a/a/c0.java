package c.a.a.a;

import android.os.Bundle;
import android.os.Handler;
import android.os.ResultReceiver;
import c.a.a.a.f;
import c.b.x0;
import java.util.List;

/* loaded from: classes.dex */
public final class c0 extends ResultReceiver {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ c f939b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c0(c cVar, Handler handler) {
        super(handler);
        this.f939b = cVar;
    }

    @Override // android.os.ResultReceiver
    public final void onReceiveResult(int i, Bundle bundle) {
        j jVar = this.f939b.f934d.f1003b.f924a;
        if (jVar == null) {
            c.d.a.b.a.a.b.b("BillingClient", "PurchasesUpdatedListener is null - no way to return the response.");
            return;
        }
        List<i> a2 = c.d.a.b.a.a.b.a(bundle);
        f.a a3 = f.a();
        a3.f951a = i;
        a3.f952b = c.d.a.b.a.a.b.b(bundle, "BillingClient");
        ((x0) jVar).a(a3.a(), a2);
    }
}
