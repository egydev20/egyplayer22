package c.a.a.a;

import c.b.a1;

/* loaded from: classes.dex */
public final class j0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ h f968b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ f f969c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ String f970d;

    public j0(h hVar, f fVar, String str) {
        this.f968b = hVar;
        this.f969c = fVar;
        this.f970d = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        c.d.a.b.a.a.b.a("BillingClient", "Successfully consumed purchase.");
        ((a1) this.f968b).a(this.f969c, this.f970d);
    }
}
