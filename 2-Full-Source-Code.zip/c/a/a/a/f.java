package c.a.a.a;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public int f950a;

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public int f951a;

        /* renamed from: b, reason: collision with root package name */
        public String f952b = "";

        public /* synthetic */ a(v vVar) {
        }

        public f a() {
            f fVar = new f();
            fVar.f950a = this.f951a;
            return fVar;
        }
    }

    public static a a() {
        return new a(null);
    }
}
