package c.a.a.a;

import c.b.y0;

/* loaded from: classes.dex */
public final class d0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ m f940b;

    public d0(m mVar) {
        this.f940b = mVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        m mVar = this.f940b;
        f fVar = w.k;
        ((y0) mVar).f1131a.f = null;
    }
}
