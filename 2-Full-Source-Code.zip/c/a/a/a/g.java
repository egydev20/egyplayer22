package c.a.a.a;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public String f955a;

    public /* synthetic */ g(x xVar) {
    }
}
