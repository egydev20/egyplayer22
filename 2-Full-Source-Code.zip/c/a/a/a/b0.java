package c.a.a.a;

import android.os.Bundle;
import c.a.a.a.k;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import org.json.JSONException;

/* loaded from: classes.dex */
public final class b0 implements Callable<Void> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f927a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ List f928b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f929c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ m f930d;
    public final /* synthetic */ c e;

    public b0(c cVar, String str, List list, String str2, m mVar) {
        this.e = cVar;
        this.f927a = str;
        this.f928b = list;
        this.f929c = str2;
        this.f930d = mVar;
    }

    @Override // java.util.concurrent.Callable
    public final /* synthetic */ Void call() {
        Void r4;
        k.a aVar;
        int i;
        Bundle a2;
        c cVar = this.e;
        String str = this.f927a;
        List list = this.f928b;
        String str2 = this.f929c;
        if (cVar != null) {
            ArrayList arrayList = new ArrayList();
            int size = list.size();
            int i2 = 0;
            while (true) {
                if (i2 >= size) {
                    r4 = null;
                    aVar = new k.a(0, "", arrayList);
                    break;
                }
                int i3 = i2 + 20;
                ArrayList<String> arrayList2 = new ArrayList<>(list.subList(i2, i3 > size ? size : i3));
                Bundle bundle = new Bundle();
                bundle.putStringArrayList("ITEM_ID_LIST", arrayList2);
                bundle.putString("playBillingLibraryVersion", cVar.f932b);
                try {
                    if (cVar.m) {
                        i = i3;
                        a2 = cVar.f.a(10, cVar.e.getPackageName(), str, bundle, c.d.a.b.a.a.b.a(cVar.l, cVar.o, cVar.p, cVar.f932b, str2));
                    } else {
                        i = i3;
                        a2 = cVar.f.a(3, cVar.e.getPackageName(), str, bundle);
                    }
                    if (a2 == null) {
                        c.d.a.b.a.a.b.b("BillingClient", "querySkuDetailsAsync got null sku details list");
                        r4 = null;
                        aVar = new k.a(4, "Null sku details list", null);
                        break;
                    }
                    if (a2.containsKey("DETAILS_LIST")) {
                        ArrayList<String> stringArrayList = a2.getStringArrayList("DETAILS_LIST");
                        if (stringArrayList == null) {
                            c.d.a.b.a.a.b.b("BillingClient", "querySkuDetailsAsync got null response list");
                            r4 = null;
                            aVar = new k.a(4, "querySkuDetailsAsync got null response list", null);
                            break;
                        }
                        for (int i4 = 0; i4 < stringArrayList.size(); i4++) {
                            try {
                                k kVar = new k(stringArrayList.get(i4));
                                String valueOf = String.valueOf(kVar);
                                StringBuilder sb = new StringBuilder(valueOf.length() + 17);
                                sb.append("Got sku details: ");
                                sb.append(valueOf);
                                c.d.a.b.a.a.b.a("BillingClient", sb.toString());
                                arrayList.add(kVar);
                            } catch (JSONException unused) {
                                c.d.a.b.a.a.b.b("BillingClient", "Got a JSON exception trying to decode SkuDetails.");
                                aVar = new k.a(6, "Error trying to decode SkuDetails.", null);
                                r4 = null;
                            }
                        }
                        i2 = i;
                    } else {
                        int a3 = c.d.a.b.a.a.b.a(a2, "BillingClient");
                        String b2 = c.d.a.b.a.a.b.b(a2, "BillingClient");
                        if (a3 != 0) {
                            StringBuilder sb2 = new StringBuilder(50);
                            sb2.append("getSkuDetails() failed. Response code: ");
                            sb2.append(a3);
                            c.d.a.b.a.a.b.b("BillingClient", sb2.toString());
                            aVar = new k.a(a3, b2, arrayList);
                        } else {
                            c.d.a.b.a.a.b.b("BillingClient", "getSkuDetails() returned a bundle with neither an error nor a detail list.");
                            aVar = new k.a(6, b2, arrayList);
                        }
                        r4 = null;
                    }
                } catch (Exception e) {
                    String valueOf2 = String.valueOf(e);
                    StringBuilder sb3 = new StringBuilder(valueOf2.length() + 63);
                    sb3.append("querySkuDetailsAsync got a remote exception (try to reconnect).");
                    sb3.append(valueOf2);
                    c.d.a.b.a.a.b.b("BillingClient", sb3.toString());
                    r4 = null;
                    aVar = new k.a(-1, "Service connection is disconnected.", null);
                }
            }
            this.e.a(new e0(this, aVar));
            return r4;
        }
        throw null;
    }
}
