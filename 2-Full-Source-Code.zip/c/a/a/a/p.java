package c.a.a.a;

import c.a.a.a.i;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public final class p implements Callable<i.a> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ String f989a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ c f990b;

    public p(c cVar, String str) {
        this.f990b = cVar;
        this.f989a = str;
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x0112  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x010a A[SYNTHETIC] */
    @Override // java.util.concurrent.Callable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final /* synthetic */ c.a.a.a.i.a call() {
        /*
            Method dump skipped, instructions count: 497
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.a.a.a.p.call():java.lang.Object");
    }
}
