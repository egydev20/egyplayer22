package c.a.a.a;

import c.a.a.a.f;

/* loaded from: classes.dex */
public final class w {

    /* renamed from: a, reason: collision with root package name */
    public static final f f998a;

    /* renamed from: b, reason: collision with root package name */
    public static final f f999b;

    /* renamed from: c, reason: collision with root package name */
    public static final f f1000c;

    /* renamed from: d, reason: collision with root package name */
    public static final f f1001d;
    public static final f e;
    public static final f f;
    public static final f g;
    public static final f h;
    public static final f i;
    public static final f j;
    public static final f k;
    public static final f l;
    public static final f m;

    static {
        f.a a2 = f.a();
        a2.f951a = 3;
        a2.f952b = "Google Play In-app Billing API version is less than 3";
        f998a = a2.a();
        f.a a3 = f.a();
        a3.f951a = 3;
        a3.f952b = "Google Play In-app Billing API version is less than 9";
        a3.a();
        f.a a4 = f.a();
        a4.f951a = 3;
        a4.f952b = "Billing service unavailable on device.";
        f999b = a4.a();
        f.a a5 = f.a();
        a5.f951a = 5;
        a5.f952b = "Client is already in the process of connecting to billing service.";
        f1000c = a5.a();
        f.a a6 = f.a();
        a6.f951a = 3;
        a6.f952b = "Play Store version installed does not support cross selling products.";
        f1001d = a6.a();
        f.a a7 = f.a();
        a7.f951a = 5;
        a7.f952b = "The list of SKUs can't be empty.";
        e = a7.a();
        f.a a8 = f.a();
        a8.f951a = 5;
        a8.f952b = "SKU type can't be empty.";
        f = a8.a();
        f.a a9 = f.a();
        a9.f951a = -2;
        a9.f952b = "Client does not support extra params.";
        g = a9.a();
        f.a a10 = f.a();
        a10.f951a = -2;
        a10.f952b = "Client does not support the feature.";
        a10.a();
        f.a a11 = f.a();
        a11.f951a = -2;
        a11.f952b = "Client does not support get purchase history.";
        a11.a();
        f.a a12 = f.a();
        a12.f951a = 5;
        a12.f952b = "Invalid purchase token.";
        a12.a();
        f.a a13 = f.a();
        a13.f951a = 6;
        a13.f952b = "An internal error occurred.";
        h = a13.a();
        f.a a14 = f.a();
        a14.f951a = 4;
        a14.f952b = "Item is unavailable for purchase.";
        a14.a();
        f.a a15 = f.a();
        a15.f951a = 5;
        a15.f952b = "SKU can't be null.";
        a15.a();
        f.a a16 = f.a();
        a16.f951a = 5;
        a16.f952b = "SKU type can't be null.";
        a16.a();
        f.a a17 = f.a();
        a17.f951a = 0;
        i = a17.a();
        f.a a18 = f.a();
        a18.f951a = -1;
        a18.f952b = "Service connection is disconnected.";
        j = a18.a();
        f.a a19 = f.a();
        a19.f951a = -3;
        a19.f952b = "Timeout communicating with service.";
        k = a19.a();
        f.a a20 = f.a();
        a20.f951a = -2;
        a20.f952b = "Client doesn't support subscriptions.";
        l = a20.a();
        f.a a21 = f.a();
        a21.f951a = -2;
        a21.f952b = "Client doesn't support subscriptions update.";
        m = a21.a();
        f.a a22 = f.a();
        a22.f951a = 5;
        a22.f952b = "Unknown feature";
        a22.a();
    }
}
