package c.a.a.a;

import c.a.a.a.c;
import c.b.x0;

/* loaded from: classes.dex */
public final class r implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ f f994b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ c.a f995c;

    public r(c.a aVar, f fVar) {
        this.f995c = aVar;
        this.f994b = fVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        synchronized (this.f995c.f935a) {
            if (this.f995c.f937c != null) {
                ((x0.a) this.f995c.f937c).a(this.f994b);
            }
        }
    }
}
