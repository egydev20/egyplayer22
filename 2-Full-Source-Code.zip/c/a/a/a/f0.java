package c.a.a.a;

import c.b.a1;

/* loaded from: classes.dex */
public final class f0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ h f953b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ g f954c;

    public f0(h hVar, g gVar) {
        this.f953b = hVar;
        this.f954c = gVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        ((a1) this.f953b).a(w.k, this.f954c.f955a);
    }
}
