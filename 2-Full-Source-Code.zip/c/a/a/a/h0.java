package c.a.a.a;

import java.util.concurrent.Future;

/* loaded from: classes.dex */
public final class h0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Future f959b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Runnable f960c;

    public h0(Future future, Runnable runnable) {
        this.f959b = future;
        this.f960c = runnable;
    }

    @Override // java.lang.Runnable
    public final void run() {
        if (this.f959b.isDone() || this.f959b.isCancelled()) {
            return;
        }
        this.f959b.cancel(true);
        c.d.a.b.a.a.b.b("BillingClient", "Async task is taking too long, cancel it!");
        Runnable runnable = this.f960c;
        if (runnable != null) {
            runnable.run();
        }
    }
}
