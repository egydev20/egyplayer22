package c.a.a.a;

import android.os.Bundle;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public final class q implements Callable<Bundle> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ k f991a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ String f992b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ c f993c;

    public q(c cVar, k kVar, String str) {
        this.f993c = cVar;
        this.f991a = kVar;
        this.f992b = str;
    }

    @Override // java.util.concurrent.Callable
    public final /* synthetic */ Bundle call() {
        c cVar = this.f993c;
        return cVar.f.a(3, cVar.e.getPackageName(), this.f991a.a(), this.f992b, (String) null);
    }
}
