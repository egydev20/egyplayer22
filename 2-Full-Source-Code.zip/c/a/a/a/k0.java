package c.a.a.a;

import c.b.a1;

/* loaded from: classes.dex */
public final class k0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Exception f976b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ h f977c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ String f978d;

    public k0(Exception exc, h hVar, String str) {
        this.f976b = exc;
        this.f977c = hVar;
        this.f978d = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        String valueOf = String.valueOf(this.f976b);
        StringBuilder sb = new StringBuilder(valueOf.length() + 30);
        sb.append("Error consuming purchase; ex: ");
        sb.append(valueOf);
        c.d.a.b.a.a.b.b("BillingClient", sb.toString());
        ((a1) this.f977c).a(w.j, this.f978d);
    }
}
