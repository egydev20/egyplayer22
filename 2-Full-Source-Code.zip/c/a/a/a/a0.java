package c.a.a.a;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import c.b.x0;

/* loaded from: classes.dex */
public final class a0 extends BroadcastReceiver {

    /* renamed from: a, reason: collision with root package name */
    public final j f924a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f925b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ z f926c;

    public /* synthetic */ a0(z zVar, j jVar, y yVar) {
        this.f926c = zVar;
        this.f924a = jVar;
    }

    @Override // android.content.BroadcastReceiver
    public final void onReceive(Context context, Intent intent) {
        ((x0) this.f924a).a(c.d.a.b.a.a.b.a(intent, "BillingBroadcastManager"), c.d.a.b.a.a.b.a(intent.getExtras()));
    }
}
