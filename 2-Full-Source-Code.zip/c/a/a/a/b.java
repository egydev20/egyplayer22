package c.a.a.a;

import android.app.Activity;
import c.a.a.a.i;

/* loaded from: classes.dex */
public abstract class b {
    public abstract f a(Activity activity, e eVar);

    public abstract i.a a(String str);

    public abstract void a(d dVar);

    public abstract void a(l lVar, m mVar);

    public abstract boolean a();
}
