package c.a.a.a;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.ResultReceiver;
import android.text.TextUtils;
import c.a.a.a.f;
import c.a.a.a.i;
import c.b.x0;
import c.b.y0;
import com.android.billingclient.api.ProxyBillingActivity;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

/* loaded from: classes.dex */
public class c extends b {

    /* renamed from: a, reason: collision with root package name */
    public int f931a;

    /* renamed from: b, reason: collision with root package name */
    public final String f932b;

    /* renamed from: c, reason: collision with root package name */
    public final Handler f933c;

    /* renamed from: d, reason: collision with root package name */
    public z f934d;
    public Context e;
    public c.d.a.b.a.a.a f;
    public a g;
    public boolean h;
    public boolean i;
    public boolean j;
    public boolean k;
    public boolean l;
    public boolean m;
    public boolean n;
    public boolean o;
    public boolean p;
    public ExecutorService q;
    public String r;
    public final ResultReceiver s;

    /* loaded from: classes.dex */
    public final class a implements ServiceConnection {

        /* renamed from: a, reason: collision with root package name */
        public final Object f935a = new Object();

        /* renamed from: b, reason: collision with root package name */
        public boolean f936b = false;

        /* renamed from: c, reason: collision with root package name */
        public d f937c;

        public /* synthetic */ a(d dVar, c0 c0Var) {
            this.f937c = dVar;
        }

        @Override // android.content.ServiceConnection
        public final void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            c.d.a.b.a.a.b.a("BillingClient", "Billing service connected.");
            c.this.f = c.d.a.b.a.a.d.a(iBinder);
            if (c.this.a(new t(this), 30000L, new s(this)) == null) {
                c.this.a(new r(this, c.this.b()));
            }
        }

        @Override // android.content.ServiceConnection
        public final void onServiceDisconnected(ComponentName componentName) {
            c.d.a.b.a.a.b.b("BillingClient", "Billing service disconnected.");
            c cVar = c.this;
            cVar.f = null;
            cVar.f931a = 0;
            synchronized (this.f935a) {
                if (this.f937c != null) {
                    x0.this.e = false;
                }
            }
        }
    }

    public c(boolean z, Context context, j jVar) {
        String str;
        try {
            str = (String) Class.forName("com.android.billingclient.ktx.BuildConfig").getField("VERSION_NAME").get(null);
        } catch (Exception unused) {
            str = "3.0.0";
        }
        this.f931a = 0;
        this.f933c = new Handler(Looper.getMainLooper());
        this.s = new c0(this, this.f933c);
        this.r = null;
        this.f932b = str;
        Context applicationContext = context.getApplicationContext();
        this.e = applicationContext;
        this.f934d = new z(applicationContext, jVar);
        this.p = z;
    }

    @Override // c.a.a.a.b
    public f a(Activity activity, e eVar) {
        f fVar;
        boolean z;
        long j;
        Future a2;
        int i;
        if (a()) {
            if (eVar != null) {
                ArrayList arrayList = new ArrayList();
                arrayList.addAll(eVar.g);
                k kVar = (k) arrayList.get(0);
                String b2 = kVar.b();
                if (!b2.equals("subs") || this.h) {
                    boolean z2 = eVar.f943c != null;
                    if (!z2 || this.i) {
                        ArrayList<k> arrayList2 = eVar.g;
                        int size = arrayList2.size();
                        int i2 = 0;
                        while (true) {
                            if (i2 >= size) {
                                z = true;
                                break;
                            }
                            k kVar2 = arrayList2.get(i2);
                            i2++;
                            if (kVar2.c().isEmpty()) {
                                z = false;
                                break;
                            }
                        }
                        if (!((!eVar.h && eVar.f942b == null && eVar.f941a == null && eVar.e == null && eVar.f == 0 && !z) ? false : true) || this.j) {
                            String str = "";
                            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                                String valueOf = String.valueOf(str);
                                String valueOf2 = String.valueOf(arrayList.get(i3));
                                StringBuilder sb = new StringBuilder(valueOf2.length() + valueOf.length());
                                sb.append(valueOf);
                                sb.append(valueOf2);
                                String sb2 = sb.toString();
                                if (i3 < arrayList.size() - 1) {
                                    sb2 = String.valueOf(sb2).concat(", ");
                                }
                                str = sb2;
                            }
                            StringBuilder sb3 = new StringBuilder(b2.length() + String.valueOf(str).length() + 41);
                            sb3.append("Constructing buy intent for ");
                            sb3.append(str);
                            sb3.append(", item type: ");
                            sb3.append(b2);
                            c.d.a.b.a.a.b.a("BillingClient", sb3.toString());
                            if (this.j) {
                                boolean z3 = this.l;
                                boolean z4 = this.p;
                                String str2 = this.f932b;
                                Bundle bundle = new Bundle();
                                bundle.putString("playBillingLibraryVersion", str2);
                                int i4 = eVar.f;
                                if (i4 != 0) {
                                    bundle.putInt("prorationMode", i4);
                                }
                                if (!TextUtils.isEmpty(eVar.f942b)) {
                                    bundle.putString("accountId", eVar.f942b);
                                }
                                if (!TextUtils.isEmpty(eVar.e)) {
                                    bundle.putString("obfuscatedProfileId", eVar.e);
                                }
                                if (eVar.h) {
                                    bundle.putBoolean("vr", true);
                                }
                                if (!TextUtils.isEmpty(eVar.f943c)) {
                                    bundle.putStringArrayList("skusToReplace", new ArrayList<>(Arrays.asList(eVar.f943c)));
                                }
                                if (!TextUtils.isEmpty(eVar.f944d)) {
                                    bundle.putString("oldSkuPurchaseToken", eVar.f944d);
                                }
                                if (z3 && z4) {
                                    bundle.putBoolean("enablePendingPurchases", true);
                                }
                                if (!kVar.f972b.optString("skuDetailsToken").isEmpty()) {
                                    bundle.putString("skuDetailsToken", kVar.f972b.optString("skuDetailsToken"));
                                }
                                if (!TextUtils.isEmpty(kVar.c())) {
                                    bundle.putString("skuPackageName", kVar.c());
                                }
                                if (!TextUtils.isEmpty(this.r)) {
                                    bundle.putString("accountName", this.r);
                                }
                                if (arrayList.size() > 1) {
                                    ArrayList<String> arrayList3 = new ArrayList<>(arrayList.size() - 1);
                                    for (int i5 = 1; i5 < arrayList.size(); i5++) {
                                        arrayList3.add(((k) arrayList.get(i5)).a());
                                    }
                                    bundle.putStringArrayList("additionalSkus", arrayList3);
                                }
                                if (this.l) {
                                    i = 9;
                                } else {
                                    i = eVar.h ? 7 : 6;
                                }
                                j = 5000;
                                a2 = a(new o(this, i, kVar, b2, eVar, bundle), 5000L, null);
                            } else {
                                j = 5000;
                                a2 = a(z2 ? new n(this, eVar, kVar) : new q(this, kVar, b2), 5000L, null);
                            }
                            try {
                                Bundle bundle2 = (Bundle) a2.get(j, TimeUnit.MILLISECONDS);
                                int a3 = c.d.a.b.a.a.b.a(bundle2, "BillingClient");
                                String b3 = c.d.a.b.a.a.b.b(bundle2, "BillingClient");
                                if (a3 == 0) {
                                    Intent intent = new Intent(activity, (Class<?>) ProxyBillingActivity.class);
                                    intent.putExtra("result_receiver", this.s);
                                    intent.putExtra("BUY_INTENT", (PendingIntent) bundle2.getParcelable("BUY_INTENT"));
                                    activity.startActivity(intent);
                                    return w.i;
                                }
                                StringBuilder sb4 = new StringBuilder(52);
                                sb4.append("Unable to buy item, Error response code: ");
                                sb4.append(a3);
                                c.d.a.b.a.a.b.b("BillingClient", sb4.toString());
                                f.a a4 = f.a();
                                a4.f951a = a3;
                                a4.f952b = b3;
                                f a5 = a4.a();
                                a(a5);
                                return a5;
                            } catch (CancellationException | TimeoutException unused) {
                                StringBuilder sb5 = new StringBuilder(String.valueOf(str).length() + 68);
                                sb5.append("Time out while launching billing flow: ; for sku: ");
                                sb5.append(str);
                                sb5.append("; try to reconnect");
                                c.d.a.b.a.a.b.b("BillingClient", sb5.toString());
                                fVar = w.k;
                            } catch (Exception unused2) {
                                StringBuilder sb6 = new StringBuilder(String.valueOf(str).length() + 69);
                                sb6.append("Exception while launching billing flow: ; for sku: ");
                                sb6.append(str);
                                sb6.append("; try to reconnect");
                                c.d.a.b.a.a.b.b("BillingClient", sb6.toString());
                            }
                        } else {
                            c.d.a.b.a.a.b.b("BillingClient", "Current client doesn't support extra params for buy intent.");
                            fVar = w.g;
                        }
                    } else {
                        c.d.a.b.a.a.b.b("BillingClient", "Current client doesn't support subscriptions update.");
                        fVar = w.m;
                    }
                } else {
                    c.d.a.b.a.a.b.b("BillingClient", "Current client doesn't support subscriptions.");
                    fVar = w.l;
                }
                a(fVar);
                return fVar;
            }
            throw null;
        }
        fVar = w.j;
        a(fVar);
        return fVar;
    }

    @Override // c.a.a.a.b
    public i.a a(String str) {
        if (!a()) {
            return new i.a(w.j, null);
        }
        if (TextUtils.isEmpty(str)) {
            c.d.a.b.a.a.b.b("BillingClient", "Please provide a valid SKU type.");
            return new i.a(w.f, null);
        }
        try {
            return (i.a) a(new p(this, str), 5000L, null).get(5000L, TimeUnit.MILLISECONDS);
        } catch (CancellationException | TimeoutException unused) {
            return new i.a(w.k, null);
        } catch (Exception unused2) {
            return new i.a(w.h, null);
        }
    }

    public final <T> Future<T> a(Callable<T> callable, long j, Runnable runnable) {
        long j2 = (long) (j * 0.95d);
        if (this.q == null) {
            this.q = Executors.newFixedThreadPool(c.d.a.b.a.a.b.f2639a);
        }
        try {
            Future<T> submit = this.q.submit(callable);
            this.f933c.postDelayed(new h0(submit, runnable), j2);
            return submit;
        } catch (Exception e) {
            String valueOf = String.valueOf(e);
            StringBuilder sb = new StringBuilder(valueOf.length() + 28);
            sb.append("Async task throws exception ");
            sb.append(valueOf);
            c.d.a.b.a.a.b.b("BillingClient", sb.toString());
            return null;
        }
    }

    public final void a(Runnable runnable) {
        if (Thread.interrupted()) {
            return;
        }
        this.f933c.post(runnable);
    }

    @Override // c.a.a.a.b
    public boolean a() {
        return (this.f931a != 2 || this.f == null || this.g == null) ? false : true;
    }

    public final f b() {
        int i = this.f931a;
        return (i == 0 || i == 3) ? w.j : w.h;
    }

    @Override // c.a.a.a.b
    public void a(l lVar, m mVar) {
        if (!a()) {
            f fVar = w.j;
            ((y0) mVar).f1131a.f = null;
            return;
        }
        String str = lVar.f979a;
        List<String> list = lVar.f981c;
        String str2 = lVar.f980b;
        if (TextUtils.isEmpty(str)) {
            c.d.a.b.a.a.b.b("BillingClient", "Please fix the input params. SKU type can't be empty.");
            f fVar2 = w.f;
            ((y0) mVar).f1131a.f = null;
            return;
        }
        if (list == null) {
            c.d.a.b.a.a.b.b("BillingClient", "Please fix the input params. The list of SKUs can't be empty.");
            f fVar3 = w.e;
            ((y0) mVar).f1131a.f = null;
        } else if (!this.o && str2 != null) {
            c.d.a.b.a.a.b.b("BillingClient", "The user's client is too old to handle skuPackageName from SkuDetails.");
            f fVar4 = w.f1001d;
            ((y0) mVar).f1131a.f = null;
        } else if (a(new b0(this, str, list, str2, mVar), 30000L, new d0(mVar)) == null) {
            b();
            ((y0) mVar).f1131a.f = null;
        }
    }

    @Override // c.a.a.a.b
    public void a(d dVar) {
        ServiceInfo serviceInfo;
        String str;
        if (a()) {
            c.d.a.b.a.a.b.a("BillingClient", "Service connection is valid. No need to re-initialize.");
            ((x0.a) dVar).a(w.i);
            return;
        }
        int i = this.f931a;
        if (i == 1) {
            c.d.a.b.a.a.b.b("BillingClient", "Client is already in the process of connecting to billing service.");
            ((x0.a) dVar).a(w.f1000c);
            return;
        }
        if (i == 3) {
            c.d.a.b.a.a.b.b("BillingClient", "Client was already closed and can't be reused. Please create another instance.");
            ((x0.a) dVar).a(w.j);
            return;
        }
        this.f931a = 1;
        z zVar = this.f934d;
        a0 a0Var = zVar.f1003b;
        Context context = zVar.f1002a;
        IntentFilter intentFilter = new IntentFilter("com.android.vending.billing.PURCHASES_UPDATED");
        if (!a0Var.f925b) {
            context.registerReceiver(a0Var.f926c.f1003b, intentFilter);
            a0Var.f925b = true;
        }
        c.d.a.b.a.a.b.a("BillingClient", "Starting in-app billing setup.");
        this.g = new a(dVar, null);
        Intent intent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
        intent.setPackage("com.android.vending");
        List<ResolveInfo> queryIntentServices = this.e.getPackageManager().queryIntentServices(intent, 0);
        if (queryIntentServices != null && !queryIntentServices.isEmpty() && (serviceInfo = queryIntentServices.get(0).serviceInfo) != null) {
            String str2 = serviceInfo.packageName;
            String str3 = serviceInfo.name;
            if (!"com.android.vending".equals(str2) || str3 == null) {
                str = "The device doesn't have valid Play Store.";
            } else {
                ComponentName componentName = new ComponentName(str2, str3);
                Intent intent2 = new Intent(intent);
                intent2.setComponent(componentName);
                intent2.putExtra("playBillingLibraryVersion", this.f932b);
                if (this.e.bindService(intent2, this.g, 1)) {
                    c.d.a.b.a.a.b.a("BillingClient", "Service was bonded successfully.");
                    return;
                }
                str = "Connection to Billing service is blocked.";
            }
            c.d.a.b.a.a.b.b("BillingClient", str);
        }
        this.f931a = 0;
        c.d.a.b.a.a.b.a("BillingClient", "Billing service unavailable on device.");
        ((x0.a) dVar).a(w.f999b);
    }

    public final f a(f fVar) {
        ((x0) this.f934d.f1003b.f924a).a(fVar, (List<i>) null);
        return fVar;
    }
}
