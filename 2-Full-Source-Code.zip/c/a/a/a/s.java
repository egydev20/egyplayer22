package c.a.a.a;

import c.a.a.a.c;

/* loaded from: classes.dex */
public final class s implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ c.a f996b;

    public s(c.a aVar) {
        this.f996b = aVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        c.a aVar = this.f996b;
        c cVar = c.this;
        cVar.f931a = 0;
        cVar.f = null;
        c.this.a(new r(aVar, w.k));
    }
}
