package c.a.a.a;

import c.b.a1;

/* loaded from: classes.dex */
public final class i0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f965b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ h f966c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ f f967d;
    public final /* synthetic */ String e;

    public i0(int i, h hVar, f fVar, String str) {
        this.f965b = i;
        this.f966c = hVar;
        this.f967d = fVar;
        this.e = str;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i = this.f965b;
        StringBuilder sb = new StringBuilder(63);
        sb.append("Error consuming purchase with token. Response code: ");
        sb.append(i);
        c.d.a.b.a.a.b.b("BillingClient", sb.toString());
        ((a1) this.f966c).a(this.f967d, this.e);
    }
}
