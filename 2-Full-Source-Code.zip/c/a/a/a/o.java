package c.a.a.a;

import android.os.Bundle;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public final class o implements Callable<Bundle> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f985a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ k f986b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f987c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ e f988d;
    public final /* synthetic */ Bundle e;
    public final /* synthetic */ c f;

    public o(c cVar, int i, k kVar, String str, e eVar, Bundle bundle) {
        this.f = cVar;
        this.f985a = i;
        this.f986b = kVar;
        this.f987c = str;
        this.f988d = eVar;
        this.e = bundle;
    }

    @Override // java.util.concurrent.Callable
    public final /* synthetic */ Bundle call() {
        c cVar = this.f;
        return cVar.f.a(this.f985a, cVar.e.getPackageName(), this.f986b.a(), this.f987c, this.f988d.f941a, this.e);
    }
}
