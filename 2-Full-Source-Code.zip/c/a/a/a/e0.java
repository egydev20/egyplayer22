package c.a.a.a;

import c.a.a.a.f;
import c.a.a.a.k;
import c.b.y0;

/* loaded from: classes.dex */
public final class e0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ k.a f948b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ b0 f949c;

    public e0(b0 b0Var, k.a aVar) {
        this.f949c = b0Var;
        this.f948b = aVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        m mVar = this.f949c.f930d;
        f.a a2 = f.a();
        k.a aVar = this.f948b;
        a2.f951a = aVar.f974b;
        a2.f952b = aVar.f975c;
        a2.a();
        ((y0) mVar).f1131a.f = this.f948b.f973a;
    }
}
