package c.a.a.a;

import android.text.TextUtils;
import java.util.List;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class i {

    /* renamed from: a, reason: collision with root package name */
    public final String f961a;

    /* renamed from: b, reason: collision with root package name */
    public final String f962b;

    /* renamed from: c, reason: collision with root package name */
    public final JSONObject f963c;

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public final List<i> f964a;

        public a(f fVar, List<i> list) {
            this.f964a = list;
        }
    }

    public i(String str, String str2) {
        this.f961a = str;
        this.f962b = str2;
        this.f963c = new JSONObject(this.f961a);
    }

    public int a() {
        return this.f963c.optInt("purchaseState", 1) != 4 ? 1 : 2;
    }

    public String b() {
        JSONObject jSONObject = this.f963c;
        return jSONObject.optString("token", jSONObject.optString("purchaseToken"));
    }

    public String c() {
        return this.f963c.optString("productId");
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i)) {
            return false;
        }
        i iVar = (i) obj;
        return TextUtils.equals(this.f961a, iVar.f961a) && TextUtils.equals(this.f962b, iVar.f962b);
    }

    public int hashCode() {
        return this.f961a.hashCode();
    }

    public String toString() {
        String valueOf = String.valueOf(this.f961a);
        return valueOf.length() != 0 ? "Purchase. Json: ".concat(valueOf) : new String("Purchase. Json: ");
    }
}
