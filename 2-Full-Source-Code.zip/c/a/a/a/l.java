package c.a.a.a;

import java.util.List;

/* loaded from: classes.dex */
public class l {

    /* renamed from: a, reason: collision with root package name */
    public String f979a;

    /* renamed from: b, reason: collision with root package name */
    public String f980b;

    /* renamed from: c, reason: collision with root package name */
    public List<String> f981c;
}
