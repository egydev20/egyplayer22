package c.a.a.a;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final String f923a;

    public a(String str, String str2) {
        this.f923a = str;
    }
}
