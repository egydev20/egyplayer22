package c.a.a.a;

import android.os.Bundle;
import java.util.Arrays;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public final class n implements Callable<Bundle> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ e f982a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ k f983b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ c f984c;

    public n(c cVar, e eVar, k kVar) {
        this.f984c = cVar;
        this.f982a = eVar;
        this.f983b = kVar;
    }

    @Override // java.util.concurrent.Callable
    public final /* synthetic */ Bundle call() {
        c cVar = this.f984c;
        return cVar.f.a(5, cVar.e.getPackageName(), Arrays.asList(this.f982a.f943c), this.f983b.a(), "subs", (String) null);
    }
}
