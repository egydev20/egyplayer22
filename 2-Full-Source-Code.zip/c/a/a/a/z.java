package c.a.a.a;

import android.content.Context;

/* loaded from: classes.dex */
public final class z {

    /* renamed from: a, reason: collision with root package name */
    public final Context f1002a;

    /* renamed from: b, reason: collision with root package name */
    public final a0 f1003b;

    public z(Context context, j jVar) {
        this.f1002a = context;
        this.f1003b = new a0(this, jVar, null);
    }
}
