package c.a.a.a;

import android.text.TextUtils;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class e {

    /* renamed from: a, reason: collision with root package name */
    public String f941a;

    /* renamed from: b, reason: collision with root package name */
    public String f942b;

    /* renamed from: c, reason: collision with root package name */
    public String f943c;

    /* renamed from: d, reason: collision with root package name */
    public String f944d;
    public String e;
    public int f = 0;
    public ArrayList<k> g;
    public boolean h;

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public String f945a;

        /* renamed from: b, reason: collision with root package name */
        public int f946b = 0;

        /* renamed from: c, reason: collision with root package name */
        public ArrayList<k> f947c;

        public /* synthetic */ a(u uVar) {
        }

        public e a() {
            ArrayList<k> arrayList = this.f947c;
            if (arrayList != null && !arrayList.isEmpty()) {
                ArrayList<k> arrayList2 = this.f947c;
                int size = arrayList2.size();
                int i = 0;
                while (i < size) {
                    k kVar = arrayList2.get(i);
                    i++;
                    if (kVar == null) {
                        throw new IllegalArgumentException("SKU cannot be null.");
                    }
                }
                if (this.f947c.size() > 1) {
                    k kVar2 = this.f947c.get(0);
                    String b2 = kVar2.b();
                    ArrayList<k> arrayList3 = this.f947c;
                    int size2 = arrayList3.size();
                    int i2 = 0;
                    while (i2 < size2) {
                        k kVar3 = arrayList3.get(i2);
                        i2++;
                        if (!b2.equals(kVar3.b())) {
                            throw new IllegalArgumentException("SKUs should have the same type.");
                        }
                    }
                    String c2 = kVar2.c();
                    if (TextUtils.isEmpty(c2)) {
                        ArrayList<k> arrayList4 = this.f947c;
                        int size3 = arrayList4.size();
                        int i3 = 0;
                        while (i3 < size3) {
                            k kVar4 = arrayList4.get(i3);
                            i3++;
                            if (!TextUtils.isEmpty(kVar4.c())) {
                                throw new IllegalArgumentException("All SKUs must have the same package name.");
                            }
                        }
                    } else {
                        ArrayList<k> arrayList5 = this.f947c;
                        int size4 = arrayList5.size();
                        int i4 = 0;
                        while (i4 < size4) {
                            k kVar5 = arrayList5.get(i4);
                            i4++;
                            if (!c2.equals(kVar5.c())) {
                                throw new IllegalArgumentException("All SKUs must have the same package name.");
                            }
                        }
                    }
                }
                e eVar = new e(null);
                eVar.f941a = null;
                eVar.f942b = this.f945a;
                eVar.e = null;
                eVar.f943c = null;
                eVar.f944d = null;
                eVar.f = this.f946b;
                eVar.g = this.f947c;
                eVar.h = false;
                return eVar;
            }
            throw new IllegalArgumentException("SkuDetails must be provided.");
        }
    }

    public /* synthetic */ e(u uVar) {
    }
}
