package c.a.a.a;

import android.text.TextUtils;
import java.util.List;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class k {

    /* renamed from: a, reason: collision with root package name */
    public final String f971a;

    /* renamed from: b, reason: collision with root package name */
    public final JSONObject f972b;

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public final List<k> f973a;

        /* renamed from: b, reason: collision with root package name */
        public final int f974b;

        /* renamed from: c, reason: collision with root package name */
        public final String f975c;

        public a(int i, String str, List<k> list) {
            this.f974b = i;
            this.f975c = str;
            this.f973a = list;
        }
    }

    public k(String str) {
        this.f971a = str;
        this.f972b = new JSONObject(this.f971a);
        if (TextUtils.isEmpty(a())) {
            throw new IllegalArgumentException("SKU cannot be empty.");
        }
        if (TextUtils.isEmpty(b())) {
            throw new IllegalArgumentException("SkuType cannot be empty.");
        }
    }

    public String a() {
        return this.f972b.optString("productId");
    }

    public String b() {
        return this.f972b.optString("type");
    }

    public final String c() {
        return this.f972b.optString("packageName");
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof k) {
            return TextUtils.equals(this.f971a, ((k) obj).f971a);
        }
        return false;
    }

    public int hashCode() {
        return this.f971a.hashCode();
    }

    public String toString() {
        String valueOf = String.valueOf(this.f971a);
        return valueOf.length() != 0 ? "SkuDetails: ".concat(valueOf) : new String("SkuDetails: ");
    }
}
