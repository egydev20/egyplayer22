package c.a.a.a;

import c.a.a.a.c;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public final class t implements Callable<Void> {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ c.a f997a;

    public t(c.a aVar) {
        this.f997a = aVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:62:0x00ee  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x00f1  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Void a() {
        /*
            Method dump skipped, instructions count: 250
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.a.a.a.t.a():java.lang.Void");
    }

    @Override // java.util.concurrent.Callable
    public final /* synthetic */ Void call() {
        a();
        return null;
    }
}
