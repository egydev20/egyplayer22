package c.a.b.a;

import android.util.Log;
import b.j.c.t;
import org.xmlpull.v1.XmlPullParser;

/* compiled from: outline */
/* loaded from: classes.dex */
public class a {
    public static String a(t tVar, StringBuilder sb) {
        sb.append(tVar.k());
        return sb.toString();
    }

    public static String a(String str, int i) {
        return str + i;
    }

    public static String a(String str, long j, String str2) {
        return str + j + str2;
    }

    public static String a(String str, String str2) {
        return str + str2;
    }

    public static String a(String str, String str2, String str3) {
        return str + str2 + str3;
    }

    public static String a(XmlPullParser xmlPullParser, StringBuilder sb, String str) {
        sb.append(xmlPullParser.getPositionDescription());
        sb.append(str);
        return sb.toString();
    }

    public static StringBuilder a(String str) {
        StringBuilder sb = new StringBuilder();
        sb.append(str);
        return sb;
    }

    public static void a(String str, int i, String str2) {
        Log.w(str2, str + i);
    }

    public static void a(StringBuilder sb, String str, String str2) {
        sb.append(str);
        Log.w(str2, sb.toString());
    }

    public static void b(String str, String str2, String str3) {
        Log.w(str3, str + str2);
    }
}
