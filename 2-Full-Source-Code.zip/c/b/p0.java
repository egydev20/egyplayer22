package c.b;

import android.app.Activity;
import android.app.UiModeManager;
import android.content.Context;
import android.util.Base64;
import android.view.InputDevice;
import com.egyplayer.iptv.R;
import java.io.File;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

/* loaded from: classes.dex */
public class p0 {

    /* renamed from: a, reason: collision with root package name */
    public static boolean f1091a = false;

    /* renamed from: b, reason: collision with root package name */
    public static int f1092b = 1;

    /* renamed from: c, reason: collision with root package name */
    public static int f1093c = 1;

    public static int a() {
        try {
            for (int i : InputDevice.getDeviceIds()) {
                InputDevice device = InputDevice.getDevice(i);
                if (!device.isVirtual() && (device.getSources() & 513) == 513) {
                    return 1;
                }
            }
            return 0;
        } catch (Exception unused) {
            return -1;
        }
    }

    public static int a(Activity activity) {
        try {
            return c(activity) == 1 ? !(a(activity, "amazon.hardware.fire_tv") == 1) ? 1 : 3 : (a() == 1 || (a(activity, "android.software.live_tv") == 1)) ? 2 : 0;
        } catch (Exception unused) {
            return 0;
        }
    }

    public static int a(Activity activity, String str) {
        try {
            return activity.getPackageManager().hasSystemFeature(str) ? 1 : 0;
        } catch (Exception unused) {
            return -1;
        }
    }

    public static String a(Context context, String str) {
        if (str != null && str.trim().length() != 0) {
            try {
                IvParameterSpec ivParameterSpec = new IvParameterSpec(a(context, 0));
                SecretKeySpec secretKeySpec = new SecretKeySpec(b(context, 0), "AES");
                byte[] decode = Base64.decode(str, 0);
                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
                cipher.init(2, secretKeySpec, ivParameterSpec);
                return new String(cipher.doFinal(decode), "UTF-8");
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public static boolean a(Context context) {
        return ((UiModeManager) context.getSystemService("uimode")).getCurrentModeType() == 4;
    }

    public static byte[] a(Context context, int i) {
        byte[] a2 = a(context.getString(R.string.cib1));
        byte[] a3 = a(context.getString(R.string.cib2));
        byte[] a4 = a(context.getString(R.string.cib3));
        byte[] a5 = a(context.getString(R.string.cib4));
        for (int i2 = 0; i2 < a2.length; i2++) {
            a2[i2] = (byte) (a2[i2] & a3[i2]);
            if (a2[i2] > a3[i2]) {
                return a2;
            }
        }
        for (int i3 = 0; i3 < a3.length; i3++) {
            a3[i3] = (byte) (a3[i3] & a5[i3]);
            if (a3[i3] > a5[i3]) {
                return a3;
            }
        }
        return i + 7 > 16 ? a5 : a4;
    }

    public static byte[] a(String str) {
        if (str == null || str.trim().length() == 0) {
            return null;
        }
        String[] split = str.split(",");
        byte[] bArr = new byte[split.length];
        for (int i = 0; i < split.length; i++) {
            bArr[i] = Byte.parseByte(split[i]);
        }
        return bArr;
    }

    public static String b(Context context, String str) {
        if (str != null && str.trim().length() != 0) {
            try {
                IvParameterSpec ivParameterSpec = new IvParameterSpec(a(context, 0));
                SecretKeySpec secretKeySpec = new SecretKeySpec(b(context, 0), "AES");
                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
                cipher.init(1, secretKeySpec, ivParameterSpec);
                String encodeToString = Base64.encodeToString(cipher.doFinal(str.getBytes("UTF-8")), 0);
                if (encodeToString != null) {
                    return encodeToString.trim();
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public static String b(String str) {
        if (str == null || str.trim().length() == 0) {
            return null;
        }
        int lastIndexOf = str.lastIndexOf(File.separatorChar);
        return lastIndexOf < 0 ? str : str.substring(lastIndexOf + 1);
    }

    public static void b(Activity activity) {
        try {
            activity.getWindow().getDecorView().setSystemUiVisibility(5894);
        } catch (Exception unused) {
        }
    }

    public static byte[] b(Context context, int i) {
        byte[] a2 = a(context.getString(R.string.ckb1));
        byte[] a3 = a(context.getString(R.string.ckb2));
        byte[] a4 = a(context.getString(R.string.ckb3));
        byte[] a5 = a(context.getString(R.string.ckb4));
        for (int i2 = 0; i2 < a2.length; i2++) {
            a2[i2] = (byte) (a2[i2] & a3[i2]);
            if (a2[i2] > a3[i2]) {
                return a2;
            }
        }
        for (int i3 = 0; i3 < a3.length; i3++) {
            a3[i3] = (byte) (a3[i3] & a5[i3]);
            if (a3[i3] > a5[i3]) {
                return a3;
            }
        }
        return i + 7 > 16 ? a5 : a4;
    }

    public static int c(Activity activity) {
        try {
            UiModeManager uiModeManager = (UiModeManager) activity.getSystemService("uimode");
            if (uiModeManager == null) {
                return -1;
            }
            return uiModeManager.getCurrentModeType() == 4 ? 1 : 0;
        } catch (Exception unused) {
            return -2;
        }
    }
}
