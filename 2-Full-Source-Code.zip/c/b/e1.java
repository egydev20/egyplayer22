package c.b;

import android.app.Activity;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.FrameLayout;
import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Objects;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.videolan.libvlc.LibVLC;
import org.videolan.libvlc.Media;
import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.RendererDiscoverer;
import org.videolan.libvlc.RendererItem;
import org.videolan.libvlc.util.VLCVideoLayout;

/* loaded from: classes.dex */
public class e1 implements MediaPlayer.EventListener, v0 {
    public String A;
    public ArrayList<MediaPlayer.TrackDescription> D;
    public ArrayList<MediaPlayer.TrackDescription> E;
    public ArrayList<MediaPlayer.TrackDescription> F;

    /* renamed from: d, reason: collision with root package name */
    public VLCVideoLayout f1036d;
    public Activity e;
    public WebView f;
    public int g;
    public int j;
    public int k;
    public long l;
    public long m;
    public double q;
    public double r;
    public double s;
    public double t;
    public RendererDiscoverer y;

    /* renamed from: b, reason: collision with root package name */
    public LibVLC f1034b = null;

    /* renamed from: c, reason: collision with root package name */
    public MediaPlayer f1035c = null;
    public boolean i = false;
    public boolean n = false;
    public String o = null;
    public String p = null;
    public boolean u = false;
    public boolean v = false;
    public String w = null;
    public String x = null;
    public boolean B = false;
    public boolean C = false;
    public Handler h = new Handler(Looper.getMainLooper());
    public ArrayList<RendererItem> z = new ArrayList<>();

    /* loaded from: classes.dex */
    public class a implements RendererDiscoverer.EventListener {
        public a() {
        }

        @Override // org.videolan.libvlc.interfaces.AbstractVLCEvent.Listener
        public void onEvent(RendererDiscoverer.Event event) {
            RendererDiscoverer.Event event2 = event;
            RendererItem item = event2.getItem();
            int i = event2.type;
            if (i == 1282) {
                e1.this.a(item);
            } else {
                if (i != 1283) {
                    return;
                }
                e1.this.b(item);
            }
        }
    }

    public e1(Activity activity, WebView webView, VLCVideoLayout vLCVideoLayout, int i) {
        this.f1036d = null;
        this.e = activity;
        this.f = webView;
        this.f1036d = vLCVideoLayout;
        this.g = i;
    }

    public final int a(Object obj, String str) {
        try {
            return ((Integer) b(obj, str)).intValue();
        } catch (Exception unused) {
            return 0;
        }
    }

    public final String a(ArrayList<RendererItem> arrayList, String str) {
        String str2;
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < arrayList.size(); i++) {
            RendererItem rendererItem = arrayList.get(i);
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("name", rendererItem.name);
                jSONObject.put("displayName", rendererItem.displayName);
                String str3 = null;
                try {
                    str2 = (String) b(rendererItem, "type");
                } catch (Exception unused) {
                    str2 = null;
                }
                jSONObject.put("type", str2);
                try {
                    str3 = (String) b(rendererItem, "iconUrl");
                } catch (Exception unused2) {
                }
                jSONObject.put("iconUrl", str3);
                jSONObject.put("flags", a(rendererItem, "flags"));
                if (str != null && Objects.equals(rendererItem.name, str)) {
                    jSONObject.put("isActive", 1);
                } else {
                    jSONObject.put("isActive", 0);
                }
                jSONArray.put(jSONObject);
            } catch (JSONException unused3) {
            }
        }
        return jSONArray.toString();
    }

    @Override // c.b.v0
    public void a() {
        f();
    }

    public final void a(double d2, double d3, double d4, double d5) {
        try {
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.f1036d.getLayoutParams();
            layoutParams.gravity = 51;
            layoutParams.width = (int) d4;
            layoutParams.height = (int) d5;
            layoutParams.leftMargin = (int) d2;
            layoutParams.topMargin = (int) d3;
            this.f1036d.setLayoutParams(layoutParams);
            this.f1036d.invalidate();
        } catch (Exception unused) {
        }
    }

    @Override // c.b.v0
    public void a(String str) {
        try {
            this.x = str;
        } catch (Exception unused) {
        }
    }

    public final void a(RendererItem rendererItem) {
        synchronized (this.z) {
            int c2 = c(rendererItem.name);
            if (c2 >= 0) {
                RendererItem rendererItem2 = this.z.get(c2);
                this.z.remove(c2);
                rendererItem2.release();
            }
            this.z.add(rendererItem);
        }
    }

    public final void a(boolean z) {
        boolean z2 = this.v;
        if (z) {
            if (!z2) {
                this.f1035c.attachViews(this.f1036d, null, true, false);
            }
        } else if (z2) {
            this.f1035c.detachViews();
        }
        this.v = z;
    }

    public final Object b(Object obj, String str) {
        try {
            Field declaredField = obj.getClass().getDeclaredField(str);
            declaredField.setAccessible(true);
            return declaredField.get(obj);
        } catch (Exception unused) {
            return null;
        }
    }

    public final String b(ArrayList<MediaPlayer.TrackDescription> arrayList, String str) {
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < arrayList.size(); i++) {
            MediaPlayer.TrackDescription trackDescription = arrayList.get(i);
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("id", Integer.toString(trackDescription.id));
                jSONObject.put("name", trackDescription.name);
                jSONObject.put("language", trackDescription.name);
                if (str != null && Objects.equals(Integer.toString(trackDescription.id), str)) {
                    jSONObject.put("selected", 1);
                } else {
                    jSONObject.put("selected", 0);
                }
                jSONArray.put(jSONObject);
            } catch (JSONException unused) {
            }
        }
        return jSONArray.toString();
    }

    public final void b(final String str) {
        try {
            if (this.h == null) {
                return;
            }
            this.h.post(new Runnable() { // from class: c.b.w
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.e(str);
                }
            });
        } catch (Exception unused) {
        }
    }

    public final void b(RendererItem rendererItem) {
        synchronized (this.z) {
            int c2 = c(rendererItem.name);
            if (c2 >= 0) {
                RendererItem rendererItem2 = this.z.get(c2);
                this.z.remove(c2);
                rendererItem2.release();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0072 A[Catch: Exception -> 0x00f8, TryCatch #0 {Exception -> 0x00f8, blocks: (B:3:0x0001, B:14:0x0062, B:16:0x0072, B:17:0x0074, B:19:0x007c, B:22:0x0080, B:24:0x0083, B:28:0x0091, B:29:0x008a, B:32:0x0094, B:34:0x009c, B:37:0x00a0, B:39:0x00a3, B:43:0x00b1, B:44:0x00aa, B:47:0x00b4, B:49:0x00bc, B:52:0x00c0, B:54:0x00c3, B:58:0x00d1, B:59:0x00ca, B:62:0x00d4, B:64:0x00dd, B:65:0x00e6, B:67:0x00ee, B:69:0x00f1, B:70:0x00e0), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0083 A[Catch: Exception -> 0x00f8, TryCatch #0 {Exception -> 0x00f8, blocks: (B:3:0x0001, B:14:0x0062, B:16:0x0072, B:17:0x0074, B:19:0x007c, B:22:0x0080, B:24:0x0083, B:28:0x0091, B:29:0x008a, B:32:0x0094, B:34:0x009c, B:37:0x00a0, B:39:0x00a3, B:43:0x00b1, B:44:0x00aa, B:47:0x00b4, B:49:0x00bc, B:52:0x00c0, B:54:0x00c3, B:58:0x00d1, B:59:0x00ca, B:62:0x00d4, B:64:0x00dd, B:65:0x00e6, B:67:0x00ee, B:69:0x00f1, B:70:0x00e0), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00a3 A[Catch: Exception -> 0x00f8, TryCatch #0 {Exception -> 0x00f8, blocks: (B:3:0x0001, B:14:0x0062, B:16:0x0072, B:17:0x0074, B:19:0x007c, B:22:0x0080, B:24:0x0083, B:28:0x0091, B:29:0x008a, B:32:0x0094, B:34:0x009c, B:37:0x00a0, B:39:0x00a3, B:43:0x00b1, B:44:0x00aa, B:47:0x00b4, B:49:0x00bc, B:52:0x00c0, B:54:0x00c3, B:58:0x00d1, B:59:0x00ca, B:62:0x00d4, B:64:0x00dd, B:65:0x00e6, B:67:0x00ee, B:69:0x00f1, B:70:0x00e0), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00c3 A[Catch: Exception -> 0x00f8, TryCatch #0 {Exception -> 0x00f8, blocks: (B:3:0x0001, B:14:0x0062, B:16:0x0072, B:17:0x0074, B:19:0x007c, B:22:0x0080, B:24:0x0083, B:28:0x0091, B:29:0x008a, B:32:0x0094, B:34:0x009c, B:37:0x00a0, B:39:0x00a3, B:43:0x00b1, B:44:0x00aa, B:47:0x00b4, B:49:0x00bc, B:52:0x00c0, B:54:0x00c3, B:58:0x00d1, B:59:0x00ca, B:62:0x00d4, B:64:0x00dd, B:65:0x00e6, B:67:0x00ee, B:69:0x00f1, B:70:0x00e0), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x00dd A[Catch: Exception -> 0x00f8, TryCatch #0 {Exception -> 0x00f8, blocks: (B:3:0x0001, B:14:0x0062, B:16:0x0072, B:17:0x0074, B:19:0x007c, B:22:0x0080, B:24:0x0083, B:28:0x0091, B:29:0x008a, B:32:0x0094, B:34:0x009c, B:37:0x00a0, B:39:0x00a3, B:43:0x00b1, B:44:0x00aa, B:47:0x00b4, B:49:0x00bc, B:52:0x00c0, B:54:0x00c3, B:58:0x00d1, B:59:0x00ca, B:62:0x00d4, B:64:0x00dd, B:65:0x00e6, B:67:0x00ee, B:69:0x00f1, B:70:0x00e0), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:67:0x00ee A[Catch: Exception -> 0x00f8, TryCatch #0 {Exception -> 0x00f8, blocks: (B:3:0x0001, B:14:0x0062, B:16:0x0072, B:17:0x0074, B:19:0x007c, B:22:0x0080, B:24:0x0083, B:28:0x0091, B:29:0x008a, B:32:0x0094, B:34:0x009c, B:37:0x00a0, B:39:0x00a3, B:43:0x00b1, B:44:0x00aa, B:47:0x00b4, B:49:0x00bc, B:52:0x00c0, B:54:0x00c3, B:58:0x00d1, B:59:0x00ca, B:62:0x00d4, B:64:0x00dd, B:65:0x00e6, B:67:0x00ee, B:69:0x00f1, B:70:0x00e0), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:69:0x00f1 A[Catch: Exception -> 0x00f8, TRY_LEAVE, TryCatch #0 {Exception -> 0x00f8, blocks: (B:3:0x0001, B:14:0x0062, B:16:0x0072, B:17:0x0074, B:19:0x007c, B:22:0x0080, B:24:0x0083, B:28:0x0091, B:29:0x008a, B:32:0x0094, B:34:0x009c, B:37:0x00a0, B:39:0x00a3, B:43:0x00b1, B:44:0x00aa, B:47:0x00b4, B:49:0x00bc, B:52:0x00c0, B:54:0x00c3, B:58:0x00d1, B:59:0x00ca, B:62:0x00d4, B:64:0x00dd, B:65:0x00e6, B:67:0x00ee, B:69:0x00f1, B:70:0x00e0), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:70:0x00e0 A[Catch: Exception -> 0x00f8, TryCatch #0 {Exception -> 0x00f8, blocks: (B:3:0x0001, B:14:0x0062, B:16:0x0072, B:17:0x0074, B:19:0x007c, B:22:0x0080, B:24:0x0083, B:28:0x0091, B:29:0x008a, B:32:0x0094, B:34:0x009c, B:37:0x00a0, B:39:0x00a3, B:43:0x00b1, B:44:0x00aa, B:47:0x00b4, B:49:0x00bc, B:52:0x00c0, B:54:0x00c3, B:58:0x00d1, B:59:0x00ca, B:62:0x00d4, B:64:0x00dd, B:65:0x00e6, B:67:0x00ee, B:69:0x00f1, B:70:0x00e0), top: B:2:0x0001 }] */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0045 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean b() {
        /*
            Method dump skipped, instructions count: 249
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.e1.b():boolean");
    }

    public final int c(String str) {
        for (int i = 0; i < this.z.size(); i++) {
            String str2 = this.z.get(i).name;
            if (str2 != null && str2.equals(str)) {
                return i;
            }
        }
        return -1;
    }

    @Override // c.b.v0
    public void c() {
        if (this.C && this.B && this.f1035c != null) {
            a(true);
            n();
            this.C = false;
        }
    }

    public /* synthetic */ void c(boolean z) {
        VLCVideoLayout vLCVideoLayout;
        int i;
        try {
            if (z) {
                vLCVideoLayout = this.f1036d;
                i = 0;
            } else {
                vLCVideoLayout = this.f1036d;
                i = 8;
            }
            vLCVideoLayout.setVisibility(i);
        } catch (Exception unused) {
        }
    }

    public final RendererItem d(String str) {
        synchronized (this.z) {
            int c2 = c(str);
            if (c2 < 0) {
                return null;
            }
            return this.z.get(c2);
        }
    }

    @Override // c.b.v0
    public void d() {
        if (!this.B || this.f1035c == null) {
            return;
        }
        setActiveCastDevice(null);
        RendererDiscoverer rendererDiscoverer = this.y;
        if (rendererDiscoverer != null) {
            rendererDiscoverer.release();
        }
        MediaPlayer mediaPlayer = this.f1035c;
        if (mediaPlayer != null) {
            mediaPlayer.release();
        }
        LibVLC libVLC = this.f1034b;
        if (libVLC != null) {
            libVLC.release();
        }
    }

    public final void d(boolean z) {
        try {
            if (z) {
                a(this.q, this.r, this.s, this.t);
                this.f1036d.setVisibility(0);
            } else {
                a(-800.0d, 0.0d, 20.0d, 20.0d);
                this.f1036d.setVisibility(4);
            }
            this.u = z;
        } catch (Exception unused) {
        }
    }

    @Override // c.b.v0
    public void e() {
        if (!this.B || this.f1035c == null) {
            return;
        }
        setActiveCastDevice(null);
        this.f1035c.stop();
        a(false);
        o();
        this.C = true;
    }

    public /* synthetic */ void e(String str) {
        try {
            if (this.f == null) {
                return;
            }
            this.f.evaluateJavascript(str, null);
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x003a, code lost:
    
        if (r2.trim().length() != 0) goto L23;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void f() {
        /*
            r5 = this;
            boolean r0 = r5.B
            if (r0 != 0) goto L65
            r0 = 1
            java.util.ArrayList r1 = new java.util.ArrayList     // Catch: java.lang.Exception -> L60
            r1.<init>()     // Catch: java.lang.Exception -> L60
            java.lang.String r2 = "--vout=android-display,none"
            r1.add(r2)     // Catch: java.lang.Exception -> L60
            java.lang.String r2 = "--http-reconnect"
            r1.add(r2)     // Catch: java.lang.Exception -> L60
            r2 = 0
            android.app.Activity r3 = r5.e     // Catch: java.lang.Exception -> L2f
            boolean r3 = r3 instanceof c.b.u0     // Catch: java.lang.Exception -> L2f
            if (r3 != 0) goto L1c
            goto L30
        L1c:
            android.app.Activity r3 = r5.e     // Catch: java.lang.Exception -> L2f
            c.b.u0 r3 = (c.b.u0) r3     // Catch: java.lang.Exception -> L2f
            c.b.f1 r3 = r3.b()     // Catch: java.lang.Exception -> L2f
            if (r3 != 0) goto L27
            goto L30
        L27:
            c.b.b1 r3 = r3.h     // Catch: java.lang.Exception -> L2f
            if (r3 != 0) goto L2c
            goto L30
        L2c:
            java.lang.String r2 = r3.f1013a     // Catch: java.lang.Exception -> L2f
            goto L30
        L2f:
        L30:
            if (r2 == 0) goto L3c
            java.lang.String r3 = r2.trim()     // Catch: java.lang.Exception -> L60
            int r3 = r3.length()     // Catch: java.lang.Exception -> L60
            if (r3 != 0) goto L3e
        L3c:
            java.lang.String r2 = "samsung"
        L3e:
            org.videolan.libvlc.LibVLC r3 = new org.videolan.libvlc.LibVLC     // Catch: java.lang.Exception -> L60
            android.app.Activity r4 = r5.e     // Catch: java.lang.Exception -> L60
            r3.<init>(r4, r1)     // Catch: java.lang.Exception -> L60
            r5.f1034b = r3     // Catch: java.lang.Exception -> L60
            r3.setUserAgent(r2, r2)     // Catch: java.lang.Exception -> L60
            org.videolan.libvlc.MediaPlayer r1 = new org.videolan.libvlc.MediaPlayer     // Catch: java.lang.Exception -> L60
            org.videolan.libvlc.LibVLC r2 = r5.f1034b     // Catch: java.lang.Exception -> L60
            r1.<init>(r2)     // Catch: java.lang.Exception -> L60
            r5.f1035c = r1     // Catch: java.lang.Exception -> L60
            r1.setEventListener(r5)     // Catch: java.lang.Exception -> L60
            r5.a(r0)     // Catch: java.lang.Exception -> L60
            r5.m()     // Catch: java.lang.Exception -> L60
            r1 = 0
            r5.d(r1)     // Catch: java.lang.Exception -> L60
        L60:
            r5.n()
            r5.B = r0
        L65:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.e1.f():void");
    }

    public /* synthetic */ void g() {
        try {
            this.f1035c.pause();
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public String getAudioTracks() {
        ArrayList<MediaPlayer.TrackDescription> arrayList = this.D;
        return (arrayList == null || arrayList.size() == 0) ? "" : b(this.D, this.o);
    }

    @JavascriptInterface
    public String getCastDeviceName() {
        return this.A;
    }

    @JavascriptInterface
    public String getCastDevices() {
        synchronized (this.z) {
            if (this.z != null && this.z.size() != 0) {
                return a(this.z, this.A);
            }
            return "";
        }
    }

    @JavascriptInterface
    public long getCurrentTimeMS() {
        return this.m;
    }

    @JavascriptInterface
    public String getDeviceId() {
        try {
            return Settings.Secure.getString(this.e.getContentResolver(), "android_id");
        } catch (Exception unused) {
            return "unknown_device";
        }
    }

    @JavascriptInterface
    public long getDurationMS() {
        return this.l;
    }

    @JavascriptInterface
    public String getSubtitleTracks() {
        ArrayList<MediaPlayer.TrackDescription> arrayList = this.F;
        return (arrayList == null || arrayList.size() == 0) ? "" : b(this.F, this.p);
    }

    @JavascriptInterface
    public int getVideoHeight() {
        return this.k;
    }

    @JavascriptInterface
    public String getVideoTracks() {
        ArrayList<MediaPlayer.TrackDescription> arrayList = this.E;
        return (arrayList == null || arrayList.size() == 0) ? "" : b(this.E, (String) null);
    }

    @JavascriptInterface
    public int getVideoWidth() {
        return this.j;
    }

    public /* synthetic */ void h() {
        try {
            this.f1035c.play();
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x002a A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public /* synthetic */ void i() {
        /*
            r3 = this;
            r0 = 0
            java.lang.String r1 = r3.w     // Catch: java.lang.Exception -> Lc
            if (r1 == 0) goto Lc
            r3.w = r0     // Catch: java.lang.Exception -> Lc
            org.videolan.libvlc.MediaPlayer r1 = r3.f1035c     // Catch: java.lang.Exception -> Lc
            r1.record(r0)     // Catch: java.lang.Exception -> Lc
        Lc:
            r1 = 0
            android.app.Activity r2 = r3.e     // Catch: java.lang.Exception -> L27
            boolean r2 = r2 instanceof c.b.u0     // Catch: java.lang.Exception -> L27
            if (r2 != 0) goto L14
            goto L27
        L14:
            android.app.Activity r2 = r3.e     // Catch: java.lang.Exception -> L27
            c.b.u0 r2 = (c.b.u0) r2     // Catch: java.lang.Exception -> L27
            c.b.f1 r2 = r2.b()     // Catch: java.lang.Exception -> L27
            if (r2 != 0) goto L1f
            goto L27
        L1f:
            c.b.b1 r2 = r2.h     // Catch: java.lang.Exception -> L27
            if (r2 != 0) goto L24
            goto L27
        L24:
            boolean r2 = r2.f1014b     // Catch: java.lang.Exception -> L27
            goto L28
        L27:
            r2 = 0
        L28:
            if (r2 != 0) goto L2d
            r3.setActiveCastDevice(r0)     // Catch: java.lang.Exception -> L35
        L2d:
            org.videolan.libvlc.MediaPlayer r0 = r3.f1035c     // Catch: java.lang.Exception -> L35
            r0.stop()     // Catch: java.lang.Exception -> L35
            r3.d(r1)     // Catch: java.lang.Exception -> L35
        L35:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.e1.i():void");
    }

    /* renamed from: i, reason: merged with bridge method [inline-methods] */
    public final void h(String str) {
        if (str != null) {
            try {
                if (str.trim().length() != 0) {
                    if (this.f1035c.setSpuTrack(Integer.parseInt(str))) {
                        this.p = str;
                    }
                }
            } catch (Exception unused) {
                return;
            }
        }
        if (this.f1035c.setSpuTrack(-1)) {
            this.p = null;
        }
    }

    public /* synthetic */ void j() {
        try {
            if (this.w != null) {
                this.w = null;
                this.f1035c.record(null);
            }
        } catch (Exception unused) {
        }
    }

    public final boolean k() {
        if (!this.i || !b()) {
            return false;
        }
        StringBuilder a2 = c.a.b.a.a.a("PlayerGateway.onMetadataReady(");
        a2.append(this.g);
        a2.append(");");
        b(a2.toString());
        return true;
    }

    public final boolean l() {
        if (!b()) {
            return false;
        }
        h(null);
        m();
        if (!this.i) {
            StringBuilder a2 = c.a.b.a.a.a("PlayerGateway.onMetadataReady(");
            a2.append(this.g);
            a2.append(");");
            b(a2.toString());
            this.i = true;
        }
        return true;
    }

    public final void m() {
        this.f1035c.setScale(0.0f);
        this.f1035c.setVideoScale(MediaPlayer.ScaleType.SURFACE_FILL);
        this.f1035c.setAspectRatio(null);
        this.f1035c.updateVideoSurfaces();
    }

    public final void n() {
        try {
            if (this.y == null || this.y.isReleased()) {
                RendererDiscoverer rendererDiscoverer = new RendererDiscoverer(this.f1034b, "microdns_renderer");
                this.y = rendererDiscoverer;
                rendererDiscoverer.setEventListener((RendererDiscoverer.EventListener) new a());
            }
            this.y.start();
        } catch (Exception unused) {
        }
    }

    public final void o() {
        try {
            if (this.y == null || this.y.isReleased()) {
                return;
            }
            this.y.stop();
            this.y.release();
            this.y = null;
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Failed to find 'out' block for switch in B:12:0x001f. Please report as an issue. */
    /* JADX WARN: Failed to find 'out' block for switch in B:13:0x0022. Please report as an issue. */
    @Override // org.videolan.libvlc.interfaces.AbstractVLCEvent.Listener
    public void onEvent(MediaPlayer.Event event) {
        String str;
        StringBuilder sb;
        String str2;
        String str3;
        StringBuilder a2;
        boolean seekable;
        StringBuilder a3;
        StringBuilder sb2;
        String str4;
        MediaPlayer.Event event2 = event;
        int i = event2.type;
        if (i != 256) {
            if (i == 274) {
                StringBuilder a4 = c.a.b.a.a.a("Vout ");
                a4.append(event2.getVoutCount());
                Log.i("JSVLCMediaPlayer", a4.toString());
                if (event2.getVoutCount() <= 0 || !l()) {
                    return;
                } else {
                    sb = new StringBuilder();
                }
            } else {
                if (i != 286) {
                    if (i == 269) {
                        a2 = c.a.b.a.a.a("SeekableChanged Type=");
                        seekable = event2.getSeekable();
                    } else if (i != 270) {
                        switch (i) {
                            case MediaPlayer.Event.Opening /* 258 */:
                                str = "Opening";
                                break;
                            case MediaPlayer.Event.Buffering /* 259 */:
                                int floor = (int) Math.floor(event2.getBuffering());
                                this.n = true;
                                a3 = c.a.b.a.a.a("PlayerGateway.onBuffering(");
                                a3.append(this.g);
                                a3.append(",");
                                a3.append(floor);
                                a3.append(");");
                                str2 = a3.toString();
                                b(str2);
                                return;
                            case MediaPlayer.Event.Playing /* 260 */:
                                Log.i("JSVLCMediaPlayer", "Playing");
                                l();
                                sb = new StringBuilder();
                                break;
                            case MediaPlayer.Event.Paused /* 261 */:
                                str = "Paused";
                                break;
                            case MediaPlayer.Event.Stopped /* 262 */:
                                str = "Stopped";
                                break;
                            default:
                                switch (i) {
                                    case MediaPlayer.Event.EndReached /* 265 */:
                                        sb = new StringBuilder();
                                        str3 = "PlayerGateway.onEnded(";
                                        sb.append(str3);
                                        sb.append(this.g);
                                        sb.append(");");
                                        str2 = sb.toString();
                                        b(str2);
                                        return;
                                    case MediaPlayer.Event.EncounteredError /* 266 */:
                                        Log.i("JSVLCMediaPlayer", "EncounteredError");
                                        String str5 = this.A;
                                        String str6 = (str5 == null || str5.trim().length() <= 0) ? "Not Found" : "Cast Error";
                                        a3 = c.a.b.a.a.a("PlayerGateway.onError(");
                                        a3.append(this.g);
                                        a3.append(",\"");
                                        a3.append(str6);
                                        a3.append("\");");
                                        str2 = a3.toString();
                                        b(str2);
                                        return;
                                    case MediaPlayer.Event.TimeChanged /* 267 */:
                                        this.m = event2.getTimeChanged();
                                        StringBuilder a5 = c.a.b.a.a.a("PlayerGateway.onTimeChange(");
                                        a5.append(this.g);
                                        a5.append(",");
                                        a5.append(this.m);
                                        a5.append(");");
                                        b(a5.toString());
                                        if (this.n) {
                                            this.n = false;
                                            sb = new StringBuilder();
                                            break;
                                        } else {
                                            return;
                                        }
                                    default:
                                        switch (i) {
                                            case MediaPlayer.Event.ESAdded /* 276 */:
                                                a2 = c.a.b.a.a.a("ESAdded Type=");
                                                a2.append(event2.getEsChangedType());
                                                a2.append(" ID=");
                                                a2.append(event2.getEsChangedID());
                                                break;
                                            case MediaPlayer.Event.ESDeleted /* 277 */:
                                                k();
                                                return;
                                            case MediaPlayer.Event.ESSelected /* 278 */:
                                                int esChangedType = event2.getEsChangedType();
                                                if (esChangedType == 0) {
                                                    sb2 = new StringBuilder();
                                                    str4 = "ESSelected Audio TrackID=";
                                                } else if (esChangedType == 1) {
                                                    sb2 = new StringBuilder();
                                                    str4 = "ESSelected Video TrackID=";
                                                } else {
                                                    if (esChangedType != 2) {
                                                        return;
                                                    }
                                                    sb2 = new StringBuilder();
                                                    str4 = "ESSelected Text TrackID=";
                                                }
                                                sb2.append(str4);
                                                sb2.append(event2.getEsChangedID());
                                                str = sb2.toString();
                                                break;
                                            default:
                                                return;
                                        }
                                        Log.i("JSVLCMediaPlayer", a2.toString());
                                        k();
                                        return;
                                }
                        }
                    } else {
                        a2 = c.a.b.a.a.a("PausableChanged Type=");
                        seekable = event2.getPausable();
                    }
                    a2.append(seekable);
                    Log.i("JSVLCMediaPlayer", a2.toString());
                    k();
                    return;
                }
                str = "RecordChanged ";
            }
            str3 = "PlayerGateway.onPlaying(";
            sb.append(str3);
            sb.append(this.g);
            sb.append(");");
            str2 = sb.toString();
            b(str2);
            return;
        }
        str = "MediaChanged";
        Log.i("JSVLCMediaPlayer", str);
    }

    @JavascriptInterface
    public void pause() {
        Handler handler = this.h;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.o
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.g();
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void play(final String str, final int i) {
        this.i = false;
        this.n = false;
        this.w = null;
        Handler handler = this.h;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.y
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.a(str, i);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void refreshCastDevices() {
        try {
            o();
            n();
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void resume() {
        Handler handler = this.h;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.s
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.h();
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void seek(final int i) {
        this.m = i;
        Handler handler = this.h;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.a0
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.a(i);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public boolean setActiveCastDevice(String str) {
        try {
            if (this.f1035c == null || Objects.equals(str, this.A)) {
                return false;
            }
            if (str != null && str.trim().length() != 0) {
                RendererItem d2 = d(str);
                if (d2 == null) {
                    return false;
                }
                this.f1035c.setRenderer(d2);
                this.A = str;
                return true;
            }
            this.A = null;
            this.f1035c.setRenderer(null);
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    @JavascriptInterface
    public void setDisplayRect(final double d2, final double d3, final double d4, final double d5, final boolean z) {
        this.q = d2;
        this.r = d3;
        this.s = d4;
        this.t = d5;
        try {
            if (this.h == null) {
                return;
            }
            this.h.post(new Runnable() { // from class: c.b.z
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.a(d2, d3, d4, d5, z);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setSoundLevelRatio(final float f) {
        try {
            if (this.h == null) {
                return;
            }
            this.h.post(new Runnable() { // from class: c.b.r
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.a(f);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void showPlayerBackground(final boolean z) {
        try {
            if (this.h == null) {
                return;
            }
            this.h.post(new Runnable() { // from class: c.b.x
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.b(z);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void showPlayerUI(final boolean z) {
        Handler handler = this.h;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.n
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.c(z);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void startRecording(final String str) {
        try {
            if (this.h == null) {
                return;
            }
            this.h.post(new Runnable() { // from class: c.b.u
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.f(str);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void stop() {
        Handler handler = this.h;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.p
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.i();
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void stopRecording() {
        try {
            if (this.h == null) {
                return;
            }
            this.h.post(new Runnable() { // from class: c.b.t
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.j();
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void switchAudioTrack(final String str) {
        Handler handler = this.h;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.v
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.g(str);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void switchSubtitleTrack(final String str) {
        Handler handler = this.h;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.q
                @Override // java.lang.Runnable
                public final void run() {
                    e1.this.h(str);
                }
            });
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void g(String str) {
        if (str != null) {
            try {
                if (str.trim().length() != 0 && this.f1035c.setAudioTrack(Integer.parseInt(str))) {
                    this.o = str;
                }
            } catch (Exception unused) {
            }
        }
    }

    public /* synthetic */ void b(boolean z) {
        try {
            if (this.e instanceof u0) {
                ((u0) this.e).a(z);
            }
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void a(String str, int i) {
        f1 b2;
        b1 b1Var;
        try {
            f();
            if (str != null && str.trim().length() != 0) {
                a(true);
                d(true);
                if (this.y == null || this.y.isReleased()) {
                    n();
                }
                boolean z = false;
                try {
                    if ((this.e instanceof u0) && (b2 = ((u0) this.e).b()) != null && (b1Var = b2.h) != null) {
                        z = b1Var.f1015c;
                    }
                } catch (Exception unused) {
                }
                Media media = (str.toLowerCase().trim().startsWith("http") || str.toLowerCase().trim().startsWith("://")) ? new Media(this.f1034b, Uri.parse(str)) : new Media(this.f1034b, str);
                media.setHWDecoderEnabled(true, z);
                this.f1035c.setMedia(media);
                media.release();
                this.f1035c.play();
            }
        } catch (Exception unused2) {
        }
    }

    public /* synthetic */ void f(String str) {
        try {
            if ((this.e instanceof u0) && this.x != null && this.x.trim().length() != 0) {
                this.w = str;
                File file = new File(this.x, str);
                if (!file.exists()) {
                    file.mkdirs();
                }
                if (Boolean.valueOf(this.f1035c.record(file.getAbsolutePath())).booleanValue()) {
                    ((u0) this.e).a(file.getAbsolutePath());
                }
            }
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void a(int i) {
        try {
            this.f1035c.setTime(i);
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void a(double d2, double d3, double d4, double d5, boolean z) {
        if (this.u) {
            a(d2, d3, d4, d5);
            m();
        }
    }

    public /* synthetic */ void a(float f) {
        try {
            this.f1035c.setVolume((int) f);
        } catch (Exception unused) {
        }
    }
}
