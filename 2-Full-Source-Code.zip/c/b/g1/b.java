package c.b.g1;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;
import com.egyplayer.iptv.repository.StoreItem;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

/* loaded from: classes.dex */
public class b {

    /* renamed from: c, reason: collision with root package name */
    public static b f1055c;

    /* renamed from: b, reason: collision with root package name */
    public Object f1057b = new Object();

    /* renamed from: a, reason: collision with root package name */
    public StoreItem[] f1056a = null;

    public static b c() {
        if (f1055c == null) {
            f1055c = new b();
        }
        return f1055c;
    }

    public StoreItem a(String str, String str2, String str3) {
        synchronized (this.f1057b) {
            if (this.f1056a != null && this.f1056a.length != 0) {
                if (str != null && str.trim().length() != 0) {
                    if (str2 != null && str2.trim().length() != 0) {
                        if (str3 != null && str3.trim().length() != 0) {
                            for (StoreItem storeItem : this.f1056a) {
                                if (Objects.equals(storeItem.targetMAC, str) && Objects.equals(storeItem.targetKey, str2) && Objects.equals(storeItem.productID, str3) && storeItem.status == 0) {
                                    return storeItem;
                                }
                            }
                            return null;
                        }
                        return null;
                    }
                    return null;
                }
                return null;
            }
            return null;
        }
    }

    public final String a(String str) {
        if (str != null) {
            try {
                if (str.trim().length() != 0) {
                    SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{10, 22, 34, 51, 55, 2, 72, 86, 21, 15, 101, 102, 45, 90, 73, 18}, "AES");
                    byte[] decode = Base64.decode(str, 0);
                    Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
                    cipher.init(2, secretKeySpec);
                    return new String(cipher.doFinal(decode), "UTF-8");
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public ArrayList<StoreItem> a() {
        try {
            synchronized (this.f1057b) {
                if (this.f1056a != null && this.f1056a.length != 0) {
                    ArrayList<StoreItem> arrayList = new ArrayList<>();
                    for (StoreItem storeItem : this.f1056a) {
                        if (!storeItem.isSent || !storeItem.isConsumed) {
                            arrayList.add(storeItem);
                        }
                    }
                    return arrayList;
                }
                return null;
            }
        } catch (Exception unused) {
            return null;
        }
    }

    public Date a(Context context) {
        try {
            Calendar.getInstance().getTime();
            SharedPreferences sharedPreferences = context.getSharedPreferences("EGYPlayerStoreFile", 0);
            if (sharedPreferences == null) {
                return new Date(0L);
            }
            long j = sharedPreferences.getLong("StoreItemsLastCheckAtMS", 0L);
            return j < 0 ? new Date(0L) : new Date(j);
        } catch (Exception unused) {
            return new Date(0L);
        }
    }

    public final boolean a(Context context, String str) {
        String b2;
        if (context == null) {
            return false;
        }
        if (str != null) {
            try {
                if (str.trim().length() != 0) {
                    b2 = b(str);
                    SharedPreferences.Editor edit = context.getSharedPreferences("EGYPlayerStoreFile", 0).edit();
                    edit.putString("Items", b2);
                    edit.commit();
                    return true;
                }
            } catch (Exception unused) {
                return false;
            }
        }
        b2 = null;
        SharedPreferences.Editor edit2 = context.getSharedPreferences("EGYPlayerStoreFile", 0).edit();
        edit2.putString("Items", b2);
        edit2.commit();
        return true;
    }

    public boolean a(StoreItem storeItem) {
        if (storeItem == null) {
            return false;
        }
        synchronized (this.f1057b) {
            if (this.f1056a == null) {
                this.f1056a = new StoreItem[0];
            }
            StoreItem[] storeItemArr = (StoreItem[]) Arrays.copyOf(this.f1056a, this.f1056a.length + 1);
            this.f1056a = storeItemArr;
            storeItemArr[storeItemArr.length - 1] = storeItem;
        }
        return true;
    }

    public final String b(String str) {
        if (str != null && str.trim().length() != 0) {
            try {
                SecretKeySpec secretKeySpec = new SecretKeySpec(new byte[]{10, 22, 34, 51, 55, 2, 72, 86, 21, 15, 101, 102, 45, 90, 73, 18}, "AES");
                Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
                cipher.init(1, secretKeySpec);
                String encodeToString = Base64.encodeToString(cipher.doFinal(str.getBytes("UTF-8")), 0);
                if (encodeToString != null) {
                    return encodeToString.trim();
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public void b() {
        synchronized (this.f1057b) {
            if (this.f1056a != null && this.f1056a.length != 0) {
                ArrayList arrayList = new ArrayList();
                for (StoreItem storeItem : this.f1056a) {
                    if (storeItem.status != 0) {
                        arrayList.add(storeItem);
                    }
                }
                this.f1056a = new StoreItem[arrayList.size()];
                for (int i = 0; i < this.f1056a.length; i++) {
                    this.f1056a[i] = (StoreItem) arrayList.get(i);
                }
            }
        }
    }

    public boolean b(Context context) {
        if (context == null) {
            return false;
        }
        try {
            synchronized (this.f1057b) {
                SharedPreferences sharedPreferences = context.getSharedPreferences("EGYPlayerStoreFile", 0);
                if (sharedPreferences == null) {
                    this.f1056a = null;
                    return false;
                }
                String string = sharedPreferences.getString("Items", null);
                if (string == null) {
                    this.f1056a = null;
                    return false;
                }
                String a2 = a(string);
                if (a2 == null) {
                    this.f1056a = null;
                    return false;
                }
                StoreItem[] storeItemArr = (StoreItem[]) new Gson().fromJson(a2, StoreItem[].class);
                if (storeItemArr == null) {
                    storeItemArr = new StoreItem[0];
                }
                this.f1056a = storeItemArr;
                return true;
            }
        } catch (Exception unused) {
            return false;
        }
    }

    public StoreItem c(String str) {
        synchronized (this.f1057b) {
            if (this.f1056a != null && this.f1056a.length != 0) {
                if (str != null && str.trim().length() != 0) {
                    for (StoreItem storeItem : this.f1056a) {
                        if (Objects.equals(storeItem.token, str)) {
                            return storeItem;
                        }
                    }
                    return null;
                }
                return null;
            }
            return null;
        }
    }

    public boolean c(Context context) {
        if (context == null) {
            return false;
        }
        try {
            synchronized (this.f1057b) {
                if (this.f1056a == null) {
                    a(context, null);
                    return false;
                }
                return a(context, new Gson().toJson(this.f1056a, StoreItem[].class));
            }
        } catch (Exception unused) {
            return false;
        }
    }

    public StoreItem d(String str) {
        synchronized (this.f1057b) {
            if (this.f1056a != null && this.f1056a.length != 0) {
                if (str != null && str.trim().length() != 0) {
                    for (StoreItem storeItem : this.f1056a) {
                        if (Objects.equals(storeItem.productID, str) && storeItem.status != 1) {
                            return storeItem;
                        }
                    }
                    return null;
                }
                return null;
            }
            return null;
        }
    }
}
