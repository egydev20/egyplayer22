package c.b.g1;

import android.content.Context;
import android.content.SharedPreferences;
import com.egyplayer.iptv.repository.ReminderItem;
import com.google.gson.Gson;
import java.util.Calendar;
import java.util.Date;

/* loaded from: classes.dex */
public class a {

    /* renamed from: b, reason: collision with root package name */
    public static a f1053b;

    /* renamed from: a, reason: collision with root package name */
    public ReminderItem[] f1054a;

    public static a a() {
        if (f1053b == null) {
            f1053b = new a();
        }
        return f1053b;
    }

    public int a(Context context) {
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences("EGYPlayerFile", 0);
            if (sharedPreferences == null) {
                return 0;
            }
            return sharedPreferences.getInt("HomeMigrationStatus1", 0);
        } catch (Exception unused) {
            return 0;
        }
    }

    public ReminderItem a(Context context, Date date) {
        ReminderItem reminderItem;
        try {
            long time = date.getTime();
            if (this.f1054a != null && this.f1054a.length != 0) {
                for (int i = 0; i < this.f1054a.length; i++) {
                    reminderItem = this.f1054a[i];
                    if (reminderItem.minTime <= 0 || time >= reminderItem.minTime) {
                        if (reminderItem.type == 0) {
                            if (reminderItem.status == 0) {
                                if (180000 + time >= reminderItem.startTime && time <= reminderItem.endTime) {
                                    break;
                                }
                            } else if (reminderItem.status == 2 && reminderItem.snoozeTime > 0 && time >= reminderItem.snoozeTime && time <= reminderItem.endTime) {
                                break;
                            }
                        } else if (reminderItem.days != null && reminderItem.days.length != 0) {
                            Calendar calendar = Calendar.getInstance();
                            calendar.setTime(date);
                            if (reminderItem.hasRecurringDay(calendar.get(7))) {
                                Date a2 = a(new Date(reminderItem.startTime), date);
                                Date a3 = a(new Date(reminderItem.endTime), date);
                                if (reminderItem.status == 0) {
                                    if (180000 + time >= a2.getTime() && time <= a3.getTime()) {
                                        break;
                                    }
                                } else if (reminderItem.status == 0 && reminderItem.snoozeTime > 0 && time >= reminderItem.snoozeTime && time <= a3.getTime()) {
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        } catch (Exception unused) {
        }
        reminderItem = null;
        if (reminderItem == null) {
            return null;
        }
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(date);
        calendar2.add(10, 22);
        reminderItem.minTime = calendar2.getTime().getTime();
        reminderItem.status = 0;
        try {
            a(context, this.f1054a == null ? null : new Gson().toJson(this.f1054a, ReminderItem[].class));
        } catch (Exception unused2) {
        }
        return reminderItem;
    }

    public final Date a(Date date, Date date2) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        Calendar calendar2 = Calendar.getInstance();
        calendar2.setTime(date2);
        int i = calendar.get(11);
        int i2 = calendar.get(12);
        int i3 = calendar.get(13);
        int i4 = calendar2.get(1);
        int i5 = calendar2.get(2);
        int i6 = calendar2.get(5);
        Calendar calendar3 = Calendar.getInstance();
        calendar3.set(i4, i5, i6, i, i2, i3);
        return calendar3.getTime();
    }

    public boolean a(Context context, int i) {
        try {
            SharedPreferences.Editor edit = context.getSharedPreferences("EGYPlayerFile", 0).edit();
            edit.putInt("HomeMigrationStatus1", i);
            edit.commit();
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public boolean a(Context context, String str) {
        try {
            SharedPreferences.Editor edit = context.getSharedPreferences("EGYPlayerFile", 0).edit();
            edit.putString("Reminders", str);
            edit.commit();
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public int b(Context context) {
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences("EGYPlayerFile", 0);
            if (sharedPreferences == null) {
                return 0;
            }
            return sharedPreferences.getInt("HomeMigrationStatus2", 0);
        } catch (Exception unused) {
            return 0;
        }
    }

    public boolean b(Context context, int i) {
        try {
            SharedPreferences.Editor edit = context.getSharedPreferences("EGYPlayerFile", 0).edit();
            edit.putInt("HomeMigrationStatus2", i);
            edit.commit();
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public String c(Context context) {
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences("EGYPlayerFile", 0);
            if (sharedPreferences == null) {
                return null;
            }
            return sharedPreferences.getString("PlayerType", null);
        } catch (Exception unused) {
            return null;
        }
    }
}
