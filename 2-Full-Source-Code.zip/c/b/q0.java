package c.b;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.os.Build;
import android.os.FileObserver;
import android.os.Handler;
import android.view.KeyEvent;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import c.a.a.a.e;
import com.egyplayer.iptv.R;
import com.google.android.exoplayer2.ui.PlayerView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Objects;
import org.videolan.libvlc.util.VLCVideoLayout;

/* loaded from: classes.dex */
public class q0 extends Activity implements u0, w0 {

    /* renamed from: b, reason: collision with root package name */
    public WebView f1096b;

    /* renamed from: c, reason: collision with root package name */
    public f1 f1097c;

    /* renamed from: d, reason: collision with root package name */
    public ArrayList<v0> f1098d;
    public File e;
    public File f;
    public File g;
    public ArrayList<FileObserver> h;
    public x0 j;
    public int i = 1973;
    public String k = "Download/EGYPlayer";
    public String l = "EGYPlayer";
    public String m = "EGY PLAYER";

    /* loaded from: classes.dex */
    public class a extends WebViewClient {
        public a(q0 q0Var) {
        }

        @Override // android.webkit.WebViewClient
        public void onPageFinished(WebView webView, String str) {
            webView.setBackgroundColor(0);
            webView.setLayerType(1, null);
        }

        @Override // android.webkit.WebViewClient
        public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest webResourceRequest) {
            return false;
        }
    }

    /* loaded from: classes.dex */
    public class b extends WebChromeClient {
        public b(q0 q0Var) {
        }

        @Override // android.webkit.WebChromeClient
        public Bitmap getDefaultVideoPoster() {
            Bitmap createBitmap = Bitmap.createBitmap(5, 5, Bitmap.Config.RGB_565);
            new Canvas(createBitmap).drawARGB(0, 0, 0, 0);
            return createBitmap;
        }
    }

    /* loaded from: classes.dex */
    public class c extends FileObserver {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ String f1099a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public c(String str, String str2) {
            super(str);
            this.f1099a = str2;
        }

        @Override // android.os.FileObserver
        public void onEvent(int i, String str) {
            q0.a(q0.this, this, this.f1099a, i, str);
        }
    }

    /* loaded from: classes.dex */
    public class d extends FileObserver {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ String f1101a;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public d(File file, String str) {
            super(file);
            this.f1101a = str;
        }

        @Override // android.os.FileObserver
        public void onEvent(int i, String str) {
            q0.a(q0.this, this, this.f1101a, i, str);
        }
    }

    /* loaded from: classes.dex */
    public class e implements c.c.a.a.g.a {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ int f1103a;

        public e(int i) {
            this.f1103a = i;
        }
    }

    /* loaded from: classes.dex */
    public class f implements DialogInterface.OnDismissListener {
        public f() {
        }

        @Override // android.content.DialogInterface.OnDismissListener
        public void onDismiss(DialogInterface dialogInterface) {
            p0.b(q0.this);
        }
    }

    public static /* synthetic */ void a(q0 q0Var, FileObserver fileObserver, String str, int i, String str2) {
        if (q0Var == null) {
            throw null;
        }
        if (str2 != null) {
            try {
                if (str2.trim().startsWith("vlc-record") && i == 8) {
                    q0Var.f1097c.a(new File(str, str2));
                    q0Var.a(fileObserver);
                }
            } catch (Exception unused) {
            }
        }
    }

    public final void a(FileObserver fileObserver) {
        if (fileObserver == null) {
            return;
        }
        try {
            synchronized (this.h) {
                this.h.remove(fileObserver);
            }
            fileObserver.stopWatching();
        } catch (Exception unused) {
        }
    }

    public final void a(File file) {
        try {
            File[] listFiles = file.listFiles();
            if (listFiles != null && listFiles.length > 0) {
                for (File file2 : listFiles) {
                    if (file2.isDirectory()) {
                        a(file2);
                    } else {
                        file2.delete();
                    }
                }
            }
            file.delete();
        } catch (Exception unused) {
        }
    }

    @Override // c.b.u0
    public void a(String str) {
        try {
            FileObserver cVar = Build.VERSION.SDK_INT < 29 ? new c(str, str) : new d(new File(str), str);
            cVar.startWatching();
            synchronized (this.h) {
                this.h.add(cVar);
            }
        } catch (Exception unused) {
        }
    }

    @Override // c.b.u0
    public void a(boolean z) {
        try {
            ((FrameLayout) findViewById(R.id.playerBackground)).setVisibility(!z ? 4 : 0);
        } catch (Exception unused) {
        }
    }

    @Override // c.b.u0
    public f1 b() {
        return this.f1097c;
    }

    @Override // c.b.w0
    public void b(boolean z) {
        Handler handler;
        Handler handler2;
        if (z) {
            final f1 f1Var = this.f1097c;
            if (f1Var == null || (handler = f1Var.k) == null) {
                return;
            }
            handler.post(new Runnable() { // from class: c.b.l0
                @Override // java.lang.Runnable
                public final void run() {
                    f1.this.c();
                }
            });
            return;
        }
        p0.b(this);
        final f1 f1Var2 = this.f1097c;
        if (f1Var2 == null || (handler2 = f1Var2.k) == null) {
            return;
        }
        handler2.post(new Runnable() { // from class: c.b.i0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.b();
            }
        });
    }

    public boolean b(String str) {
        return true;
    }

    @Override // c.b.u0
    public void c() {
        try {
            if (this.f1098d != null && this.f1098d.size() > 0) {
                for (int i = 0; i < this.f1098d.size(); i++) {
                    this.f1098d.get(i).d();
                }
                this.f1098d.clear();
                this.f1096b.removeJavascriptInterface("PlayerInterface1");
                this.f1096b.removeJavascriptInterface("PlayerInterface2");
            }
            e();
        } catch (Exception unused) {
        }
    }

    public final void d() {
        File file = this.e;
        if (file != null) {
            file.getAbsolutePath();
        }
        File file2 = this.f;
        String absolutePath = file2 != null ? file2.getAbsolutePath() : null;
        File file3 = this.g;
        String absolutePath2 = file3 != null ? file3.getAbsolutePath() : null;
        f1 f1Var = this.f1097c;
        if (f1Var != null) {
            if (f1Var == null) {
                throw null;
            }
            if (f1Var != null) {
                try {
                    f1Var.f = absolutePath;
                } catch (Exception unused) {
                }
                f1 f1Var2 = this.f1097c;
                if (f1Var2 == null) {
                    throw null;
                }
                try {
                    f1Var2.g = absolutePath2;
                } catch (Exception unused2) {
                }
            } else {
                throw null;
            }
        }
        if (this.f1098d != null) {
            for (int i = 0; i < this.f1098d.size(); i++) {
                this.f1098d.get(i).a(absolutePath);
            }
        }
    }

    @Override // android.app.Activity, android.view.Window.Callback
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        try {
            int keyCode = keyEvent.getKeyCode();
            if (keyEvent.getAction() == 0) {
                if (keyCode == 4) {
                    this.f1096b.evaluateJavascript("Main.sendBackKey();", null);
                    return true;
                }
                this.f1097c.f1047d = keyCode;
            }
            return super.dispatchKeyEvent(keyEvent);
        } catch (Exception unused) {
            return super.dispatchKeyEvent(keyEvent);
        }
    }

    public final void e() {
        v0 d1Var;
        v0 d1Var2;
        try {
            this.f1098d = new ArrayList<>();
            String c2 = c.b.g1.a.a().c(this);
            if (c2 == null) {
                if (this.f1097c.getSDKVersionValue() > 27) {
                    long deviceMemory = this.f1097c.getDeviceMemory();
                    if ((deviceMemory <= 0 || deviceMemory >= 2147483648L) && this.f1097c.isTVDevice() != 1 && this.f1097c.hasRemoteControl() != 1 && this.f1097c.hasFeature("android.software.live_tv") != 1) {
                        c2 = "VLC";
                        this.f1097c.f(c2);
                    }
                }
                c2 = "EXO";
                this.f1097c.f(c2);
            }
            VLCVideoLayout vLCVideoLayout = (VLCVideoLayout) findViewById(R.id.vlc_player_view1);
            VLCVideoLayout vLCVideoLayout2 = (VLCVideoLayout) findViewById(R.id.vlc_player_view2);
            PlayerView playerView = (PlayerView) findViewById(R.id.exo_player_view1);
            PlayerView playerView2 = (PlayerView) findViewById(R.id.exo_player_view2);
            if (Objects.equals(c2, "VLC")) {
                d1Var = new e1(this, this.f1096b, vLCVideoLayout, 1);
                this.f1096b.addJavascriptInterface(d1Var, "PlayerInterface1");
                d1Var2 = new e1(this, this.f1096b, vLCVideoLayout2, 2);
                this.f1096b.addJavascriptInterface(d1Var2, "PlayerInterface2");
                playerView.setVisibility(4);
                playerView2.setVisibility(4);
            } else {
                d1Var = new d1(this, this.f1096b, playerView, 1);
                this.f1096b.addJavascriptInterface(d1Var, "PlayerInterface1");
                d1Var2 = new d1(this, this.f1096b, playerView2, 2);
                this.f1096b.addJavascriptInterface(d1Var2, "PlayerInterface2");
                vLCVideoLayout.setVisibility(4);
                vLCVideoLayout2.setVisibility(4);
            }
            this.f1098d.add(d1Var);
            this.f1098d.add(d1Var2);
        } catch (Exception unused) {
        }
    }

    /*  JADX ERROR: JadxRuntimeException in pass: RegionMakerVisitor
        jadx.core.utils.exceptions.JadxRuntimeException: Can't find top splitter block for handler:B:19:0x00b4
        	at jadx.core.utils.BlockUtils.getTopSplitterForHandler(BlockUtils.java:1166)
        	at jadx.core.dex.visitors.regions.RegionMaker.processTryCatchBlocks(RegionMaker.java:1022)
        	at jadx.core.dex.visitors.regions.RegionMakerVisitor.visit(RegionMakerVisitor.java:55)
        */
    public final void f() {
        /*
            r8 = this;
            java.lang.String r0 = "Backups"
            java.lang.String r1 = "Recordings"
            java.io.File r2 = new java.io.File     // Catch: java.lang.Exception -> L6c
            java.io.File r3 = android.os.Environment.getExternalStorageDirectory()     // Catch: java.lang.Exception -> L6c
            java.lang.String r4 = r8.k     // Catch: java.lang.Exception -> L6c
            r2.<init>(r3, r4)     // Catch: java.lang.Exception -> L6c
            r8.e = r2     // Catch: java.lang.Exception -> L6c
            java.io.File r2 = new java.io.File     // Catch: java.lang.Exception -> L6c
            java.io.File r3 = android.os.Environment.getExternalStorageDirectory()     // Catch: java.lang.Exception -> L6c
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L6c
            r4.<init>()     // Catch: java.lang.Exception -> L6c
            java.lang.String r5 = r8.k     // Catch: java.lang.Exception -> L6c
            r4.append(r5)     // Catch: java.lang.Exception -> L6c
            java.lang.String r5 = java.io.File.separator     // Catch: java.lang.Exception -> L6c
            r4.append(r5)     // Catch: java.lang.Exception -> L6c
            r4.append(r1)     // Catch: java.lang.Exception -> L6c
            java.lang.String r4 = r4.toString()     // Catch: java.lang.Exception -> L6c
            r2.<init>(r3, r4)     // Catch: java.lang.Exception -> L6c
            r8.f = r2     // Catch: java.lang.Exception -> L6c
            boolean r2 = r2.exists()     // Catch: java.lang.Exception -> L6c
            if (r2 != 0) goto L3d
            java.io.File r2 = r8.f     // Catch: java.lang.Exception -> L6c
            r2.mkdirs()     // Catch: java.lang.Exception -> L6c
        L3d:
            java.io.File r2 = new java.io.File     // Catch: java.lang.Exception -> L6c
            java.io.File r3 = android.os.Environment.getExternalStorageDirectory()     // Catch: java.lang.Exception -> L6c
            java.lang.StringBuilder r4 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L6c
            r4.<init>()     // Catch: java.lang.Exception -> L6c
            java.lang.String r5 = r8.k     // Catch: java.lang.Exception -> L6c
            r4.append(r5)     // Catch: java.lang.Exception -> L6c
            java.lang.String r5 = java.io.File.separator     // Catch: java.lang.Exception -> L6c
            r4.append(r5)     // Catch: java.lang.Exception -> L6c
            r4.append(r0)     // Catch: java.lang.Exception -> L6c
            java.lang.String r4 = r4.toString()     // Catch: java.lang.Exception -> L6c
            r2.<init>(r3, r4)     // Catch: java.lang.Exception -> L6c
            r8.g = r2     // Catch: java.lang.Exception -> L6c
            boolean r2 = r2.exists()     // Catch: java.lang.Exception -> L6c
            if (r2 != 0) goto L69
            java.io.File r2 = r8.g     // Catch: java.lang.Exception -> L6c
            r2.mkdirs()     // Catch: java.lang.Exception -> L6c
        L69:
            r8.d()     // Catch: java.lang.Exception -> L6c
        L6c:
            r2 = 1
            r3 = 2
            c.b.g1.a r4 = c.b.g1.a.a()     // Catch: java.lang.Exception -> Lb4
            int r4 = r4.a(r8)     // Catch: java.lang.Exception -> Lb4
            if (r4 != r3) goto L79
            goto Lb4
        L79:
            java.io.File r4 = new java.io.File     // Catch: java.lang.Exception -> Lb4
            java.io.File r5 = android.os.Environment.getExternalStorageDirectory()     // Catch: java.lang.Exception -> Lb4
            java.lang.String r6 = r8.l     // Catch: java.lang.Exception -> Lb4
            r4.<init>(r5, r6)     // Catch: java.lang.Exception -> Lb4
            boolean r5 = r4.exists()     // Catch: java.lang.Exception -> Lb4
            if (r5 != 0) goto L92
        L8a:
            c.b.g1.a r4 = c.b.g1.a.a()     // Catch: java.lang.Exception -> Lb4
            r4.a(r8, r2)     // Catch: java.lang.Exception -> Lb4
            goto Lb4
        L92:
            java.io.File r5 = new java.io.File     // Catch: java.lang.Exception -> Lb4
            java.io.File r6 = android.os.Environment.getExternalStorageDirectory()     // Catch: java.lang.Exception -> Lb4
            java.lang.String r7 = r8.k     // Catch: java.lang.Exception -> Lb4
            r5.<init>(r6, r7)     // Catch: java.lang.Exception -> Lb4
            boolean r6 = r5.exists()     // Catch: java.lang.Exception -> Lb4
            if (r6 != 0) goto La4
            goto L8a
        La4:
            r8.a(r4, r5, r1)     // Catch: java.lang.Exception -> Laa
            r8.a(r4, r5, r0)     // Catch: java.lang.Exception -> Laa
        Laa:
            r8.a(r4)     // Catch: java.lang.Exception -> Lb4
            c.b.g1.a r4 = c.b.g1.a.a()     // Catch: java.lang.Exception -> Lb4
            r4.a(r8, r3)     // Catch: java.lang.Exception -> Lb4
        Lb4:
            c.b.g1.a r4 = c.b.g1.a.a()     // Catch: java.lang.Exception -> Lfa
            int r4 = r4.b(r8)     // Catch: java.lang.Exception -> Lfa
            if (r4 != r3) goto Lbf
            goto Lfa
        Lbf:
            java.io.File r4 = new java.io.File     // Catch: java.lang.Exception -> Lfa
            java.io.File r5 = android.os.Environment.getExternalStorageDirectory()     // Catch: java.lang.Exception -> Lfa
            java.lang.String r6 = r8.m     // Catch: java.lang.Exception -> Lfa
            r4.<init>(r5, r6)     // Catch: java.lang.Exception -> Lfa
            boolean r5 = r4.exists()     // Catch: java.lang.Exception -> Lfa
            if (r5 != 0) goto Ld8
        Ld0:
            c.b.g1.a r0 = c.b.g1.a.a()     // Catch: java.lang.Exception -> Lfa
            r0.b(r8, r2)     // Catch: java.lang.Exception -> Lfa
            goto Lfa
        Ld8:
            java.io.File r5 = new java.io.File     // Catch: java.lang.Exception -> Lfa
            java.io.File r6 = android.os.Environment.getExternalStorageDirectory()     // Catch: java.lang.Exception -> Lfa
            java.lang.String r7 = r8.k     // Catch: java.lang.Exception -> Lfa
            r5.<init>(r6, r7)     // Catch: java.lang.Exception -> Lfa
            boolean r6 = r5.exists()     // Catch: java.lang.Exception -> Lfa
            if (r6 != 0) goto Lea
            goto Ld0
        Lea:
            r8.a(r4, r5, r1)     // Catch: java.lang.Exception -> Lf0
            r8.a(r4, r5, r0)     // Catch: java.lang.Exception -> Lf0
        Lf0:
            r8.a(r4)     // Catch: java.lang.Exception -> Lfa
            c.b.g1.a r0 = c.b.g1.a.a()     // Catch: java.lang.Exception -> Lfa
            r0.b(r8, r3)     // Catch: java.lang.Exception -> Lfa
        Lfa:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.q0.f():void");
    }

    public void g() {
        if (p0.a((Activity) this) == 0) {
            try {
                requestWindowFeature(1);
                getWindow().setFlags(1024, 1024);
            } catch (Exception unused) {
            }
        }
    }

    @Override // android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        if (i != this.i || i2 == -1) {
            return;
        }
        finish();
    }

    /* JADX WARN: Removed duplicated region for block: B:10:0x002b A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:12:0x002c  */
    @Override // android.app.Activity
    @android.annotation.SuppressLint({"SetJavaScriptEnabled"})
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onCreate(android.os.Bundle r12) {
        /*
            Method dump skipped, instructions count: 315
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.q0.onCreate(android.os.Bundle):void");
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        try {
            if (this.f1098d == null || this.f1098d.size() <= 0) {
                return;
            }
            for (int i = 0; i < this.f1098d.size(); i++) {
                this.f1098d.get(i).d();
            }
            this.f1098d.clear();
        } catch (Exception unused) {
        }
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        try {
            if (this.f1096b == null || this.f1097c == null || !this.f1097c.isAppLoaded()) {
                return;
            }
            this.f1096b.evaluateJavascript("Main.onHostAppHidden();", null);
        } catch (Exception unused) {
        }
    }

    @Override // android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        try {
            if (iArr.length <= 0 || iArr[0] != 0) {
                return;
            }
            f();
        } catch (Exception unused) {
        }
    }

    @Override // android.app.Activity
    public void onResume() {
        super.onResume();
        try {
            boolean z = false;
            if (!(this.j.f1126d != null)) {
                this.j.d();
            }
            x0 x0Var = this.j;
            if (x0Var.e && x0Var.f1126d.a()) {
                this.j.e();
            } else {
                this.j.f();
            }
            if (this.f1096b != null && this.f1097c != null) {
                if (this.f1097c.isAppLoaded()) {
                    this.f1096b.evaluateJavascript("Main.onHostAppShown();", null);
                }
                if (this.f1098d != null && this.f1098d.size() > 0) {
                    for (int i = 0; i < this.f1098d.size(); i++) {
                        this.f1098d.get(i).c();
                    }
                }
                f1 f1Var = this.f1097c;
                if (f1Var != null) {
                    z = f1Var.hasStorageAccessPermission();
                }
                if (z) {
                    f();
                }
            }
        } catch (Exception unused) {
        }
    }

    @Override // android.app.Activity
    public void onStop() {
        super.onStop();
        try {
            if (this.f1098d == null || this.f1098d.size() <= 0) {
                return;
            }
            for (int i = 0; i < this.f1098d.size(); i++) {
                this.f1098d.get(i).e();
            }
        } catch (Exception unused) {
        }
    }

    public final void a(File file, File file2, String str) {
        File[] listFiles;
        FileChannel fileChannel;
        try {
            File file3 = new File(file, str);
            if (!file3.exists() || (listFiles = file3.listFiles()) == null || listFiles.length <= 0) {
                return;
            }
            for (File file4 : listFiles) {
                if (!file4.isDirectory()) {
                    File file5 = new File(new File(file2, str), file4.getName());
                    FileChannel fileChannel2 = null;
                    try {
                        FileChannel channel = new FileInputStream(file4).getChannel();
                        try {
                            fileChannel2 = new FileOutputStream(file5).getChannel();
                            fileChannel2.transferFrom(channel, 0L, channel.size());
                            channel.close();
                            fileChannel2.close();
                        } catch (Throwable th) {
                            th = th;
                            fileChannel = fileChannel2;
                            fileChannel2 = channel;
                            if (fileChannel2 != null) {
                                fileChannel2.close();
                            }
                            if (fileChannel != null) {
                                fileChannel.close();
                            }
                            throw th;
                        }
                    } catch (Throwable th2) {
                        th = th2;
                        fileChannel = null;
                    }
                }
            }
        } catch (Exception unused) {
        }
    }

    @Override // c.b.u0
    public void a() {
        try {
            ((FrameLayout) findViewById(R.id.loading_background)).setVisibility(4);
            ((ProgressBar) findViewById(R.id.loading_progress)).setVisibility(4);
            ((TextView) findViewById(R.id.loading_text)).setVisibility(4);
        } catch (Exception unused) {
        }
        f1 f1Var = this.f1097c;
        if (f1Var == null ? false : f1Var.hasStorageAccessPermission()) {
            f();
        }
        ArrayList<v0> arrayList = this.f1098d;
        if (arrayList == null || arrayList.size() <= 0) {
            return;
        }
        for (int i = 0; i < this.f1098d.size(); i++) {
            this.f1098d.get(i).a();
        }
    }

    @Override // c.b.u0
    public void a(String str, int i) {
        c.c.a.a.h.a aVar = new c.c.a.a.h.a();
        aVar.f1147a = 0;
        aVar.f1148b = 0;
        aVar.f1149c = new File("/mnt");
        aVar.f1150d = new File("/mnt");
        aVar.e = new File("/mnt");
        if (i == 1) {
            aVar.f = new String[]{"m3u", "m3u8"};
        } else {
            aVar.f = null;
        }
        c.c.a.a.j.a aVar2 = new c.c.a.a.j.a(this, aVar);
        aVar2.setTitle(str);
        aVar2.h = new e(i);
        aVar2.setOnDismissListener(new f());
        aVar2.show();
    }

    @Override // c.b.u0
    public void a(String str, String str2) {
        if (str == null && str2 == null) {
            return;
        }
        if (str != null) {
            try {
                if (str.length() > 0) {
                    ((FrameLayout) findViewById(R.id.mainLayout)).setBackgroundColor(Color.parseColor(str));
                }
            } catch (Exception unused) {
                return;
            }
        }
        if (str2 != null) {
            String lowerCase = str2.trim().toLowerCase();
            Resources resources = getResources();
            ((FrameLayout) findViewById(R.id.mainLayout)).setBackground(resources.getDrawable(resources.getIdentifier(lowerCase, "drawable", getPackageName()), null));
        }
    }

    @Override // c.b.u0
    public int a(int i, String str, String str2, String str3) {
        x0 x0Var = this.j;
        if (x0Var == null) {
            return 1;
        }
        x0Var.h = i;
        x0Var.k = str;
        x0Var.i = str2;
        x0Var.j = str3;
        try {
            if (x0Var.f1126d.a() && x0Var.e) {
                if (str2 != null && str2.trim().length() != 0) {
                    if (str3 != null && str3.trim().length() != 0) {
                        String c2 = x0Var.c(i);
                        if (c2 == null) {
                            return 9;
                        }
                        c.a.a.a.k d2 = x0Var.d(c2);
                        if (d2 == null) {
                            return 6;
                        }
                        x0Var.a(str2, str3, c2, str);
                        String str4 = "ACC-" + str2 + '-' + str3;
                        e.a aVar = new e.a(null);
                        ArrayList<c.a.a.a.k> arrayList = new ArrayList<>();
                        arrayList.add(d2);
                        aVar.f947c = arrayList;
                        aVar.f945a = str4;
                        return x0Var.f1126d.a((Activity) x0Var.f1123a, aVar.a()).f950a == 0 ? 0 : 10;
                    }
                    return 4;
                }
                return 3;
            }
            return 5;
        } catch (Exception unused) {
            return 1;
        }
    }
}
