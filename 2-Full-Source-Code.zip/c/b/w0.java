package c.b;

/* loaded from: classes.dex */
public interface w0 {
    void b(boolean z);
}
