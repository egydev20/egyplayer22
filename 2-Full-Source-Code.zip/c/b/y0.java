package c.b;

/* loaded from: classes.dex */
public class y0 implements c.a.a.a.m {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ x0 f1131a;

    public y0(x0 x0Var) {
        this.f1131a = x0Var;
    }
}
