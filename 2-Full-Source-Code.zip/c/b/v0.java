package c.b;

/* loaded from: classes.dex */
public interface v0 {
    void a();

    void a(String str);

    void c();

    void d();

    void e();
}
