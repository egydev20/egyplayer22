package c.b;

import android.graphics.Rect;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewTreeObserver;

/* loaded from: classes.dex */
public class r0 implements ViewTreeObserver.OnGlobalLayoutListener {

    /* renamed from: b, reason: collision with root package name */
    public boolean f1108b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1109c = 48 + 100;

    /* renamed from: d, reason: collision with root package name */
    public final Rect f1110d = new Rect();
    public final /* synthetic */ View e;
    public final /* synthetic */ w0 f;

    public r0(q0 q0Var, View view, w0 w0Var) {
        this.e = view;
        this.f = w0Var;
    }

    @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
    public void onGlobalLayout() {
        try {
            boolean z = true;
            int applyDimension = (int) TypedValue.applyDimension(1, this.f1109c, this.e.getResources().getDisplayMetrics());
            this.e.getWindowVisibleDisplayFrame(this.f1110d);
            if (this.e.getRootView().getHeight() - (this.f1110d.bottom - this.f1110d.top) < applyDimension) {
                z = false;
            }
            if (z == this.f1108b) {
                return;
            }
            this.f1108b = z;
            this.f.b(z);
        } catch (Exception unused) {
        }
    }
}
