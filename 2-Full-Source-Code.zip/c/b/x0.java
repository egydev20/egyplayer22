package c.b;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.RingtoneManager;
import android.net.Uri;
import android.util.Base64;
import c.a.a.a.i;
import com.egyplayer.iptv.NormalMainActivity;
import com.egyplayer.iptv.R;
import com.egyplayer.iptv.TVMainActivity;
import com.egyplayer.iptv.repository.StoreItem;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class x0 implements c.a.a.a.j {

    /* renamed from: a, reason: collision with root package name */
    public Context f1123a;

    /* renamed from: b, reason: collision with root package name */
    public f1 f1124b;

    /* renamed from: c, reason: collision with root package name */
    public NotificationManager f1125c;

    /* renamed from: d, reason: collision with root package name */
    public c.a.a.a.b f1126d;
    public boolean e;
    public List<c.a.a.a.k> f;
    public boolean g;
    public int h;
    public String i;
    public String j;
    public String k;
    public List<String> l;
    public List<String> m;
    public List<String> n;
    public List<String> o;
    public List<String> p;
    public List<String> q = new ArrayList();

    /* loaded from: classes.dex */
    public class a implements c.a.a.a.d {
        public a() {
        }

        public void a(c.a.a.a.f fVar) {
            if (fVar.f950a == 0) {
                x0 x0Var = x0.this;
                x0Var.e = true;
                try {
                    ArrayList arrayList = new ArrayList();
                    arrayList.addAll(x0Var.l);
                    arrayList.addAll(x0Var.m);
                    arrayList.addAll(x0Var.n);
                    arrayList.addAll(x0Var.o);
                    ArrayList arrayList2 = new ArrayList(arrayList);
                    c.a.a.a.b bVar = x0Var.f1126d;
                    c.a.a.a.l lVar = new c.a.a.a.l();
                    lVar.f979a = "inapp";
                    lVar.f981c = arrayList2;
                    lVar.f980b = null;
                    bVar.a(lVar, new y0(x0Var));
                } catch (Exception unused) {
                }
                x0.this.e();
            }
        }
    }

    public x0(Context context, f1 f1Var, boolean z, NotificationManager notificationManager) {
        this.f1123a = context;
        this.f1124b = f1Var;
        this.f1125c = notificationManager;
        ArrayList arrayList = new ArrayList();
        this.l = arrayList;
        arrayList.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW/Q2bFFalccJ6KqzFJZ6dek="));
        this.l.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW4ap2LnxLceP7jlfR/b650Y="));
        this.l.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiWzSeVwgEyfDtm4E4lE6OmV4="));
        this.l.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW6CVMX+aiJZ8Tr5UTBEtmvA="));
        ArrayList arrayList2 = new ArrayList();
        this.m = arrayList2;
        arrayList2.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiWxxkH8Z/aVwqbAthuMJcFGM="));
        this.m.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW9BowTNtJi1PK96r2m1ERdE="));
        this.m.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW5uFn+mvQ1wiLa+a+OPTMBU="));
        this.m.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiWxLH4gSI0KgEr5SZKFPn/04="));
        ArrayList arrayList3 = new ArrayList();
        this.n = arrayList3;
        arrayList3.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW19ver52r0SXklIA+d7aab92jITJgDOxFcTKinONGNlZ"));
        this.n.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW19ver52r0SXklIA+d7aab9pPOhZ2MeMv6Pinqmc1X0J"));
        this.n.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW19ver52r0SXklIA+d7aab9VeYA5AEBsk33ygQ9TvwOz"));
        this.n.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW19ver52r0SXklIA+d7aab9TrjWV5JngNGU4kQwPRLSK"));
        ArrayList arrayList4 = new ArrayList();
        this.o = arrayList4;
        arrayList4.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW5eUueCCzFOUnl3ezqXC5fDpIjyNcePHqN4f53HLGtX0"));
        this.o.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW5eUueCCzFOUnl3ezqXC5fA95KHPM9gFjJdv/xMc5TRl"));
        this.o.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW5eUueCCzFOUnl3ezqXC5fCqwroi01GwZzsameA91abb"));
        this.o.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW5eUueCCzFOUnl3ezqXC5fBtMHg3j//aa2w/JliIzh5O"));
        ArrayList arrayList5 = new ArrayList();
        this.p = arrayList5;
        arrayList5.add(p0.a(this.f1123a, "i0rrCQ2AFhh2gFQIZ9hiW0bngsHdE7XvFkZ/JNUDFQ4="));
    }

    public final String a(String str) {
        if (str != null && str.trim().length() != 0) {
            try {
                IvParameterSpec ivParameterSpec = new IvParameterSpec(a(0));
                SecretKeySpec secretKeySpec = new SecretKeySpec(b(0), "AES");
                byte[] decode = Base64.decode(str, 0);
                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
                cipher.init(2, secretKeySpec, ivParameterSpec);
                return new String(cipher.doFinal(decode), "UTF-8");
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public final void a(StoreItem storeItem) {
        c.a.a.a.f b2;
        try {
            String str = storeItem.token;
            if (str != null) {
                c.a.a.a.g gVar = new c.a.a.a.g(null);
                gVar.f955a = str;
                a1 a1Var = new a1(this, storeItem);
                c.a.a.a.c cVar = (c.a.a.a.c) this.f1126d;
                if (!cVar.a()) {
                    b2 = c.a.a.a.w.j;
                } else if (cVar.a(new c.a.a.a.g0(cVar, gVar, a1Var), 30000L, new c.a.a.a.f0(a1Var, gVar)) != null) {
                    return;
                } else {
                    b2 = cVar.b();
                }
                a1Var.a(b2, gVar.f955a);
                return;
            }
            throw new IllegalArgumentException("Purchase token must be set");
        } catch (Exception unused) {
        }
    }

    public final void a(StoreItem storeItem, int i) {
        try {
            if (this.f1124b == null) {
                return;
            }
            if (storeItem != null) {
                this.f1124b.b(c(storeItem.productID), storeItem.planName, storeItem.targetMAC, storeItem.targetKey, storeItem.orderID, i);
            } else {
                this.f1124b.b(this.h, this.k, this.i, this.j, "", i);
            }
        } catch (Exception unused) {
        }
    }

    public final byte[] a(int i) {
        byte[] a2 = p0.a(this.f1123a.getString(R.string.tib1));
        byte[] a3 = p0.a(this.f1123a.getString(R.string.tib2));
        byte[] a4 = p0.a(this.f1123a.getString(R.string.tib3));
        byte[] a5 = p0.a(this.f1123a.getString(R.string.tib4));
        for (int i2 = 0; i2 < a2.length; i2++) {
            a2[i2] = (byte) (a2[i2] & a3[i2]);
            if (a2[i2] > a3[i2]) {
                return a2;
            }
        }
        for (int i3 = 0; i3 < a3.length; i3++) {
            a3[i3] = (byte) (a3[i3] & a5[i3]);
            if (a3[i3] > a5[i3]) {
                return a3;
            }
        }
        return i + 7 > 16 ? a5 : a4;
    }

    public final String b() {
        c.b.g1.a a2 = c.b.g1.a.a();
        Context context = this.f1123a;
        if (a2 == null) {
            throw null;
        }
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences("EGYPlayerFile", 0);
            if (sharedPreferences == null) {
                return null;
            }
            return sharedPreferences.getString("deviceMAC", "");
        } catch (Exception unused) {
            return null;
        }
    }

    public final String b(String str) {
        if (str != null && str.trim().length() != 0) {
            try {
                IvParameterSpec ivParameterSpec = new IvParameterSpec(a(0));
                SecretKeySpec secretKeySpec = new SecretKeySpec(b(0), "AES");
                Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
                cipher.init(1, secretKeySpec, ivParameterSpec);
                String encodeToString = Base64.encodeToString(cipher.doFinal(str.getBytes("UTF-8")), 0);
                if (encodeToString != null) {
                    return encodeToString.trim();
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public final byte[] b(int i) {
        byte[] a2 = p0.a(this.f1123a.getString(R.string.tkb1));
        byte[] a3 = p0.a(this.f1123a.getString(R.string.tkb2));
        byte[] a4 = p0.a(this.f1123a.getString(R.string.tkb3));
        byte[] a5 = p0.a(this.f1123a.getString(R.string.tkb4));
        for (int i2 = 0; i2 < a2.length; i2++) {
            a2[i2] = (byte) (a2[i2] & a3[i2]);
            if (a2[i2] > a3[i2]) {
                return a2;
            }
        }
        for (int i3 = 0; i3 < a3.length; i3++) {
            a3[i3] = (byte) (a3[i3] & a5[i3]);
            if (a3[i3] > a5[i3]) {
                return a3;
            }
        }
        return i + 7 > 16 ? a5 : a4;
    }

    public final int c(String str) {
        Iterator<String> it = this.l.iterator();
        while (it.hasNext()) {
            if (Objects.equals(str, it.next())) {
                return 1;
            }
        }
        Iterator<String> it2 = this.m.iterator();
        while (it2.hasNext()) {
            if (Objects.equals(str, it2.next())) {
                return 2;
            }
        }
        Iterator<String> it3 = this.n.iterator();
        while (it3.hasNext()) {
            if (Objects.equals(str, it3.next())) {
                return 10;
            }
        }
        Iterator<String> it4 = this.o.iterator();
        while (it4.hasNext()) {
            if (Objects.equals(str, it4.next())) {
                return 20;
            }
        }
        Iterator<String> it5 = this.p.iterator();
        while (it5.hasNext()) {
            if (Objects.equals(str, it5.next())) {
                return 99;
            }
        }
        return 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x0042 A[Catch: Exception -> 0x0090, TryCatch #0 {Exception -> 0x0090, blocks: (B:4:0x000a, B:5:0x0022, B:6:0x002a, B:10:0x0035, B:12:0x0039, B:16:0x0042, B:17:0x0053, B:18:0x0057, B:20:0x005d, B:21:0x0067, B:23:0x006d, B:25:0x0079, B:28:0x007f, B:47:0x0047, B:49:0x004c, B:51:0x0051, B:54:0x000f, B:56:0x0014, B:58:0x0019, B:61:0x0020), top: B:2:0x0008 }] */
    /* JADX WARN: Removed duplicated region for block: B:20:0x005d A[Catch: Exception -> 0x0090, TryCatch #0 {Exception -> 0x0090, blocks: (B:4:0x000a, B:5:0x0022, B:6:0x002a, B:10:0x0035, B:12:0x0039, B:16:0x0042, B:17:0x0053, B:18:0x0057, B:20:0x005d, B:21:0x0067, B:23:0x006d, B:25:0x0079, B:28:0x007f, B:47:0x0047, B:49:0x004c, B:51:0x0051, B:54:0x000f, B:56:0x0014, B:58:0x0019, B:61:0x0020), top: B:2:0x0008 }] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0045  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.String c(int r11) {
        /*
            r10 = this;
            r0 = 0
            r1 = 20
            r2 = 10
            r3 = 0
            r4 = 2
            r5 = 1
            if (r11 != r5) goto Ld
            java.util.List<java.lang.String> r6 = r10.l     // Catch: java.lang.Exception -> L90
            goto L22
        Ld:
            if (r11 != r4) goto L12
            java.util.List<java.lang.String> r6 = r10.m     // Catch: java.lang.Exception -> L90
            goto L22
        L12:
            if (r11 != r2) goto L17
            java.util.List<java.lang.String> r6 = r10.n     // Catch: java.lang.Exception -> L90
            goto L22
        L17:
            if (r11 != r1) goto L1c
            java.util.List<java.lang.String> r6 = r10.o     // Catch: java.lang.Exception -> L90
            goto L22
        L1c:
            r6 = 99
            if (r11 != r6) goto L29
            java.util.List<java.lang.String> r6 = r10.p     // Catch: java.lang.Exception -> L90
        L22:
            java.lang.Object r6 = r6.get(r3)     // Catch: java.lang.Exception -> L90
            java.lang.String r6 = (java.lang.String) r6     // Catch: java.lang.Exception -> L90
            goto L2a
        L29:
            r6 = r0
        L2a:
            c.a.a.a.b r7 = r10.f1126d     // Catch: java.lang.Exception -> L90
            java.lang.String r8 = "inapp"
            c.a.a.a.i$a r7 = r7.a(r8)     // Catch: java.lang.Exception -> L90
            if (r7 != 0) goto L35
            return r6
        L35:
            java.util.List<c.a.a.a.i> r7 = r7.f964a     // Catch: java.lang.Exception -> L90
            if (r7 == 0) goto L8f
            int r8 = r7.size()     // Catch: java.lang.Exception -> L90
            if (r8 != 0) goto L40
            goto L8f
        L40:
            if (r11 != r5) goto L45
            java.util.List<java.lang.String> r11 = r10.l     // Catch: java.lang.Exception -> L90
            goto L53
        L45:
            if (r11 != r4) goto L4a
            java.util.List<java.lang.String> r11 = r10.m     // Catch: java.lang.Exception -> L90
            goto L53
        L4a:
            if (r11 != r2) goto L4f
            java.util.List<java.lang.String> r11 = r10.n     // Catch: java.lang.Exception -> L90
            goto L53
        L4f:
            if (r11 != r1) goto L8f
            java.util.List<java.lang.String> r11 = r10.o     // Catch: java.lang.Exception -> L90
        L53:
            java.util.Iterator r11 = r11.iterator()     // Catch: java.lang.Exception -> L90
        L57:
            boolean r1 = r11.hasNext()     // Catch: java.lang.Exception -> L90
            if (r1 == 0) goto L8f
            java.lang.Object r1 = r11.next()     // Catch: java.lang.Exception -> L90
            java.lang.String r1 = (java.lang.String) r1     // Catch: java.lang.Exception -> L90
            java.util.Iterator r2 = r7.iterator()     // Catch: java.lang.Exception -> L90
        L67:
            boolean r8 = r2.hasNext()     // Catch: java.lang.Exception -> L90
            if (r8 == 0) goto L8b
            java.lang.Object r8 = r2.next()     // Catch: java.lang.Exception -> L90
            c.a.a.a.i r8 = (c.a.a.a.i) r8     // Catch: java.lang.Exception -> L90
            int r9 = r8.a()     // Catch: java.lang.Exception -> L90
            if (r9 == r5) goto L7f
            int r9 = r8.a()     // Catch: java.lang.Exception -> L90
            if (r9 != r4) goto L67
        L7f:
            java.lang.String r8 = r8.c()     // Catch: java.lang.Exception -> L90
            boolean r8 = java.util.Objects.equals(r8, r1)     // Catch: java.lang.Exception -> L90
            if (r8 == 0) goto L67
            r2 = 1
            goto L8c
        L8b:
            r2 = 0
        L8c:
            if (r2 != 0) goto L57
            return r1
        L8f:
            return r6
        L90:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.x0.c(int):java.lang.String");
    }

    public final c.a.a.a.k d(String str) {
        List<c.a.a.a.k> list = this.f;
        if (list != null && list.size() != 0 && str != null && str.trim().length() != 0) {
            for (c.a.a.a.k kVar : this.f) {
                if (Objects.equals(str, kVar.a())) {
                    return kVar;
                }
            }
        }
        return null;
    }

    public boolean d() {
        try {
            Context context = this.f1123a;
            if (context != null) {
                this.f1126d = new c.a.a.a.c(true, context, this);
                return true;
            }
            throw new IllegalArgumentException("Please provide a valid Context.");
        } catch (Exception unused) {
            return false;
        }
    }

    public boolean e() {
        if (this.g) {
            return false;
        }
        this.g = true;
        try {
            if (!this.f1126d.a()) {
                return false;
            }
            if (!this.e) {
                return false;
            }
            ArrayList arrayList = new ArrayList();
            i.a a2 = this.f1126d.a("inapp");
            if (a2 != null && a2.f964a != null) {
                for (c.a.a.a.i iVar : a2.f964a) {
                    if (!arrayList.contains(iVar.b())) {
                        arrayList.add(iVar.b());
                        a(iVar, false);
                    }
                }
            }
            ArrayList<StoreItem> a3 = c.b.g1.b.c().a();
            if (a3 != null) {
                Iterator<StoreItem> it = a3.iterator();
                while (it.hasNext()) {
                    StoreItem next = it.next();
                    if (next.status == 1 && !arrayList.contains(next.token)) {
                        arrayList.add(next.token);
                        if (!next.isSent) {
                            a(next, false);
                        } else if (!next.isConsumed) {
                            a(next);
                        }
                    }
                }
            }
            return true;
        } catch (Exception unused) {
            return false;
        } finally {
            this.g = false;
        }
    }

    public final boolean e(String str) {
        if (str != null && str.trim().length() != 0) {
            Iterator<String> it = this.n.iterator();
            while (it.hasNext()) {
                if (Objects.equals(str, it.next())) {
                    return true;
                }
            }
            Iterator<String> it2 = this.o.iterator();
            while (it2.hasNext()) {
                if (Objects.equals(str, it2.next())) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean f() {
        try {
            if (this.e && this.f1126d.a()) {
                return true;
            }
            this.f1126d.a(new a());
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    public final void b(StoreItem storeItem, int i) {
        String str;
        PendingIntent activity;
        StringBuilder sb;
        String str2;
        try {
            if (this.f1125c == null) {
                return;
            }
            String str3 = "We will try again after a few minutes. Keep this device on";
            if (i == 0) {
                if (e(storeItem.productID)) {
                    str = "Gift codes ready";
                    sb = new StringBuilder();
                    sb.append("Login to https://egyplayer.com using ");
                    sb.append(storeItem.targetMAC);
                    str2 = " to get your gift codes";
                } else {
                    str = "Activation completed";
                    sb = new StringBuilder();
                    sb.append(storeItem.targetMAC);
                    sb.append(" / ");
                    sb.append(storeItem.targetKey);
                    str2 = " is activated";
                }
                sb.append(str2);
                str3 = sb.toString();
            } else {
                if (i != 1 && i != 100 && i != 101) {
                    return;
                }
                str = !e(storeItem.productID) ? "Activation pending" : "Gift codes pending";
            }
            if (e(storeItem.productID)) {
                Intent intent = new Intent("android.intent.action.VIEW");
                intent.setData(Uri.parse("https://egyplayer.com"));
                activity = PendingIntent.getActivity(this.f1123a, 0, intent, 0);
            } else {
                Intent intent2 = !p0.a(this.f1123a) ? new Intent(this.f1123a, (Class<?>) NormalMainActivity.class) : new Intent(this.f1123a, (Class<?>) TVMainActivity.class);
                String json = new Gson().toJson(storeItem, StoreItem.class);
                intent2.setFlags(872415232);
                intent2.putExtra("StoreItem", json);
                intent2.setAction("StoreItem");
                activity = PendingIntent.getActivity(this.f1123a, 0, intent2, 134217728);
            }
            Uri defaultUri = RingtoneManager.getDefaultUri(2);
            b.d.d.c cVar = new b.d.d.c(this.f1123a, "EGYPlayerChannelID");
            cVar.M.icon = R.drawable.logo;
            cVar.b(str);
            cVar.a(str3);
            cVar.l = 0;
            cVar.a(defaultUri);
            cVar.a(true);
            cVar.f = activity;
            cVar.M.vibrate = new long[]{1000, 1000, 1000, 1000, 1000};
            this.f1125c.notify(p0.f1093c, cVar.a());
            p0.f1093c++;
        } catch (Exception unused) {
        }
    }

    public final String c() {
        String str;
        SharedPreferences sharedPreferences;
        c.b.g1.a a2 = c.b.g1.a.a();
        Context context = this.f1123a;
        if (a2 != null) {
            try {
                sharedPreferences = context.getSharedPreferences("EGYPlayerFile", 0);
            } catch (Exception unused) {
            }
            if (sharedPreferences != null) {
                str = sharedPreferences.getString("servicesEndPoint", "");
                if (str != null) {
                }
                return null;
            }
            str = null;
            if (str != null || str.trim().length() == 0) {
                return null;
            }
            String trim = str.trim();
            if (!trim.endsWith("/")) {
                trim = c.a.b.a.a.a(trim, "/");
            }
            return c.a.b.a.a.a(trim, "API/Main/AddRenewalSubscription");
        }
        throw null;
    }

    /* JADX WARN: Can't wrap try/catch for region: R(19:5|(2:19|(17:23|24|25|26|27|(1:29)(1:80)|30|31|32|33|34|(1:36)(1:75)|37|38|39|40|(15:42|43|44|45|46|(1:48)(1:64)|49|50|51|52|(1:54)(1:60)|55|56|57|58)(16:68|(1:70)(1:73)|71|44|45|46|(0)(0)|49|50|51|52|(0)(0)|55|56|57|58)))|84|24|25|26|27|(0)(0)|30|31|32|33|34|(0)(0)|37|38|39|40|(0)(0)) */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x0124, code lost:
    
        if (r7 == null) goto L68;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x0111, code lost:
    
        if (r7 == null) goto L61;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x00d6, code lost:
    
        if (r1 == null) goto L43;
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x00bf, code lost:
    
        if (r1 == null) goto L36;
     */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x00cb  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x00e2  */
    /* JADX WARN: Removed duplicated region for block: B:48:0x010c  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x011d  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x011e A[Catch: Exception -> 0x0126, TRY_LEAVE, TryCatch #1 {Exception -> 0x0126, blocks: (B:52:0x0119, B:60:0x011e), top: B:51:0x0119 }] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x010d A[Catch: Exception -> 0x0113, TRY_LEAVE, TryCatch #3 {Exception -> 0x0113, blocks: (B:46:0x0108, B:64:0x010d), top: B:45:0x0108 }] */
    /* JADX WARN: Removed duplicated region for block: B:68:0x00e3 A[Catch: Exception -> 0x0102, TryCatch #4 {Exception -> 0x0102, blocks: (B:40:0x00de, B:68:0x00e3, B:70:0x00f9, B:71:0x00ff), top: B:39:0x00de }] */
    /* JADX WARN: Removed duplicated region for block: B:75:0x00cc A[Catch: Exception -> 0x00d8, TRY_LEAVE, TryCatch #0 {Exception -> 0x00d8, blocks: (B:34:0x00c7, B:75:0x00cc), top: B:33:0x00c7 }] */
    /* JADX WARN: Removed duplicated region for block: B:80:0x00af A[Catch: Exception -> 0x00c1, TRY_LEAVE, TryCatch #5 {Exception -> 0x00c1, blocks: (B:27:0x00aa, B:80:0x00af), top: B:26:0x00aa }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final com.egyplayer.iptv.repository.StoreItem a(java.lang.String r4, java.lang.String r5, java.lang.String r6, java.lang.String r7) {
        /*
            Method dump skipped, instructions count: 327
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.x0.a(java.lang.String, java.lang.String, java.lang.String, java.lang.String):com.egyplayer.iptv.repository.StoreItem");
    }

    public final String a() {
        c.b.g1.a a2 = c.b.g1.a.a();
        Context context = this.f1123a;
        if (a2 == null) {
            throw null;
        }
        try {
            SharedPreferences sharedPreferences = context.getSharedPreferences("EGYPlayerFile", 0);
            if (sharedPreferences == null) {
                return null;
            }
            return sharedPreferences.getString("deviceKey", "");
        } catch (Exception unused) {
            return null;
        }
    }

    public final StoreItem a(c.a.a.a.i iVar, boolean z) {
        String str;
        String str2;
        String str3;
        String str4;
        try {
            String b2 = iVar.b();
            String c2 = iVar.c();
            c.a.a.a.k d2 = d(c2);
            String optString = d2 != null ? d2.f972b.optString("title") : "";
            int a2 = iVar.a();
            String c3 = iVar.c();
            StoreItem c4 = c.b.g1.b.c().c(b2);
            if (c4 == null) {
                c4 = c.b.g1.b.c().d(c3);
            }
            if (c4 == null) {
                String optString2 = iVar.f963c.optString("obfuscatedAccountId");
                String optString3 = iVar.f963c.optString("obfuscatedProfileId");
                c.a.a.a.a aVar = (optString2 == null && optString3 == null) ? null : new c.a.a.a.a(optString2, optString3);
                if (aVar != null && (str3 = aVar.f923a) != null && str3.trim().length() > 0) {
                    if (str3.startsWith("ACC-")) {
                        String[] split = str3.substring(4).split("-");
                        if (split != null && split.length >= 2) {
                            str2 = split[0].trim();
                            str4 = split[1];
                            str = str4.trim();
                        }
                    } else {
                        String[] split2 = a(str3).split("\\|");
                        if (split2 != null && split2.length >= 2) {
                            str2 = split2[0].trim();
                            str4 = split2[1];
                            str = str4.trim();
                        }
                    }
                    if (str2 != null || str2.trim().length() == 0) {
                        str2 = b();
                    }
                    if (str != null || str.trim().length() == 0) {
                        str = a();
                    }
                    c4 = a(str2, str, c2, optString);
                }
                str = null;
                str2 = null;
                if (str2 != null) {
                }
                str2 = b();
                if (str != null) {
                }
                str = a();
                c4 = a(str2, str, c2, optString);
            }
            c4.token = b2;
            c4.orderID = iVar.f963c.optString("orderId");
            c4.rawData = iVar.f961a;
            if (a2 == 1) {
                c4.status = 1;
                if (!c4.isSent) {
                    a(c4, z);
                } else if (!c4.isConsumed) {
                    a(c4);
                }
            } else if (a2 == 2) {
                c4.status = 2;
            } else {
                c4.status = 0;
            }
            c.b.g1.b.c().c(this.f1123a);
            return c4;
        } catch (Exception unused) {
            return null;
        }
    }

    public void a(c.a.a.a.f fVar, List<c.a.a.a.i> list) {
        c.b.g1.b c2;
        try {
            try {
                int i = fVar.f950a;
                if (i != 0 || list == null) {
                    if (i == 1) {
                        a((StoreItem) null, 7);
                        c.b.g1.b.c().b();
                        c2 = c.b.g1.b.c();
                    } else {
                        a((StoreItem) null, 10);
                        c.b.g1.b.c().b();
                        c2 = c.b.g1.b.c();
                    }
                    c2.c(this.f1123a);
                    return;
                }
                for (c.a.a.a.i iVar : list) {
                    StoreItem a2 = a(iVar, true);
                    if (iVar.a() == 2) {
                        a(a2, 8);
                    } else if (iVar.a() == 0) {
                        a(a2, 10);
                    }
                }
            } catch (Exception unused) {
            }
        } catch (Exception unused2) {
            c.b.g1.b.c().b();
            c.b.g1.b.c().c(this.f1123a);
        }
    }

    public final void a(StoreItem storeItem, boolean z) {
        try {
            if (this.q.contains(storeItem.token)) {
                return;
            }
            this.q.add(storeItem.token);
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("orderID", storeItem.orderID);
            jSONObject.put("token", storeItem.token);
            jSONObject.put("targetMAC", storeItem.targetMAC);
            jSONObject.put("targetKey", storeItem.targetKey);
            jSONObject.put("mac", b());
            jSONObject.put("key", a());
            c.b.g1.a a2 = c.b.g1.a.a();
            Context context = this.f1123a;
            String str = null;
            if (a2 != null) {
                try {
                    SharedPreferences sharedPreferences = context.getSharedPreferences("EGYPlayerFile", 0);
                    if (sharedPreferences != null) {
                        str = sharedPreferences.getString("deviceRID", "");
                    }
                } catch (Exception unused) {
                }
                jSONObject.put("rid", str);
                jSONObject.put("productID", storeItem.productID);
                jSONObject.put("productType", c(storeItem.productID));
                jSONObject.put("storeType", 1);
                jSONObject.put("rawData", storeItem.rawData);
                jSONObject.put("createdTimeMS", storeItem.createdTimeMS);
                jSONObject.put("renewForSelf", storeItem.renewForSelf);
                jSONObject.put("srcToken", storeItem.srcToken);
                String b2 = b(jSONObject.toString());
                JSONObject jSONObject2 = new JSONObject();
                jSONObject2.put("value", b2);
                new Thread(new z0(this, storeItem, jSONObject2.toString(), z)).start();
                return;
            }
            throw null;
        } catch (Exception unused2) {
            if (this.q.contains(storeItem.token)) {
                this.q.remove(storeItem.token);
            }
        }
    }
}
