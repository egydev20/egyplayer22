package c.b;

import com.egyplayer.iptv.repository.StoreItem;

/* loaded from: classes.dex */
public class a1 implements c.a.a.a.h {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ StoreItem f1008a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ x0 f1009b;

    public a1(x0 x0Var, StoreItem storeItem) {
        this.f1009b = x0Var;
        this.f1008a = storeItem;
    }

    public void a(c.a.a.a.f fVar, String str) {
        int i = fVar.f950a;
        if (i == 0 || i == 8) {
            StoreItem storeItem = this.f1008a;
            storeItem.isConsumed = true;
            storeItem.consumedTimeMS = System.currentTimeMillis();
            c.b.g1.b.c().c(this.f1009b.f1123a);
        }
    }
}
