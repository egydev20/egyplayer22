package c.b;

/* loaded from: classes.dex */
public interface u0 {
    int a(int i, String str, String str2, String str3);

    void a();

    void a(String str);

    void a(String str, int i);

    void a(String str, String str2);

    void a(boolean z);

    f1 b();

    void c();
}
