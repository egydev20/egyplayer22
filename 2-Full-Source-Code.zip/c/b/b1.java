package c.b;

/* loaded from: classes.dex */
public class b1 {

    /* renamed from: a, reason: collision with root package name */
    public String f1013a = "";

    /* renamed from: b, reason: collision with root package name */
    public boolean f1014b = true;

    /* renamed from: c, reason: collision with root package name */
    public boolean f1015c = true;

    /* renamed from: d, reason: collision with root package name */
    public String f1016d = null;
}
