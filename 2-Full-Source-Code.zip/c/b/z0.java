package c.b;

import com.egyplayer.iptv.repository.StoreItem;

/* loaded from: classes.dex */
public class z0 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ StoreItem f1135b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ String f1136c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ boolean f1137d;
    public final /* synthetic */ x0 e;

    public z0(x0 x0Var, StoreItem storeItem, String str, boolean z) {
        this.e = x0Var;
        this.f1135b = storeItem;
        this.f1136c = str;
        this.f1137d = z;
    }

    /* JADX WARN: Code restructure failed: missing block: B:64:0x00b0, code lost:
    
        r0.a(r1, 1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x00c3, code lost:
    
        r0.a(r1, 1);
     */
    @Override // java.lang.Runnable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void run() {
        /*
            Method dump skipped, instructions count: 269
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.z0.run():void");
    }
}
