package c.b;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/* loaded from: classes.dex */
public class s0 {
    public static t0 a(String str, byte[] bArr) {
        try {
            t0 t0Var = new t0();
            HttpURLConnection httpURLConnection = (HttpURLConnection) new URL(str).openConnection();
            httpURLConnection.setRequestMethod("POST");
            httpURLConnection.setRequestProperty("Content-Type", "application/json; utf-8");
            httpURLConnection.setRequestProperty("Accept", "application/json");
            httpURLConnection.setDoOutput(true);
            httpURLConnection.setDoInput(true);
            OutputStream outputStream = httpURLConnection.getOutputStream();
            try {
                outputStream.write(bArr, 0, bArr.length);
                outputStream.close();
                t0Var.f1113a = httpURLConnection.getResponseCode();
                httpURLConnection.getResponseMessage();
                if (t0Var.f1113a == 200) {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(httpURLConnection.getInputStream(), "utf-8"));
                    try {
                        StringBuilder sb = new StringBuilder();
                        while (true) {
                            String readLine = bufferedReader.readLine();
                            if (readLine == null) {
                                break;
                            }
                            sb.append(readLine.trim());
                        }
                        t0Var.f1114b = sb.toString();
                        bufferedReader.close();
                    } finally {
                    }
                }
                httpURLConnection.disconnect();
                return t0Var;
            } finally {
            }
        } catch (Exception unused) {
            return null;
        }
    }
}
