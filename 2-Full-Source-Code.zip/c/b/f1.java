package c.b;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.UiModeManager;
import android.content.ComponentCallbacks2;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Base64;
import android.view.InputDevice;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class f1 {

    /* renamed from: a, reason: collision with root package name */
    public Activity f1044a;

    /* renamed from: b, reason: collision with root package name */
    public WebView f1045b;
    public String e;
    public b1 h;
    public String i;
    public String j;
    public String l;
    public String m;
    public String n;

    /* renamed from: c, reason: collision with root package name */
    public Boolean f1046c = false;

    /* renamed from: d, reason: collision with root package name */
    public int f1047d = 0;
    public String f = null;
    public String g = null;
    public Handler k = new Handler(Looper.getMainLooper());

    /* JADX WARN: Code restructure failed: missing block: B:10:0x0053, code lost:
    
        r8 = r9.getHardwareAddress();
     */
    /* JADX WARN: Code restructure failed: missing block: B:11:0x0057, code lost:
    
        if (r8 != null) goto L12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x005a, code lost:
    
        r9 = new java.lang.StringBuilder();
        r2 = r8.length;
        r3 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x0062, code lost:
    
        if (r3 >= r2) goto L38;
     */
    /* JADX WARN: Code restructure failed: missing block: B:32:0x0064, code lost:
    
        r9.append(java.lang.String.format("%02X:", java.lang.Byte.valueOf(r8[r3])));
        r3 = r3 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:35:0x007e, code lost:
    
        if (r9.length() <= 0) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x0080, code lost:
    
        r9.deleteCharAt(r9.length() - 1);
     */
    /* JADX WARN: Code restructure failed: missing block: B:37:0x0088, code lost:
    
        r1 = r9.toString();
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public f1(android.app.Activity r8, android.webkit.WebView r9) {
        /*
            r7 = this;
            r7.<init>()
            r0 = 0
            java.lang.Boolean r1 = java.lang.Boolean.valueOf(r0)
            r7.f1046c = r1
            r7.f1047d = r0
            r1 = 0
            r7.f = r1
            r7.g = r1
            r7.i = r1
            r7.f1044a = r8
            r7.f1045b = r9
            android.os.Handler r8 = new android.os.Handler
            android.os.Looper r9 = android.os.Looper.getMainLooper()
            r8.<init>(r9)
            r7.k = r8
            c.b.g1.a r8 = c.b.g1.a.a()
            android.app.Activity r9 = r7.f1044a
            java.lang.String r8 = r8.c(r9)
            r7.i = r8
            java.util.Enumeration r8 = java.net.NetworkInterface.getNetworkInterfaces()     // Catch: java.lang.Exception -> L8c
            java.util.ArrayList r8 = java.util.Collections.list(r8)     // Catch: java.lang.Exception -> L8c
            java.util.Iterator r8 = r8.iterator()     // Catch: java.lang.Exception -> L8c
        L3a:
            boolean r9 = r8.hasNext()     // Catch: java.lang.Exception -> L8c
            if (r9 == 0) goto L8c
            java.lang.Object r9 = r8.next()     // Catch: java.lang.Exception -> L8c
            java.net.NetworkInterface r9 = (java.net.NetworkInterface) r9     // Catch: java.lang.Exception -> L8c
            java.lang.String r2 = r9.getName()     // Catch: java.lang.Exception -> L8c
            java.lang.String r3 = "wlan0"
            boolean r2 = r2.equalsIgnoreCase(r3)     // Catch: java.lang.Exception -> L8c
            if (r2 != 0) goto L53
            goto L3a
        L53:
            byte[] r8 = r9.getHardwareAddress()     // Catch: java.lang.Exception -> L8c
            if (r8 != 0) goto L5a
            goto L8c
        L5a:
            java.lang.StringBuilder r9 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> L8c
            r9.<init>()     // Catch: java.lang.Exception -> L8c
            int r2 = r8.length     // Catch: java.lang.Exception -> L8c
            r3 = 0
        L61:
            r4 = 1
            if (r3 >= r2) goto L7a
            r5 = r8[r3]     // Catch: java.lang.Exception -> L8c
            java.lang.String r6 = "%02X:"
            java.lang.Object[] r4 = new java.lang.Object[r4]     // Catch: java.lang.Exception -> L8c
            java.lang.Byte r5 = java.lang.Byte.valueOf(r5)     // Catch: java.lang.Exception -> L8c
            r4[r0] = r5     // Catch: java.lang.Exception -> L8c
            java.lang.String r4 = java.lang.String.format(r6, r4)     // Catch: java.lang.Exception -> L8c
            r9.append(r4)     // Catch: java.lang.Exception -> L8c
            int r3 = r3 + 1
            goto L61
        L7a:
            int r8 = r9.length()     // Catch: java.lang.Exception -> L8c
            if (r8 <= 0) goto L88
            int r8 = r9.length()     // Catch: java.lang.Exception -> L8c
            int r8 = r8 - r4
            r9.deleteCharAt(r8)     // Catch: java.lang.Exception -> L8c
        L88:
            java.lang.String r1 = r9.toString()     // Catch: java.lang.Exception -> L8c
        L8c:
            r7.j = r1
            android.app.Activity r8 = r7.f1044a     // Catch: java.lang.Exception -> Lb4
            if (r8 != 0) goto L93
            goto Lb4
        L93:
            android.app.Activity r8 = r7.f1044a     // Catch: java.lang.Exception -> Lb4
            java.lang.String r8 = r8.getPackageName()     // Catch: java.lang.Exception -> Lb4
            r7.l = r8     // Catch: java.lang.Exception -> Lb4
            android.app.Activity r8 = r7.f1044a     // Catch: java.lang.Exception -> Lb4
            android.content.pm.PackageManager r8 = r8.getPackageManager()     // Catch: java.lang.Exception -> Lb4
            java.lang.String r9 = r7.l     // Catch: java.lang.Exception -> Lb4
            android.content.pm.ApplicationInfo r9 = r8.getApplicationInfo(r9, r0)     // Catch: java.lang.Exception -> Lb4
            if (r9 == 0) goto Lae
            java.lang.CharSequence r8 = r8.getApplicationLabel(r9)     // Catch: java.lang.Exception -> Lb4
            goto Lb0
        Lae:
            java.lang.String r8 = ""
        Lb0:
            java.lang.String r8 = (java.lang.String) r8     // Catch: java.lang.Exception -> Lb4
            r7.m = r8     // Catch: java.lang.Exception -> Lb4
        Lb4:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.f1.<init>(android.app.Activity, android.webkit.WebView):void");
    }

    @JavascriptInterface
    public static String getSDKVersion() {
        try {
            return Build.VERSION.SDK_INT + "-" + Build.VERSION.RELEASE;
        } catch (Exception unused) {
            return null;
        }
    }

    @JavascriptInterface
    public String ReadBackupFile(String str) {
        try {
            if (this.g != null && this.g.trim().length() != 0 && str != null && str.trim().length() != 0) {
                File file = new File(this.g, str);
                if (!file.exists()) {
                    return null;
                }
                byte[] bArr = new byte[(int) file.length()];
                FileInputStream fileInputStream = new FileInputStream(file);
                fileInputStream.read(bArr);
                fileInputStream.close();
                return new String(bArr);
            }
        } catch (Exception unused) {
        }
        return null;
    }

    @JavascriptInterface
    public String WriteBackupFile(String str, String str2) {
        try {
            if (this.g != null && this.g.trim().length() != 0 && str != null && str.trim().length() != 0 && str2 != null && str2.trim().length() != 0) {
                File file = new File(this.g, str + ".duplexBAK");
                if (file.exists()) {
                    file.delete();
                }
                FileOutputStream fileOutputStream = new FileOutputStream(file);
                fileOutputStream.write(str2.getBytes());
                fileOutputStream.close();
                return file.getAbsolutePath();
            }
        } catch (Exception unused) {
        }
        return null;
    }

    public final String a(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        char[] charArray = str.toCharArray();
        StringBuilder sb = new StringBuilder();
        boolean z = true;
        for (char c2 : charArray) {
            if (z && Character.isLetter(c2)) {
                sb.append(Character.toUpperCase(c2));
                z = false;
            } else {
                if (Character.isWhitespace(c2)) {
                    z = true;
                }
                sb.append(c2);
            }
        }
        return sb.toString();
    }

    public final String a(String str, int i) {
        if (str == null || str.trim().length() == 0) {
            return "";
        }
        if (i > 0 && str.length() > i) {
            str = str.substring(0, i);
        }
        try {
            return str.replaceAll("[-\\[\\]^/,'*:.!><~@#$%+=?|\"\\\\()]+", "-");
        } catch (Exception unused) {
            return str;
        }
    }

    public final String a(Signature[] signatureArr) {
        if (signatureArr != null) {
            try {
                if (signatureArr.length != 0) {
                    String str = "";
                    for (Signature signature : signatureArr) {
                        MessageDigest messageDigest = MessageDigest.getInstance("SHA1");
                        messageDigest.update(signature.toByteArray());
                        String trim = Base64.encodeToString(messageDigest.digest(), 0).trim();
                        if (str.trim().length() > 0) {
                            str = str + "-";
                        }
                        str = str + trim;
                    }
                    return str;
                }
            } catch (Exception unused) {
            }
        }
        return "";
    }

    public void a() {
        File[] listFiles;
        try {
            if (this.f == null || this.f.trim().length() == 0 || (listFiles = new File(this.f).listFiles()) == null) {
                return;
            }
            for (File file : listFiles) {
                if (file.isDirectory()) {
                    for (File file2 : file.listFiles()) {
                        if (!file2.isDirectory()) {
                            a(file2);
                        }
                    }
                }
            }
        } catch (Exception unused) {
        }
    }

    public void a(File file) {
        String name;
        try {
            if (file.exists()) {
                String name2 = file.getName();
                File parentFile = file.getParentFile();
                if (parentFile != null && (name = parentFile.getName()) != null && name.trim().length() != 0) {
                    if (Boolean.valueOf(file.renameTo(new File(parentFile.getParent(), new SimpleDateFormat("ddMMyyyy-HHmmssSSS").format(new Date()) + "-" + name + name2.substring(name2.lastIndexOf("."))))).booleanValue()) {
                        Boolean.valueOf(parentFile.delete()).booleanValue();
                    }
                }
            }
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void a(String str, int i, String str2, String str3) {
        try {
            c("Main.onFileSelected('" + str + "'," + i + ",'" + str2 + "','" + str3 + "');");
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void b() {
        try {
            c("Main.onNativeKeyboardClosed();");
        } catch (Exception unused) {
        }
    }

    public void b(final int i, final String str, final String str2, final String str3, final String str4, final int i2) {
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.j0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.a(i, str, str2, str3, str4, i2);
            }
        });
    }

    /* renamed from: b, reason: merged with bridge method [inline-methods] */
    public final void c(String str) {
        try {
            if (this.f1045b == null) {
                return;
            }
            this.f1045b.evaluateJavascript(str, null);
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void c() {
        try {
            c("Main.onNativeKeyboardOpened();");
        } catch (Exception unused) {
        }
    }

    /* renamed from: c, reason: merged with bridge method [inline-methods] */
    public final void a(int i, String str, String str2, String str3, String str4, int i2) {
        try {
            c("Main.onSubscriptionProcessCompleted(" + i + ",'" + str + "','" + str2 + "','" + str3 + "','" + str4 + "'," + i2 + ");");
        } catch (Exception unused) {
        }
    }

    public final void c(String str, String str2) {
        try {
            JSONObject jSONObject = new JSONObject();
            jSONObject.put("status", -1);
            jSONObject.put("errorMessage", str2);
            jSONObject.put("content64", (Object) null);
            a(str, jSONObject);
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void d(String str) {
        ComponentCallbacks2 componentCallbacks2 = this.f1044a;
        if (componentCallbacks2 instanceof u0) {
            ((u0) componentCallbacks2).a();
        }
    }

    public /* synthetic */ void e(String str) {
        c.b.g1.a.a().a(this.f1044a, str);
    }

    public void f(String str) {
        c.b.g1.a a2 = c.b.g1.a.a();
        Activity activity = this.f1044a;
        if (a2 != null) {
            try {
                SharedPreferences.Editor edit = activity.getSharedPreferences("EGYPlayerFile", 0).edit();
                edit.putString("PlayerType", str);
                edit.commit();
            } catch (Exception unused) {
            }
            this.i = str;
            return;
        }
        throw null;
    }

    @JavascriptInterface
    public String getBackupsFiles() {
        String substring;
        try {
            if (this.g != null && this.g.trim().length() != 0) {
                JSONArray jSONArray = new JSONArray();
                for (File file : new File(this.g).listFiles()) {
                    if (!file.isDirectory() && (substring = file.getName().substring(file.getName().lastIndexOf("."))) != null && substring.trim().length() != 0 && Objects.equals(substring.trim().toLowerCase(), ".duplexBAK".toLowerCase())) {
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put("name", file.getName());
                        jSONObject.put("path", file.getAbsolutePath());
                        jSONObject.put("size", file.length());
                        jSONObject.put("createdAt", file.lastModified());
                        jSONArray.put(jSONObject);
                    }
                }
                return jSONArray.toString();
            }
            return "";
        } catch (Exception unused) {
            return "";
        }
    }

    @JavascriptInterface
    public String getDeviceID() {
        try {
            if (this.f1044a == null) {
                return null;
            }
            return Settings.Secure.getString(this.f1044a.getContentResolver(), "android_id");
        } catch (Exception unused) {
            return null;
        }
    }

    @JavascriptInterface
    public String getDeviceId() {
        try {
            return Settings.Secure.getString(this.f1044a.getContentResolver(), "android_id");
        } catch (Exception unused) {
            return "unknown_device";
        }
    }

    @JavascriptInterface
    public String getDeviceMAC() {
        try {
            return this.j;
        } catch (Exception unused) {
            return null;
        }
    }

    @JavascriptInterface
    public long getDeviceMemory() {
        try {
            ActivityManager activityManager = (ActivityManager) this.f1044a.getSystemService("activity");
            ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();
            activityManager.getMemoryInfo(memoryInfo);
            return memoryInfo.totalMem;
        } catch (Exception unused) {
            return 0L;
        }
    }

    @JavascriptInterface
    public int getDeviceMode() {
        try {
            UiModeManager uiModeManager = (UiModeManager) this.f1044a.getSystemService("uimode");
            if (uiModeManager == null) {
                return -1;
            }
            return uiModeManager.getCurrentModeType();
        } catch (Exception unused) {
            return -2;
        }
    }

    @JavascriptInterface
    public String getDeviceName() {
        try {
            String str = Build.MANUFACTURER;
            String str2 = Build.MODEL;
            if (str2.startsWith(str)) {
                return a(str2);
            }
            return a(a(str) + " " + str2, 48);
        } catch (Exception unused) {
            return null;
        }
    }

    @JavascriptInterface
    public int getHomeMigrationStatus1() {
        try {
            return c.b.g1.a.a().a(this.f1044a);
        } catch (Exception unused) {
            return 0;
        }
    }

    @JavascriptInterface
    public int getHomeMigrationStatus2() {
        try {
            return c.b.g1.a.a().b(this.f1044a);
        } catch (Exception unused) {
            return 0;
        }
    }

    @JavascriptInterface
    public String getInputDevicesIDs() {
        try {
            String str = "";
            for (int i : InputDevice.getDeviceIds()) {
                if (str != "") {
                    str = str + ",";
                }
                str = (str + i + "-") + InputDevice.getDevice(i).getSources();
            }
            return str;
        } catch (Exception unused) {
            return "";
        }
    }

    @JavascriptInterface
    public String getInstallerName() {
        try {
            String installerPackageName = this.f1044a.getPackageManager().getInstallerPackageName(this.f1044a.getPackageName());
            return installerPackageName == null ? "" : installerPackageName;
        } catch (Exception unused) {
            return "";
        }
    }

    @JavascriptInterface
    public int getIsOfficial() {
        return 1;
    }

    @JavascriptInterface
    public int getLastKeyCode() {
        return this.f1047d;
    }

    @JavascriptInterface
    public String getOSVersion() {
        try {
            return a(Build.VERSION.BASE_OS, 16);
        } catch (Exception unused) {
            return null;
        }
    }

    @JavascriptInterface
    public String getPName() {
        return this.l;
    }

    @JavascriptInterface
    public String getPTitle() {
        return this.m;
    }

    @JavascriptInterface
    public String getPlayerType() {
        return this.i;
    }

    @JavascriptInterface
    public String getPublisherID() {
        try {
            PackageManager packageManager = this.f1044a.getPackageManager();
            String packageName = this.f1044a.getPackageName();
            if (Build.VERSION.SDK_INT >= 28) {
                PackageInfo packageInfo = packageManager.getPackageInfo(packageName, 134217728);
                if (packageInfo != null && packageInfo.signingInfo != null) {
                    return packageInfo.signingInfo.hasMultipleSigners() ? a(packageInfo.signingInfo.getApkContentsSigners()) : a(packageInfo.signingInfo.getSigningCertificateHistory());
                }
                return "";
            }
            PackageInfo packageInfo2 = packageManager.getPackageInfo(packageName, 64);
            if (packageInfo2 != null && packageInfo2.signatures != null && packageInfo2.signatures.length != 0 && packageInfo2.signatures[0] != null) {
                return a(packageInfo2.signatures);
            }
            return "";
        } catch (Exception unused) {
            return "";
        }
    }

    @JavascriptInterface
    public String getRecordedFiles() {
        try {
            if (this.f != null && this.f.trim().length() != 0) {
                a();
                JSONArray jSONArray = new JSONArray();
                File[] listFiles = new File(this.f).listFiles();
                if (listFiles == null) {
                    return "";
                }
                for (File file : listFiles) {
                    if (!file.isDirectory()) {
                        JSONObject jSONObject = new JSONObject();
                        jSONObject.put("path", file.getAbsolutePath());
                        jSONObject.put("size", file.length());
                        jSONArray.put(jSONObject);
                    }
                }
                return jSONArray.toString();
            }
            return "";
        } catch (Exception unused) {
            return "";
        }
    }

    @JavascriptInterface
    public int getSDKVersionValue() {
        try {
            return Build.VERSION.SDK_INT;
        } catch (Exception unused) {
            return 0;
        }
    }

    @JavascriptInterface
    public int hasFeature(String str) {
        return p0.a(this.f1044a, str);
    }

    @JavascriptInterface
    public int hasRemoteControl() {
        return p0.a();
    }

    @JavascriptInterface
    public boolean hasStorageAccessPermission() {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                return this.f1044a.checkSelfPermission("android.permission.WRITE_EXTERNAL_STORAGE") == 0;
            }
            return true;
        } catch (Exception unused) {
            return false;
        }
    }

    @JavascriptInterface
    public boolean isAppLoaded() {
        return this.f1046c.booleanValue();
    }

    @JavascriptInterface
    public int isTVDevice() {
        return p0.c(this.f1044a);
    }

    @JavascriptInterface
    public int isTouchSupported() {
        try {
            return this.f1044a.getPackageManager().hasSystemFeature("android.hardware.touchscreen") ? 1 : 0;
        } catch (Exception unused) {
            return -1;
        }
    }

    @JavascriptInterface
    public String listFolderItems(String str) {
        if (str == null) {
            return null;
        }
        try {
            File externalStorageDirectory = Environment.getExternalStorageDirectory();
            if (!Objects.equals(str, "") && !Objects.equals(str, "/") && !Objects.equals(str, "//")) {
                externalStorageDirectory = new File(externalStorageDirectory.getPath(), str);
            }
            if (!externalStorageDirectory.exists()) {
                return null;
            }
            JSONArray jSONArray = new JSONArray();
            File[] listFiles = externalStorageDirectory.listFiles();
            if (listFiles != null && listFiles.length != 0) {
                for (File file : listFiles) {
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("name", file.getName());
                    jSONObject.put("path", file.getPath());
                    if (file.isDirectory()) {
                        jSONObject.put("isDir", 1);
                        jSONObject.put("size", 0);
                    } else {
                        jSONObject.put("isDir", 0);
                        jSONObject.put("size", (int) file.length());
                    }
                    jSONArray.put(jSONObject);
                }
                return jSONArray.toString();
            }
            return jSONArray.toString();
        } catch (Exception unused) {
            return null;
        }
    }

    @JavascriptInterface
    public void onAppLoaded(final String str) {
        this.f1046c = true;
        this.n = str;
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.b0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.d(str);
            }
        });
    }

    @JavascriptInterface
    public void onReminderItemsChanged(final String str) {
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.o0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.e(str);
            }
        });
    }

    @JavascriptInterface
    public void onSynchronizeJSDevice(final String str, final String str2, final String str3) {
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.e0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.a(str, str2, str3);
            }
        });
    }

    @JavascriptInterface
    public void onSynchronizeJSEndPoints(final String str, final String str2) {
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.h0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.a(str, str2);
            }
        });
    }

    @JavascriptInterface
    public void onSynchronizeJSTime(final long j) {
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.n0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.a(j);
            }
        });
    }

    @JavascriptInterface
    public void openDeviceSettings() {
        try {
            Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.parse("package:" + this.f1044a.getPackageName()));
            intent.addCategory("android.intent.category.DEFAULT");
            intent.addFlags(268435456);
            this.f1044a.startActivity(intent);
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void openFileSelector(final String str, final int i) {
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.f0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.b(str, i);
            }
        });
    }

    @JavascriptInterface
    public String pullPendingStartupJson() {
        String str = this.e;
        this.e = null;
        return str;
    }

    @JavascriptInterface
    public String readTextFile(String str) {
        if (str != null) {
            try {
                if (str.trim().length() != 0) {
                    File file = new File(str);
                    if (!file.exists()) {
                        return null;
                    }
                    byte[] bArr = new byte[(int) file.length()];
                    FileInputStream fileInputStream = new FileInputStream(file);
                    fileInputStream.read(bArr);
                    fileInputStream.close();
                    return new String(bArr);
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    @JavascriptInterface
    public void readTextFileAsync(String str, String str2) {
        try {
            String string = new JSONObject(str2).getString("filePath");
            if (string != null && string.trim().length() != 0) {
                File file = new File(string);
                if (!file.exists()) {
                    c(str, "File not exists");
                    return;
                }
                byte[] bArr = new byte[(int) file.length()];
                FileInputStream fileInputStream = new FileInputStream(file);
                fileInputStream.read(bArr);
                fileInputStream.close();
                try {
                    String encodeToString = Base64.encodeToString(new String(bArr).getBytes("UTF-8"), 2);
                    JSONObject jSONObject = new JSONObject();
                    jSONObject.put("status", 0);
                    jSONObject.put("errorMessage", "");
                    jSONObject.put("content64", encodeToString);
                    a(str, jSONObject);
                    return;
                } catch (Exception unused) {
                    return;
                }
            }
            c(str, "FilePath is null");
        } catch (Exception e) {
            c(str, e.getMessage());
        }
    }

    @JavascriptInterface
    public void removeFile(String str) {
        try {
            File file = new File(str);
            if (file.exists()) {
                if (!Boolean.valueOf(file.delete()).booleanValue()) {
                }
            }
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void requestStorageAccessPermission() {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                b.d.d.a.a(this.f1044a, new String[]{"android.permission.WRITE_EXTERNAL_STORAGE"}, 1);
            }
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setBackground(final String str, final String str2) {
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.m0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.b(str, str2);
            }
        });
    }

    @JavascriptInterface
    public void startSubscriptionProcess(final int i, final String str, final String str2, final String str3) {
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.g0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.a(i, str, str2, str3);
            }
        });
    }

    @JavascriptInterface
    public void synchronizeAppSettings(final String str, final boolean z) {
        Handler handler = this.k;
        if (handler == null) {
            return;
        }
        handler.post(new Runnable() { // from class: c.b.k0
            @Override // java.lang.Runnable
            public final void run() {
                f1.this.a(str, z);
            }
        });
    }

    @JavascriptInterface
    public void terminateApp() {
        try {
            if (this.f1044a != null) {
                this.f1044a.finish();
            }
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void vibrate(int i) {
        try {
            Vibrator vibrator = (Vibrator) this.f1044a.getSystemService("vibrator");
            if (vibrator == null) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 26) {
                vibrator.vibrate(VibrationEffect.createOneShot(i, 5));
            } else {
                vibrator.vibrate(i);
            }
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void a(String str, String str2, String str3) {
        c.b.g1.a a2 = c.b.g1.a.a();
        Activity activity = this.f1044a;
        if (a2 == null) {
            throw null;
        }
        try {
            SharedPreferences.Editor edit = activity.getSharedPreferences("EGYPlayerFile", 0).edit();
            edit.putString("deviceMAC", str);
            edit.putString("deviceKey", str2);
            edit.putString("deviceRID", str3);
            edit.commit();
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void b(String str, int i) {
        ComponentCallbacks2 componentCallbacks2 = this.f1044a;
        if (componentCallbacks2 instanceof u0) {
            ((u0) componentCallbacks2).a(str, i);
        }
    }

    public /* synthetic */ void b(String str, String str2) {
        ComponentCallbacks2 componentCallbacks2 = this.f1044a;
        if (componentCallbacks2 instanceof u0) {
            ((u0) componentCallbacks2).a(str, str2);
        }
    }

    public /* synthetic */ void a(String str, String str2) {
        c.b.g1.a a2 = c.b.g1.a.a();
        Activity activity = this.f1044a;
        if (a2 == null) {
            throw null;
        }
        try {
            SharedPreferences.Editor edit = activity.getSharedPreferences("EGYPlayerFile", 0).edit();
            edit.putString("servicesEndPoint", str);
            edit.putString("epgEndPoint", str2);
            edit.commit();
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void a(long j) {
        c.b.g1.a a2 = c.b.g1.a.a();
        Activity activity = this.f1044a;
        if (a2 == null) {
            throw null;
        }
        try {
            SharedPreferences.Editor edit = activity.getSharedPreferences("EGYPlayerFile", 0).edit();
            edit.putLong("JSTime", j);
            edit.putLong("NativeTime", System.currentTimeMillis());
            edit.commit();
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void a(int i, String str, String str2, String str3) {
        try {
            int a2 = ((u0) this.f1044a).a(i, str, str2, str3);
            if (a2 == 0 || a2 == 10) {
                return;
            }
            a(i, str, str2, str3, "", a2);
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0069 A[Catch: Exception -> 0x00c2, TryCatch #0 {Exception -> 0x00c2, blocks: (B:2:0x0000, B:4:0x0009, B:9:0x0015, B:11:0x0030, B:14:0x0037, B:15:0x0044, B:17:0x004c, B:20:0x0053, B:21:0x0060, B:23:0x0069, B:26:0x0070, B:27:0x007d, B:29:0x0085, B:32:0x008c, B:33:0x0099, B:35:0x009f, B:37:0x00ab, B:39:0x00b5, B:41:0x00bb, B:48:0x0095, B:49:0x0079, B:50:0x005c, B:51:0x0040), top: B:1:0x0000 }] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0085 A[Catch: Exception -> 0x00c2, TryCatch #0 {Exception -> 0x00c2, blocks: (B:2:0x0000, B:4:0x0009, B:9:0x0015, B:11:0x0030, B:14:0x0037, B:15:0x0044, B:17:0x004c, B:20:0x0053, B:21:0x0060, B:23:0x0069, B:26:0x0070, B:27:0x007d, B:29:0x0085, B:32:0x008c, B:33:0x0099, B:35:0x009f, B:37:0x00ab, B:39:0x00b5, B:41:0x00bb, B:48:0x0095, B:49:0x0079, B:50:0x005c, B:51:0x0040), top: B:1:0x0000 }] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x009f A[Catch: Exception -> 0x00c2, TryCatch #0 {Exception -> 0x00c2, blocks: (B:2:0x0000, B:4:0x0009, B:9:0x0015, B:11:0x0030, B:14:0x0037, B:15:0x0044, B:17:0x004c, B:20:0x0053, B:21:0x0060, B:23:0x0069, B:26:0x0070, B:27:0x007d, B:29:0x0085, B:32:0x008c, B:33:0x0099, B:35:0x009f, B:37:0x00ab, B:39:0x00b5, B:41:0x00bb, B:48:0x0095, B:49:0x0079, B:50:0x005c, B:51:0x0040), top: B:1:0x0000 }] */
    /* JADX WARN: Removed duplicated region for block: B:47:? A[ADDED_TO_REGION, RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public /* synthetic */ void a(java.lang.String r4, boolean r5) {
        /*
            r3 = this;
            c.b.b1 r0 = new c.b.b1     // Catch: java.lang.Exception -> Lc2
            r0.<init>()     // Catch: java.lang.Exception -> Lc2
            r3.h = r0     // Catch: java.lang.Exception -> Lc2
            if (r4 == 0) goto Lc2
            java.lang.String r0 = r4.trim()     // Catch: java.lang.Exception -> Lc2
            int r0 = r0.length()     // Catch: java.lang.Exception -> Lc2
            if (r0 != 0) goto L15
            goto Lc2
        L15:
            com.google.gson.Gson r0 = new com.google.gson.Gson     // Catch: java.lang.Exception -> Lc2
            r0.<init>()     // Catch: java.lang.Exception -> Lc2
            com.google.gson.Gson r0 = new com.google.gson.Gson     // Catch: java.lang.Exception -> Lc2
            r0.<init>()     // Catch: java.lang.Exception -> Lc2
            java.lang.Class<com.google.gson.JsonObject> r1 = com.google.gson.JsonObject.class
            java.lang.Object r4 = r0.fromJson(r4, r1)     // Catch: java.lang.Exception -> Lc2
            com.google.gson.JsonObject r4 = (com.google.gson.JsonObject) r4     // Catch: java.lang.Exception -> Lc2
            java.lang.String r0 = "playerType"
            com.google.gson.JsonElement r0 = r4.get(r0)     // Catch: java.lang.Exception -> Lc2
            r1 = 0
            if (r0 == 0) goto L40
            boolean r2 = r0.isJsonNull()     // Catch: java.lang.Exception -> Lc2
            if (r2 == 0) goto L37
            goto L40
        L37:
            c.b.b1 r2 = r3.h     // Catch: java.lang.Exception -> Lc2
            java.lang.String r0 = r0.getAsString()     // Catch: java.lang.Exception -> Lc2
            r2.f1016d = r0     // Catch: java.lang.Exception -> Lc2
            goto L44
        L40:
            c.b.b1 r0 = r3.h     // Catch: java.lang.Exception -> Lc2
            r0.f1016d = r1     // Catch: java.lang.Exception -> Lc2
        L44:
            java.lang.String r0 = "userAgent"
            com.google.gson.JsonElement r0 = r4.get(r0)     // Catch: java.lang.Exception -> Lc2
            if (r0 == 0) goto L5c
            boolean r2 = r0.isJsonNull()     // Catch: java.lang.Exception -> Lc2
            if (r2 == 0) goto L53
            goto L5c
        L53:
            c.b.b1 r1 = r3.h     // Catch: java.lang.Exception -> Lc2
            java.lang.String r0 = r0.getAsString()     // Catch: java.lang.Exception -> Lc2
            r1.f1013a = r0     // Catch: java.lang.Exception -> Lc2
            goto L60
        L5c:
            c.b.b1 r0 = r3.h     // Catch: java.lang.Exception -> Lc2
            r0.f1013a = r1     // Catch: java.lang.Exception -> Lc2
        L60:
            java.lang.String r0 = "enableHWAcc"
            com.google.gson.JsonElement r0 = r4.get(r0)     // Catch: java.lang.Exception -> Lc2
            r1 = 0
            if (r0 == 0) goto L79
            boolean r2 = r0.isJsonNull()     // Catch: java.lang.Exception -> Lc2
            if (r2 == 0) goto L70
            goto L79
        L70:
            c.b.b1 r2 = r3.h     // Catch: java.lang.Exception -> Lc2
            boolean r0 = r0.getAsBoolean()     // Catch: java.lang.Exception -> Lc2
            r2.f1015c = r0     // Catch: java.lang.Exception -> Lc2
            goto L7d
        L79:
            c.b.b1 r0 = r3.h     // Catch: java.lang.Exception -> Lc2
            r0.f1015c = r1     // Catch: java.lang.Exception -> Lc2
        L7d:
            java.lang.String r0 = "castKeepConnected"
            com.google.gson.JsonElement r4 = r4.get(r0)     // Catch: java.lang.Exception -> Lc2
            if (r4 == 0) goto L95
            boolean r0 = r4.isJsonNull()     // Catch: java.lang.Exception -> Lc2
            if (r0 == 0) goto L8c
            goto L95
        L8c:
            c.b.b1 r0 = r3.h     // Catch: java.lang.Exception -> Lc2
            boolean r4 = r4.getAsBoolean()     // Catch: java.lang.Exception -> Lc2
            r0.f1014b = r4     // Catch: java.lang.Exception -> Lc2
            goto L99
        L95:
            c.b.b1 r4 = r3.h     // Catch: java.lang.Exception -> Lc2
            r4.f1014b = r1     // Catch: java.lang.Exception -> Lc2
        L99:
            c.b.b1 r4 = r3.h     // Catch: java.lang.Exception -> Lc2
            java.lang.String r4 = r4.f1016d     // Catch: java.lang.Exception -> Lc2
            if (r4 == 0) goto Lc2
            java.lang.String r4 = r3.i     // Catch: java.lang.Exception -> Lc2
            c.b.b1 r0 = r3.h     // Catch: java.lang.Exception -> Lc2
            java.lang.String r0 = r0.f1016d     // Catch: java.lang.Exception -> Lc2
            boolean r4 = java.util.Objects.equals(r4, r0)     // Catch: java.lang.Exception -> Lc2
            if (r4 != 0) goto Lc2
            c.b.b1 r4 = r3.h     // Catch: java.lang.Exception -> Lc2
            java.lang.String r4 = r4.f1016d     // Catch: java.lang.Exception -> Lc2
            r3.f(r4)     // Catch: java.lang.Exception -> Lc2
            r4 = 1
            if (r5 != r4) goto Lc2
            android.app.Activity r4 = r3.f1044a     // Catch: java.lang.Exception -> Lc2
            boolean r4 = r4 instanceof c.b.u0     // Catch: java.lang.Exception -> Lc2
            if (r4 == 0) goto Lc2
            android.app.Activity r4 = r3.f1044a     // Catch: java.lang.Exception -> Lc2
            c.b.u0 r4 = (c.b.u0) r4     // Catch: java.lang.Exception -> Lc2
            r4.c()     // Catch: java.lang.Exception -> Lc2
        Lc2:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.f1.a(java.lang.String, boolean):void");
    }

    public final void a(String str, JSONObject jSONObject) {
        try {
            final String str2 = "Platform.appManager.onDispatchFunctionResult('" + str + "','" + jSONObject.toString().replaceAll("(\r\n|\n)", "").replaceAll("(\\r\\n|\\n)", "").replaceAll("(\\\\r\\\\n|\\\\n)", "") + "'); ";
            Handler handler = this.k;
            if (handler == null) {
                return;
            }
            handler.post(new Runnable() { // from class: c.b.c0
                @Override // java.lang.Runnable
                public final void run() {
                    f1.this.c(str2);
                }
            });
        } catch (Exception unused) {
        }
    }
}
