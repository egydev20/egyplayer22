package c.b;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Surface;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;
import android.widget.FrameLayout;
import c.d.a.a.j1.c;
import c.d.a.a.j1.e;
import c.d.a.a.q0;
import c.d.a.a.r;
import com.google.android.exoplayer2.ui.PlayerView;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* loaded from: classes.dex */
public class d1 implements q0.a, c.d.a.a.i1.k, v0 {
    public double A;
    public double B;
    public double C;
    public double D;

    /* renamed from: b, reason: collision with root package name */
    public c.d.a.a.w0 f1026b;

    /* renamed from: c, reason: collision with root package name */
    public Activity f1027c;

    /* renamed from: d, reason: collision with root package name */
    public WebView f1028d;
    public PlayerView e;
    public int f;
    public int i;
    public int j;
    public long k;
    public long l;
    public Handler m;
    public Runnable n;
    public ArrayList<c.d.a.a.f0> t;
    public ArrayList<c.d.a.a.f0> u;
    public ArrayList<c.d.a.a.f0> v;
    public c.d.a.a.j1.c w;
    public boolean h = false;
    public boolean o = false;
    public boolean p = false;
    public long q = 0;
    public String r = null;
    public String s = null;
    public boolean x = false;
    public boolean y = false;
    public boolean z = false;
    public Handler g = new Handler(Looper.getMainLooper());

    public d1(Activity activity, WebView webView, PlayerView playerView, int i) {
        this.f1027c = activity;
        this.f1028d = webView;
        this.e = playerView;
        this.f = i;
    }

    public final int a(c.d.a.a.f0 f0Var) {
        String str;
        if (f0Var == null || (str = f0Var.j) == null || str.trim().length() == 0) {
            return 0;
        }
        if (str.toLowerCase().contains("video")) {
            return 1;
        }
        if (str.toLowerCase().contains("audio")) {
            return 2;
        }
        return (str.toLowerCase().contains("text") || str.toLowerCase().contains("subrip")) ? 3 : 0;
    }

    public final c.d.a.a.f0 a(String str, c.d.a.a.h1.d0 d0Var) {
        if (d0Var != null) {
            try {
                if (d0Var.f1824b != 0) {
                    for (int i = 0; i < d0Var.f1824b; i++) {
                        c.d.a.a.h1.c0 c0Var = d0Var.f1825c[i];
                        if (c0Var != null && c0Var.f1818b != 0) {
                            for (int i2 = 0; i2 < c0Var.f1818b; i2++) {
                                c.d.a.a.f0 f0Var = c0Var.f1819c[i2];
                                if (Objects.equals(f0Var.f1709b, str)) {
                                    return f0Var;
                                }
                            }
                        }
                    }
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    public final String a(ArrayList<c.d.a.a.f0> arrayList, String str) {
        JSONArray jSONArray = new JSONArray();
        for (int i = 0; i < arrayList.size(); i++) {
            c.d.a.a.f0 f0Var = arrayList.get(i);
            JSONObject jSONObject = new JSONObject();
            try {
                jSONObject.put("id", f0Var.f1709b);
                jSONObject.put("name", f0Var.f1710c);
                jSONObject.put("language", f0Var.B);
                if (str != null && Objects.equals(f0Var.f1709b, str)) {
                    jSONObject.put("selected", 1);
                } else {
                    jSONObject.put("selected", 0);
                }
                jSONArray.put(jSONObject);
            } catch (JSONException unused) {
            }
        }
        return jSONArray.toString();
    }

    @Override // c.b.v0
    public void a() {
        h();
    }

    public final void a(double d2, double d3, double d4, double d5) {
        try {
            FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) this.e.getLayoutParams();
            layoutParams.gravity = 51;
            layoutParams.width = (int) d4;
            layoutParams.height = (int) d5;
            layoutParams.leftMargin = (int) d2;
            layoutParams.topMargin = (int) d3;
            this.e.setLayoutParams(layoutParams);
            this.e.invalidate();
        } catch (Exception unused) {
        }
    }

    public final void a(int i, String str) {
        StringBuilder a2 = c.a.b.a.a.a("PlayerGateway.onCueChange(");
        a2.append(this.f);
        a2.append(",");
        a2.append(i);
        a2.append(",'");
        a2.append(str);
        a2.append("');");
        b(a2.toString());
    }

    @Override // c.d.a.a.q0.a
    public /* synthetic */ void a(c.d.a.a.n0 n0Var) {
        c.d.a.a.p0.a(this, n0Var);
    }

    @Override // c.d.a.a.q0.a
    public /* synthetic */ void a(c.d.a.a.x0 x0Var, int i) {
        c.d.a.a.p0.a(this, x0Var, i);
    }

    @Override // c.d.a.a.q0.a
    @Deprecated
    public /* synthetic */ void a(c.d.a.a.x0 x0Var, Object obj, int i) {
        c.d.a.a.p0.a(this, x0Var, obj, i);
    }

    @Override // c.b.v0
    public void a(String str) {
    }

    @Override // c.d.a.a.q0.a
    public void a(boolean z) {
    }

    public final c.d.a.a.h1.c0 b(String str, c.d.a.a.h1.d0 d0Var) {
        if (d0Var != null) {
            try {
                if (d0Var.f1824b != 0) {
                    for (int i = 0; i < d0Var.f1824b; i++) {
                        c.d.a.a.h1.c0 c0Var = d0Var.f1825c[i];
                        if (c0Var != null && c0Var.f1818b != 0) {
                            for (int i2 = 0; i2 < c0Var.f1818b; i2++) {
                                if (Objects.equals(c0Var.f1819c[i2].f1709b, str)) {
                                    return c0Var;
                                }
                            }
                        }
                    }
                }
            } catch (Exception unused) {
            }
        }
        return null;
    }

    @Override // c.d.a.a.q0.a
    public /* synthetic */ void b() {
        c.d.a.a.p0.a(this);
    }

    @Override // c.d.a.a.q0.a
    public /* synthetic */ void b(int i) {
        c.d.a.a.p0.a(this, i);
    }

    public final void b(final String str) {
        try {
            if (this.g == null) {
                return;
            }
            this.g.post(new Runnable() { // from class: c.b.j
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.c(str);
                }
            });
        } catch (Exception unused) {
        }
    }

    @Override // c.d.a.a.q0.a
    public /* synthetic */ void b(boolean z) {
        c.d.a.a.p0.c(this, z);
    }

    @Override // c.b.v0
    public void c() {
        c.d.a.a.w0 w0Var;
        if (this.y && this.x && (w0Var = this.f1026b) != null) {
            w0Var.a(true);
            this.y = false;
        }
    }

    @Override // c.d.a.a.q0.a
    public /* synthetic */ void c(int i) {
        c.d.a.a.p0.b(this, i);
    }

    public /* synthetic */ void c(String str) {
        try {
            if (this.f1028d == null) {
                return;
            }
            this.f1028d.evaluateJavascript(str, null);
        } catch (Exception unused) {
        }
    }

    @Override // c.d.a.a.q0.a
    public /* synthetic */ void c(boolean z) {
        c.d.a.a.p0.a(this, z);
    }

    @Override // c.d.a.a.q0.a
    public /* synthetic */ void d(int i) {
        c.d.a.a.p0.c(this, i);
    }

    public /* synthetic */ void d(String str) {
        e.a aVar;
        c.d.a.a.h1.d0 d0Var;
        c.d.a.a.f0 a2;
        c.d.a.a.h1.c0 b2;
        int a3;
        int a4;
        if (str != null) {
            try {
                if (str.trim().length() != 0 && (aVar = this.w.f2270c) != null && (d0Var = aVar.f2273c[1]) != null && (a2 = a(str, d0Var)) != null && (b2 = b(str, d0Var)) != null && (a3 = b2.a(a2)) >= 0 && (a4 = d0Var.a(b2)) >= 0) {
                    c.f fVar = new c.f(a4, a3);
                    c.d.a.a.j1.c cVar = this.w;
                    c.e a5 = this.w.a();
                    a5.a(1, d0Var, fVar);
                    cVar.a(a5);
                }
            } catch (Exception unused) {
            }
        }
    }

    public final void d(boolean z) {
        c.d.a.a.j1.c cVar = this.w;
        c.e a2 = cVar.a();
        a2.a(3, !z);
        cVar.a(a2);
    }

    public /* synthetic */ void e(boolean z) {
        try {
            if (this.f1027c instanceof u0) {
                ((u0) this.f1027c).a(z);
            }
        } catch (Exception unused) {
        }
    }

    public final void f() {
        try {
            c.d.a.a.j1.c cVar = this.w;
            c.e eVar = new c.e(this.f1027c);
            if (eVar.z.size() != 0) {
                eVar.z.clear();
            }
            eVar.a(3, true);
            cVar.a(eVar.a());
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x005d, code lost:
    
        if ((!r4.e() && r4.a(r3.t(), r3.f2581a).f) != false) goto L15;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void g() {
        /*
            r9 = this;
            r0 = 0
            r9.i = r0
            r9.j = r0
            r1 = 0
            r9.k = r1
            r9.l = r1
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            r9.u = r3
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            r9.t = r3
            java.util.ArrayList r3 = new java.util.ArrayList
            r3.<init>()
            r9.v = r3
            c.d.a.a.w0 r3 = r9.f1026b     // Catch: java.lang.Exception -> Lb7
            c.d.a.a.f0 r3 = r3.q     // Catch: java.lang.Exception -> Lb7
            if (r3 == 0) goto L2e
            int r4 = r3.o     // Catch: java.lang.Exception -> Lb7
            r9.i = r4     // Catch: java.lang.Exception -> Lb7
            int r3 = r3.p     // Catch: java.lang.Exception -> Lb7
            r9.j = r3     // Catch: java.lang.Exception -> Lb7
        L2e:
            c.d.a.a.w0 r3 = r9.f1026b     // Catch: java.lang.Exception -> Lb7
            r3.B()     // Catch: java.lang.Exception -> Lb7
            c.d.a.a.c0 r3 = r3.f2606c     // Catch: java.lang.Exception -> Lb7
            long r3 = r3.getDuration()     // Catch: java.lang.Exception -> Lb7
            r9.k = r3     // Catch: java.lang.Exception -> Lb7
            r5 = 1
            int r6 = (r3 > r1 ? 1 : (r3 == r1 ? 0 : -1))
            if (r6 < 0) goto L5f
            c.d.a.a.w0 r3 = r9.f1026b     // Catch: java.lang.Exception -> Lb7
            c.d.a.a.x0 r4 = r3.m()     // Catch: java.lang.Exception -> Lb7
            boolean r6 = r4.e()     // Catch: java.lang.Exception -> Lb7
            if (r6 != 0) goto L5c
            int r6 = r3.t()     // Catch: java.lang.Exception -> Lb7
            c.d.a.a.x0$c r3 = r3.f2581a     // Catch: java.lang.Exception -> Lb7
            c.d.a.a.x0$c r3 = r4.a(r6, r3)     // Catch: java.lang.Exception -> Lb7
            boolean r3 = r3.f     // Catch: java.lang.Exception -> Lb7
            if (r3 == 0) goto L5c
            r3 = 1
            goto L5d
        L5c:
            r3 = 0
        L5d:
            if (r3 == 0) goto L61
        L5f:
            r9.k = r1     // Catch: java.lang.Exception -> Lb7
        L61:
            c.d.a.a.w0 r1 = r9.f1026b     // Catch: java.lang.Exception -> Lb7
            r1.B()     // Catch: java.lang.Exception -> Lb7
            c.d.a.a.c0 r1 = r1.f2606c     // Catch: java.lang.Exception -> Lb7
            c.d.a.a.m0 r1 = r1.t     // Catch: java.lang.Exception -> Lb7
            c.d.a.a.h1.d0 r1 = r1.h     // Catch: java.lang.Exception -> Lb7
            if (r1 == 0) goto Lb7
            int r2 = r1.f1824b     // Catch: java.lang.Exception -> Lb7
            if (r2 <= 0) goto Lb7
            r2 = 0
        L73:
            int r3 = r1.f1824b     // Catch: java.lang.Exception -> Lb7
            if (r2 >= r3) goto Lb7
            c.d.a.a.h1.c0[] r3 = r1.f1825c     // Catch: java.lang.Exception -> Lb7
            r3 = r3[r2]     // Catch: java.lang.Exception -> Lb7
            if (r3 == 0) goto Lb4
            int r4 = r3.f1818b     // Catch: java.lang.Exception -> Lb7
            if (r4 <= 0) goto Lb4
            r4 = 0
        L82:
            int r6 = r3.f1818b     // Catch: java.lang.Exception -> Lb7
            if (r4 >= r6) goto Lb4
            c.d.a.a.f0[] r6 = r3.f1819c     // Catch: java.lang.Exception -> Lb7
            r6 = r6[r4]     // Catch: java.lang.Exception -> Lb7
            java.lang.String r7 = r6.j     // Catch: java.lang.Exception -> Lb7
            if (r7 == 0) goto Lb1
            java.lang.String r7 = r7.trim()     // Catch: java.lang.Exception -> Lb7
            int r7 = r7.length()     // Catch: java.lang.Exception -> Lb7
            if (r7 != 0) goto L99
            goto Lb1
        L99:
            int r7 = r9.a(r6)     // Catch: java.lang.Exception -> Lb7
            if (r7 != r5) goto La5
            java.util.ArrayList<c.d.a.a.f0> r7 = r9.u     // Catch: java.lang.Exception -> Lb7
        La1:
            r7.add(r6)     // Catch: java.lang.Exception -> Lb7
            goto Lb1
        La5:
            r8 = 2
            if (r7 != r8) goto Lab
            java.util.ArrayList<c.d.a.a.f0> r7 = r9.t     // Catch: java.lang.Exception -> Lb7
            goto La1
        Lab:
            r8 = 3
            if (r7 != r8) goto Lb1
            java.util.ArrayList<c.d.a.a.f0> r7 = r9.v     // Catch: java.lang.Exception -> Lb7
            goto La1
        Lb1:
            int r4 = r4 + 1
            goto L82
        Lb4:
            int r2 = r2 + 1
            goto L73
        Lb7:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.d1.g():void");
    }

    public final void g(boolean z) {
        try {
            if (z) {
                a(this.A, this.B, this.C, this.D);
                this.e.setVisibility(0);
            } else {
                a(-800.0d, 0.0d, 20.0d, 20.0d);
                this.e.setVisibility(4);
            }
            this.z = z;
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public String getAudioTracks() {
        ArrayList<c.d.a.a.f0> arrayList = this.t;
        return (arrayList == null || arrayList.size() == 0) ? "" : a(this.t, this.r);
    }

    @JavascriptInterface
    public String getCastDeviceName() {
        return null;
    }

    @JavascriptInterface
    public String getCastDevices() {
        return "";
    }

    @JavascriptInterface
    public long getCurrentTimeMS() {
        return this.l;
    }

    @JavascriptInterface
    public String getDeviceId() {
        try {
            return Settings.Secure.getString(this.f1027c.getContentResolver(), "android_id");
        } catch (Exception unused) {
            return "unknown_device";
        }
    }

    @JavascriptInterface
    public long getDurationMS() {
        return this.k;
    }

    @JavascriptInterface
    public String getSubtitleTracks() {
        ArrayList<c.d.a.a.f0> arrayList = this.v;
        return (arrayList == null || arrayList.size() == 0) ? "" : a(this.v, this.s);
    }

    @JavascriptInterface
    public int getVideoHeight() {
        return this.j;
    }

    @JavascriptInterface
    public String getVideoTracks() {
        ArrayList<c.d.a.a.f0> arrayList = this.u;
        return (arrayList == null || arrayList.size() == 0) ? "" : a(this.u, (String) null);
    }

    @JavascriptInterface
    public int getVideoWidth() {
        return this.i;
    }

    public final void h() {
        if (this.x) {
            return;
        }
        try {
            c.d.a.a.y yVar = new c.d.a.a.y(this.f1027c);
            yVar.f2622b = 2;
            this.w = new c.d.a.a.j1.c(this.f1027c);
            f();
            Activity activity = this.f1027c;
            new c.d.a.a.j1.c(activity);
            c.d.a.a.w wVar = new c.d.a.a.w();
            c.d.a.a.l1.p a2 = c.d.a.a.l1.p.a(activity);
            Looper myLooper = Looper.myLooper();
            if (myLooper == null) {
                myLooper = Looper.getMainLooper();
            }
            c.d.a.a.z0.a aVar = new c.d.a.a.z0.a(c.d.a.a.m1.f.f2432a);
            c.d.a.a.m1.f fVar = c.d.a.a.m1.f.f2432a;
            c.d.a.a.j1.c cVar = this.w;
            c.d.a.a.m1.e.b(true);
            c.d.a.a.m1.e.b(true);
            c.d.a.a.w0 w0Var = new c.d.a.a.w0(activity, yVar, cVar, wVar, a2, aVar, fVar, myLooper);
            this.f1026b = w0Var;
            w0Var.B();
            w0Var.f2606c.h.addIfAbsent(new r.a(this));
            c.d.a.a.w0 w0Var2 = this.f1026b;
            if (!w0Var2.D.isEmpty()) {
                a(w0Var2.D);
            }
            w0Var2.h.add(this);
            this.e.setUseController(false);
            this.e.getSubtitleView().setVisibility(4);
            this.e.setPlayer(this.f1026b);
            this.e.setResizeMode(3);
            c.d.a.a.w0 w0Var3 = this.f1026b;
            w0Var3.B();
            for (c.d.a.a.t0 t0Var : w0Var3.f2605b) {
                if (t0Var.m() == 2) {
                    c.d.a.a.r0 a3 = w0Var3.f2606c.a(t0Var);
                    a3.a(4);
                    a3.a((Object) 1);
                    a3.c();
                }
            }
            g(false);
        } catch (Exception unused) {
        }
        this.x = true;
    }

    public /* synthetic */ void i() {
        try {
            this.f1026b.a(false);
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void j() {
        try {
            this.f1026b.a(true);
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void k() {
        Runnable runnable;
        try {
            this.o = true;
            Handler handler = this.m;
            if (handler != null && (runnable = this.n) != null) {
                handler.removeCallbacks(runnable);
            }
            this.f1026b.a(false);
            this.f1026b.c(true);
            g(false);
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void l() {
        this.l = this.p ? this.q : this.f1026b.getCurrentPosition();
    }

    @JavascriptInterface
    public void pause() {
        Handler handler = this.g;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.c
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.i();
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void play(final String str, final int i) {
        this.h = false;
        this.p = false;
        this.q = 0L;
        Handler handler = this.g;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.i
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.a(str, i);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void refreshCastDevices() {
    }

    @JavascriptInterface
    public void resume() {
        Handler handler = this.g;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.l
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.j();
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void seek(final int i) {
        long j = i;
        this.l = j;
        this.p = true;
        this.q = j;
        Handler handler = this.g;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.a
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.a(i);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public boolean setActiveCastDevice(String str) {
        return false;
    }

    @JavascriptInterface
    public void setDisplayRect(final double d2, final double d3, final double d4, final double d5, final boolean z) {
        this.A = d2;
        this.B = d3;
        this.C = d4;
        this.D = d5;
        try {
            if (this.g == null) {
                return;
            }
            this.g.post(new Runnable() { // from class: c.b.f
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.a(d2, d3, d4, d5, z);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void setSoundLevelRatio(final float f) {
        try {
            if (this.g == null) {
                return;
            }
            this.g.post(new Runnable() { // from class: c.b.d
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.a(f);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void showPlayerBackground(final boolean z) {
        try {
            if (this.g == null) {
                return;
            }
            this.g.post(new Runnable() { // from class: c.b.e
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.e(z);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void showPlayerUI(final boolean z) {
        Handler handler = this.g;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.m
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.f(z);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void startRecording(String str) {
    }

    @JavascriptInterface
    public void stop() {
        this.p = false;
        this.q = 0L;
        Handler handler = this.g;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.h
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.k();
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void stopRecording() {
    }

    @JavascriptInterface
    public void switchAudioTrack(final String str) {
        Handler handler = this.g;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.g
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.d(str);
                }
            });
        } catch (Exception unused) {
        }
    }

    @JavascriptInterface
    public void switchSubtitleTrack(final String str) {
        Handler handler = this.g;
        if (handler == null) {
            return;
        }
        try {
            handler.post(new Runnable() { // from class: c.b.k
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.e(str);
                }
            });
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:31:0x006f, code lost:
    
        if (r0.booleanValue() == true) goto L9;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public /* synthetic */ void e(java.lang.String r8) {
        /*
            r7 = this;
            c.d.a.a.j1.c r0 = r7.w     // Catch: java.lang.Exception -> L72
            java.util.concurrent.atomic.AtomicReference<c.d.a.a.j1.c$d> r0 = r0.e     // Catch: java.lang.Exception -> L72
            java.lang.Object r0 = r0.get()     // Catch: java.lang.Exception -> L72
            c.d.a.a.j1.c$d r0 = (c.d.a.a.j1.c.d) r0     // Catch: java.lang.Exception -> L72
            r1 = 3
            boolean r0 = r0.a(r1)     // Catch: java.lang.Exception -> L72
            r2 = 1
            r0 = r0 ^ r2
            java.lang.Boolean r0 = java.lang.Boolean.valueOf(r0)     // Catch: java.lang.Exception -> L72
            r3 = 0
            if (r8 == 0) goto L6b
            java.lang.String r4 = r8.trim()     // Catch: java.lang.Exception -> L72
            int r4 = r4.length()     // Catch: java.lang.Exception -> L72
            if (r4 != 0) goto L23
            goto L6b
        L23:
            c.d.a.a.j1.c r0 = r7.w     // Catch: java.lang.Exception -> L72
            c.d.a.a.j1.e$a r0 = r0.f2270c     // Catch: java.lang.Exception -> L72
            if (r0 != 0) goto L2d
        L29:
            r7.d(r3)     // Catch: java.lang.Exception -> L72
            goto L72
        L2d:
            c.d.a.a.h1.d0[] r0 = r0.f2273c     // Catch: java.lang.Exception -> L72
            r0 = r0[r1]     // Catch: java.lang.Exception -> L72
            if (r0 != 0) goto L34
            goto L29
        L34:
            c.d.a.a.f0 r4 = r7.a(r8, r0)     // Catch: java.lang.Exception -> L72
            if (r4 != 0) goto L3b
            goto L29
        L3b:
            c.d.a.a.h1.c0 r8 = r7.b(r8, r0)     // Catch: java.lang.Exception -> L72
            if (r8 != 0) goto L42
            goto L29
        L42:
            int r4 = r8.a(r4)     // Catch: java.lang.Exception -> L72
            if (r4 >= 0) goto L49
            goto L29
        L49:
            int r8 = r0.a(r8)     // Catch: java.lang.Exception -> L72
            if (r8 >= 0) goto L50
            goto L29
        L50:
            c.d.a.a.j1.c$f r5 = new c.d.a.a.j1.c$f     // Catch: java.lang.Exception -> L72
            int[] r6 = new int[r2]     // Catch: java.lang.Exception -> L72
            r6[r3] = r4     // Catch: java.lang.Exception -> L72
            r5.<init>(r8, r6)     // Catch: java.lang.Exception -> L72
            c.d.a.a.j1.c r8 = r7.w     // Catch: java.lang.Exception -> L72
            c.d.a.a.j1.c r3 = r7.w     // Catch: java.lang.Exception -> L72
            c.d.a.a.j1.c$e r3 = r3.a()     // Catch: java.lang.Exception -> L72
            r3.a(r1, r0, r5)     // Catch: java.lang.Exception -> L72
            r8.a(r3)     // Catch: java.lang.Exception -> L72
            r7.d(r2)     // Catch: java.lang.Exception -> L72
            goto L72
        L6b:
            boolean r8 = r0.booleanValue()     // Catch: java.lang.Exception -> L72
            if (r8 != r2) goto L72
            goto L29
        L72:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.d1.e(java.lang.String):void");
    }

    public /* synthetic */ void f(boolean z) {
        PlayerView playerView;
        int i;
        try {
            if (z) {
                playerView = this.e;
                i = 0;
            } else {
                playerView = this.e;
                i = 8;
            }
            playerView.setVisibility(i);
        } catch (Exception unused) {
        }
    }

    /* JADX WARN: Can't wrap try/catch for region: R(10:10|11|(2:12|13)|(5:62|(1:55)|20|21|(7:23|24|(1:26)|27|(2:34|(1:(1:51)(4:44|(1:46)|47|(1:49)(1:50)))(1:40))(1:31)|32|33)(10:52|(0)|27|(1:29)|34|(2:36|38)|(1:42)|51|32|33))|16|(1:18)|55|20|21|(0)(0)) */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0050  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x005f A[Catch: Exception -> 0x015d, TRY_ENTER, TryCatch #0 {Exception -> 0x015d, blocks: (B:3:0x0004, B:5:0x0009, B:10:0x0015, B:18:0x003a, B:26:0x005f, B:27:0x0067, B:29:0x0092, B:31:0x00a2, B:32:0x0153, B:34:0x00c2, B:36:0x00cd, B:38:0x00d5, B:40:0x00dd, B:42:0x010b, B:44:0x0113, B:46:0x011c, B:47:0x0123, B:49:0x0128, B:50:0x0144, B:51:0x0145), top: B:2:0x0004 }] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x0051 A[Catch: Exception -> 0x005c, TRY_LEAVE, TryCatch #1 {Exception -> 0x005c, blocks: (B:21:0x0046, B:52:0x0051), top: B:20:0x0046 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public /* synthetic */ void a(java.lang.String r22, int r23) {
        /*
            Method dump skipped, instructions count: 350
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.b.d1.a(java.lang.String, int):void");
    }

    @Override // c.b.v0
    public void d() {
        if (!this.x || this.f1026b == null) {
            return;
        }
        PlayerView playerView = this.e;
        if (playerView != null) {
            playerView.setPlayer(null);
        }
        c.d.a.a.w0 w0Var = this.f1026b;
        if (w0Var != null) {
            w0Var.B();
            c.d.a.a.p pVar = w0Var.n;
            if (pVar != null) {
                if (pVar.f2571c) {
                    pVar.f2569a.unregisterReceiver(pVar.f2570b);
                    pVar.f2571c = false;
                }
                w0Var.o.a(true);
                w0Var.p.f2625a = false;
                c.d.a.a.c0 c0Var = w0Var.f2606c;
                if (c0Var != null) {
                    StringBuilder a2 = c.a.b.a.a.a("Release ");
                    a2.append(Integer.toHexString(System.identityHashCode(c0Var)));
                    a2.append(" [");
                    a2.append("ExoPlayerLib/2.11.3");
                    a2.append("] [");
                    a2.append(c.d.a.a.m1.c0.e);
                    a2.append("] [");
                    a2.append(c.d.a.a.e0.a());
                    a2.append("]");
                    Log.i("ExoPlayerImpl", a2.toString());
                    c0Var.f.i();
                    c0Var.e.removeCallbacksAndMessages(null);
                    c0Var.t = c0Var.a(false, false, false, 1);
                    w0Var.z();
                    Surface surface = w0Var.s;
                    if (surface != null) {
                        if (w0Var.t) {
                            surface.release();
                        }
                        w0Var.s = null;
                    }
                    c.d.a.a.h1.t tVar = w0Var.C;
                    if (tVar != null) {
                        tVar.a(w0Var.m);
                        w0Var.C = null;
                    }
                    if (w0Var.I) {
                        throw null;
                    }
                    w0Var.l.a(w0Var.m);
                    w0Var.D = Collections.emptyList();
                    return;
                }
                throw null;
            }
            throw null;
        }
    }

    @Override // c.b.v0
    public void e() {
        c.d.a.a.w0 w0Var;
        if (!this.x || (w0Var = this.f1026b) == null) {
            return;
        }
        w0Var.c(false);
        this.y = true;
    }

    public /* synthetic */ void a(int i) {
        try {
            c.d.a.a.w0 w0Var = this.f1026b;
            w0Var.a(w0Var.t(), i);
        } catch (Exception unused) {
        }
    }

    public /* synthetic */ void a(double d2, double d3, double d4, double d5, boolean z) {
        if (this.z) {
            a(d2, d3, d4, d5);
        }
    }

    public /* synthetic */ void a(float f) {
        float f2 = f / 100.0f;
        if (f2 < 0.0f) {
            f2 = 0.0f;
        }
        if (f2 > 1.0f) {
            f2 = 1.0f;
        }
        try {
            c.d.a.a.w0 w0Var = this.f1026b;
            w0Var.B();
            float a2 = c.d.a.a.m1.c0.a(f2, 0.0f, 1.0f);
            if (w0Var.B == a2) {
                return;
            }
            w0Var.B = a2;
            w0Var.A();
            Iterator<c.d.a.a.a1.k> it = w0Var.g.iterator();
            while (it.hasNext()) {
                it.next().a(a2);
            }
        } catch (Exception unused) {
        }
    }

    @Override // c.d.a.a.i1.k
    public void a(List<c.d.a.a.i1.b> list) {
        CharSequence charSequence;
        String str;
        if (list == null || list.size() == 0) {
            a(0, "");
            return;
        }
        for (int i = 0; i < list.size(); i++) {
            c.d.a.a.i1.b bVar = list.get(i);
            if (bVar == null || (charSequence = bVar.f2110b) == null) {
                a(0, "");
            } else {
                if (charSequence != null) {
                    try {
                        str = charSequence.toString().replace("\r", "\\r").replace("\n", "\\n").replace("\t", "\\t").replace("'", "\"");
                    } catch (Exception unused) {
                        str = "";
                    }
                    a(1000, str);
                }
                str = "";
                a(1000, str);
            }
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v8, types: [java.lang.Exception] */
    @Override // c.d.a.a.q0.a
    public void a(c.d.a.a.z zVar) {
        String message;
        c.d.a.a.z zVar2;
        int i = zVar.f2626b;
        if (i != 0) {
            if (i != 1) {
                zVar2 = zVar;
                if (i == 2) {
                    c.d.a.a.m1.e.b(i == 2);
                    Throwable th = zVar.f;
                    c.d.a.a.m1.e.b(th);
                    message = ((RuntimeException) th).getMessage();
                }
            } else {
                c.d.a.a.m1.e.b(i == 1);
                Throwable th2 = zVar.f;
                c.d.a.a.m1.e.b(th2);
                zVar2 = (Exception) th2;
            }
            message = zVar2.getMessage();
        } else {
            c.d.a.a.m1.e.b(i == 0);
            Throwable th3 = zVar.f;
            c.d.a.a.m1.e.b(th3);
            message = ((IOException) th3).getMessage();
        }
        StringBuilder a2 = c.a.b.a.a.a("PlayerGateway.onError(");
        a2.append(this.f);
        a2.append(",\"");
        a2.append(message);
        a2.append("\");");
        b(a2.toString());
    }

    @Override // c.d.a.a.q0.a
    public void a(boolean z, int i) {
        StringBuilder sb;
        try {
            if (i == 2) {
                sb = new StringBuilder();
                sb.append("PlayerGateway.onBuffering(");
                sb.append(this.f);
                sb.append(",0);");
            } else {
                if (i != 3) {
                    if (i == 4) {
                        sb = new StringBuilder();
                        sb.append("PlayerGateway.onEnded(");
                        sb.append(this.f);
                        sb.append(");");
                    }
                }
                this.p = false;
                this.q = 0L;
                if (!this.h) {
                    this.h = true;
                    g();
                    b("PlayerGateway.onMetadataReady(" + this.f + ");");
                    this.o = false;
                    this.m = new Handler();
                    c1 c1Var = new c1(this);
                    this.n = c1Var;
                    this.m.post(c1Var);
                }
                sb = new StringBuilder();
                sb.append("PlayerGateway.onPlaying(");
                sb.append(this.f);
                sb.append(");");
            }
            b(sb.toString());
        } catch (Exception unused) {
        }
    }

    @Override // c.d.a.a.q0.a
    public void a(c.d.a.a.h1.d0 d0Var, c.d.a.a.j1.h hVar) {
        c.d.a.a.f0 c2;
        this.r = null;
        this.s = null;
        if (hVar != null) {
            try {
                if (hVar.f2279a > 0) {
                    for (int i = 0; i < hVar.f2279a; i++) {
                        c.d.a.a.j1.g gVar = hVar.f2280b[i];
                        if (gVar != null && (c2 = gVar.c()) != null) {
                            int a2 = a(c2);
                            if (a2 == 2) {
                                this.r = c2.f1709b;
                            } else if (a2 == 3) {
                                this.s = c2.f1709b;
                            }
                        }
                    }
                }
            } catch (Exception unused) {
            }
        }
    }
}
