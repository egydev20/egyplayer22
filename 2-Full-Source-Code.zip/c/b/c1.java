package c.b;

import android.os.Handler;

/* loaded from: classes.dex */
public class c1 implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ d1 f1020b;

    public c1(d1 d1Var) {
        this.f1020b = d1Var;
    }

    @Override // java.lang.Runnable
    public void run() {
        final d1 d1Var = this.f1020b;
        Handler handler = d1Var.g;
        if (handler != null) {
            handler.post(new Runnable() { // from class: c.b.b
                @Override // java.lang.Runnable
                public final void run() {
                    d1.this.l();
                }
            });
            d1Var.b("PlayerGateway.onTimeChange(" + d1Var.f + "," + d1Var.l + ");");
        }
        d1 d1Var2 = this.f1020b;
        if (d1Var2.o) {
            return;
        }
        d1Var2.m.postDelayed(this, 1000L);
    }
}
