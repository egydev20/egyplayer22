package c.b;

/* loaded from: classes.dex */
public class t0 {

    /* renamed from: a, reason: collision with root package name */
    public int f1113a;

    /* renamed from: b, reason: collision with root package name */
    public String f1114b;
}
