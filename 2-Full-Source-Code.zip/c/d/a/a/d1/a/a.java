package c.d.a.a.d1.a;

import android.os.Handler;
import c.d.a.a.a1.a0;
import c.d.a.a.a1.l;
import c.d.a.a.a1.m;
import c.d.a.a.a1.t;
import c.d.a.a.f0;
import c.d.a.a.m1.e;
import com.google.android.exoplayer2.ext.ffmpeg.FfmpegDecoder;

/* loaded from: classes.dex */
public final class a extends a0 {
    public final boolean K;
    public FfmpegDecoder L;

    public a() {
        this(null, null, new l[0]);
    }

    public a(Handler handler, m mVar, l... lVarArr) {
        super(handler, mVar, null, false, new t(null, lVarArr));
        this.K = false;
    }

    public final boolean b(f0 f0Var) {
        e.b(f0Var.j);
        if (!this.K) {
            return false;
        }
        if (!((t) this.p).a(f0Var.w, 4)) {
            return false;
        }
        String str = f0Var.j;
        char c2 = 65535;
        int hashCode = str.hashCode();
        if (hashCode != 187078296) {
            if (hashCode == 187094639 && str.equals("audio/raw")) {
                c2 = 0;
            }
        } else if (str.equals("audio/ac3")) {
            c2 = 1;
        }
        if (c2 != 0) {
            return c2 != 1;
        }
        int i = f0Var.y;
        return i == 536870912 || i == 805306368 || i == 4;
    }

    @Override // c.d.a.a.s
    public final int u() {
        return 8;
    }
}
