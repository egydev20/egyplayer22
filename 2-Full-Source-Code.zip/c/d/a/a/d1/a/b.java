package c.d.a.a.d1.a;

/* loaded from: classes.dex */
public final class b extends Exception {
    public b(String str) {
        super(str);
    }

    public b(String str, Throwable th) {
        super(str, th);
    }
}
