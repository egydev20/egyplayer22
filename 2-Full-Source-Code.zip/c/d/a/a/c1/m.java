package c.d.a.a.c1;

import c.d.a.a.c1.q;
import java.io.IOException;

/* loaded from: classes.dex */
public interface m<T extends q> {

    /* loaded from: classes.dex */
    public static class a extends IOException {
        public a(Throwable th) {
            super(th);
        }
    }

    boolean a();

    T b();

    a c();

    void d();

    int getState();

    void release();
}
