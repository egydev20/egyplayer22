package c.d.a.a.c1;

import c.d.a.a.c1.r;
import java.util.UUID;

/* loaded from: classes.dex */
public interface u {
    byte[] a(UUID uuid, r.a aVar);

    byte[] a(UUID uuid, r.b bVar);
}
