package c.d.a.a.c1;

import c.d.a.a.c1.m;
import c.d.a.a.c1.q;

/* loaded from: classes.dex */
public final class p<T extends q> implements m<T> {

    /* renamed from: a, reason: collision with root package name */
    public final m.a f1308a;

    public p(m.a aVar) {
        if (aVar == null) {
            throw null;
        }
        this.f1308a = aVar;
    }

    @Override // c.d.a.a.c1.m
    public boolean a() {
        return false;
    }

    @Override // c.d.a.a.c1.m
    public T b() {
        return null;
    }

    @Override // c.d.a.a.c1.m
    public m.a c() {
        return this.f1308a;
    }

    @Override // c.d.a.a.c1.m
    public void d() {
    }

    @Override // c.d.a.a.c1.m
    public int getState() {
        return 1;
    }

    @Override // c.d.a.a.c1.m
    public void release() {
    }
}
