package c.d.a.a.c1;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.media.NotProvisionedException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.Message;
import android.os.SystemClock;
import android.util.Log;
import android.util.Pair;
import c.d.a.a.c1.k;
import c.d.a.a.c1.m;
import c.d.a.a.c1.q;
import c.d.a.a.c1.r;
import c.d.a.a.l1.x;
import c.d.a.a.m1.c0;
import c.d.a.a.m1.l;
import com.google.gson.Gson;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.checkerframework.checker.nullness.qual.EnsuresNonNullIf;
import org.checkerframework.checker.nullness.qual.RequiresNonNull;

@TargetApi(18)
/* loaded from: classes.dex */
public class h<T extends q> implements m<T> {

    /* renamed from: a, reason: collision with root package name */
    public final List<k.b> f1287a;

    /* renamed from: b, reason: collision with root package name */
    public final r<T> f1288b;

    /* renamed from: c, reason: collision with root package name */
    public final a<T> f1289c;

    /* renamed from: d, reason: collision with root package name */
    public final b<T> f1290d;
    public final int e;
    public final boolean f;
    public final boolean g;
    public final HashMap<String, String> h;
    public final c.d.a.a.m1.l<i> i;
    public final x j;
    public final u k;
    public final UUID l;
    public final h<T>.e m;
    public int n;
    public int o;
    public HandlerThread p;
    public h<T>.c q;
    public T r;
    public m.a s;
    public byte[] t;
    public byte[] u;
    public r.a v;
    public r.b w;

    /* loaded from: classes.dex */
    public interface a<T extends q> {
        void a();

        void a(h<T> hVar);

        void a(Exception exc);
    }

    /* loaded from: classes.dex */
    public interface b<T extends q> {
        void a(h<T> hVar);
    }

    @SuppressLint({"HandlerLeak"})
    /* loaded from: classes.dex */
    public class c extends Handler {
        public c(Looper looper) {
            super(looper);
        }

        /* JADX WARN: Removed duplicated region for block: B:18:0x0089 A[RETURN] */
        /* JADX WARN: Removed duplicated region for block: B:19:0x008a  */
        @Override // android.os.Handler
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void handleMessage(android.os.Message r14) {
            /*
                r13 = this;
                java.lang.Object r0 = r14.obj
                c.d.a.a.c1.h$d r0 = (c.d.a.a.c1.h.d) r0
                r1 = 1
                int r2 = r14.what     // Catch: java.lang.Exception -> L34
                if (r2 == 0) goto L23
                if (r2 != r1) goto L1d
                c.d.a.a.c1.h r2 = c.d.a.a.c1.h.this     // Catch: java.lang.Exception -> L34
                c.d.a.a.c1.u r2 = r2.k     // Catch: java.lang.Exception -> L34
                c.d.a.a.c1.h r3 = c.d.a.a.c1.h.this     // Catch: java.lang.Exception -> L34
                java.util.UUID r3 = r3.l     // Catch: java.lang.Exception -> L34
                java.lang.Object r4 = r0.f1294c     // Catch: java.lang.Exception -> L34
                c.d.a.a.c1.r$a r4 = (c.d.a.a.c1.r.a) r4     // Catch: java.lang.Exception -> L34
                byte[] r1 = r2.a(r3, r4)     // Catch: java.lang.Exception -> L34
                goto L8b
            L1d:
                java.lang.RuntimeException r2 = new java.lang.RuntimeException     // Catch: java.lang.Exception -> L34
                r2.<init>()     // Catch: java.lang.Exception -> L34
                throw r2     // Catch: java.lang.Exception -> L34
            L23:
                c.d.a.a.c1.h r2 = c.d.a.a.c1.h.this     // Catch: java.lang.Exception -> L34
                c.d.a.a.c1.u r2 = r2.k     // Catch: java.lang.Exception -> L34
                c.d.a.a.c1.h r3 = c.d.a.a.c1.h.this     // Catch: java.lang.Exception -> L34
                java.util.UUID r3 = r3.l     // Catch: java.lang.Exception -> L34
                java.lang.Object r4 = r0.f1294c     // Catch: java.lang.Exception -> L34
                c.d.a.a.c1.r$b r4 = (c.d.a.a.c1.r.b) r4     // Catch: java.lang.Exception -> L34
                byte[] r1 = r2.a(r3, r4)     // Catch: java.lang.Exception -> L34
                goto L8b
            L34:
                r2 = move-exception
                java.lang.Object r3 = r14.obj
                c.d.a.a.c1.h$d r3 = (c.d.a.a.c1.h.d) r3
                boolean r4 = r3.f1292a
                r5 = 0
                if (r4 != 0) goto L40
            L3e:
                r1 = 0
                goto L87
            L40:
                int r4 = r3.f1295d
                int r4 = r4 + r1
                r3.f1295d = r4
                c.d.a.a.c1.h r6 = c.d.a.a.c1.h.this
                c.d.a.a.l1.x r6 = r6.j
                r7 = 3
                c.d.a.a.l1.u r6 = (c.d.a.a.l1.u) r6
                int r6 = r6.a(r7)
                if (r4 <= r6) goto L53
                goto L3e
            L53:
                boolean r4 = r2 instanceof java.io.IOException
                if (r4 == 0) goto L5b
                r4 = r2
                java.io.IOException r4 = (java.io.IOException) r4
                goto L60
            L5b:
                c.d.a.a.c1.h$f r4 = new c.d.a.a.c1.h$f
                r4.<init>(r2)
            L60:
                r10 = r4
                c.d.a.a.c1.h r4 = c.d.a.a.c1.h.this
                c.d.a.a.l1.x r4 = r4.j
                r7 = 3
                long r8 = android.os.SystemClock.elapsedRealtime()
                long r11 = r3.f1293b
                long r8 = r8 - r11
                int r11 = r3.f1295d
                r6 = r4
                c.d.a.a.l1.u r6 = (c.d.a.a.l1.u) r6
                long r3 = r6.b(r7, r8, r10, r11)
                r6 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
                int r8 = (r3 > r6 ? 1 : (r3 == r6 ? 0 : -1))
                if (r8 != 0) goto L80
                goto L3e
            L80:
                android.os.Message r5 = android.os.Message.obtain(r14)
                r13.sendMessageDelayed(r5, r3)
            L87:
                if (r1 == 0) goto L8a
                return
            L8a:
                r1 = r2
            L8b:
                c.d.a.a.c1.h r2 = c.d.a.a.c1.h.this
                c.d.a.a.c1.h<T>$e r2 = r2.m
                int r14 = r14.what
                java.lang.Object r0 = r0.f1294c
                android.util.Pair r0 = android.util.Pair.create(r0, r1)
                android.os.Message r14 = r2.obtainMessage(r14, r0)
                r14.sendToTarget()
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.c1.h.c.handleMessage(android.os.Message):void");
        }
    }

    /* loaded from: classes.dex */
    public static final class d {

        /* renamed from: a, reason: collision with root package name */
        public final boolean f1292a;

        /* renamed from: b, reason: collision with root package name */
        public final long f1293b;

        /* renamed from: c, reason: collision with root package name */
        public final Object f1294c;

        /* renamed from: d, reason: collision with root package name */
        public int f1295d;

        public d(boolean z, long j, Object obj) {
            this.f1292a = z;
            this.f1293b = j;
            this.f1294c = obj;
        }
    }

    @SuppressLint({"HandlerLeak"})
    /* loaded from: classes.dex */
    public class e extends Handler {
        public e(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            a<T> aVar;
            c.d.a.a.m1.l<i> lVar;
            l.a<i> aVar2;
            Pair pair = (Pair) message.obj;
            Object obj = pair.first;
            Object obj2 = pair.second;
            int i = message.what;
            if (i == 0) {
                h hVar = h.this;
                if (obj == hVar.w) {
                    if (hVar.n == 2 || hVar.e()) {
                        hVar.w = null;
                        if (obj2 instanceof Exception) {
                            aVar = hVar.f1289c;
                            e = (Exception) obj2;
                        } else {
                            try {
                                hVar.f1288b.b((byte[]) obj2);
                                hVar.f1289c.a();
                                return;
                            } catch (Exception e) {
                                e = e;
                                aVar = hVar.f1289c;
                            }
                        }
                        aVar.a(e);
                        return;
                    }
                    return;
                }
                return;
            }
            if (i != 1) {
                return;
            }
            h hVar2 = h.this;
            if (obj == hVar2.v && hVar2.e()) {
                hVar2.v = null;
                if (obj2 instanceof Exception) {
                    e = (Exception) obj2;
                } else {
                    try {
                        byte[] bArr = (byte[]) obj2;
                        if (hVar2.e == 3) {
                            r<T> rVar = hVar2.f1288b;
                            byte[] bArr2 = hVar2.u;
                            c0.a(bArr2);
                            rVar.b(bArr2, bArr);
                            lVar = hVar2.i;
                            aVar2 = c.d.a.a.c1.f.f1285a;
                        } else {
                            byte[] b2 = hVar2.f1288b.b(hVar2.t, bArr);
                            if ((hVar2.e == 2 || (hVar2.e == 0 && hVar2.u != null)) && b2 != null && b2.length != 0) {
                                hVar2.u = b2;
                            }
                            hVar2.n = 4;
                            lVar = hVar2.i;
                            aVar2 = new l.a() { // from class: c.d.a.a.c1.g
                                @Override // c.d.a.a.m1.l.a
                                public final void a(Object obj3) {
                                    ((c.d.a.a.z0.a) ((i) obj3)).f();
                                }
                            };
                        }
                        lVar.a(aVar2);
                        return;
                    } catch (Exception e2) {
                        e = e2;
                    }
                }
                hVar2.b(e);
            }
        }
    }

    /* loaded from: classes.dex */
    public static final class f extends IOException {
        /* JADX WARN: Illegal instructions before constructor call */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public f(java.lang.Throwable r3) {
            /*
                r2 = this;
                java.lang.String r0 = "Unexpected "
                java.lang.StringBuilder r0 = c.a.b.a.a.a(r0)
                java.lang.Class r1 = r3.getClass()
                java.lang.String r1 = r1.getSimpleName()
                r0.append(r1)
                java.lang.String r1 = ": "
                r0.append(r1)
                java.lang.String r1 = r3.getMessage()
                r0.append(r1)
                java.lang.String r0 = r0.toString()
                r2.<init>(r0, r3)
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.c1.h.f.<init>(java.lang.Throwable):void");
        }
    }

    public h(UUID uuid, r<T> rVar, a<T> aVar, b<T> bVar, List<k.b> list, int i, boolean z, boolean z2, byte[] bArr, HashMap<String, String> hashMap, u uVar, Looper looper, c.d.a.a.m1.l<i> lVar, x xVar) {
        if ((i == 1 || i == 3) && bArr == null) {
            throw null;
        }
        this.l = uuid;
        this.f1289c = aVar;
        this.f1290d = bVar;
        this.f1288b = rVar;
        this.e = i;
        this.f = z;
        this.g = z2;
        if (bArr != null) {
            this.u = bArr;
            this.f1287a = null;
        } else {
            if (list == null) {
                throw null;
            }
            this.f1287a = Collections.unmodifiableList(list);
        }
        this.h = hashMap;
        this.k = uVar;
        this.i = lVar;
        this.j = xVar;
        this.n = 2;
        this.m = new e(looper);
    }

    public final void a(final Exception exc) {
        this.s = new m.a(exc);
        this.i.a(new l.a() { // from class: c.d.a.a.c1.b
            @Override // c.d.a.a.m1.l.a
            public final void a(Object obj) {
                ((c.d.a.a.z0.a) ((i) obj)).a(exc);
            }
        });
        if (this.n != 4) {
            this.n = 1;
        }
    }

    /* JADX WARN: Can't wrap try/catch for region: R(9:51|(2:52|53)|(6:55|56|57|58|(1:60)|62)|65|56|57|58|(0)|62) */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0092 A[Catch: NumberFormatException -> 0x0096, TRY_LEAVE, TryCatch #0 {NumberFormatException -> 0x0096, blocks: (B:58:0x008a, B:60:0x0092), top: B:57:0x008a }] */
    @org.checkerframework.checker.nullness.qual.RequiresNonNull({"sessionId"})
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a(boolean r11) {
        /*
            Method dump skipped, instructions count: 240
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.c1.h.a(boolean):void");
    }

    @Override // c.d.a.a.c1.m
    public boolean a() {
        return this.f;
    }

    @Override // c.d.a.a.c1.m
    public final T b() {
        return this.r;
    }

    public final void b(Exception exc) {
        if (exc instanceof NotProvisionedException) {
            this.f1289c.a(this);
        } else {
            a(exc);
        }
    }

    @Override // c.d.a.a.c1.m
    public final m.a c() {
        if (this.n == 1) {
            return this.s;
        }
        return null;
    }

    @Override // c.d.a.a.c1.m
    public void d() {
        boolean z = false;
        c.d.a.a.m1.e.b(this.o >= 0);
        int i = this.o + 1;
        this.o = i;
        if (i == 1) {
            c.d.a.a.m1.e.b(this.n == 2);
            HandlerThread handlerThread = new HandlerThread("DrmRequestHandler");
            this.p = handlerThread;
            handlerThread.start();
            this.q = new c(this.p.getLooper());
            if (!e()) {
                try {
                    byte[] b2 = this.f1288b.b();
                    this.t = b2;
                    this.r = this.f1288b.a(b2);
                    this.i.a(new l.a() { // from class: c.d.a.a.c1.e
                        @Override // c.d.a.a.m1.l.a
                        public final void a(Object obj) {
                            ((c.d.a.a.z0.a) ((i) obj)).h();
                        }
                    });
                    this.n = 3;
                    c.d.a.a.m1.e.b(this.t);
                } catch (NotProvisionedException unused) {
                    this.f1289c.a(this);
                } catch (Exception e2) {
                    a(e2);
                }
            }
            z = true;
            if (z) {
                a(true);
            }
        }
    }

    @EnsuresNonNullIf(expression = {"sessionId"}, result = Gson.DEFAULT_ESCAPE_HTML)
    public final boolean e() {
        int i = this.n;
        return i == 3 || i == 4;
    }

    public Map<String, String> f() {
        byte[] bArr = this.t;
        if (bArr == null) {
            return null;
        }
        return this.f1288b.c(bArr);
    }

    @RequiresNonNull({"sessionId", "offlineLicenseKeySetId"})
    public final boolean g() {
        try {
            this.f1288b.a(this.t, this.u);
            return true;
        } catch (Exception e2) {
            Log.e("DefaultDrmSession", "Error trying to restore keys.", e2);
            a(e2);
            return false;
        }
    }

    @Override // c.d.a.a.c1.m
    public final int getState() {
        return this.n;
    }

    @Override // c.d.a.a.c1.m
    public void release() {
        int i = this.o - 1;
        this.o = i;
        if (i == 0) {
            this.n = 0;
            h<T>.e eVar = this.m;
            c0.a(eVar);
            eVar.removeCallbacksAndMessages(null);
            this.q.removeCallbacksAndMessages(null);
            this.q = null;
            this.p.quit();
            this.p = null;
            this.r = null;
            this.s = null;
            this.v = null;
            this.w = null;
            byte[] bArr = this.t;
            if (bArr != null) {
                this.f1288b.d(bArr);
                this.t = null;
                this.i.a(new l.a() { // from class: c.d.a.a.c1.a
                    @Override // c.d.a.a.m1.l.a
                    public final void a(Object obj) {
                        ((c.d.a.a.z0.a) ((i) obj)).i();
                    }
                });
            }
            this.f1290d.a(this);
        }
    }

    public final void a(byte[] bArr, int i, boolean z) {
        try {
            this.v = this.f1288b.a(bArr, this.f1287a, i, this.h);
            h<T>.c cVar = this.q;
            c0.a(cVar);
            r.a aVar = this.v;
            c.d.a.a.m1.e.b(aVar);
            if (cVar == null) {
                throw null;
            }
            cVar.obtainMessage(1, new d(z, SystemClock.elapsedRealtime(), aVar)).sendToTarget();
        } catch (Exception e2) {
            b(e2);
        }
    }
}
