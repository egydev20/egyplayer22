package c.d.a.a.c1;

import android.os.Looper;
import c.d.a.a.c1.m;
import c.d.a.a.c1.q;

/* loaded from: classes.dex */
public interface o<T extends q> {

    /* renamed from: a, reason: collision with root package name */
    public static final o<q> f1307a = new a();

    /* loaded from: classes.dex */
    public static class a implements o<q> {
        @Override // c.d.a.a.c1.o
        public /* synthetic */ m<T> a(Looper looper, int i) {
            return n.a(this, looper, i);
        }

        @Override // c.d.a.a.c1.o
        public m<q> a(Looper looper, k kVar) {
            return new p(new m.a(new v(1)));
        }

        @Override // c.d.a.a.c1.o
        public /* synthetic */ void a() {
            n.a(this);
        }

        @Override // c.d.a.a.c1.o
        public boolean a(k kVar) {
            return false;
        }

        @Override // c.d.a.a.c1.o
        public Class<q> b(k kVar) {
            return null;
        }

        @Override // c.d.a.a.c1.o
        public /* synthetic */ void release() {
            n.b(this);
        }
    }

    m<T> a(Looper looper, int i);

    m<T> a(Looper looper, k kVar);

    void a();

    boolean a(k kVar);

    Class<? extends q> b(k kVar);

    void release();
}
