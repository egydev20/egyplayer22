package c.d.a.a.c1;

import c.d.a.a.m1.l;

/* compiled from: lambda */
/* loaded from: classes.dex */
public final /* synthetic */ class f implements l.a {

    /* renamed from: a, reason: collision with root package name */
    public static final /* synthetic */ f f1285a = new f();

    private /* synthetic */ f() {
    }

    @Override // c.d.a.a.m1.l.a
    public final void a(Object obj) {
        ((c.d.a.a.z0.a) ((i) obj)).g();
    }
}
