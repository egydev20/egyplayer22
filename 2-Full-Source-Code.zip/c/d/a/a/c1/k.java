package c.d.a.a.c1;

import android.os.Parcel;
import android.os.Parcelable;
import c.d.a.a.m1.c0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.UUID;

/* loaded from: classes.dex */
public final class k implements Comparator<b>, Parcelable {
    public static final Parcelable.Creator<k> CREATOR = new a();

    /* renamed from: b, reason: collision with root package name */
    public final b[] f1301b;

    /* renamed from: c, reason: collision with root package name */
    public int f1302c;

    /* renamed from: d, reason: collision with root package name */
    public final String f1303d;
    public final int e;

    /* loaded from: classes.dex */
    public static class a implements Parcelable.Creator<k> {
        @Override // android.os.Parcelable.Creator
        public k createFromParcel(Parcel parcel) {
            return new k(parcel);
        }

        @Override // android.os.Parcelable.Creator
        public k[] newArray(int i) {
            return new k[i];
        }
    }

    /* loaded from: classes.dex */
    public static final class b implements Parcelable {
        public static final Parcelable.Creator<b> CREATOR = new a();

        /* renamed from: b, reason: collision with root package name */
        public int f1304b;

        /* renamed from: c, reason: collision with root package name */
        public final UUID f1305c;

        /* renamed from: d, reason: collision with root package name */
        public final String f1306d;
        public final String e;
        public final byte[] f;

        /* loaded from: classes.dex */
        public static class a implements Parcelable.Creator<b> {
            @Override // android.os.Parcelable.Creator
            public b createFromParcel(Parcel parcel) {
                return new b(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public b[] newArray(int i) {
                return new b[i];
            }
        }

        public b(Parcel parcel) {
            this.f1305c = new UUID(parcel.readLong(), parcel.readLong());
            this.f1306d = parcel.readString();
            String readString = parcel.readString();
            c0.a(readString);
            this.e = readString;
            this.f = parcel.createByteArray();
        }

        public b(UUID uuid, String str, String str2, byte[] bArr) {
            if (uuid == null) {
                throw null;
            }
            this.f1305c = uuid;
            this.f1306d = str;
            if (str2 == null) {
                throw null;
            }
            this.e = str2;
            this.f = bArr;
        }

        public boolean a(UUID uuid) {
            return c.d.a.a.t.f2591a.equals(this.f1305c) || uuid.equals(this.f1305c);
        }

        public boolean c() {
            return this.f != null;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        public boolean equals(Object obj) {
            if (!(obj instanceof b)) {
                return false;
            }
            if (obj == this) {
                return true;
            }
            b bVar = (b) obj;
            return c0.a((Object) this.f1306d, (Object) bVar.f1306d) && c0.a((Object) this.e, (Object) bVar.e) && c0.a(this.f1305c, bVar.f1305c) && Arrays.equals(this.f, bVar.f);
        }

        public int hashCode() {
            if (this.f1304b == 0) {
                int hashCode = this.f1305c.hashCode() * 31;
                String str = this.f1306d;
                this.f1304b = Arrays.hashCode(this.f) + ((this.e.hashCode() + ((hashCode + (str == null ? 0 : str.hashCode())) * 31)) * 31);
            }
            return this.f1304b;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeLong(this.f1305c.getMostSignificantBits());
            parcel.writeLong(this.f1305c.getLeastSignificantBits());
            parcel.writeString(this.f1306d);
            parcel.writeString(this.e);
            parcel.writeByteArray(this.f);
        }
    }

    public k(Parcel parcel) {
        this.f1303d = parcel.readString();
        Object[] createTypedArray = parcel.createTypedArray(b.CREATOR);
        c0.a(createTypedArray);
        b[] bVarArr = (b[]) createTypedArray;
        this.f1301b = bVarArr;
        this.e = bVarArr.length;
    }

    public k(String str, boolean z, b... bVarArr) {
        this.f1303d = str;
        bVarArr = z ? (b[]) bVarArr.clone() : bVarArr;
        this.f1301b = bVarArr;
        this.e = bVarArr.length;
        Arrays.sort(bVarArr, this);
    }

    public static k a(k kVar, k kVar2) {
        String str;
        boolean z;
        ArrayList arrayList = new ArrayList();
        if (kVar != null) {
            str = kVar.f1303d;
            for (b bVar : kVar.f1301b) {
                if (bVar.c()) {
                    arrayList.add(bVar);
                }
            }
        } else {
            str = null;
        }
        if (kVar2 != null) {
            if (str == null) {
                str = kVar2.f1303d;
            }
            int size = arrayList.size();
            for (b bVar2 : kVar2.f1301b) {
                if (bVar2.c()) {
                    UUID uuid = bVar2.f1305c;
                    int i = 0;
                    while (true) {
                        if (i >= size) {
                            z = false;
                            break;
                        }
                        if (((b) arrayList.get(i)).f1305c.equals(uuid)) {
                            z = true;
                            break;
                        }
                        i++;
                    }
                    if (!z) {
                        arrayList.add(bVar2);
                    }
                }
            }
        }
        if (arrayList.isEmpty()) {
            return null;
        }
        return new k(str, false, (b[]) arrayList.toArray(new b[0]));
    }

    public k a(String str) {
        return c0.a((Object) this.f1303d, (Object) str) ? this : new k(str, false, this.f1301b);
    }

    @Override // java.util.Comparator
    public int compare(b bVar, b bVar2) {
        b bVar3 = bVar;
        b bVar4 = bVar2;
        if (c.d.a.a.t.f2591a.equals(bVar3.f1305c)) {
            return c.d.a.a.t.f2591a.equals(bVar4.f1305c) ? 0 : 1;
        }
        return bVar3.f1305c.compareTo(bVar4.f1305c);
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return 0;
    }

    @Override // java.util.Comparator
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || k.class != obj.getClass()) {
            return false;
        }
        k kVar = (k) obj;
        return c0.a((Object) this.f1303d, (Object) kVar.f1303d) && Arrays.equals(this.f1301b, kVar.f1301b);
    }

    public int hashCode() {
        if (this.f1302c == 0) {
            String str = this.f1303d;
            this.f1302c = ((str == null ? 0 : str.hashCode()) * 31) + Arrays.hashCode(this.f1301b);
        }
        return this.f1302c;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(this.f1303d);
        parcel.writeTypedArray(this.f1301b, 0);
    }
}
