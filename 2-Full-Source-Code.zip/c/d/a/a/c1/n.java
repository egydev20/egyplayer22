package c.d.a.a.c1;

import android.os.Looper;

/* loaded from: classes.dex */
public final /* synthetic */ class n {
    public static m a(o oVar, Looper looper, int i) {
        return null;
    }

    public static <T extends q> o<T> a() {
        return (o<T>) o.f1307a;
    }

    public static void a(o oVar) {
    }

    public static void b(o oVar) {
    }
}
