package c.d.a.a.c1;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import c.d.a.a.c1.h;
import c.d.a.a.c1.j;
import c.d.a.a.c1.k;
import c.d.a.a.c1.q;
import c.d.a.a.m1.c0;
import c.d.a.a.m1.l;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;

@TargetApi(18)
/* loaded from: classes.dex */
public class j<T extends q> implements o<T> {

    /* renamed from: b, reason: collision with root package name */
    public final List<h<T>> f1297b;

    /* renamed from: c, reason: collision with root package name */
    public int f1298c;

    /* renamed from: d, reason: collision with root package name */
    public r<T> f1299d;
    public h<T> e;
    public Looper f;
    public volatile j<T>.b g;

    @SuppressLint({"HandlerLeak"})
    /* loaded from: classes.dex */
    public class b extends Handler {
        public b(Looper looper) {
            super(looper);
        }

        @Override // android.os.Handler
        public void handleMessage(Message message) {
            byte[] bArr = (byte[]) message.obj;
            if (bArr == null) {
                return;
            }
            for (h<T> hVar : j.this.f1297b) {
                if (Arrays.equals(hVar.t, bArr)) {
                    if (message.what == 2 && hVar.e == 0 && hVar.n == 4) {
                        c0.a(hVar.t);
                        hVar.a(false);
                        return;
                    }
                    return;
                }
            }
        }
    }

    /* loaded from: classes.dex */
    public static final class c extends Exception {
        public /* synthetic */ c(UUID uuid, a aVar) {
            super("Media does not support uuid: " + uuid);
        }
    }

    public final h<T> a(List<k.b> list, boolean z) {
        c.d.a.a.m1.e.b(this.f1299d);
        r<T> rVar = this.f1299d;
        h.b bVar = new h.b() { // from class: c.d.a.a.c1.d
            @Override // c.d.a.a.c1.h.b
            public final void a(h hVar) {
                j jVar = j.this;
                throw null;
            }
        };
        Looper looper = this.f;
        c.d.a.a.m1.e.b(looper);
        return new h<>(null, rVar, null, bVar, list, 0, false | z, z, null, null, null, looper, null, null);
    }

    @Override // c.d.a.a.c1.o
    public m<T> a(Looper looper, int i) {
        Looper looper2 = this.f;
        c.d.a.a.m1.e.b(looper2 == null || looper2 == looper);
        this.f = looper;
        r<T> rVar = this.f1299d;
        c.d.a.a.m1.e.b(rVar);
        if (s.class.equals(rVar.a()) && s.f1309d) {
            return null;
        }
        throw null;
    }

    @Override // c.d.a.a.c1.o
    public final void a() {
        int i = this.f1298c;
        this.f1298c = i + 1;
        if (i == 0) {
            c.d.a.a.m1.e.b(this.f1299d == null);
            throw null;
        }
    }

    @Override // c.d.a.a.c1.o
    public Class<T> b(k kVar) {
        if (!a(kVar)) {
            return null;
        }
        r<T> rVar = this.f1299d;
        c.d.a.a.m1.e.b(rVar);
        return rVar.a();
    }

    @Override // c.d.a.a.c1.o
    public final void release() {
        int i = this.f1298c - 1;
        this.f1298c = i;
        if (i == 0) {
            r<T> rVar = this.f1299d;
            c.d.a.a.m1.e.b(rVar);
            rVar.release();
            this.f1299d = null;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // c.d.a.a.c1.o
    public m<T> a(Looper looper, k kVar) {
        Looper looper2 = this.f;
        c.d.a.a.m1.e.b(looper2 == null || looper2 == looper);
        this.f = looper;
        if (this.g == null) {
            this.g = new b(looper);
        }
        UUID uuid = null;
        Object[] objArr = 0;
        List<k.b> a2 = a(kVar, null, false);
        if (((ArrayList) a2).isEmpty()) {
            final c cVar = new c(uuid, objArr == true ? 1 : 0);
            new l.a() { // from class: c.d.a.a.c1.c
                @Override // c.d.a.a.m1.l.a
                public final void a(Object obj) {
                    ((c.d.a.a.z0.a) ((i) obj)).a(j.c.this);
                }
            };
            throw null;
        }
        h<T> hVar = this.e;
        if (hVar != null) {
            hVar.d();
            return hVar;
        }
        this.e = a(a2, false);
        throw null;
    }

    @Override // c.d.a.a.c1.o
    public boolean a(k kVar) {
        if (((ArrayList) a(kVar, null, true)).isEmpty()) {
            if (kVar.e != 1 || !kVar.f1301b[0].a(c.d.a.a.t.f2592b)) {
                return false;
            }
            Log.w("DefaultDrmSessionMgr", "DrmInitData only contains common PSSH SchemeData. Assuming support for: " + ((Object) null));
        }
        String str = kVar.f1303d;
        if (str == null || "cenc".equals(str)) {
            return true;
        }
        return !("cbc1".equals(str) || "cbcs".equals(str) || "cens".equals(str)) || c0.f2426a >= 25;
    }

    public static List<k.b> a(k kVar, UUID uuid, boolean z) {
        ArrayList arrayList = new ArrayList(kVar.e);
        for (int i = 0; i < kVar.e; i++) {
            k.b bVar = kVar.f1301b[i];
            if ((bVar.a(uuid) || (c.d.a.a.t.f2593c.equals(uuid) && bVar.a(c.d.a.a.t.f2592b))) && (bVar.f != null || z)) {
                arrayList.add(bVar);
            }
        }
        return arrayList;
    }
}
