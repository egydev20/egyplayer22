package c.d.a.a.c1;

/* loaded from: classes.dex */
public final class v extends Exception {
    public v(int i) {
    }
}
