package c.d.a.a.c1;

import c.d.a.a.m1.c0;
import java.util.UUID;

/* loaded from: classes.dex */
public final class s implements q {

    /* renamed from: d, reason: collision with root package name */
    public static final boolean f1309d;

    /* renamed from: a, reason: collision with root package name */
    public final UUID f1310a;

    /* renamed from: b, reason: collision with root package name */
    public final byte[] f1311b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f1312c;

    static {
        f1309d = "Amazon".equals(c0.f2428c) && ("AFTM".equals(c0.f2429d) || "AFTB".equals(c0.f2429d));
    }
}
