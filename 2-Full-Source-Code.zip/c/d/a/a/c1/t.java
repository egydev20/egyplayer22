package c.d.a.a.c1;

/* loaded from: classes.dex */
public final class t extends Exception {
}
