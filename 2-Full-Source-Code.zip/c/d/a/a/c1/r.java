package c.d.a.a.c1;

import c.d.a.a.c1.k;
import c.d.a.a.c1.q;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public interface r<T extends q> {

    /* loaded from: classes.dex */
    public static final class a {
    }

    /* loaded from: classes.dex */
    public static final class b {
    }

    T a(byte[] bArr);

    a a(byte[] bArr, List<k.b> list, int i, HashMap<String, String> hashMap);

    Class<T> a();

    void a(byte[] bArr, byte[] bArr2);

    void b(byte[] bArr);

    byte[] b();

    byte[] b(byte[] bArr, byte[] bArr2);

    Map<String, String> c(byte[] bArr);

    void d(byte[] bArr);

    void release();
}
