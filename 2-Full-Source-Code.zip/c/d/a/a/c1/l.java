package c.d.a.a.c1;

/* loaded from: classes.dex */
public final /* synthetic */ class l {
    public static <T extends q> void a(m<T> mVar, m<T> mVar2) {
        if (mVar == mVar2) {
            return;
        }
        if (mVar2 != null) {
            mVar2.d();
        }
        if (mVar != null) {
            mVar.release();
        }
    }
}
