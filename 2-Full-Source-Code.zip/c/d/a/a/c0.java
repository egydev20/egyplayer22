package c.d.a.a;

import android.annotation.SuppressLint;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Pair;
import c.d.a.a.c0;
import c.d.a.a.d0;
import c.d.a.a.h1.t;
import c.d.a.a.j1.e;
import c.d.a.a.q0;
import c.d.a.a.r;
import c.d.a.a.r0;
import c.d.a.a.x0;
import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: classes.dex */
public final class c0 extends r implements a0 {

    /* renamed from: b, reason: collision with root package name */
    public final c.d.a.a.j1.k f1274b;

    /* renamed from: c, reason: collision with root package name */
    public final t0[] f1275c;

    /* renamed from: d, reason: collision with root package name */
    public final c.d.a.a.j1.j f1276d;
    public final Handler e;
    public final d0 f;
    public final Handler g;
    public final CopyOnWriteArrayList<r.a> h;
    public final x0.b i;
    public final ArrayDeque<Runnable> j;
    public boolean k;
    public int l;
    public int m;
    public boolean n;
    public int o;
    public boolean p;
    public boolean q;
    public int r;
    public n0 s;
    public m0 t;
    public int u;
    public int v;
    public long w;

    /* loaded from: classes.dex */
    public static final class a implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public final m0 f1277b;

        /* renamed from: c, reason: collision with root package name */
        public final CopyOnWriteArrayList<r.a> f1278c;

        /* renamed from: d, reason: collision with root package name */
        public final c.d.a.a.j1.j f1279d;
        public final boolean e;
        public final int f;
        public final int g;
        public final boolean h;
        public final boolean i;
        public final boolean j;
        public final boolean k;
        public final boolean l;
        public final boolean m;
        public final boolean n;
        public final boolean o;

        public a(m0 m0Var, m0 m0Var2, CopyOnWriteArrayList<r.a> copyOnWriteArrayList, c.d.a.a.j1.j jVar, boolean z, int i, int i2, boolean z2, boolean z3, boolean z4) {
            this.f1277b = m0Var;
            this.f1278c = new CopyOnWriteArrayList<>(copyOnWriteArrayList);
            this.f1279d = jVar;
            this.e = z;
            this.f = i;
            this.g = i2;
            this.h = z2;
            this.n = z3;
            this.o = z4;
            this.i = m0Var2.e != m0Var.e;
            z zVar = m0Var2.f;
            z zVar2 = m0Var.f;
            this.j = (zVar == zVar2 || zVar2 == null) ? false : true;
            this.k = m0Var2.f2411a != m0Var.f2411a;
            this.l = m0Var2.g != m0Var.g;
            this.m = m0Var2.i != m0Var.i;
        }

        public /* synthetic */ void a(q0.a aVar) {
            aVar.a(this.f1277b.f2411a, this.g);
        }

        public /* synthetic */ void b(q0.a aVar) {
            aVar.c(this.f);
        }

        public /* synthetic */ void c(q0.a aVar) {
            aVar.a(this.f1277b.f);
        }

        public /* synthetic */ void d(q0.a aVar) {
            m0 m0Var = this.f1277b;
            aVar.a(m0Var.h, m0Var.i.f2293c);
        }

        public /* synthetic */ void e(q0.a aVar) {
            aVar.a(this.f1277b.g);
        }

        public /* synthetic */ void f(q0.a aVar) {
            aVar.a(this.n, this.f1277b.e);
        }

        public /* synthetic */ void g(q0.a aVar) {
            aVar.c(this.f1277b.e == 3);
        }

        @Override // java.lang.Runnable
        public void run() {
            if (this.k || this.g == 0) {
                c0.a(this.f1278c, new r.b() { // from class: c.d.a.a.f
                    @Override // c.d.a.a.r.b
                    public final void a(q0.a aVar) {
                        c0.a.this.a(aVar);
                    }
                });
            }
            if (this.e) {
                c0.a(this.f1278c, new r.b() { // from class: c.d.a.a.e
                    @Override // c.d.a.a.r.b
                    public final void a(q0.a aVar) {
                        c0.a.this.b(aVar);
                    }
                });
            }
            if (this.j) {
                c0.a(this.f1278c, new r.b() { // from class: c.d.a.a.i
                    @Override // c.d.a.a.r.b
                    public final void a(q0.a aVar) {
                        c0.a.this.c(aVar);
                    }
                });
            }
            if (this.m) {
                c.d.a.a.j1.j jVar = this.f1279d;
                Object obj = this.f1277b.i.f2294d;
                c.d.a.a.j1.e eVar = (c.d.a.a.j1.e) jVar;
                if (eVar != null) {
                    eVar.f2270c = (e.a) obj;
                    c0.a(this.f1278c, new r.b() { // from class: c.d.a.a.h
                        @Override // c.d.a.a.r.b
                        public final void a(q0.a aVar) {
                            c0.a.this.d(aVar);
                        }
                    });
                } else {
                    throw null;
                }
            }
            if (this.l) {
                c0.a(this.f1278c, new r.b() { // from class: c.d.a.a.j
                    @Override // c.d.a.a.r.b
                    public final void a(q0.a aVar) {
                        c0.a.this.e(aVar);
                    }
                });
            }
            if (this.i) {
                c0.a(this.f1278c, new r.b() { // from class: c.d.a.a.d
                    @Override // c.d.a.a.r.b
                    public final void a(q0.a aVar) {
                        c0.a.this.f(aVar);
                    }
                });
            }
            if (this.o) {
                c0.a(this.f1278c, new r.b() { // from class: c.d.a.a.g
                    @Override // c.d.a.a.r.b
                    public final void a(q0.a aVar) {
                        c0.a.this.g(aVar);
                    }
                });
            }
            if (this.h) {
                Iterator<r.a> it = this.f1278c.iterator();
                while (it.hasNext()) {
                    r.a next = it.next();
                    if (!next.f2583b) {
                        next.f2582a.b();
                    }
                }
            }
        }
    }

    @SuppressLint({"HandlerLeak"})
    public c0(t0[] t0VarArr, c.d.a.a.j1.j jVar, w wVar, c.d.a.a.l1.f fVar, c.d.a.a.m1.f fVar2, Looper looper) {
        StringBuilder a2 = c.a.b.a.a.a("Init ");
        a2.append(Integer.toHexString(System.identityHashCode(this)));
        a2.append(" [");
        a2.append("ExoPlayerLib/2.11.3");
        a2.append("] [");
        a2.append(c.d.a.a.m1.c0.e);
        a2.append("]");
        Log.i("ExoPlayerImpl", a2.toString());
        c.d.a.a.m1.e.b(t0VarArr.length > 0);
        this.f1275c = t0VarArr;
        if (jVar != null) {
            this.f1276d = jVar;
            this.k = false;
            this.m = 0;
            this.n = false;
            this.h = new CopyOnWriteArrayList<>();
            this.f1274b = new c.d.a.a.j1.k(new u0[t0VarArr.length], new c.d.a.a.j1.g[t0VarArr.length], null);
            this.i = new x0.b();
            this.s = n0.e;
            v0 v0Var = v0.f2598d;
            this.l = 0;
            this.e = new b0(this, looper);
            this.t = m0.a(0L, this.f1274b);
            this.j = new ArrayDeque<>();
            this.f = new d0(t0VarArr, jVar, this.f1274b, wVar, fVar, this.k, this.m, this.n, this.e, fVar2);
            this.g = new Handler(this.f.i.getLooper());
            return;
        }
        throw null;
    }

    public static /* synthetic */ void a(boolean z, boolean z2, int i, boolean z3, int i2, boolean z4, boolean z5, q0.a aVar) {
        if (z) {
            aVar.a(z2, i);
        }
        if (z3) {
            aVar.b(i2);
        }
        if (z4) {
            aVar.c(z5);
        }
    }

    public final m0 a(boolean z, boolean z2, boolean z3, int i) {
        int a2;
        if (z) {
            this.u = 0;
            this.v = 0;
            this.w = 0L;
        } else {
            this.u = t();
            if (y()) {
                a2 = this.v;
            } else {
                m0 m0Var = this.t;
                a2 = m0Var.f2411a.a(m0Var.f2412b.f2054a);
            }
            this.v = a2;
            this.w = getCurrentPosition();
        }
        boolean z4 = z || z2;
        m0 m0Var2 = this.t;
        t.a a3 = z4 ? m0Var2.a(this.n, this.f2581a, this.i) : m0Var2.f2412b;
        long j = z4 ? 0L : this.t.m;
        return new m0(z2 ? x0.f2612a : this.t.f2411a, a3, j, z4 ? -9223372036854775807L : this.t.f2414d, i, z3 ? null : this.t.f, false, z2 ? c.d.a.a.h1.d0.e : this.t.h, z2 ? this.f1274b : this.t.i, a3, j, 0L, j);
    }

    @Override // c.d.a.a.q0
    public n0 a() {
        return this.s;
    }

    public r0 a(r0.b bVar) {
        return new r0(this.f, bVar, this.t.f2411a, t(), this.g);
    }

    public final void a(m0 m0Var, boolean z, int i, int i2, boolean z2) {
        boolean isPlaying = isPlaying();
        m0 m0Var2 = this.t;
        this.t = m0Var;
        a(new a(m0Var, m0Var2, this.h, this.f1276d, z, i, i2, z2, this.k, isPlaying != isPlaying()));
    }

    @Override // c.d.a.a.q0
    public void a(q0.a aVar) {
        this.h.addIfAbsent(new r.a(aVar));
    }

    public final void a(final r.b bVar) {
        final CopyOnWriteArrayList copyOnWriteArrayList = new CopyOnWriteArrayList(this.h);
        a(new Runnable() { // from class: c.d.a.a.b
            @Override // java.lang.Runnable
            public final void run() {
                c0.a((CopyOnWriteArrayList<r.a>) copyOnWriteArrayList, bVar);
            }
        });
    }

    public final void a(Runnable runnable) {
        boolean z = !this.j.isEmpty();
        this.j.addLast(runnable);
        if (z) {
            return;
        }
        while (!this.j.isEmpty()) {
            this.j.peekFirst().run();
            this.j.removeFirst();
        }
    }

    @Override // c.d.a.a.q0
    public void a(boolean z) {
        a(z, 0);
    }

    @Override // c.d.a.a.q0
    public int b(int i) {
        return this.f1275c[i].m();
    }

    @Override // c.d.a.a.q0
    public q0.c b() {
        return null;
    }

    @Override // c.d.a.a.q0
    public void b(q0.a aVar) {
        Iterator<r.a> it = this.h.iterator();
        while (it.hasNext()) {
            r.a next = it.next();
            if (next.f2582a.equals(aVar)) {
                next.f2583b = true;
                this.h.remove(next);
            }
        }
    }

    @Override // c.d.a.a.q0
    public void c(boolean z) {
        m0 a2 = a(z, z, z, 1);
        this.o++;
        this.f.h.a(6, z ? 1 : 0, 0).sendToTarget();
        a(a2, false, 4, 1, false);
    }

    @Override // c.d.a.a.q0
    public boolean c() {
        return !y() && this.t.f2412b.a();
    }

    @Override // c.d.a.a.q0
    public int e() {
        if (c()) {
            return this.t.f2412b.f2056c;
        }
        return -1;
    }

    @Override // c.d.a.a.q0
    public long f() {
        if (!c()) {
            return getCurrentPosition();
        }
        m0 m0Var = this.t;
        m0Var.f2411a.a(m0Var.f2412b.f2054a, this.i);
        m0 m0Var2 = this.t;
        if (m0Var2.f2414d == -9223372036854775807L) {
            return t.b(m0Var2.f2411a.a(t(), this.f2581a).i);
        }
        return t.b(this.i.f2616d) + t.b(this.t.f2414d);
    }

    @Override // c.d.a.a.q0
    public long g() {
        return t.b(this.t.l);
    }

    @Override // c.d.a.a.q0
    public long getCurrentPosition() {
        if (y()) {
            return this.w;
        }
        if (this.t.f2412b.a()) {
            return t.b(this.t.m);
        }
        m0 m0Var = this.t;
        return a(m0Var.f2412b, m0Var.m);
    }

    @Override // c.d.a.a.q0
    public long getDuration() {
        if (c()) {
            m0 m0Var = this.t;
            t.a aVar = m0Var.f2412b;
            m0Var.f2411a.a(aVar.f2054a, this.i);
            return t.b(this.i.a(aVar.f2055b, aVar.f2056c));
        }
        x0 m = m();
        if (m.e()) {
            return -9223372036854775807L;
        }
        return m.a(t(), this.f2581a).a();
    }

    @Override // c.d.a.a.q0
    public int i() {
        return this.l;
    }

    @Override // c.d.a.a.q0
    public c.d.a.a.h1.d0 j() {
        return this.t.h;
    }

    @Override // c.d.a.a.q0
    public boolean k() {
        return this.k;
    }

    @Override // c.d.a.a.q0
    public int l() {
        return this.m;
    }

    @Override // c.d.a.a.q0
    public x0 m() {
        return this.t.f2411a;
    }

    @Override // c.d.a.a.q0
    public int o() {
        return this.t.e;
    }

    @Override // c.d.a.a.q0
    public Looper p() {
        return this.e.getLooper();
    }

    @Override // c.d.a.a.q0
    public boolean q() {
        return this.n;
    }

    @Override // c.d.a.a.q0
    public z r() {
        return this.t.f;
    }

    @Override // c.d.a.a.q0
    public long s() {
        if (y()) {
            return this.w;
        }
        m0 m0Var = this.t;
        if (m0Var.j.f2057d != m0Var.f2412b.f2057d) {
            return m0Var.f2411a.a(t(), this.f2581a).a();
        }
        long j = m0Var.k;
        if (this.t.j.a()) {
            m0 m0Var2 = this.t;
            x0.b a2 = m0Var2.f2411a.a(m0Var2.j.f2054a, this.i);
            long a3 = a2.a(this.t.j.f2055b);
            j = a3 == Long.MIN_VALUE ? a2.f2615c : a3;
        }
        return a(this.t.j, j);
    }

    @Override // c.d.a.a.q0
    public int t() {
        if (y()) {
            return this.u;
        }
        m0 m0Var = this.t;
        return m0Var.f2411a.a(m0Var.f2412b.f2054a, this.i).f2614b;
    }

    @Override // c.d.a.a.q0
    public c.d.a.a.j1.h v() {
        return this.t.i.f2293c;
    }

    @Override // c.d.a.a.q0
    public int w() {
        if (c()) {
            return this.t.f2412b.f2055b;
        }
        return -1;
    }

    @Override // c.d.a.a.q0
    public q0.b x() {
        return null;
    }

    public final boolean y() {
        return this.t.f2411a.e() || this.o > 0;
    }

    public static void a(CopyOnWriteArrayList<r.a> copyOnWriteArrayList, r.b bVar) {
        Iterator<r.a> it = copyOnWriteArrayList.iterator();
        while (it.hasNext()) {
            r.a next = it.next();
            if (!next.f2583b) {
                bVar.a(next.f2582a);
            }
        }
    }

    @Override // c.d.a.a.q0
    public void b(final boolean z) {
        if (this.n != z) {
            this.n = z;
            this.f.h.a(13, z ? 1 : 0, 0).sendToTarget();
            a(new r.b() { // from class: c.d.a.a.k
                @Override // c.d.a.a.r.b
                public final void a(q0.a aVar) {
                    aVar.b(z);
                }
            });
        }
    }

    public final long a(t.a aVar, long j) {
        long b2 = t.b(j);
        this.t.f2411a.a(aVar.f2054a, this.i);
        return b2 + t.b(this.i.f2616d);
    }

    @Override // c.d.a.a.q0
    public void a(int i, long j) {
        long a2;
        x0 x0Var = this.t.f2411a;
        if (i < 0 || (!x0Var.e() && i >= x0Var.d())) {
            throw new h0(x0Var, i, j);
        }
        this.q = true;
        this.o++;
        if (c()) {
            Log.w("ExoPlayerImpl", "seekTo ignored because an ad is playing");
            this.e.obtainMessage(0, 1, -1, this.t).sendToTarget();
            return;
        }
        this.u = i;
        if (x0Var.e()) {
            this.w = j != -9223372036854775807L ? j : 0L;
            this.v = 0;
        } else {
            if (j == -9223372036854775807L) {
                a2 = x0Var.a(i, this.f2581a, 0L).i;
            } else {
                a2 = t.a(j);
            }
            long j2 = a2;
            Pair<Object, Long> a3 = x0Var.a(this.f2581a, this.i, i, j2);
            this.w = t.b(j2);
            this.v = x0Var.a(a3.first);
        }
        this.f.h.a(3, new d0.e(x0Var, i, t.a(j))).sendToTarget();
        a(new r.b() { // from class: c.d.a.a.c
            @Override // c.d.a.a.r.b
            public final void a(q0.a aVar) {
                aVar.c(1);
            }
        });
    }

    public void a(final boolean z, final int i) {
        boolean isPlaying = isPlaying();
        int i2 = (this.k && this.l == 0) ? 1 : 0;
        int i3 = (z && i == 0) ? 1 : 0;
        if (i2 != i3) {
            this.f.h.a(1, i3, 0).sendToTarget();
        }
        final boolean z2 = this.k != z;
        final boolean z3 = this.l != i;
        this.k = z;
        this.l = i;
        final boolean isPlaying2 = isPlaying();
        final boolean z4 = isPlaying != isPlaying2;
        if (z2 || z3 || z4) {
            final int i4 = this.t.e;
            a(new r.b() { // from class: c.d.a.a.l
                @Override // c.d.a.a.r.b
                public final void a(q0.a aVar) {
                    c0.a(z2, z, i4, z3, i, z4, isPlaying2, aVar);
                }
            });
        }
    }

    @Override // c.d.a.a.q0
    public void a(final int i) {
        if (this.m != i) {
            this.m = i;
            this.f.h.a(12, i, 0).sendToTarget();
            a(new r.b() { // from class: c.d.a.a.n
                @Override // c.d.a.a.r.b
                public final void a(q0.a aVar) {
                    aVar.d(i);
                }
            });
        }
    }
}
