package c.d.a.a.b1;

import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public class h extends f {

    /* renamed from: a, reason: collision with root package name */
    public final g<?, h, ?> f1271a;

    /* renamed from: b, reason: collision with root package name */
    public ByteBuffer f1272b;

    public h(g<?, h, ?> gVar) {
        this.f1271a = gVar;
    }

    @Override // c.d.a.a.b1.a
    public void clear() {
        super.clear();
        ByteBuffer byteBuffer = this.f1272b;
        if (byteBuffer != null) {
            byteBuffer.clear();
        }
    }

    @Override // c.d.a.a.b1.f
    public void release() {
        this.f1271a.a((g<?, h, ?>) this);
    }
}
