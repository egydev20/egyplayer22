package c.d.a.a.b1;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public int f1259a;

    /* renamed from: b, reason: collision with root package name */
    public int f1260b;

    /* renamed from: c, reason: collision with root package name */
    public int f1261c;

    /* renamed from: d, reason: collision with root package name */
    public int f1262d;
    public int e;
    public int f;
    public int g;
    public int h;
    public int i;

    public synchronized void a() {
    }
}
