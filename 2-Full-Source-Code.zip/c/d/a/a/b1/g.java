package c.d.a.a.b1;

import c.d.a.a.b1.e;
import c.d.a.a.b1.f;
import java.lang.Exception;
import java.util.ArrayDeque;

/* loaded from: classes.dex */
public abstract class g<I extends e, O extends f, E extends Exception> implements c<I, O, E> {

    /* renamed from: a, reason: collision with root package name */
    public final Thread f1266a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f1267b = new Object();

    /* renamed from: c, reason: collision with root package name */
    public final ArrayDeque<I> f1268c = new ArrayDeque<>();

    /* renamed from: d, reason: collision with root package name */
    public final ArrayDeque<O> f1269d = new ArrayDeque<>();
    public final I[] e;
    public final O[] f;
    public int g;
    public int h;
    public I i;
    public E j;
    public boolean k;
    public boolean l;
    public int m;

    /* loaded from: classes.dex */
    public class a extends Thread {
        public a() {
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            g gVar = g.this;
            if (gVar == null) {
                throw null;
            }
            do {
                try {
                } catch (InterruptedException e) {
                    throw new IllegalStateException(e);
                }
            } while (gVar.f());
        }
    }

    public g(I[] iArr, O[] oArr) {
        this.e = iArr;
        this.g = iArr.length;
        for (int i = 0; i < this.g; i++) {
            this.e[i] = d();
        }
        this.f = oArr;
        this.h = oArr.length;
        for (int i2 = 0; i2 < this.h; i2++) {
            this.f[i2] = e();
        }
        a aVar = new a();
        this.f1266a = aVar;
        aVar.start();
    }

    @Override // c.d.a.a.b1.c
    public final O a() {
        synchronized (this.f1267b) {
            h();
            if (this.f1269d.isEmpty()) {
                return null;
            }
            return this.f1269d.removeFirst();
        }
    }

    public abstract E a(I i, O o, boolean z);

    public abstract E a(Throwable th);

    public final void a(int i) {
        c.d.a.a.m1.e.b(this.g == this.e.length);
        for (I i2 : this.e) {
            i2.c(i);
        }
    }

    @Override // c.d.a.a.b1.c
    public final void a(I i) {
        synchronized (this.f1267b) {
            h();
            c.d.a.a.m1.e.a(i == this.i);
            this.f1268c.addLast(i);
            g();
            this.i = null;
        }
    }

    public void a(O o) {
        synchronized (this.f1267b) {
            o.clear();
            O[] oArr = this.f;
            int i = this.h;
            this.h = i + 1;
            oArr[i] = o;
            g();
        }
    }

    @Override // c.d.a.a.b1.c
    public final I b() {
        I i;
        synchronized (this.f1267b) {
            h();
            c.d.a.a.m1.e.b(this.i == null);
            if (this.g == 0) {
                i = null;
            } else {
                I[] iArr = this.e;
                int i2 = this.g - 1;
                this.g = i2;
                i = iArr[i2];
            }
            this.i = i;
        }
        return i;
    }

    public final void b(I i) {
        i.clear();
        I[] iArr = this.e;
        int i2 = this.g;
        this.g = i2 + 1;
        iArr[i2] = i;
    }

    public abstract I d();

    public abstract O e();

    public final boolean f() {
        synchronized (this.f1267b) {
            while (!this.l) {
                if (!this.f1268c.isEmpty() && this.h > 0) {
                    break;
                }
                this.f1267b.wait();
            }
            if (this.l) {
                return false;
            }
            I removeFirst = this.f1268c.removeFirst();
            O[] oArr = this.f;
            int i = this.h - 1;
            this.h = i;
            O o = oArr[i];
            boolean z = this.k;
            this.k = false;
            if (removeFirst.isEndOfStream()) {
                o.addFlag(4);
            } else {
                if (removeFirst.isDecodeOnly()) {
                    o.addFlag(Integer.MIN_VALUE);
                }
                try {
                    this.j = a(removeFirst, o, z);
                } catch (OutOfMemoryError | RuntimeException e) {
                    this.j = a(e);
                }
                if (this.j != null) {
                    synchronized (this.f1267b) {
                    }
                    return false;
                }
            }
            synchronized (this.f1267b) {
                if (!this.k) {
                    if (o.isDecodeOnly()) {
                        this.m++;
                    } else {
                        o.skippedOutputBufferCount = this.m;
                        this.m = 0;
                        this.f1269d.addLast(o);
                        b(removeFirst);
                    }
                }
                o.release();
                b(removeFirst);
            }
            return true;
        }
    }

    @Override // c.d.a.a.b1.c
    public final void flush() {
        synchronized (this.f1267b) {
            this.k = true;
            this.m = 0;
            if (this.i != null) {
                b(this.i);
                this.i = null;
            }
            while (!this.f1268c.isEmpty()) {
                b(this.f1268c.removeFirst());
            }
            while (!this.f1269d.isEmpty()) {
                this.f1269d.removeFirst().release();
            }
        }
    }

    public final void g() {
        if (!this.f1268c.isEmpty() && this.h > 0) {
            this.f1267b.notify();
        }
    }

    public final void h() {
        E e = this.j;
        if (e != null) {
            throw e;
        }
    }

    @Override // c.d.a.a.b1.c
    public void release() {
        synchronized (this.f1267b) {
            this.l = true;
            this.f1267b.notify();
        }
        try {
            this.f1266a.join();
        } catch (InterruptedException unused) {
            Thread.currentThread().interrupt();
        }
    }
}
