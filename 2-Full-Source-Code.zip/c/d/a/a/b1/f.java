package c.d.a.a.b1;

/* loaded from: classes.dex */
public abstract class f extends a {
    public int skippedOutputBufferCount;
    public long timeUs;

    public abstract void release();
}
