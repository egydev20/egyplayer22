package c.d.a.a.b1;

import java.lang.Exception;

/* loaded from: classes.dex */
public interface c<I, O, E extends Exception> {
    O a();

    void a(I i);

    I b();

    String c();

    void flush();

    void release();
}
