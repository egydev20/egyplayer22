package c.d.a.a.b1;

import android.annotation.TargetApi;
import android.media.MediaCodec;
import c.d.a.a.m1.c0;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public byte[] f1253a;

    /* renamed from: b, reason: collision with root package name */
    public int[] f1254b;

    /* renamed from: c, reason: collision with root package name */
    public int[] f1255c;

    /* renamed from: d, reason: collision with root package name */
    public final MediaCodec.CryptoInfo f1256d;
    public final C0034b e;

    @TargetApi(24)
    /* renamed from: c.d.a.a.b1.b$b, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static final class C0034b {

        /* renamed from: a, reason: collision with root package name */
        public final MediaCodec.CryptoInfo f1257a;

        /* renamed from: b, reason: collision with root package name */
        public final MediaCodec.CryptoInfo.Pattern f1258b = new MediaCodec.CryptoInfo.Pattern(0, 0);

        public /* synthetic */ C0034b(MediaCodec.CryptoInfo cryptoInfo, a aVar) {
            this.f1257a = cryptoInfo;
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    public b() {
        MediaCodec.CryptoInfo cryptoInfo = new MediaCodec.CryptoInfo();
        this.f1256d = cryptoInfo;
        this.e = c0.f2426a >= 24 ? new C0034b(cryptoInfo, 0 == true ? 1 : 0) : null;
    }
}
