package c.d.a.a.b1;

import java.nio.ByteBuffer;
import org.checkerframework.checker.nullness.qual.EnsuresNonNull;

/* loaded from: classes.dex */
public class e extends a {

    /* renamed from: b, reason: collision with root package name */
    public final b f1263b = new b();

    /* renamed from: c, reason: collision with root package name */
    public ByteBuffer f1264c;

    /* renamed from: d, reason: collision with root package name */
    public long f1265d;
    public ByteBuffer e;
    public final int f;

    public e(int i) {
        this.f = i;
    }

    public final ByteBuffer b(int i) {
        int i2 = this.f;
        if (i2 == 1) {
            return ByteBuffer.allocate(i);
        }
        if (i2 == 2) {
            return ByteBuffer.allocateDirect(i);
        }
        ByteBuffer byteBuffer = this.f1264c;
        throw new IllegalStateException("Buffer too small (" + (byteBuffer == null ? 0 : byteBuffer.capacity()) + " < " + i + ")");
    }

    public final void b() {
        this.f1264c.flip();
        ByteBuffer byteBuffer = this.e;
        if (byteBuffer != null) {
            byteBuffer.flip();
        }
    }

    @EnsuresNonNull({"data"})
    public void c(int i) {
        ByteBuffer byteBuffer = this.f1264c;
        if (byteBuffer == null) {
            this.f1264c = b(i);
            return;
        }
        int capacity = byteBuffer.capacity();
        int position = this.f1264c.position();
        int i2 = i + position;
        if (capacity >= i2) {
            return;
        }
        ByteBuffer b2 = b(i2);
        if (position > 0) {
            this.f1264c.flip();
            b2.put(this.f1264c);
        }
        this.f1264c = b2;
    }

    public final boolean c() {
        return getFlag(1073741824);
    }

    @Override // c.d.a.a.b1.a
    public void clear() {
        super.clear();
        ByteBuffer byteBuffer = this.f1264c;
        if (byteBuffer != null) {
            byteBuffer.clear();
        }
        ByteBuffer byteBuffer2 = this.e;
        if (byteBuffer2 != null) {
            byteBuffer2.clear();
        }
    }
}
