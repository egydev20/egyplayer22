package c.d.a.a.e1;

import c.d.a.a.e1.q;
import c.d.a.a.m1.c0;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public final C0035a f1332a;

    /* renamed from: b, reason: collision with root package name */
    public final f f1333b;

    /* renamed from: c, reason: collision with root package name */
    public c f1334c;

    /* renamed from: d, reason: collision with root package name */
    public final int f1335d;

    /* renamed from: c.d.a.a.e1.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0035a implements q {

        /* renamed from: a, reason: collision with root package name */
        public final d f1336a;

        /* renamed from: b, reason: collision with root package name */
        public final long f1337b;

        /* renamed from: c, reason: collision with root package name */
        public final long f1338c;

        /* renamed from: d, reason: collision with root package name */
        public final long f1339d;
        public final long e;
        public final long f;
        public final long g;

        public C0035a(d dVar, long j, long j2, long j3, long j4, long j5, long j6) {
            this.f1336a = dVar;
            this.f1337b = j;
            this.f1338c = j2;
            this.f1339d = j3;
            this.e = j4;
            this.f = j5;
            this.g = j6;
        }

        @Override // c.d.a.a.e1.q
        public boolean a() {
            return true;
        }

        @Override // c.d.a.a.e1.q
        public q.a b(long j) {
            return new q.a(new r(j, c.a(this.f1336a.a(j), this.f1338c, this.f1339d, this.e, this.f, this.g)));
        }

        @Override // c.d.a.a.e1.q
        public long c() {
            return this.f1337b;
        }
    }

    /* loaded from: classes.dex */
    public static final class b implements d {
        @Override // c.d.a.a.e1.a.d
        public long a(long j) {
            return j;
        }
    }

    /* loaded from: classes.dex */
    public static class c {

        /* renamed from: a, reason: collision with root package name */
        public final long f1340a;

        /* renamed from: b, reason: collision with root package name */
        public final long f1341b;

        /* renamed from: c, reason: collision with root package name */
        public final long f1342c;

        /* renamed from: d, reason: collision with root package name */
        public long f1343d;
        public long e;
        public long f;
        public long g;
        public long h;

        public c(long j, long j2, long j3, long j4, long j5, long j6, long j7) {
            this.f1340a = j;
            this.f1341b = j2;
            this.f1343d = j3;
            this.e = j4;
            this.f = j5;
            this.g = j6;
            this.f1342c = j7;
            this.h = a(j2, j3, j4, j5, j6, j7);
        }

        public static long a(long j, long j2, long j3, long j4, long j5, long j6) {
            if (j4 + 1 >= j5 || j2 + 1 >= j3) {
                return j4;
            }
            long j7 = ((float) (j - j2)) * (((float) (j5 - j4)) / ((float) (j3 - j2)));
            return c0.b(((j7 + j4) - j6) - (j7 / 20), j4, j5 - 1);
        }
    }

    /* loaded from: classes.dex */
    public interface d {
        long a(long j);
    }

    /* loaded from: classes.dex */
    public static final class e {

        /* renamed from: d, reason: collision with root package name */
        public static final e f1344d = new e(-3, -9223372036854775807L, -1);

        /* renamed from: a, reason: collision with root package name */
        public final int f1345a;

        /* renamed from: b, reason: collision with root package name */
        public final long f1346b;

        /* renamed from: c, reason: collision with root package name */
        public final long f1347c;

        public e(int i, long j, long j2) {
            this.f1345a = i;
            this.f1346b = j;
            this.f1347c = j2;
        }

        public static e a(long j) {
            return new e(0, -9223372036854775807L, j);
        }

        public static e a(long j, long j2) {
            return new e(-1, j, j2);
        }

        public static e b(long j, long j2) {
            return new e(-2, j, j2);
        }
    }

    /* loaded from: classes.dex */
    public interface f {
        e a(c.d.a.a.e1.e eVar, long j);

        void a();
    }

    public a(d dVar, f fVar, long j, long j2, long j3, long j4, long j5, long j6, int i) {
        this.f1333b = fVar;
        this.f1335d = i;
        this.f1332a = new C0035a(dVar, j, j2, j3, j4, j5, j6);
    }

    public int a(c.d.a.a.e1.e eVar, p pVar) {
        c.d.a.a.e1.e eVar2 = eVar;
        p pVar2 = pVar;
        f fVar = this.f1333b;
        c.d.a.a.m1.e.b(fVar);
        while (true) {
            c cVar = this.f1334c;
            c.d.a.a.m1.e.b(cVar);
            long j = cVar.f;
            long j2 = cVar.g;
            long j3 = cVar.h;
            if (j2 - j <= this.f1335d) {
                a(false, j);
                return a(eVar2, j, pVar2);
            }
            if (!a(eVar2, j3)) {
                return a(eVar2, j3, pVar2);
            }
            eVar2.f = 0;
            e a2 = fVar.a(eVar2, cVar.f1341b);
            int i = a2.f1345a;
            if (i == -3) {
                a(false, j3);
                return a(eVar, j3, pVar);
            }
            if (i == -2) {
                long j4 = a2.f1346b;
                long j5 = a2.f1347c;
                cVar.f1343d = j4;
                cVar.f = j5;
                cVar.h = c.a(cVar.f1341b, j4, cVar.e, j5, cVar.g, cVar.f1342c);
            } else {
                if (i != -1) {
                    if (i != 0) {
                        throw new IllegalStateException("Invalid case");
                    }
                    a(true, a2.f1347c);
                    a(eVar2, a2.f1347c);
                    return a(eVar2, a2.f1347c, pVar2);
                }
                long j6 = a2.f1346b;
                long j7 = a2.f1347c;
                cVar.e = j6;
                cVar.g = j7;
                cVar.h = c.a(cVar.f1341b, cVar.f1343d, j6, cVar.f, j7, cVar.f1342c);
            }
            eVar2 = eVar;
            pVar2 = pVar;
        }
    }

    public final void a(boolean z, long j) {
        this.f1334c = null;
        this.f1333b.a();
    }

    public final boolean a() {
        return this.f1334c != null;
    }

    public final int a(c.d.a.a.e1.e eVar, long j, p pVar) {
        if (j == eVar.f1490d) {
            return 0;
        }
        pVar.f1662a = j;
        return 1;
    }

    public final void a(long j) {
        c cVar = this.f1334c;
        if (cVar == null || cVar.f1340a != j) {
            long a2 = this.f1332a.f1336a.a(j);
            C0035a c0035a = this.f1332a;
            this.f1334c = new c(j, a2, c0035a.f1338c, c0035a.f1339d, c0035a.e, c0035a.f, c0035a.g);
        }
    }

    public final boolean a(c.d.a.a.e1.e eVar, long j) {
        long j2 = j - eVar.f1490d;
        if (j2 < 0 || j2 > 262144) {
            return false;
        }
        eVar.c((int) j2);
        return true;
    }
}
