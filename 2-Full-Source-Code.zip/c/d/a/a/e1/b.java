package c.d.a.a.e1;

import c.d.a.a.e1.a;

/* loaded from: classes.dex */
public final /* synthetic */ class b {
    public static void a(a.f fVar) {
    }
}
