package c.d.a.a.e1.a0;

/* loaded from: classes.dex */
public interface c {
}
