package c.d.a.a.e1.a0;

import c.d.a.a.m1.t;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final t f1367a = new t(8);

    /* renamed from: b, reason: collision with root package name */
    public int f1368b;

    public final long a(c.d.a.a.e1.e eVar) {
        int i = 0;
        eVar.a(this.f1367a.f2478a, 0, 1, false);
        int i2 = this.f1367a.f2478a[0] & 255;
        if (i2 == 0) {
            return Long.MIN_VALUE;
        }
        int i3 = 128;
        int i4 = 0;
        while ((i2 & i3) == 0) {
            i3 >>= 1;
            i4++;
        }
        int i5 = i2 & (~i3);
        eVar.a(this.f1367a.f2478a, 1, i4, false);
        while (i < i4) {
            i++;
            i5 = (this.f1367a.f2478a[i] & 255) + (i5 << 8);
        }
        this.f1368b = i4 + 1 + this.f1368b;
        return i5;
    }
}
