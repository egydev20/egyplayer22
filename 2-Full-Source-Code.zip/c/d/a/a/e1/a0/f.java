package c.d.a.a.e1.a0;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: d, reason: collision with root package name */
    public static final long[] f1369d = {128, 64, 32, 16, 8, 4, 2, 1};

    /* renamed from: a, reason: collision with root package name */
    public final byte[] f1370a = new byte[8];

    /* renamed from: b, reason: collision with root package name */
    public int f1371b;

    /* renamed from: c, reason: collision with root package name */
    public int f1372c;

    public static int a(int i) {
        long j;
        int i2 = 0;
        do {
            long[] jArr = f1369d;
            if (i2 >= jArr.length) {
                return -1;
            }
            j = jArr[i2] & i;
            i2++;
        } while (j == 0);
        return i2;
    }

    public static long a(byte[] bArr, int i, boolean z) {
        long j = bArr[0] & 255;
        if (z) {
            j &= ~f1369d[i - 1];
        }
        for (int i2 = 1; i2 < i; i2++) {
            j = (j << 8) | (bArr[i2] & 255);
        }
        return j;
    }

    public long a(c.d.a.a.e1.e eVar, boolean z, boolean z2, int i) {
        if (this.f1371b == 0) {
            if (!eVar.b(this.f1370a, 0, 1, z)) {
                return -1L;
            }
            int a2 = a(this.f1370a[0] & 255);
            this.f1372c = a2;
            if (a2 == -1) {
                throw new IllegalStateException("No valid varint length mask found");
            }
            this.f1371b = 1;
        }
        int i2 = this.f1372c;
        if (i2 > i) {
            this.f1371b = 0;
            return -2L;
        }
        if (i2 != 1) {
            eVar.b(this.f1370a, 1, i2 - 1, false);
        }
        this.f1371b = 0;
        return a(this.f1370a, this.f1372c, z2);
    }
}
