package c.d.a.a.e1.a0;

import android.util.SparseArray;
import c.d.a.a.c1.k;
import c.d.a.a.e1.h;
import c.d.a.a.e1.i;
import c.d.a.a.e1.s;
import c.d.a.a.l0;
import c.d.a.a.m1.c0;
import c.d.a.a.m1.o;
import c.d.a.a.m1.r;
import c.d.a.a.m1.t;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Locale;
import java.util.UUID;
import org.videolan.libvlc.media.MediaPlayer;

/* loaded from: classes.dex */
public class d implements h {
    public static final byte[] b0 = {49, 10, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 48, 48, 32, 45, 45, 62, 32, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 48, 48, 10};
    public static final byte[] c0 = c0.b("Format: Start, End, ReadOrder, Layer, Style, Name, MarginL, MarginR, MarginV, Effect, Text");
    public static final byte[] d0 = {68, 105, 97, 108, 111, 103, 117, 101, 58, 32, 48, 58, 48, 48, 58, 48, 48, 58, 48, 48, 44, 48, 58, 48, 48, 58, 48, 48, 58, 48, 48, 44};
    public static final UUID e0 = new UUID(72057594037932032L, -9223371306706625679L);
    public long A;
    public long B;
    public o C;
    public o D;
    public boolean E;
    public boolean F;
    public int G;
    public long H;
    public long I;
    public int J;
    public int K;
    public int[] L;
    public int M;
    public int N;
    public int O;
    public int P;
    public boolean Q;
    public int R;
    public int S;
    public int T;
    public boolean U;
    public boolean V;
    public boolean W;
    public int X;
    public byte Y;
    public boolean Z;

    /* renamed from: a, reason: collision with root package name */
    public final c.d.a.a.e1.a0.c f1354a;
    public i a0;

    /* renamed from: b, reason: collision with root package name */
    public final f f1355b;

    /* renamed from: c, reason: collision with root package name */
    public final SparseArray<c> f1356c;

    /* renamed from: d, reason: collision with root package name */
    public final boolean f1357d;
    public final t e;
    public final t f;
    public final t g;
    public final t h;
    public final t i;
    public final t j;
    public final t k;
    public final t l;
    public final t m;
    public final t n;
    public ByteBuffer o;
    public long p;
    public long q;
    public long r;
    public long s;
    public long t;
    public c u;
    public boolean v;
    public int w;
    public long x;
    public boolean y;
    public long z;

    /* loaded from: classes.dex */
    public final class b implements c.d.a.a.e1.a0.b {
        public /* synthetic */ b(a aVar) {
        }

        /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
        /* JADX WARN: Code restructure failed: missing block: B:301:0x0531, code lost:
        
            if (r0.i() == c.d.a.a.e1.a0.d.e0.getLeastSignificantBits()) goto L278;
         */
        /* JADX WARN: Failed to find 'out' block for switch in B:159:0x04b1. Please report as an issue. */
        /* JADX WARN: Removed duplicated region for block: B:153:0x0347  */
        /* JADX WARN: Removed duplicated region for block: B:169:0x0766  */
        /* JADX WARN: Removed duplicated region for block: B:172:0x0770  */
        /* JADX WARN: Removed duplicated region for block: B:176:0x0795  */
        /* JADX WARN: Removed duplicated region for block: B:271:0x0768  */
        /* JADX WARN: Removed duplicated region for block: B:291:0x0538  */
        /* JADX WARN: Removed duplicated region for block: B:294:0x0559  */
        /* JADX WARN: Removed duplicated region for block: B:487:0x09fb  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void a(int r43) {
            /*
                Method dump skipped, instructions count: 2828
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.e1.a0.d.b.a(int):void");
        }
    }

    /* loaded from: classes.dex */
    public static final class c {
        public C0037d R;
        public boolean S;
        public s V;
        public int W;

        /* renamed from: a, reason: collision with root package name */
        public String f1359a;

        /* renamed from: b, reason: collision with root package name */
        public String f1360b;

        /* renamed from: c, reason: collision with root package name */
        public int f1361c;

        /* renamed from: d, reason: collision with root package name */
        public int f1362d;
        public int e;
        public int f;
        public boolean g;
        public byte[] h;
        public s.a i;
        public byte[] j;
        public k k;
        public int l = -1;
        public int m = -1;
        public int n = -1;
        public int o = -1;
        public int p = 0;
        public int q = -1;
        public float r = 0.0f;
        public float s = 0.0f;
        public float t = 0.0f;
        public byte[] u = null;
        public int v = -1;
        public boolean w = false;
        public int x = -1;
        public int y = -1;
        public int z = -1;
        public int A = 1000;
        public int B = MediaPlayer.MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK;
        public float C = -1.0f;
        public float D = -1.0f;
        public float E = -1.0f;
        public float F = -1.0f;
        public float G = -1.0f;
        public float H = -1.0f;
        public float I = -1.0f;
        public float J = -1.0f;
        public float K = -1.0f;
        public float L = -1.0f;
        public int M = 1;
        public int N = -1;
        public int O = 8000;
        public long P = 0;
        public long Q = 0;
        public boolean T = true;
        public String U = "eng";

        public c() {
        }

        public /* synthetic */ c(a aVar) {
        }
    }

    /* renamed from: c.d.a.a.e1.a0.d$d, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static final class C0037d {

        /* renamed from: a, reason: collision with root package name */
        public final byte[] f1363a = new byte[10];

        /* renamed from: b, reason: collision with root package name */
        public boolean f1364b;

        /* renamed from: c, reason: collision with root package name */
        public int f1365c;

        /* renamed from: d, reason: collision with root package name */
        public long f1366d;
        public int e;
        public int f;
        public int g;

        public void a(c cVar) {
            if (this.f1365c > 0) {
                cVar.V.a(this.f1366d, this.e, this.f, this.g, cVar.i);
                this.f1365c = 0;
            }
        }
    }

    public d(int i) {
        c.d.a.a.e1.a0.a aVar = new c.d.a.a.e1.a0.a();
        this.q = -1L;
        this.r = -9223372036854775807L;
        this.s = -9223372036854775807L;
        this.t = -9223372036854775807L;
        this.z = -1L;
        this.A = -1L;
        this.B = -9223372036854775807L;
        this.f1354a = aVar;
        aVar.f1351d = new b(null);
        this.f1357d = (i & 1) == 0;
        this.f1355b = new f();
        this.f1356c = new SparseArray<>();
        this.g = new t(4);
        this.h = new t(ByteBuffer.allocate(4).putInt(-1).array());
        this.i = new t(4);
        this.e = new t(r.f2463a);
        this.f = new t(4);
        this.j = new t();
        this.k = new t();
        this.l = new t(8);
        this.m = new t();
        this.n = new t();
    }

    public static byte[] a(long j, String str, long j2) {
        c.d.a.a.m1.e.a(j != -9223372036854775807L);
        int i = (int) (j / 3600000000L);
        long j3 = j - ((i * 3600) * 1000000);
        int i2 = (int) (j3 / 60000000);
        long j4 = j3 - ((i2 * 60) * 1000000);
        int i3 = (int) (j4 / 1000000);
        return c0.b(String.format(Locale.US, str, Integer.valueOf(i), Integer.valueOf(i2), Integer.valueOf(i3), Integer.valueOf((int) ((j4 - (i3 * 1000000)) / j2))));
    }

    public static int[] a(int[] iArr, int i) {
        return iArr == null ? new int[i] : iArr.length >= i ? iArr : new int[Math.max(iArr.length * 2, i)];
    }

    public final int a(c.d.a.a.e1.e eVar, s sVar, int i) {
        int a2 = this.j.a();
        if (a2 <= 0) {
            return sVar.a(eVar, i, false);
        }
        int min = Math.min(i, a2);
        sVar.a(this.j, min);
        return min;
    }

    public final long a(long j) {
        long j2 = this.r;
        if (j2 != -9223372036854775807L) {
            return c0.c(j, j2, 1000L);
        }
        throw new l0("Can't scale timecode prior to timecodeScale being set.");
    }

    public final void a() {
        this.R = 0;
        this.S = 0;
        this.T = 0;
        this.U = false;
        this.V = false;
        this.W = false;
        this.X = 0;
        this.Y = (byte) 0;
        this.Z = false;
        this.j.s();
    }

    /* JADX WARN: Removed duplicated region for block: B:21:0x00c9  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0094  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00a7  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a(c.d.a.a.e1.a0.d.c r17, long r18, int r20, int r21, int r22) {
        /*
            Method dump skipped, instructions count: 236
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.e1.a0.d.a(c.d.a.a.e1.a0.d$c, long, int, int, int):void");
    }

    @Override // c.d.a.a.e1.h
    public final void a(i iVar) {
        this.a0 = iVar;
    }

    @Override // c.d.a.a.e1.h
    public final void release() {
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Code restructure failed: missing block: B:251:0x03c1, code lost:
    
        throw new c.d.a.a.l0("EBML lacing sample size out of range.");
     */
    /* JADX WARN: Code restructure failed: missing block: B:340:0x06d5, code lost:
    
        if (r3 != 7) goto L451;
     */
    /* JADX WARN: Code restructure failed: missing block: B:359:0x0543, code lost:
    
        if (r3 != 3) goto L451;
     */
    /* JADX WARN: Code restructure failed: missing block: B:409:0x0614, code lost:
    
        throw new c.d.a.a.l0(c.a.b.a.a.a("DocTypeReadVersion ", r2, " not supported"));
     */
    /* JADX WARN: Code restructure failed: missing block: B:504:0x0841, code lost:
    
        if (r5 != false) goto L488;
     */
    /* JADX WARN: Code restructure failed: missing block: B:505:0x0843, code lost:
    
        r1 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:507:0x084a, code lost:
    
        if (r1 >= r28.f1356c.size()) goto L540;
     */
    /* JADX WARN: Code restructure failed: missing block: B:508:0x084c, code lost:
    
        r2 = r28.f1356c.valueAt(r1);
        r3 = r2.R;
     */
    /* JADX WARN: Code restructure failed: missing block: B:509:0x0856, code lost:
    
        if (r3 == null) goto L542;
     */
    /* JADX WARN: Code restructure failed: missing block: B:510:0x0858, code lost:
    
        r3.a(r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:512:0x085b, code lost:
    
        r1 = r1 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:515:0x085e, code lost:
    
        return -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:516:0x0860, code lost:
    
        return 0;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0828 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:23:0x082c A[SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r11v16, types: [c.d.a.a.e1.a0.f] */
    /* JADX WARN: Type inference failed for: r3v123 */
    /* JADX WARN: Type inference failed for: r3v124 */
    /* JADX WARN: Type inference failed for: r3v57 */
    /* JADX WARN: Type inference failed for: r3v59 */
    /* JADX WARN: Type inference failed for: r3v68 */
    /* JADX WARN: Type inference failed for: r3v86, types: [int] */
    /* JADX WARN: Type inference failed for: r4v123 */
    /* JADX WARN: Type inference failed for: r4v136 */
    /* JADX WARN: Type inference failed for: r4v2, types: [boolean] */
    /* JADX WARN: Type inference failed for: r6v21, types: [int[]] */
    /* JADX WARN: Type inference failed for: r7v26, types: [c.d.a.a.e1.a0.f] */
    /* JADX WARN: Type inference failed for: r7v27, types: [c.d.a.a.e1.a0.f] */
    @Override // c.d.a.a.e1.h
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final int a(c.d.a.a.e1.e r29, c.d.a.a.e1.p r30) {
        /*
            Method dump skipped, instructions count: 2670
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.e1.a0.d.a(c.d.a.a.e1.e, c.d.a.a.e1.p):int");
    }

    public final void a(c.d.a.a.e1.e eVar, int i) {
        t tVar = this.g;
        if (tVar.f2480c >= i) {
            return;
        }
        byte[] bArr = tVar.f2478a;
        if (bArr.length < i) {
            tVar.a(Arrays.copyOf(bArr, Math.max(bArr.length * 2, i)), this.g.f2480c);
        }
        t tVar2 = this.g;
        byte[] bArr2 = tVar2.f2478a;
        int i2 = tVar2.f2480c;
        eVar.b(bArr2, i2, i - i2, false);
        this.g.d(i);
    }

    @Override // c.d.a.a.e1.h
    public void a(long j, long j2) {
        this.B = -9223372036854775807L;
        this.G = 0;
        c.d.a.a.e1.a0.a aVar = (c.d.a.a.e1.a0.a) this.f1354a;
        aVar.e = 0;
        aVar.f1349b.clear();
        f fVar = aVar.f1350c;
        fVar.f1371b = 0;
        fVar.f1372c = 0;
        f fVar2 = this.f1355b;
        fVar2.f1371b = 0;
        fVar2.f1372c = 0;
        a();
        for (int i = 0; i < this.f1356c.size(); i++) {
            C0037d c0037d = this.f1356c.valueAt(i).R;
            if (c0037d != null) {
                c0037d.f1364b = false;
                c0037d.f1365c = 0;
            }
        }
    }

    @Override // c.d.a.a.e1.h
    public final boolean a(c.d.a.a.e1.e eVar) {
        e eVar2 = new e();
        long j = eVar.f1489c;
        long j2 = 1024;
        if (j != -1 && j <= 1024) {
            j2 = j;
        }
        int i = (int) j2;
        eVar.a(eVar2.f1367a.f2478a, 0, 4, false);
        eVar2.f1368b = 4;
        for (long m = eVar2.f1367a.m(); m != 440786851; m = (eVar2.f1367a.f2478a[0] & 255) | ((m << 8) & (-256))) {
            int i2 = eVar2.f1368b + 1;
            eVar2.f1368b = i2;
            if (i2 == i) {
                return false;
            }
            eVar.a(eVar2.f1367a.f2478a, 0, 1, false);
        }
        long a2 = eVar2.a(eVar);
        long j3 = eVar2.f1368b;
        if (a2 == Long.MIN_VALUE) {
            return false;
        }
        if (j != -1 && j3 + a2 >= j) {
            return false;
        }
        while (true) {
            long j4 = eVar2.f1368b;
            long j5 = j3 + a2;
            if (j4 >= j5) {
                return j4 == j5;
            }
            if (eVar2.a(eVar) == Long.MIN_VALUE) {
                return false;
            }
            long a3 = eVar2.a(eVar);
            if (a3 < 0 || a3 > 2147483647L) {
                return false;
            }
            if (a3 != 0) {
                int i3 = (int) a3;
                eVar.a(i3, false);
                eVar2.f1368b += i3;
            }
        }
    }

    public final int a(c.d.a.a.e1.e eVar, c cVar, int i) {
        int i2;
        int i3;
        if ("S_TEXT/UTF8".equals(cVar.f1360b)) {
            a(eVar, b0, i);
            int i4 = this.S;
            a();
            return i4;
        }
        if ("S_TEXT/ASS".equals(cVar.f1360b)) {
            a(eVar, d0, i);
            int i5 = this.S;
            a();
            return i5;
        }
        s sVar = cVar.V;
        if (!this.U) {
            if (cVar.g) {
                this.O &= -1073741825;
                if (!this.V) {
                    eVar.b(this.g.f2478a, 0, 1, false);
                    this.R++;
                    byte[] bArr = this.g.f2478a;
                    if ((bArr[0] & 128) == 128) {
                        throw new l0("Extension bit is set in signal byte");
                    }
                    this.Y = bArr[0];
                    this.V = true;
                }
                if ((this.Y & 1) == 1) {
                    boolean z = (this.Y & 2) == 2;
                    this.O |= 1073741824;
                    if (!this.Z) {
                        eVar.b(this.l.f2478a, 0, 8, false);
                        this.R += 8;
                        this.Z = true;
                        this.g.f2478a[0] = (byte) ((z ? 128 : 0) | 8);
                        this.g.e(0);
                        sVar.a(this.g, 1);
                        this.S++;
                        this.l.e(0);
                        sVar.a(this.l, 8);
                        this.S += 8;
                    }
                    if (z) {
                        if (!this.W) {
                            eVar.b(this.g.f2478a, 0, 1, false);
                            this.R++;
                            this.g.e(0);
                            this.X = this.g.l();
                            this.W = true;
                        }
                        int i6 = this.X * 4;
                        this.g.c(i6);
                        eVar.b(this.g.f2478a, 0, i6, false);
                        this.R += i6;
                        short s = (short) ((this.X / 2) + 1);
                        int i7 = (s * 6) + 2;
                        ByteBuffer byteBuffer = this.o;
                        if (byteBuffer == null || byteBuffer.capacity() < i7) {
                            this.o = ByteBuffer.allocate(i7);
                        }
                        this.o.position(0);
                        this.o.putShort(s);
                        int i8 = 0;
                        int i9 = 0;
                        while (true) {
                            i3 = this.X;
                            if (i8 >= i3) {
                                break;
                            }
                            int o = this.g.o();
                            if (i8 % 2 == 0) {
                                this.o.putShort((short) (o - i9));
                            } else {
                                this.o.putInt(o - i9);
                            }
                            i8++;
                            i9 = o;
                        }
                        int i10 = (i - this.R) - i9;
                        int i11 = i3 % 2;
                        ByteBuffer byteBuffer2 = this.o;
                        if (i11 == 1) {
                            byteBuffer2.putInt(i10);
                        } else {
                            byteBuffer2.putShort((short) i10);
                            this.o.putInt(0);
                        }
                        this.m.a(this.o.array(), i7);
                        sVar.a(this.m, i7);
                        this.S += i7;
                    }
                }
            } else {
                byte[] bArr2 = cVar.h;
                if (bArr2 != null) {
                    this.j.a(bArr2, bArr2.length);
                }
            }
            if (cVar.f > 0) {
                this.O |= 268435456;
                this.n.s();
                this.g.c(4);
                t tVar = this.g;
                byte[] bArr3 = tVar.f2478a;
                bArr3[0] = (byte) ((i >> 24) & 255);
                bArr3[1] = (byte) ((i >> 16) & 255);
                bArr3[2] = (byte) ((i >> 8) & 255);
                bArr3[3] = (byte) (i & 255);
                sVar.a(tVar, 4);
                this.S += 4;
            }
            this.U = true;
        }
        int i12 = i + this.j.f2480c;
        if (!"V_MPEG4/ISO/AVC".equals(cVar.f1360b) && !"V_MPEGH/ISO/HEVC".equals(cVar.f1360b)) {
            if (cVar.R != null) {
                c.d.a.a.m1.e.b(this.j.f2480c == 0);
                C0037d c0037d = cVar.R;
                if (!c0037d.f1364b) {
                    eVar.a(c0037d.f1363a, 0, 10, false);
                    eVar.f = 0;
                    byte[] bArr4 = c0037d.f1363a;
                    if (bArr4[4] == -8 && bArr4[5] == 114 && bArr4[6] == 111 && (bArr4[7] & 254) == 186) {
                        i2 = 40 << ((bArr4[(bArr4[7] & 255) == 187 ? '\t' : '\b'] >> 4) & 7);
                    } else {
                        i2 = 0;
                    }
                    if (i2 != 0) {
                        c0037d.f1364b = true;
                    }
                }
            }
            while (true) {
                int i13 = this.R;
                if (i13 >= i12) {
                    break;
                }
                int a2 = a(eVar, sVar, i12 - i13);
                this.R += a2;
                this.S += a2;
            }
        } else {
            byte[] bArr5 = this.f.f2478a;
            bArr5[0] = 0;
            bArr5[1] = 0;
            bArr5[2] = 0;
            int i14 = cVar.W;
            int i15 = 4 - i14;
            while (this.R < i12) {
                int i16 = this.T;
                if (i16 == 0) {
                    int min = Math.min(i14, this.j.a());
                    eVar.b(bArr5, i15 + min, i14 - min, false);
                    if (min > 0) {
                        t tVar2 = this.j;
                        System.arraycopy(tVar2.f2478a, tVar2.f2479b, bArr5, i15, min);
                        tVar2.f2479b += min;
                    }
                    this.R += i14;
                    this.f.e(0);
                    this.T = this.f.o();
                    this.e.e(0);
                    sVar.a(this.e, 4);
                    this.S += 4;
                } else {
                    int a3 = a(eVar, sVar, i16);
                    this.R += a3;
                    this.S += a3;
                    this.T -= a3;
                }
            }
        }
        if ("A_VORBIS".equals(cVar.f1360b)) {
            this.h.e(0);
            sVar.a(this.h, 4);
            this.S += 4;
        }
        int i17 = this.S;
        a();
        return i17;
    }

    public final void a(c.d.a.a.e1.e eVar, byte[] bArr, int i) {
        int length = bArr.length + i;
        t tVar = this.k;
        byte[] bArr2 = tVar.f2478a;
        if (bArr2.length < length) {
            tVar.f2478a = Arrays.copyOf(bArr, length + i);
        } else {
            System.arraycopy(bArr, 0, bArr2, 0, bArr.length);
        }
        eVar.b(this.k.f2478a, bArr.length, i, false);
        this.k.c(length);
    }
}
