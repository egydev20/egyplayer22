package c.d.a.a.e1.a0;

import java.util.ArrayDeque;

/* loaded from: classes.dex */
public final class a implements c {

    /* renamed from: a, reason: collision with root package name */
    public final byte[] f1348a = new byte[8];

    /* renamed from: b, reason: collision with root package name */
    public final ArrayDeque<b> f1349b = new ArrayDeque<>();

    /* renamed from: c, reason: collision with root package name */
    public final f f1350c = new f();

    /* renamed from: d, reason: collision with root package name */
    public c.d.a.a.e1.a0.b f1351d;
    public int e;
    public int f;
    public long g;

    /* loaded from: classes.dex */
    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        public final int f1352a;

        /* renamed from: b, reason: collision with root package name */
        public final long f1353b;

        public /* synthetic */ b(int i, long j, C0036a c0036a) {
            this.f1352a = i;
            this.f1353b = j;
        }
    }

    public final long a(c.d.a.a.e1.e eVar, int i) {
        eVar.b(this.f1348a, 0, i, false);
        long j = 0;
        for (int i2 = 0; i2 < i; i2++) {
            j = (j << 8) | (this.f1348a[i2] & 255);
        }
        return j;
    }
}
