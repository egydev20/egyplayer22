package c.d.a.a.e1.b0;

import c.d.a.a.e1.h;
import c.d.a.a.e1.i;
import c.d.a.a.e1.m;
import c.d.a.a.e1.n;
import c.d.a.a.e1.o;
import c.d.a.a.e1.s;
import c.d.a.a.g1.k.h;
import c.d.a.a.m1.t;
import java.io.EOFException;

/* loaded from: classes.dex */
public final class d implements h {
    public static final h.a q = new h.a() { // from class: c.d.a.a.e1.b0.a
        @Override // c.d.a.a.g1.k.h.a
        public final boolean a(int i, int i2, int i3, int i4, int i5) {
            return d.a(i, i2, i3, i4, i5);
        }
    };

    /* renamed from: a, reason: collision with root package name */
    public final int f1377a;

    /* renamed from: b, reason: collision with root package name */
    public final long f1378b;

    /* renamed from: c, reason: collision with root package name */
    public final t f1379c;

    /* renamed from: d, reason: collision with root package name */
    public final o f1380d;
    public final m e;
    public final n f;
    public i g;
    public s h;
    public int i;
    public c.d.a.a.g1.a j;
    public e k;
    public boolean l;
    public long m;
    public long n;
    public long o;
    public int p;

    public d() {
        this(0, -9223372036854775807L);
    }

    public d(int i, long j) {
        this.f1377a = i;
        this.f1378b = j;
        this.f1379c = new t(10);
        this.f1380d = new o();
        this.e = new m();
        this.m = -9223372036854775807L;
        this.f = new n();
    }

    public static /* synthetic */ boolean a(int i, int i2, int i3, int i4, int i5) {
        return (i2 == 67 && i3 == 79 && i4 == 77 && (i5 == 77 || i == 2)) || (i2 == 77 && i3 == 76 && i4 == 76 && (i5 == 84 || i == 2));
    }

    public static boolean a(int i, long j) {
        return ((long) (i & (-128000))) == (j & (-128000));
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x0058, code lost:
    
        if (r8 != 1231971951) goto L22;
     */
    /* JADX WARN: Removed duplicated region for block: B:114:0x0168  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x01fb  */
    /* JADX WARN: Removed duplicated region for block: B:136:0x0243  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0078 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:53:0x025a  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x02a9  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x02fe  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0301  */
    /* JADX WARN: Removed duplicated region for block: B:96:0x02b1  */
    @Override // c.d.a.a.e1.h
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public int a(c.d.a.a.e1.e r42, c.d.a.a.e1.p r43) {
        /*
            Method dump skipped, instructions count: 987
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.e1.b0.d.a(c.d.a.a.e1.e, c.d.a.a.e1.p):int");
    }

    @Override // c.d.a.a.e1.h
    public void a(long j, long j2) {
        this.i = 0;
        this.m = -9223372036854775807L;
        this.n = 0L;
        this.p = 0;
    }

    @Override // c.d.a.a.e1.h
    public void a(i iVar) {
        this.g = iVar;
        this.h = iVar.a(0, 1);
        this.g.a();
    }

    @Override // c.d.a.a.e1.h
    public boolean a(c.d.a.a.e1.e eVar) {
        return a(eVar, true);
    }

    public final e b(c.d.a.a.e1.e eVar) {
        eVar.a(this.f1379c.f2478a, 0, 4, false);
        this.f1379c.e(0);
        o.a(this.f1379c.c(), this.f1380d);
        return new b(eVar.f1489c, eVar.f1490d, this.f1380d);
    }

    public final boolean c(c.d.a.a.e1.e eVar) {
        e eVar2 = this.k;
        if (eVar2 != null) {
            long b2 = eVar2.b();
            if (b2 != -1 && eVar.a() > b2 - 4) {
                return true;
            }
        }
        try {
            return !eVar.a(this.f1379c.f2478a, 0, 4, true);
        } catch (EOFException unused) {
            return true;
        }
    }

    @Override // c.d.a.a.e1.h
    public void release() {
    }

    /* JADX WARN: Code restructure failed: missing block: B:50:0x0099, code lost:
    
        if (r12 == false) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x009b, code lost:
    
        r11.c(r3 + r5);
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00a2, code lost:
    
        r10.i = r2;
     */
    /* JADX WARN: Code restructure failed: missing block: B:53:0x00a4, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x00a0, code lost:
    
        r11.f = 0;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean a(c.d.a.a.e1.e r11, boolean r12) {
        /*
            r10 = this;
            if (r12 == 0) goto L5
            r0 = 16384(0x4000, float:2.2959E-41)
            goto L7
        L5:
            r0 = 131072(0x20000, float:1.83671E-40)
        L7:
            r1 = 0
            r11.f = r1
            long r2 = r11.f1490d
            r4 = 0
            r6 = 1
            int r7 = (r2 > r4 ? 1 : (r2 == r4 ? 0 : -1))
            if (r7 != 0) goto L3d
            int r2 = r10.f1377a
            r2 = r2 & 2
            if (r2 != 0) goto L1b
            r2 = 1
            goto L1c
        L1b:
            r2 = 0
        L1c:
            if (r2 == 0) goto L20
            r2 = 0
            goto L22
        L20:
            c.d.a.a.g1.k.h$a r2 = c.d.a.a.e1.b0.d.q
        L22:
            c.d.a.a.e1.n r3 = r10.f
            c.d.a.a.g1.a r2 = r3.a(r11, r2)
            r10.j = r2
            if (r2 == 0) goto L31
            c.d.a.a.e1.m r3 = r10.e
            r3.a(r2)
        L31:
            long r2 = r11.a()
            int r3 = (int) r2
            if (r12 != 0) goto L3b
            r11.c(r3)
        L3b:
            r2 = 0
            goto L3f
        L3d:
            r2 = 0
            r3 = 0
        L3f:
            r4 = 0
            r5 = 0
        L41:
            boolean r7 = r10.c(r11)
            if (r7 == 0) goto L50
            if (r4 <= 0) goto L4a
            goto L99
        L4a:
            java.io.EOFException r11 = new java.io.EOFException
            r11.<init>()
            throw r11
        L50:
            c.d.a.a.m1.t r7 = r10.f1379c
            r7.e(r1)
            c.d.a.a.m1.t r7 = r10.f1379c
            int r7 = r7.c()
            if (r2 == 0) goto L64
            long r8 = (long) r2
            boolean r8 = a(r7, r8)
            if (r8 == 0) goto L6b
        L64:
            int r8 = c.d.a.a.e1.o.a(r7)
            r9 = -1
            if (r8 != r9) goto L8b
        L6b:
            int r2 = r5 + 1
            if (r5 != r0) goto L7a
            if (r12 == 0) goto L72
            return r1
        L72:
            c.d.a.a.l0 r11 = new c.d.a.a.l0
            java.lang.String r12 = "Searched too many bytes."
            r11.<init>(r12)
            throw r11
        L7a:
            if (r12 == 0) goto L84
            r11.f = r1
            int r4 = r3 + r2
            r11.a(r4, r1)
            goto L87
        L84:
            r11.c(r6)
        L87:
            r5 = r2
            r2 = 0
            r4 = 0
            goto L41
        L8b:
            int r4 = r4 + 1
            if (r4 != r6) goto L96
            c.d.a.a.e1.o r2 = r10.f1380d
            c.d.a.a.e1.o.a(r7, r2)
            r2 = r7
            goto La5
        L96:
            r7 = 4
            if (r4 != r7) goto La5
        L99:
            if (r12 == 0) goto La0
            int r3 = r3 + r5
            r11.c(r3)
            goto La2
        La0:
            r11.f = r1
        La2:
            r10.i = r2
            return r6
        La5:
            int r8 = r8 + (-4)
            r11.a(r8, r1)
            goto L41
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.e1.b0.d.a(c.d.a.a.e1.e, boolean):boolean");
    }
}
