package c.d.a.a.e1.b0;

import c.d.a.a.e1.o;

/* loaded from: classes.dex */
public final class b extends c.d.a.a.e1.d implements e {
    public b(long j, long j2, o oVar) {
        super(j, j2, oVar.f, oVar.f1660c);
    }

    @Override // c.d.a.a.e1.b0.e
    public long a(long j) {
        return c.d.a.a.e1.d.a(j, this.f1455b, this.e);
    }

    @Override // c.d.a.a.e1.b0.e
    public long b() {
        return -1L;
    }
}
