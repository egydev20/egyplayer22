package c.d.a.a.e1.b0;

import c.d.a.a.e1.q;

/* loaded from: classes.dex */
public interface e extends q {

    /* loaded from: classes.dex */
    public static class a extends q.b implements e {
        public a() {
            super(-9223372036854775807L, 0L);
        }

        @Override // c.d.a.a.e1.b0.e
        public long a(long j) {
            return 0L;
        }

        @Override // c.d.a.a.e1.b0.e
        public long b() {
            return -1L;
        }
    }

    long a(long j);

    long b();
}
