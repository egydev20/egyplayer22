package c.d.a.a.e1.b0;

import c.d.a.a.e1.q;
import c.d.a.a.e1.r;
import c.d.a.a.m1.c0;

/* loaded from: classes.dex */
public final class g implements e {

    /* renamed from: a, reason: collision with root package name */
    public final long f1385a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1386b;

    /* renamed from: c, reason: collision with root package name */
    public final long f1387c;

    /* renamed from: d, reason: collision with root package name */
    public final long f1388d;
    public final long e;
    public final long[] f;

    public g(long j, int i, long j2, long j3, long[] jArr) {
        this.f1385a = j;
        this.f1386b = i;
        this.f1387c = j2;
        this.f = jArr;
        this.f1388d = j3;
        this.e = j3 != -1 ? j + j3 : -1L;
    }

    @Override // c.d.a.a.e1.b0.e
    public long a(long j) {
        long j2 = j - this.f1385a;
        if (!a() || j2 <= this.f1386b) {
            return 0L;
        }
        long[] jArr = this.f;
        c.d.a.a.m1.e.b(jArr);
        double d2 = (j2 * 256.0d) / this.f1388d;
        int b2 = c0.b(jArr, (long) d2, true, true);
        long j3 = this.f1387c;
        long j4 = (b2 * j3) / 100;
        long j5 = jArr[b2];
        int i = b2 + 1;
        long j6 = (j3 * i) / 100;
        return Math.round((j5 == (b2 == 99 ? 256L : jArr[i]) ? 0.0d : (d2 - j5) / (r0 - j5)) * (j6 - j4)) + j4;
    }

    @Override // c.d.a.a.e1.q
    public boolean a() {
        return this.f != null;
    }

    @Override // c.d.a.a.e1.b0.e
    public long b() {
        return this.e;
    }

    @Override // c.d.a.a.e1.q
    public q.a b(long j) {
        if (!a()) {
            return new q.a(new r(0L, this.f1385a + this.f1386b));
        }
        long b2 = c0.b(j, 0L, this.f1387c);
        double d2 = (b2 * 100.0d) / this.f1387c;
        double d3 = 0.0d;
        if (d2 > 0.0d) {
            if (d2 >= 100.0d) {
                d3 = 256.0d;
            } else {
                int i = (int) d2;
                long[] jArr = this.f;
                c.d.a.a.m1.e.b(jArr);
                double d4 = jArr[i];
                d3 = d4 + (((i == 99 ? 256.0d : r3[i + 1]) - d4) * (d2 - i));
            }
        }
        return new q.a(new r(b2, this.f1385a + c0.b(Math.round((d3 / 256.0d) * this.f1388d), this.f1386b, this.f1388d - 1)));
    }

    @Override // c.d.a.a.e1.q
    public long c() {
        return this.f1387c;
    }
}
