package c.d.a.a.e1.b0;

import c.d.a.a.e1.q;
import c.d.a.a.e1.r;
import c.d.a.a.m1.c0;

/* loaded from: classes.dex */
public final class f implements e {

    /* renamed from: a, reason: collision with root package name */
    public final long[] f1381a;

    /* renamed from: b, reason: collision with root package name */
    public final long[] f1382b;

    /* renamed from: c, reason: collision with root package name */
    public final long f1383c;

    /* renamed from: d, reason: collision with root package name */
    public final long f1384d;

    public f(long[] jArr, long[] jArr2, long j, long j2) {
        this.f1381a = jArr;
        this.f1382b = jArr2;
        this.f1383c = j;
        this.f1384d = j2;
    }

    @Override // c.d.a.a.e1.b0.e
    public long a(long j) {
        return this.f1381a[c0.b(this.f1382b, j, true, true)];
    }

    @Override // c.d.a.a.e1.q
    public boolean a() {
        return true;
    }

    @Override // c.d.a.a.e1.b0.e
    public long b() {
        return this.f1384d;
    }

    @Override // c.d.a.a.e1.q
    public q.a b(long j) {
        int b2 = c0.b(this.f1381a, j, true, true);
        r rVar = new r(this.f1381a[b2], this.f1382b[b2]);
        if (rVar.f1668a >= j || b2 == this.f1381a.length - 1) {
            return new q.a(rVar);
        }
        int i = b2 + 1;
        return new q.a(rVar, new r(this.f1381a[i], this.f1382b[i]));
    }

    @Override // c.d.a.a.e1.q
    public long c() {
        return this.f1383c;
    }
}
