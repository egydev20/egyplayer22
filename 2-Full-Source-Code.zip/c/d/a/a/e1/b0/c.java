package c.d.a.a.e1.b0;

import android.util.Pair;
import c.d.a.a.e1.q;
import c.d.a.a.e1.r;
import c.d.a.a.m1.c0;
import c.d.a.a.t;

/* loaded from: classes.dex */
public final class c implements e {

    /* renamed from: a, reason: collision with root package name */
    public final long[] f1374a;

    /* renamed from: b, reason: collision with root package name */
    public final long[] f1375b;

    /* renamed from: c, reason: collision with root package name */
    public final long f1376c;

    public c(long[] jArr, long[] jArr2) {
        this.f1374a = jArr;
        this.f1375b = jArr2;
        this.f1376c = t.a(jArr2[jArr2.length - 1]);
    }

    public static Pair<Long, Long> a(long j, long[] jArr, long[] jArr2) {
        Long valueOf;
        Long valueOf2;
        int b2 = c0.b(jArr, j, true, true);
        long j2 = jArr[b2];
        long j3 = jArr2[b2];
        int i = b2 + 1;
        if (i == jArr.length) {
            valueOf = Long.valueOf(j2);
            valueOf2 = Long.valueOf(j3);
        } else {
            long j4 = jArr[i];
            long j5 = jArr2[i];
            double d2 = j4 == j2 ? 0.0d : (j - j2) / (j4 - j2);
            valueOf = Long.valueOf(j);
            valueOf2 = Long.valueOf(((long) (d2 * (j5 - j3))) + j3);
        }
        return Pair.create(valueOf, valueOf2);
    }

    @Override // c.d.a.a.e1.b0.e
    public long a(long j) {
        return t.a(((Long) a(j, this.f1374a, this.f1375b).second).longValue());
    }

    @Override // c.d.a.a.e1.q
    public boolean a() {
        return true;
    }

    @Override // c.d.a.a.e1.b0.e
    public long b() {
        return -1L;
    }

    @Override // c.d.a.a.e1.q
    public q.a b(long j) {
        Pair<Long, Long> a2 = a(t.b(c0.b(j, 0L, this.f1376c)), this.f1375b, this.f1374a);
        return new q.a(new r(t.a(((Long) a2.first).longValue()), ((Long) a2.second).longValue()));
    }

    @Override // c.d.a.a.e1.q
    public long c() {
        return this.f1376c;
    }
}
