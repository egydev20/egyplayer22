package c.d.a.a;

import java.util.HashSet;

/* loaded from: classes.dex */
public final class e0 {

    /* renamed from: a, reason: collision with root package name */
    public static final HashSet<String> f1330a = new HashSet<>();

    /* renamed from: b, reason: collision with root package name */
    public static String f1331b = "goog.exo.core";

    public static synchronized String a() {
        String str;
        synchronized (e0.class) {
            str = f1331b;
        }
        return str;
    }

    public static synchronized void a(String str) {
        synchronized (e0.class) {
            if (f1330a.add(str)) {
                f1331b += ", " + str;
            }
        }
    }
}
