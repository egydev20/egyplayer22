package c.d.a.a.a1;

import android.os.Handler;
import android.os.SystemClock;
import c.d.a.a.a1.m;
import c.d.a.a.a1.n;
import c.d.a.a.f0;
import c.d.a.a.g0;
import c.d.a.a.n0;
import com.google.android.exoplayer2.ext.ffmpeg.FfmpegDecoder;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public abstract class a0 extends c.d.a.a.s implements c.d.a.a.m1.p {
    public c.d.a.a.c1.m<c.d.a.a.c1.q> A;
    public int B;
    public boolean C;
    public boolean D;
    public long E;
    public boolean F;
    public boolean G;
    public boolean H;
    public boolean I;
    public boolean J;
    public final c.d.a.a.c1.o<c.d.a.a.c1.q> m;
    public final boolean n;
    public final m.a o;
    public final n p;
    public final c.d.a.a.b1.e q;
    public boolean r;
    public c.d.a.a.b1.d s;
    public f0 t;
    public int u;
    public int v;
    public c.d.a.a.b1.g<c.d.a.a.b1.e, ? extends c.d.a.a.b1.h, ? extends c.d.a.a.d1.a.b> w;
    public c.d.a.a.b1.e x;
    public c.d.a.a.b1.h y;
    public c.d.a.a.c1.m<c.d.a.a.c1.q> z;

    public a0(Handler handler, m mVar, c.d.a.a.c1.o<c.d.a.a.c1.q> oVar, boolean z, n nVar) {
        super(1);
        this.m = oVar;
        this.n = z;
        this.o = new m.a(handler, mVar);
        this.p = nVar;
        ((t) nVar).k = new b(null);
        this.q = new c.d.a.a.b1.e(0);
        this.B = 0;
        this.D = true;
    }

    public final void A() {
        long a2 = ((t) this.p).a(d());
        if (a2 != Long.MIN_VALUE) {
            if (!this.G) {
                a2 = Math.max(this.E, a2);
            }
            this.E = a2;
            this.G = false;
        }
    }

    @Override // c.d.a.a.m1.p
    public n0 a() {
        return ((t) this.p).d();
    }

    @Override // c.d.a.a.s, c.d.a.a.r0.b
    public void a(int i, Object obj) {
        if (i == 2) {
            n nVar = this.p;
            float floatValue = ((Float) obj).floatValue();
            t tVar = (t) nVar;
            if (tVar.D != floatValue) {
                tVar.D = floatValue;
                tVar.o();
                return;
            }
            return;
        }
        if (i == 3) {
            ((t) this.p).a((i) obj);
        } else {
            if (i != 5) {
                return;
            }
            ((t) this.p).a((q) obj);
        }
    }

    @Override // c.d.a.a.t0
    public void a(long j, long j2) {
        if (this.I) {
            try {
                ((t) this.p).m();
                return;
            } catch (n.d e) {
                throw a(e, this.t);
            }
        }
        if (this.t == null) {
            g0 p = p();
            this.q.clear();
            int a2 = a(p, this.q, true);
            if (a2 != -5) {
                if (a2 == -4) {
                    c.d.a.a.m1.e.b(this.q.isEndOfStream());
                    this.H = true;
                    y();
                    return;
                }
                return;
            }
            a(p);
        }
        x();
        if (this.w != null) {
            try {
                c.d.a.a.m1.e.a("drainAndFeed");
                do {
                } while (v());
                do {
                } while (w());
                c.d.a.a.m1.e.b();
                this.s.a();
            } catch (n.a | n.b | n.d | c.d.a.a.d1.a.b e2) {
                throw a(e2, this.t);
            }
        }
    }

    public final void a(c.d.a.a.c1.m<c.d.a.a.c1.q> mVar) {
        c.d.a.a.c1.l.a(this.z, mVar);
        this.z = mVar;
    }

    @Override // c.d.a.a.m1.p
    public void a(n0 n0Var) {
        ((t) this.p).a(n0Var);
    }

    @Override // c.d.a.a.m1.p
    public long b() {
        if (this.f == 2) {
            A();
        }
        return this.E;
    }

    public final void b(c.d.a.a.c1.m<c.d.a.a.c1.q> mVar) {
        c.d.a.a.c1.l.a(this.A, mVar);
        this.A = mVar;
    }

    @Override // c.d.a.a.t0
    public boolean c() {
        if (!((t) this.p).g()) {
            if (this.t != null && !this.J) {
                if ((j() ? this.k : this.g.c()) || this.y != null) {
                }
            }
            return false;
        }
        return true;
    }

    @Override // c.d.a.a.t0
    public boolean d() {
        return this.I && ((t) this.p).h();
    }

    @Override // c.d.a.a.s, c.d.a.a.t0
    public c.d.a.a.m1.p l() {
        return this;
    }

    @Override // c.d.a.a.s
    public void q() {
        this.t = null;
        this.D = true;
        this.J = false;
        try {
            b(null);
            z();
            ((t) this.p).n();
        } finally {
            this.o.a(this.s);
        }
    }

    @Override // c.d.a.a.s
    public void r() {
        c.d.a.a.c1.o<c.d.a.a.c1.q> oVar = this.m;
        if (oVar == null || !this.r) {
            return;
        }
        this.r = false;
        oVar.release();
    }

    @Override // c.d.a.a.s
    public void s() {
        ((t) this.p).k();
    }

    @Override // c.d.a.a.s
    public void t() {
        A();
        ((t) this.p).j();
    }

    public final boolean v() {
        if (this.y == null) {
            c.d.a.a.b1.h a2 = this.w.a();
            this.y = a2;
            if (a2 == null) {
                return false;
            }
            int i = a2.skippedOutputBufferCount;
            if (i > 0) {
                this.s.f += i;
                ((t) this.p).f();
            }
        }
        if (this.y.isEndOfStream()) {
            if (this.B == 2) {
                z();
                x();
                this.D = true;
            } else {
                c.d.a.a.b1.h hVar = this.y;
                hVar.f1271a.a((c.d.a.a.b1.g<?, c.d.a.a.b1.h, ?>) hVar);
                this.y = null;
                y();
            }
            return false;
        }
        if (this.D) {
            c.d.a.a.d1.a.a aVar = (c.d.a.a.d1.a.a) this;
            c.d.a.a.m1.e.b(aVar.L);
            f0 a3 = f0.a((String) null, "audio/raw", (String) null, -1, -1, aVar.L.t, aVar.L.u, aVar.L.p, (List<byte[]>) Collections.emptyList(), (c.d.a.a.c1.k) null, 0, (String) null);
            ((t) this.p).a(a3.y, a3.w, a3.x, 0, null, this.u, this.v);
            this.D = false;
        }
        n nVar = this.p;
        c.d.a.a.b1.h hVar2 = this.y;
        if (!((t) nVar).a(hVar2.f1272b, hVar2.timeUs)) {
            return false;
        }
        this.s.e++;
        c.d.a.a.b1.h hVar3 = this.y;
        hVar3.f1271a.a((c.d.a.a.b1.g<?, c.d.a.a.b1.h, ?>) hVar3);
        this.y = null;
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:44:0x009a A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:45:0x009b  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean w() {
        /*
            Method dump skipped, instructions count: 214
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.a1.a0.w():boolean");
    }

    public final void x() {
        if (this.w != null) {
            return;
        }
        a(this.A);
        c.d.a.a.c1.m<c.d.a.a.c1.q> mVar = this.z;
        if (mVar != null && mVar.b() == null && this.z.c() == null) {
            return;
        }
        try {
            long elapsedRealtime = SystemClock.elapsedRealtime();
            c.d.a.a.m1.e.a("createAudioDecoder");
            f0 f0Var = this.t;
            c.d.a.a.d1.a.a aVar = (c.d.a.a.d1.a.a) this;
            int i = f0Var.k;
            FfmpegDecoder ffmpegDecoder = new FfmpegDecoder(16, 16, i != -1 ? i : 5760, f0Var, aVar.b(f0Var));
            aVar.L = ffmpegDecoder;
            this.w = ffmpegDecoder;
            c.d.a.a.m1.e.b();
            long elapsedRealtime2 = SystemClock.elapsedRealtime();
            this.o.a(this.w.c(), elapsedRealtime2, elapsedRealtime2 - elapsedRealtime);
            this.s.f1259a++;
        } catch (c.d.a.a.d1.a.b e) {
            throw a(e, this.t);
        }
    }

    public final void y() {
        this.I = true;
        try {
            ((t) this.p).m();
        } catch (n.d e) {
            throw a(e, this.t);
        }
    }

    public final void z() {
        this.x = null;
        this.y = null;
        this.B = 0;
        this.C = false;
        c.d.a.a.b1.g<c.d.a.a.b1.e, ? extends c.d.a.a.b1.h, ? extends c.d.a.a.d1.a.b> gVar = this.w;
        if (gVar != null) {
            gVar.release();
            this.w = null;
            this.s.f1260b++;
        }
        a((c.d.a.a.c1.m<c.d.a.a.c1.q>) null);
    }

    @Override // c.d.a.a.s
    public void a(boolean z) {
        c.d.a.a.c1.o<c.d.a.a.c1.q> oVar = this.m;
        if (oVar != null && !this.r) {
            this.r = true;
            oVar.a();
        }
        c.d.a.a.b1.d dVar = new c.d.a.a.b1.d();
        this.s = dVar;
        m.a aVar = this.o;
        Handler handler = aVar.f1209a;
        if (handler != null) {
            handler.post(new c(aVar, dVar));
        }
        int i = this.f2590d.f2596a;
        if (i != 0) {
            ((t) this.p).a(i);
            return;
        }
        t tVar = (t) this.p;
        if (tVar.Q) {
            tVar.Q = false;
            tVar.O = 0;
            tVar.b();
        }
    }

    /* loaded from: classes.dex */
    public final class b implements n.c {
        public /* synthetic */ b(a aVar) {
        }

        @Override // c.d.a.a.a1.n.c
        public void a(int i) {
            m.a aVar = a0.this.o;
            Handler handler = aVar.f1209a;
            if (handler != null) {
                handler.post(new d(aVar, i));
            }
            if (a0.this == null) {
                throw null;
            }
        }

        @Override // c.d.a.a.a1.n.c
        public void c() {
            a0 a0Var = a0.this;
            if (a0Var != null) {
                a0Var.G = true;
                return;
            }
            throw null;
        }

        @Override // c.d.a.a.a1.n.c
        public void a(int i, long j, long j2) {
            a0.this.o.a(i, j, j2);
            if (a0.this == null) {
                throw null;
            }
        }
    }

    public a0(Handler handler, m mVar, l... lVarArr) {
        this(handler, mVar, null, false, new t(null, lVarArr));
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void a(g0 g0Var) {
        f0 f0Var = g0Var.f1736c;
        c.d.a.a.m1.e.b(f0Var);
        if (g0Var.f1734a) {
            b(g0Var.f1735b);
        } else {
            this.A = a(this.t, f0Var, this.m, this.A);
        }
        this.t = f0Var;
        if (this.C) {
            this.B = 1;
        } else {
            z();
            x();
            this.D = true;
        }
        f0 f0Var2 = this.t;
        this.u = f0Var2.z;
        this.v = f0Var2.A;
        m.a aVar = this.o;
        Handler handler = aVar.f1209a;
        if (handler != null) {
            handler.post(new c.d.a.a.a1.a(aVar, f0Var2));
        }
    }

    @Override // c.d.a.a.s
    public void a(long j, boolean z) {
        ((t) this.p).b();
        this.E = j;
        this.F = true;
        this.G = true;
        this.H = false;
        this.I = false;
        if (this.w != null) {
            this.J = false;
            if (this.B != 0) {
                z();
                x();
                return;
            }
            this.x = null;
            c.d.a.a.b1.h hVar = this.y;
            if (hVar != null) {
                hVar.f1271a.a((c.d.a.a.b1.g<?, c.d.a.a.b1.h, ?>) hVar);
                this.y = null;
            }
            this.w.flush();
            this.C = false;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x0054  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x006d  */
    @Override // c.d.a.a.s
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final int a(c.d.a.a.f0 r9) {
        /*
            r8 = this;
            java.lang.String r0 = r9.j
            boolean r0 = c.d.a.a.m1.q.h(r0)
            r1 = 0
            if (r0 != 0) goto La
            return r1
        La:
            c.d.a.a.c1.o<c.d.a.a.c1.q> r0 = r8.m
            r2 = r8
            c.d.a.a.d1.a.a r2 = (c.d.a.a.d1.a.a) r2
            java.lang.String r3 = r9.j
            c.d.a.a.m1.e.b(r3)
            boolean r3 = com.google.android.exoplayer2.ext.ffmpeg.FfmpegLibrary.a()
            r4 = 2
            r5 = 1
            if (r3 != 0) goto L1e
            r5 = 0
            goto L78
        L1e:
            java.lang.String r3 = r9.j
            boolean r6 = com.google.android.exoplayer2.ext.ffmpeg.FfmpegLibrary.a()
            if (r6 != 0) goto L27
            goto L4f
        L27:
            java.lang.String r3 = com.google.android.exoplayer2.ext.ffmpeg.FfmpegLibrary.a(r3)
            if (r3 != 0) goto L2e
            goto L4f
        L2e:
            boolean r6 = com.google.android.exoplayer2.ext.ffmpeg.FfmpegLibrary.ffmpegHasDecoder(r3)
            if (r6 != 0) goto L51
            java.lang.StringBuilder r6 = new java.lang.StringBuilder
            r6.<init>()
            java.lang.String r7 = "No "
            r6.append(r7)
            r6.append(r3)
            java.lang.String r3 = " decoder available. Check the FFmpeg build configuration."
            r6.append(r3)
            java.lang.String r3 = r6.toString()
            java.lang.String r6 = "FfmpegLibrary"
            android.util.Log.w(r6, r3)
        L4f:
            r3 = 0
            goto L52
        L51:
            r3 = 1
        L52:
            if (r3 == 0) goto L78
            boolean r3 = r2.b(r9)
            if (r3 != 0) goto L69
            int r3 = r9.w
            c.d.a.a.a1.n r2 = r2.p
            c.d.a.a.a1.t r2 = (c.d.a.a.a1.t) r2
            boolean r2 = r2.a(r3, r4)
            if (r2 == 0) goto L67
            goto L69
        L67:
            r2 = 0
            goto L6a
        L69:
            r2 = 1
        L6a:
            if (r2 != 0) goto L6d
            goto L78
        L6d:
            c.d.a.a.c1.k r9 = r9.m
            boolean r9 = c.d.a.a.s.a(r0, r9)
            if (r9 != 0) goto L77
            r5 = 2
            goto L78
        L77:
            r5 = 4
        L78:
            if (r5 > r4) goto L7e
            r9 = r5 | 0
            r9 = r9 | r1
            return r9
        L7e:
            int r9 = c.d.a.a.m1.c0.f2426a
            r0 = 21
            if (r9 < r0) goto L86
            r1 = 32
        L86:
            r9 = r5 | 8
            r9 = r9 | r1
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.a1.a0.a(c.d.a.a.f0):int");
    }
}
