package c.d.a.a.a1;

import c.d.a.a.a1.l;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public final class z extends r {
    public int i;
    public boolean j;
    public byte[] k;
    public byte[] l;
    public int m;
    public int n;
    public int o;
    public boolean p;
    public long q;

    public z() {
        byte[] bArr = c.d.a.a.m1.c0.f;
        this.k = bArr;
        this.l = bArr;
    }

    @Override // c.d.a.a.a1.l
    public void a(ByteBuffer byteBuffer) {
        int position;
        while (byteBuffer.hasRemaining() && !this.g.hasRemaining()) {
            int i = this.m;
            if (i == 0) {
                int limit = byteBuffer.limit();
                byteBuffer.limit(Math.min(limit, byteBuffer.position() + this.k.length));
                int limit2 = byteBuffer.limit() - 1;
                while (true) {
                    if (limit2 < byteBuffer.position()) {
                        position = byteBuffer.position();
                        break;
                    } else {
                        if (Math.abs((int) byteBuffer.get(limit2)) > 4) {
                            int i2 = this.i;
                            position = ((limit2 / i2) * i2) + i2;
                            break;
                        }
                        limit2 -= 2;
                    }
                }
                if (position == byteBuffer.position()) {
                    this.m = 1;
                } else {
                    byteBuffer.limit(position);
                    int remaining = byteBuffer.remaining();
                    a(remaining).put(byteBuffer).flip();
                    if (remaining > 0) {
                        this.p = true;
                    }
                }
                byteBuffer.limit(limit);
            } else if (i == 1) {
                int limit3 = byteBuffer.limit();
                int b2 = b(byteBuffer);
                int position2 = b2 - byteBuffer.position();
                byte[] bArr = this.k;
                int length = bArr.length;
                int i3 = this.n;
                int i4 = length - i3;
                if (b2 >= limit3 || position2 >= i4) {
                    int min = Math.min(position2, i4);
                    byteBuffer.limit(byteBuffer.position() + min);
                    byteBuffer.get(this.k, this.n, min);
                    int i5 = this.n + min;
                    this.n = i5;
                    byte[] bArr2 = this.k;
                    if (i5 == bArr2.length) {
                        if (this.p) {
                            a(bArr2, this.o);
                            this.q += (this.n - (this.o * 2)) / this.i;
                        } else {
                            this.q += (i5 - this.o) / this.i;
                        }
                        a(byteBuffer, this.k, this.n);
                        this.n = 0;
                        this.m = 2;
                    }
                    byteBuffer.limit(limit3);
                } else {
                    a(bArr, i3);
                    this.n = 0;
                    this.m = 0;
                }
            } else if (i == 2) {
                int limit4 = byteBuffer.limit();
                int b3 = b(byteBuffer);
                byteBuffer.limit(b3);
                this.q += byteBuffer.remaining() / this.i;
                a(byteBuffer, this.l, this.o);
                if (b3 < limit4) {
                    a(this.l, this.o);
                    this.m = 0;
                    byteBuffer.limit(limit4);
                }
            } else {
                throw new IllegalStateException();
            }
        }
    }

    public final void a(ByteBuffer byteBuffer, byte[] bArr, int i) {
        int min = Math.min(byteBuffer.remaining(), this.o);
        int i2 = this.o - min;
        System.arraycopy(bArr, i - i2, this.l, 0, i2);
        byteBuffer.position(byteBuffer.limit() - min);
        byteBuffer.get(this.l, i2, min);
    }

    public final void a(byte[] bArr, int i) {
        a(i).put(bArr, 0, i).flip();
        if (i > 0) {
            this.p = true;
        }
    }

    public final int b(ByteBuffer byteBuffer) {
        for (int position = byteBuffer.position() + 1; position < byteBuffer.limit(); position += 2) {
            if (Math.abs((int) byteBuffer.get(position)) > 4) {
                int i = this.i;
                return (position / i) * i;
            }
        }
        return byteBuffer.limit();
    }

    @Override // c.d.a.a.a1.r
    public l.a b(l.a aVar) {
        if (aVar.f1207c == 2) {
            return this.j ? aVar : l.a.e;
        }
        throw new l.b(aVar);
    }

    @Override // c.d.a.a.a1.r, c.d.a.a.a1.l
    public boolean c() {
        return this.j;
    }

    @Override // c.d.a.a.a1.r
    public void e() {
        if (this.j) {
            int i = this.f1225b.f1208d;
            this.i = i;
            int i2 = ((int) ((r0.f1205a * 150000) / 1000000)) * i;
            if (this.k.length != i2) {
                this.k = new byte[i2];
            }
            int i3 = ((int) ((this.f1225b.f1205a * 20000) / 1000000)) * this.i;
            this.o = i3;
            if (this.l.length != i3) {
                this.l = new byte[i3];
            }
        }
        this.m = 0;
        this.q = 0L;
        this.n = 0;
        this.p = false;
    }

    @Override // c.d.a.a.a1.r
    public void g() {
        int i = this.n;
        if (i > 0) {
            a(this.k, i);
        }
        if (this.p) {
            return;
        }
        this.q += this.o / this.i;
    }

    @Override // c.d.a.a.a1.r
    public void h() {
        this.j = false;
        this.o = 0;
        byte[] bArr = c.d.a.a.m1.c0.f;
        this.k = bArr;
        this.l = bArr;
    }
}
