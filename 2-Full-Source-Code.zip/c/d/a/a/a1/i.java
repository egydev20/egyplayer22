package c.d.a.a.a1;

import android.annotation.TargetApi;
import android.media.AudioAttributes;

/* loaded from: classes.dex */
public final class i {
    public static final i f;

    /* renamed from: a, reason: collision with root package name */
    public final int f1196a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1197b;

    /* renamed from: c, reason: collision with root package name */
    public final int f1198c;

    /* renamed from: d, reason: collision with root package name */
    public final int f1199d;
    public AudioAttributes e;

    static {
        int i = 0;
        int i2 = 1;
        f = new i(i, i, i2, i2, null);
    }

    public /* synthetic */ i(int i, int i2, int i3, int i4, a aVar) {
        this.f1196a = i;
        this.f1197b = i2;
        this.f1198c = i3;
        this.f1199d = i4;
    }

    @TargetApi(21)
    public AudioAttributes a() {
        if (this.e == null) {
            AudioAttributes.Builder usage = new AudioAttributes.Builder().setContentType(this.f1196a).setFlags(this.f1197b).setUsage(this.f1198c);
            if (c.d.a.a.m1.c0.f2426a >= 29) {
                usage.setAllowedCapturePolicy(this.f1199d);
            }
            this.e = usage.build();
        }
        return this.e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || i.class != obj.getClass()) {
            return false;
        }
        i iVar = (i) obj;
        return this.f1196a == iVar.f1196a && this.f1197b == iVar.f1197b && this.f1198c == iVar.f1198c && this.f1199d == iVar.f1199d;
    }

    public int hashCode() {
        return ((((((527 + this.f1196a) * 31) + this.f1197b) * 31) + this.f1198c) * 31) + this.f1199d;
    }
}
