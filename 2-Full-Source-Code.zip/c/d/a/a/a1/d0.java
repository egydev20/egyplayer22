package c.d.a.a.a1;

import c.d.a.a.a1.l;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public final class d0 extends r {
    public int i;
    public int j;
    public boolean k;
    public int l;
    public byte[] m = c.d.a.a.m1.c0.f;
    public int n;
    public long o;

    @Override // c.d.a.a.a1.r, c.d.a.a.a1.l
    public ByteBuffer a() {
        int i;
        if (super.d() && (i = this.n) > 0) {
            a(i).put(this.m, 0, this.n).flip();
            this.n = 0;
        }
        return super.a();
    }

    @Override // c.d.a.a.a1.l
    public void a(ByteBuffer byteBuffer) {
        int position = byteBuffer.position();
        int limit = byteBuffer.limit();
        int i = limit - position;
        if (i == 0) {
            return;
        }
        int min = Math.min(i, this.l);
        this.o += min / this.f1225b.f1208d;
        this.l -= min;
        byteBuffer.position(position + min);
        if (this.l > 0) {
            return;
        }
        int i2 = i - min;
        int length = (this.n + i2) - this.m.length;
        ByteBuffer a2 = a(length);
        int a3 = c.d.a.a.m1.c0.a(length, 0, this.n);
        a2.put(this.m, 0, a3);
        int a4 = c.d.a.a.m1.c0.a(length - a3, 0, i2);
        byteBuffer.limit(byteBuffer.position() + a4);
        a2.put(byteBuffer);
        byteBuffer.limit(limit);
        int i3 = i2 - a4;
        int i4 = this.n - a3;
        this.n = i4;
        byte[] bArr = this.m;
        System.arraycopy(bArr, a3, bArr, 0, i4);
        byteBuffer.get(this.m, this.n, i3);
        this.n += i3;
        a2.flip();
    }

    @Override // c.d.a.a.a1.r
    public l.a b(l.a aVar) {
        if (aVar.f1207c != 2) {
            throw new l.b(aVar);
        }
        this.k = true;
        return (this.i == 0 && this.j == 0) ? l.a.e : aVar;
    }

    @Override // c.d.a.a.a1.r, c.d.a.a.a1.l
    public boolean d() {
        return super.d() && this.n == 0;
    }

    @Override // c.d.a.a.a1.r
    public void e() {
        if (this.k) {
            this.k = false;
            int i = this.j;
            int i2 = this.f1225b.f1208d;
            this.m = new byte[i * i2];
            this.l = this.i * i2;
        } else {
            this.l = 0;
        }
        this.n = 0;
    }

    @Override // c.d.a.a.a1.r
    public void g() {
        if (this.k) {
            if (this.n > 0) {
                this.o += r0 / this.f1225b.f1208d;
            }
            this.n = 0;
        }
    }

    @Override // c.d.a.a.a1.r
    public void h() {
        this.m = c.d.a.a.m1.c0.f;
    }
}
