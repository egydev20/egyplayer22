package c.d.a.a.a1;

import android.annotation.TargetApi;
import android.media.AudioTimestamp;
import android.media.AudioTrack;

/* loaded from: classes.dex */
public final class o {

    /* renamed from: a, reason: collision with root package name */
    public final a f1211a;

    /* renamed from: b, reason: collision with root package name */
    public int f1212b;

    /* renamed from: c, reason: collision with root package name */
    public long f1213c;

    /* renamed from: d, reason: collision with root package name */
    public long f1214d;
    public long e;
    public long f;

    @TargetApi(19)
    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public final AudioTrack f1215a;

        /* renamed from: b, reason: collision with root package name */
        public final AudioTimestamp f1216b = new AudioTimestamp();

        /* renamed from: c, reason: collision with root package name */
        public long f1217c;

        /* renamed from: d, reason: collision with root package name */
        public long f1218d;
        public long e;

        public a(AudioTrack audioTrack) {
            this.f1215a = audioTrack;
        }
    }

    public o(AudioTrack audioTrack) {
        if (c.d.a.a.m1.c0.f2426a >= 19) {
            this.f1211a = new a(audioTrack);
            a();
        } else {
            this.f1211a = null;
            a(3);
        }
    }

    public void a() {
        if (this.f1211a != null) {
            a(0);
        }
    }

    public final void a(int i) {
        this.f1212b = i;
        long j = 5000;
        if (i == 0) {
            this.e = 0L;
            this.f = -1L;
            this.f1213c = System.nanoTime() / 1000;
        } else if (i != 1) {
            if (i == 2 || i == 3) {
                j = 10000000;
            } else {
                if (i != 4) {
                    throw new IllegalStateException();
                }
                j = 500000;
            }
        }
        this.f1214d = j;
    }
}
