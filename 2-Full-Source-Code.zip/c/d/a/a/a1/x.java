package c.d.a.a.a1;

import android.content.Context;
import android.media.MediaCodec;
import android.media.MediaCrypto;
import android.media.MediaFormat;
import android.os.Handler;
import android.util.Log;
import android.view.Surface;
import c.d.a.a.a1.m;
import c.d.a.a.a1.n;
import c.d.a.a.f0;
import c.d.a.a.g0;
import c.d.a.a.n0;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public class x extends c.d.a.a.f1.f implements c.d.a.a.m1.p {
    public boolean A0;
    public MediaFormat B0;
    public f0 C0;
    public long D0;
    public boolean E0;
    public boolean F0;
    public long G0;
    public int H0;
    public final Context t0;
    public final m.a u0;
    public final n v0;
    public final long[] w0;
    public int x0;
    public boolean y0;
    public boolean z0;

    @Deprecated
    public x(Context context, c.d.a.a.f1.g gVar, c.d.a.a.c1.o<c.d.a.a.c1.s> oVar, boolean z, boolean z2, Handler handler, m mVar, n nVar) {
        super(1, gVar, oVar, z, z2, 44100.0f);
        this.t0 = context.getApplicationContext();
        this.v0 = nVar;
        this.G0 = -9223372036854775807L;
        this.w0 = new long[10];
        this.u0 = new m.a(handler, mVar);
        ((t) nVar).k = new b(null);
    }

    @Override // c.d.a.a.f1.f
    public void E() {
        try {
            ((t) this.v0).m();
        } catch (n.d e) {
            throw a(e, this.C0);
        }
    }

    public final void J() {
        long a2 = ((t) this.v0).a(d());
        if (a2 != Long.MIN_VALUE) {
            if (!this.F0) {
                a2 = Math.max(this.D0, a2);
            }
            this.D0 = a2;
            this.F0 = false;
        }
    }

    @Override // c.d.a.a.f1.f
    public float a(float f, f0 f0Var, f0[] f0VarArr) {
        int i = -1;
        for (f0 f0Var2 : f0VarArr) {
            int i2 = f0Var2.x;
            if (i2 != -1) {
                i = Math.max(i, i2);
            }
        }
        if (i == -1) {
            return -1.0f;
        }
        return f * i;
    }

    public int a(int i, String str) {
        if ("audio/eac3-joc".equals(str)) {
            if (((t) this.v0).a(-1, 18)) {
                return c.d.a.a.m1.q.c("audio/eac3-joc");
            }
            str = "audio/eac3";
        }
        int c2 = c.d.a.a.m1.q.c(str);
        if (((t) this.v0).a(i, c2)) {
            return c2;
        }
        return 0;
    }

    @Override // c.d.a.a.f1.f
    public int a(MediaCodec mediaCodec, c.d.a.a.f1.e eVar, f0 f0Var, f0 f0Var2) {
        if (a(eVar, f0Var2) <= this.x0 && f0Var.z == 0 && f0Var.A == 0 && f0Var2.z == 0 && f0Var2.A == 0) {
            if (eVar.a(f0Var, f0Var2, true)) {
                return 3;
            }
            if (c.d.a.a.m1.c0.a((Object) f0Var.j, (Object) f0Var2.j) && f0Var.w == f0Var2.w && f0Var.x == f0Var2.x && f0Var.y == f0Var2.y && f0Var.b(f0Var2) && !"audio/opus".equals(f0Var.j)) {
                return 1;
            }
        }
        return 0;
    }

    public final int a(c.d.a.a.f1.e eVar, f0 f0Var) {
        int i;
        if (!"OMX.google.raw.decoder".equals(eVar.f1716a) || (i = c.d.a.a.m1.c0.f2426a) >= 24 || (i == 23 && c.d.a.a.m1.c0.d(this.t0))) {
            return f0Var.k;
        }
        return -1;
    }

    @Override // c.d.a.a.m1.p
    public n0 a() {
        return ((t) this.v0).d();
    }

    @Override // c.d.a.a.f1.f, c.d.a.a.s
    public void a(long j, boolean z) {
        super.a(j, z);
        ((t) this.v0).b();
        this.D0 = j;
        this.E0 = true;
        this.F0 = true;
        this.G0 = -9223372036854775807L;
        this.H0 = 0;
    }

    @Override // c.d.a.a.m1.p
    public void a(n0 n0Var) {
        ((t) this.v0).a(n0Var);
    }

    @Override // c.d.a.a.f1.f
    public void a(String str, long j, long j2) {
        this.u0.a(str, j, j2);
    }

    @Override // c.d.a.a.f1.f
    public boolean a(long j, long j2, MediaCodec mediaCodec, ByteBuffer byteBuffer, int i, int i2, long j3, boolean z, boolean z2, f0 f0Var) {
        if (this.A0 && j3 == 0 && (i2 & 4) != 0) {
            long j4 = this.G0;
            if (j4 != -9223372036854775807L) {
                j3 = j4;
            }
        }
        if (this.y0 && (i2 & 2) != 0) {
            mediaCodec.releaseOutputBuffer(i, false);
            return true;
        }
        if (z) {
            mediaCodec.releaseOutputBuffer(i, false);
            this.r0.f++;
            ((t) this.v0).f();
            return true;
        }
        try {
            if (!((t) this.v0).a(byteBuffer, j3)) {
                return false;
            }
            mediaCodec.releaseOutputBuffer(i, false);
            this.r0.e++;
            return true;
        } catch (n.b | n.d e) {
            throw a(e, this.C0);
        }
    }

    @Override // c.d.a.a.m1.p
    public long b() {
        if (this.f == 2) {
            J();
        }
        return this.D0;
    }

    @Override // c.d.a.a.f1.f
    public void b(long j) {
        while (this.H0 != 0 && j >= this.w0[0]) {
            ((t) this.v0).f();
            int i = this.H0 - 1;
            this.H0 = i;
            long[] jArr = this.w0;
            System.arraycopy(jArr, 1, jArr, 0, i);
        }
    }

    @Override // c.d.a.a.f1.f
    public void b(c.d.a.a.b1.e eVar) {
        if (this.E0 && !eVar.isDecodeOnly()) {
            if (Math.abs(eVar.f1265d - this.D0) > 500000) {
                this.D0 = eVar.f1265d;
            }
            this.E0 = false;
        }
        this.G0 = Math.max(eVar.f1265d, this.G0);
    }

    @Override // c.d.a.a.f1.f, c.d.a.a.t0
    public boolean c() {
        return ((t) this.v0).g() || super.c();
    }

    @Override // c.d.a.a.f1.f, c.d.a.a.t0
    public boolean d() {
        return this.m0 && ((t) this.v0).h();
    }

    @Override // c.d.a.a.s, c.d.a.a.t0
    public c.d.a.a.m1.p l() {
        return this;
    }

    @Override // c.d.a.a.f1.f, c.d.a.a.s
    public void q() {
        try {
            this.G0 = -9223372036854775807L;
            this.H0 = 0;
            ((t) this.v0).b();
            try {
                super.q();
            } finally {
            }
        } catch (Throwable th) {
            try {
                super.q();
                throw th;
            } finally {
            }
        }
    }

    @Override // c.d.a.a.f1.f, c.d.a.a.s
    public void r() {
        try {
            super.r();
        } finally {
            ((t) this.v0).n();
        }
    }

    @Override // c.d.a.a.s
    public void s() {
        ((t) this.v0).k();
    }

    @Override // c.d.a.a.s
    public void t() {
        J();
        ((t) this.v0).j();
    }

    @Override // c.d.a.a.f1.f
    public void a(c.d.a.a.f1.e eVar, MediaCodec mediaCodec, f0 f0Var, MediaCrypto mediaCrypto, float f) {
        f0[] f0VarArr = this.h;
        int a2 = a(eVar, f0Var);
        if (f0VarArr.length != 1) {
            for (f0 f0Var2 : f0VarArr) {
                if (eVar.a(f0Var, f0Var2, false)) {
                    a2 = Math.max(a2, a(eVar, f0Var2));
                }
            }
        }
        this.x0 = a2;
        this.z0 = c.d.a.a.m1.c0.f2426a < 24 && "OMX.SEC.aac.dec".equals(eVar.f1716a) && "samsung".equals(c.d.a.a.m1.c0.f2428c) && (c.d.a.a.m1.c0.f2427b.startsWith("zeroflte") || c.d.a.a.m1.c0.f2427b.startsWith("herolte") || c.d.a.a.m1.c0.f2427b.startsWith("heroqlte"));
        this.A0 = c.d.a.a.m1.c0.f2426a < 21 && "OMX.SEC.mp3.dec".equals(eVar.f1716a) && "samsung".equals(c.d.a.a.m1.c0.f2428c) && (c.d.a.a.m1.c0.f2427b.startsWith("baffin") || c.d.a.a.m1.c0.f2427b.startsWith("grand") || c.d.a.a.m1.c0.f2427b.startsWith("fortuna") || c.d.a.a.m1.c0.f2427b.startsWith("gprimelte") || c.d.a.a.m1.c0.f2427b.startsWith("j2y18lte") || c.d.a.a.m1.c0.f2427b.startsWith("ms01"));
        boolean z = eVar.g;
        this.y0 = z;
        String str = z ? "audio/raw" : eVar.f1718c;
        int i = this.x0;
        MediaFormat mediaFormat = new MediaFormat();
        mediaFormat.setString("mime", str);
        mediaFormat.setInteger("channel-count", f0Var.w);
        mediaFormat.setInteger("sample-rate", f0Var.x);
        a.a.a.a.a.a(mediaFormat, f0Var.l);
        a.a.a.a.a.a(mediaFormat, "max-input-size", i);
        if (c.d.a.a.m1.c0.f2426a >= 23) {
            mediaFormat.setInteger("priority", 0);
            if (f != -1.0f) {
                if (!(c.d.a.a.m1.c0.f2426a == 23 && ("ZTE B2017G".equals(c.d.a.a.m1.c0.f2429d) || "AXON 7 mini".equals(c.d.a.a.m1.c0.f2429d)))) {
                    mediaFormat.setFloat("operating-rate", f);
                }
            }
        }
        if (c.d.a.a.m1.c0.f2426a <= 28 && "audio/ac4".equals(f0Var.j)) {
            mediaFormat.setInteger("ac4-is-sync", 1);
        }
        mediaCodec.configure(mediaFormat, (Surface) null, mediaCrypto, 0);
        if (!this.y0) {
            this.B0 = null;
        } else {
            this.B0 = mediaFormat;
            mediaFormat.setString("mime", f0Var.j);
        }
    }

    /* loaded from: classes.dex */
    public final class b implements n.c {
        public /* synthetic */ b(a aVar) {
        }

        @Override // c.d.a.a.a1.n.c
        public void a(int i) {
            m.a aVar = x.this.u0;
            Handler handler = aVar.f1209a;
            if (handler != null) {
                handler.post(new d(aVar, i));
            }
            if (x.this == null) {
                throw null;
            }
        }

        @Override // c.d.a.a.a1.n.c
        public void c() {
            x xVar = x.this;
            if (xVar != null) {
                xVar.F0 = true;
                return;
            }
            throw null;
        }

        @Override // c.d.a.a.a1.n.c
        public void a(int i, long j, long j2) {
            x.this.u0.a(i, j, j2);
            if (x.this == null) {
                throw null;
            }
        }
    }

    @Override // c.d.a.a.f1.f
    public List<c.d.a.a.f1.e> a(c.d.a.a.f1.g gVar, f0 f0Var, boolean z) {
        c.d.a.a.f1.e a2;
        String str = f0Var.j;
        if (str == null) {
            return Collections.emptyList();
        }
        if ((a(f0Var.w, str) != 0) && (a2 = gVar.a()) != null) {
            return Collections.singletonList(a2);
        }
        List<c.d.a.a.f1.e> a3 = c.d.a.a.f1.h.a(gVar.a(str, z, false), f0Var);
        if ("audio/eac3-joc".equals(str)) {
            ArrayList arrayList = new ArrayList(a3);
            arrayList.addAll(gVar.a("audio/eac3", z, false));
            a3 = arrayList;
        }
        return Collections.unmodifiableList(a3);
    }

    @Override // c.d.a.a.s, c.d.a.a.r0.b
    public void a(int i, Object obj) {
        if (i == 2) {
            n nVar = this.v0;
            float floatValue = ((Float) obj).floatValue();
            t tVar = (t) nVar;
            if (tVar.D != floatValue) {
                tVar.D = floatValue;
                tVar.o();
                return;
            }
            return;
        }
        if (i == 3) {
            ((t) this.v0).a((i) obj);
        } else {
            if (i != 5) {
                return;
            }
            ((t) this.v0).a((q) obj);
        }
    }

    @Override // c.d.a.a.f1.f, c.d.a.a.s
    public void a(boolean z) {
        super.a(z);
        m.a aVar = this.u0;
        c.d.a.a.b1.d dVar = this.r0;
        Handler handler = aVar.f1209a;
        if (handler != null) {
            handler.post(new c(aVar, dVar));
        }
        int i = this.f2590d.f2596a;
        if (i != 0) {
            ((t) this.v0).a(i);
            return;
        }
        t tVar = (t) this.v0;
        if (tVar.Q) {
            tVar.Q = false;
            tVar.O = 0;
            tVar.b();
        }
    }

    @Override // c.d.a.a.f1.f
    public void a(g0 g0Var) {
        super.a(g0Var);
        f0 f0Var = g0Var.f1736c;
        this.C0 = f0Var;
        m.a aVar = this.u0;
        Handler handler = aVar.f1209a;
        if (handler != null) {
            handler.post(new c.d.a.a.a1.a(aVar, f0Var));
        }
    }

    @Override // c.d.a.a.f1.f
    public void a(MediaCodec mediaCodec, MediaFormat mediaFormat) {
        int i;
        int i2;
        int[] iArr;
        int i3;
        MediaFormat mediaFormat2 = this.B0;
        if (mediaFormat2 != null) {
            i2 = a(mediaFormat2.getInteger("channel-count"), mediaFormat2.getString("mime"));
            mediaFormat = mediaFormat2;
        } else {
            if (mediaFormat.containsKey("v-bits-per-sample")) {
                i = c.d.a.a.m1.c0.a(mediaFormat.getInteger("v-bits-per-sample"));
            } else {
                f0 f0Var = this.C0;
                i = "audio/raw".equals(f0Var.j) ? f0Var.y : 2;
            }
            i2 = i;
        }
        int integer = mediaFormat.getInteger("channel-count");
        int integer2 = mediaFormat.getInteger("sample-rate");
        if (this.z0 && integer == 6 && (i3 = this.C0.w) < 6) {
            iArr = new int[i3];
            for (int i4 = 0; i4 < this.C0.w; i4++) {
                iArr[i4] = i4;
            }
        } else {
            iArr = null;
        }
        try {
            ((t) this.v0).a(i2, integer, integer2, 0, iArr, this.C0.z, this.C0.A);
        } catch (n.a e) {
            throw a(e, this.C0);
        }
    }

    @Override // c.d.a.a.s
    public void a(f0[] f0VarArr, long j) {
        if (this.G0 != -9223372036854775807L) {
            int i = this.H0;
            if (i == this.w0.length) {
                StringBuilder a2 = c.a.b.a.a.a("Too many stream changes, so dropping change at ");
                a2.append(this.w0[this.H0 - 1]);
                Log.w("MediaCodecAudioRenderer", a2.toString());
            } else {
                this.H0 = i + 1;
            }
            this.w0[this.H0 - 1] = this.G0;
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x005f, code lost:
    
        if (((c.d.a.a.a1.t) r6.v0).a(r9.w, r9.y) != false) goto L34;
     */
    @Override // c.d.a.a.f1.f
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public int a(c.d.a.a.f1.g r7, c.d.a.a.c1.o<c.d.a.a.c1.s> r8, c.d.a.a.f0 r9) {
        /*
            r6 = this;
            java.lang.String r0 = r9.j
            boolean r1 = c.d.a.a.m1.q.h(r0)
            r2 = 0
            if (r1 != 0) goto La
            return r2
        La:
            int r1 = c.d.a.a.m1.c0.f2426a
            r3 = 21
            if (r1 < r3) goto L13
            r1 = 32
            goto L14
        L13:
            r1 = 0
        L14:
            c.d.a.a.c1.k r3 = r9.m
            r4 = 1
            if (r3 == 0) goto L32
            java.lang.Class<c.d.a.a.c1.s> r3 = c.d.a.a.c1.s.class
            java.lang.Class<? extends c.d.a.a.c1.q> r5 = r9.D
            boolean r3 = r3.equals(r5)
            if (r3 != 0) goto L32
            java.lang.Class<? extends c.d.a.a.c1.q> r3 = r9.D
            if (r3 != 0) goto L30
            c.d.a.a.c1.k r3 = r9.m
            boolean r8 = c.d.a.a.s.a(r8, r3)
            if (r8 == 0) goto L30
            goto L32
        L30:
            r8 = 0
            goto L33
        L32:
            r8 = 1
        L33:
            if (r8 == 0) goto L4b
            int r3 = r9.w
            int r3 = r6.a(r3, r0)
            if (r3 == 0) goto L3f
            r3 = 1
            goto L40
        L3f:
            r3 = 0
        L40:
            if (r3 == 0) goto L4b
            c.d.a.a.f1.e r3 = r7.a()
            if (r3 == 0) goto L4b
            r7 = r1 | 12
            return r7
        L4b:
            java.lang.String r3 = "audio/raw"
            boolean r0 = r3.equals(r0)
            if (r0 == 0) goto L61
            c.d.a.a.a1.n r0 = r6.v0
            int r3 = r9.w
            int r5 = r9.y
            c.d.a.a.a1.t r0 = (c.d.a.a.a1.t) r0
            boolean r0 = r0.a(r3, r5)
            if (r0 == 0) goto L6e
        L61:
            c.d.a.a.a1.n r0 = r6.v0
            int r3 = r9.w
            c.d.a.a.a1.t r0 = (c.d.a.a.a1.t) r0
            r5 = 2
            boolean r0 = r0.a(r3, r5)
            if (r0 != 0) goto L6f
        L6e:
            return r4
        L6f:
            java.util.List r7 = r6.a(r7, r9, r2)
            boolean r0 = r7.isEmpty()
            if (r0 == 0) goto L7a
            return r4
        L7a:
            if (r8 != 0) goto L7d
            return r5
        L7d:
            java.lang.Object r7 = r7.get(r2)
            c.d.a.a.f1.e r7 = (c.d.a.a.f1.e) r7
            boolean r8 = r7.a(r9)
            if (r8 == 0) goto L92
            boolean r7 = r7.b(r9)
            if (r7 == 0) goto L92
            r7 = 16
            goto L94
        L92:
            r7 = 8
        L94:
            if (r8 == 0) goto L98
            r8 = 4
            goto L99
        L98:
            r8 = 3
        L99:
            r7 = r7 | r8
            r7 = r7 | r1
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.a1.x.a(c.d.a.a.f1.g, c.d.a.a.c1.o, c.d.a.a.f0):int");
    }
}
