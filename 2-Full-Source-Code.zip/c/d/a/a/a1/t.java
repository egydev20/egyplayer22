package c.d.a.a.a1;

import android.media.AudioTrack;
import android.os.ConditionVariable;
import android.os.SystemClock;
import android.util.Log;
import c.d.a.a.a1.n;
import c.d.a.a.a1.p;
import c.d.a.a.n0;
import java.nio.ByteBuffer;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

/* loaded from: classes.dex */
public final class t implements n {
    public int A;
    public int B;
    public long C;
    public float D;
    public l[] E;
    public ByteBuffer[] F;
    public ByteBuffer G;
    public ByteBuffer H;
    public byte[] I;
    public int J;
    public int K;
    public boolean L;
    public boolean M;
    public boolean N;
    public int O;
    public q P;
    public boolean Q;
    public long R;

    /* renamed from: a, reason: collision with root package name */
    public final j f1228a;

    /* renamed from: b, reason: collision with root package name */
    public final b f1229b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f1230c;

    /* renamed from: d, reason: collision with root package name */
    public final s f1231d;
    public final d0 e;
    public final l[] f;
    public final l[] g;
    public final ConditionVariable h;
    public final p i;
    public final ArrayDeque<e> j;
    public n.c k;
    public AudioTrack l;
    public c m;
    public c n;
    public AudioTrack o;
    public i p;
    public n0 q;
    public n0 r;
    public long s;
    public long t;
    public ByteBuffer u;
    public int v;
    public long w;
    public long x;
    public long y;
    public long z;

    /* loaded from: classes.dex */
    public class a extends Thread {

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ AudioTrack f1232b;

        public a(AudioTrack audioTrack) {
            this.f1232b = audioTrack;
        }

        @Override // java.lang.Thread, java.lang.Runnable
        public void run() {
            try {
                this.f1232b.flush();
                this.f1232b.release();
            } finally {
                t.this.h.open();
            }
        }
    }

    /* loaded from: classes.dex */
    public interface b {
        long a(long j);

        n0 a(n0 n0Var);

        l[] a();

        long b();
    }

    /* loaded from: classes.dex */
    public static final class c {

        /* renamed from: a, reason: collision with root package name */
        public final boolean f1234a;

        /* renamed from: b, reason: collision with root package name */
        public final int f1235b;

        /* renamed from: c, reason: collision with root package name */
        public final int f1236c;

        /* renamed from: d, reason: collision with root package name */
        public final int f1237d;
        public final int e;
        public final int f;
        public final int g;
        public final int h;
        public final boolean i;
        public final boolean j;
        public final l[] k;

        public c(boolean z, int i, int i2, int i3, int i4, int i5, int i6, int i7, boolean z2, boolean z3, l[] lVarArr) {
            int i8;
            int i9;
            this.f1234a = z;
            this.f1235b = i;
            this.f1236c = i2;
            this.f1237d = i3;
            this.e = i4;
            this.f = i5;
            this.g = i6;
            if (i7 == 0) {
                if (z) {
                    int minBufferSize = AudioTrack.getMinBufferSize(i4, i5, i6);
                    c.d.a.a.m1.e.b(minBufferSize != -2);
                    long j = this.e;
                    int i10 = this.f1237d;
                    i9 = c.d.a.a.m1.c0.a(minBufferSize * 4, ((int) ((250000 * j) / 1000000)) * i10, (int) Math.max(minBufferSize, ((j * 750000) / 1000000) * i10));
                } else {
                    if (i6 != 5) {
                        if (i6 != 6) {
                            if (i6 == 7) {
                                i8 = 192000;
                            } else if (i6 == 8) {
                                i8 = 2250000;
                            } else if (i6 == 14) {
                                i8 = 3062500;
                            } else if (i6 == 17) {
                                i8 = 336000;
                            } else if (i6 != 18) {
                                throw new IllegalArgumentException();
                            }
                        }
                        i8 = 768000;
                    } else {
                        i8 = 80000;
                    }
                    i9 = (int) (((this.g == 5 ? i8 * 2 : i8) * 250000) / 1000000);
                }
                i7 = i9;
            }
            this.h = i7;
            this.i = z2;
            this.j = z3;
            this.k = lVarArr;
        }

        public long a(long j) {
            return (j * 1000000) / this.e;
        }
    }

    /* loaded from: classes.dex */
    public static final class e {

        /* renamed from: a, reason: collision with root package name */
        public final n0 f1241a;

        /* renamed from: b, reason: collision with root package name */
        public final long f1242b;

        /* renamed from: c, reason: collision with root package name */
        public final long f1243c;

        public /* synthetic */ e(n0 n0Var, long j, long j2, a aVar) {
            this.f1241a = n0Var;
            this.f1242b = j;
            this.f1243c = j2;
        }
    }

    /* loaded from: classes.dex */
    public final class f implements p.a {
        public /* synthetic */ f(a aVar) {
        }

        @Override // c.d.a.a.a1.p.a
        public void a(long j) {
            Log.w("AudioTrack", "Ignoring impossibly large audio latency: " + j);
        }

        @Override // c.d.a.a.a1.p.a
        public void b(long j, long j2, long j3, long j4) {
            StringBuilder sb = new StringBuilder();
            sb.append("Spurious audio timestamp (system clock mismatch): ");
            sb.append(j);
            sb.append(", ");
            sb.append(j2);
            sb.append(", ");
            sb.append(j3);
            sb.append(", ");
            sb.append(j4);
            sb.append(", ");
            t tVar = t.this;
            sb.append(tVar.n.f1234a ? tVar.w / r5.f1235b : tVar.x);
            sb.append(", ");
            sb.append(t.this.e());
            Log.w("AudioTrack", sb.toString());
        }

        @Override // c.d.a.a.a1.p.a
        public void a(long j, long j2, long j3, long j4) {
            StringBuilder sb = new StringBuilder();
            sb.append("Spurious audio timestamp (frame position mismatch): ");
            sb.append(j);
            sb.append(", ");
            sb.append(j2);
            sb.append(", ");
            sb.append(j3);
            sb.append(", ");
            sb.append(j4);
            sb.append(", ");
            t tVar = t.this;
            sb.append(tVar.n.f1234a ? tVar.w / r5.f1235b : tVar.x);
            sb.append(", ");
            sb.append(t.this.e());
            Log.w("AudioTrack", sb.toString());
        }

        @Override // c.d.a.a.a1.p.a
        public void a(int i, long j) {
            if (t.this.k != null) {
                long elapsedRealtime = SystemClock.elapsedRealtime();
                t tVar = t.this;
                tVar.k.a(i, j, elapsedRealtime - tVar.R);
            }
        }
    }

    public t(j jVar, l[] lVarArr) {
        d dVar = new d(lVarArr);
        this.f1228a = jVar;
        this.f1229b = dVar;
        this.f1230c = false;
        this.h = new ConditionVariable(true);
        this.i = new p(new f(null));
        this.f1231d = new s();
        this.e = new d0();
        ArrayList arrayList = new ArrayList();
        Collections.addAll(arrayList, new y(), this.f1231d, this.e);
        Collections.addAll(arrayList, dVar.a());
        this.f = (l[]) arrayList.toArray(new l[0]);
        this.g = new l[]{new w()};
        this.D = 1.0f;
        this.B = 0;
        this.p = i.f;
        this.O = 0;
        this.P = new q(0, 0.0f);
        this.r = n0.e;
        this.K = -1;
        this.E = new l[0];
        this.F = new ByteBuffer[0];
        this.j = new ArrayDeque<>();
    }

    public void a(int i) {
        c.d.a.a.m1.e.b(c.d.a.a.m1.c0.f2426a >= 21);
        if (this.Q && this.O == i) {
            return;
        }
        this.Q = true;
        this.O = i;
        b();
    }

    public final void a(long j) {
        ByteBuffer byteBuffer;
        int length = this.E.length;
        int i = length;
        while (i >= 0) {
            if (i > 0) {
                byteBuffer = this.F[i - 1];
            } else {
                byteBuffer = this.G;
                if (byteBuffer == null) {
                    byteBuffer = l.f1204a;
                }
            }
            if (i == length) {
                b(byteBuffer, j);
            } else {
                l lVar = this.E[i];
                lVar.a(byteBuffer);
                ByteBuffer a2 = lVar.a();
                this.F[i] = a2;
                if (a2.hasRemaining()) {
                    i++;
                }
            }
            if (byteBuffer.hasRemaining()) {
                return;
            } else {
                i--;
            }
        }
    }

    public void a(i iVar) {
        if (this.p.equals(iVar)) {
            return;
        }
        this.p = iVar;
        if (this.Q) {
            return;
        }
        b();
        this.O = 0;
    }

    public void a(q qVar) {
        if (this.P.equals(qVar)) {
            return;
        }
        int i = qVar.f1223a;
        float f2 = qVar.f1224b;
        AudioTrack audioTrack = this.o;
        if (audioTrack != null) {
            if (this.P.f1223a != i) {
                audioTrack.attachAuxEffect(i);
            }
            if (i != 0) {
                this.o.setAuxEffectSendLevel(f2);
            }
        }
        this.P = qVar;
    }

    public void a(n0 n0Var) {
        c cVar = this.n;
        if (cVar != null && !cVar.j) {
            this.r = n0.e;
        } else {
            if (n0Var.equals(d())) {
                return;
            }
            if (i()) {
                this.q = n0Var;
            } else {
                this.r = n0Var;
            }
        }
    }

    public final void a(n0 n0Var, long j) {
        this.j.add(new e(this.n.j ? this.f1229b.a(n0Var) : n0.e, Math.max(0L, j), this.n.a(e()), null));
        l[] lVarArr = this.n.k;
        ArrayList arrayList = new ArrayList();
        for (l lVar : lVarArr) {
            if (lVar.c()) {
                arrayList.add(lVar);
            } else {
                lVar.flush();
            }
        }
        int size = arrayList.size();
        this.E = (l[]) arrayList.toArray(new l[size]);
        this.F = new ByteBuffer[size];
        c();
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0038  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0023  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:16:0x0034 -> B:6:0x0012). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean a() {
        /*
            r9 = this;
            int r0 = r9.K
            r1 = -1
            r2 = 1
            r3 = 0
            if (r0 != r1) goto L16
            c.d.a.a.a1.t$c r0 = r9.n
            boolean r0 = r0.i
            if (r0 == 0) goto Lf
            r0 = 0
            goto L12
        Lf:
            c.d.a.a.a1.l[] r0 = r9.E
            int r0 = r0.length
        L12:
            r9.K = r0
            r0 = 1
            goto L17
        L16:
            r0 = 0
        L17:
            int r4 = r9.K
            c.d.a.a.a1.l[] r5 = r9.E
            int r6 = r5.length
            r7 = -9223372036854775807(0x8000000000000001, double:-4.9E-324)
            if (r4 >= r6) goto L38
            r4 = r5[r4]
            if (r0 == 0) goto L2a
            r4.b()
        L2a:
            r9.a(r7)
            boolean r0 = r4.d()
            if (r0 != 0) goto L34
            return r3
        L34:
            int r0 = r9.K
            int r0 = r0 + r2
            goto L12
        L38:
            java.nio.ByteBuffer r0 = r9.H
            if (r0 == 0) goto L44
            r9.b(r0, r7)
            java.nio.ByteBuffer r0 = r9.H
            if (r0 == 0) goto L44
            return r3
        L44:
            r9.K = r1
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.a1.t.a():boolean");
    }

    public void b() {
        if (i()) {
            this.w = 0L;
            this.x = 0L;
            this.y = 0L;
            this.z = 0L;
            this.A = 0;
            n0 n0Var = this.q;
            if (n0Var != null) {
                this.r = n0Var;
                this.q = null;
            } else if (!this.j.isEmpty()) {
                this.r = this.j.getLast().f1241a;
            }
            this.j.clear();
            this.s = 0L;
            this.t = 0L;
            this.e.o = 0L;
            c();
            this.G = null;
            this.H = null;
            this.M = false;
            this.L = false;
            this.K = -1;
            this.u = null;
            this.v = 0;
            this.B = 0;
            AudioTrack audioTrack = this.i.f1221c;
            c.d.a.a.m1.e.b(audioTrack);
            if (audioTrack.getPlayState() == 3) {
                this.o.pause();
            }
            AudioTrack audioTrack2 = this.o;
            this.o = null;
            c cVar = this.m;
            if (cVar != null) {
                this.n = cVar;
                this.m = null;
            }
            p pVar = this.i;
            pVar.j = 0L;
            pVar.u = 0;
            pVar.t = 0;
            pVar.k = 0L;
            pVar.f1221c = null;
            pVar.f = null;
            this.h.close();
            new a(audioTrack2).start();
        }
    }

    public final void c() {
        int i = 0;
        while (true) {
            l[] lVarArr = this.E;
            if (i >= lVarArr.length) {
                return;
            }
            l lVar = lVarArr[i];
            lVar.flush();
            this.F[i] = lVar.a();
            i++;
        }
    }

    public n0 d() {
        n0 n0Var = this.q;
        if (n0Var != null) {
            return n0Var;
        }
        if (!this.j.isEmpty()) {
            return this.j.getLast().f1241a;
        }
        return this.r;
    }

    public final long e() {
        return this.n.f1234a ? this.y / r0.f1237d : this.z;
    }

    public void f() {
        if (this.B == 1) {
            this.B = 2;
        }
    }

    public boolean g() {
        return i() && this.i.b(e());
    }

    public boolean h() {
        return !i() || (this.L && !g());
    }

    public final boolean i() {
        return this.o != null;
    }

    public void j() {
        boolean z = false;
        this.N = false;
        if (i()) {
            p pVar = this.i;
            pVar.j = 0L;
            pVar.u = 0;
            pVar.t = 0;
            pVar.k = 0L;
            if (pVar.v == -9223372036854775807L) {
                o oVar = pVar.f;
                c.d.a.a.m1.e.b(oVar);
                oVar.a();
                z = true;
            }
            if (z) {
                this.o.pause();
            }
        }
    }

    public void k() {
        this.N = true;
        if (i()) {
            o oVar = this.i.f;
            c.d.a.a.m1.e.b(oVar);
            oVar.a();
            this.o.play();
        }
    }

    public final void l() {
        if (this.M) {
            return;
        }
        this.M = true;
        p pVar = this.i;
        long e2 = e();
        pVar.x = pVar.a();
        pVar.v = SystemClock.elapsedRealtime() * 1000;
        pVar.y = e2;
        this.o.stop();
        this.v = 0;
    }

    public void m() {
        if (!this.L && i() && a()) {
            l();
            this.L = true;
        }
    }

    public void n() {
        b();
        AudioTrack audioTrack = this.l;
        if (audioTrack != null) {
            this.l = null;
            new u(this, audioTrack).start();
        }
        for (l lVar : this.f) {
            lVar.f();
        }
        for (l lVar2 : this.g) {
            lVar2.f();
        }
        this.O = 0;
        this.N = false;
    }

    public final void o() {
        if (i()) {
            if (c.d.a.a.m1.c0.f2426a >= 21) {
                this.o.setVolume(this.D);
                return;
            }
            AudioTrack audioTrack = this.o;
            float f2 = this.D;
            audioTrack.setStereoVolume(f2, f2);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:56:0x00c1  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x00f4  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x012c  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x00cf  */
    /* JADX WARN: Removed duplicated region for block: B:80:0x00d4  */
    /* JADX WARN: Removed duplicated region for block: B:81:0x00d9  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:83:0x00e3  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x00ed  */
    /* JADX WARN: Removed duplicated region for block: B:86:0x00f0 A[FALL_THROUGH] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void a(int r20, int r21, int r22, int r23, int[] r24, int r25, int r26) {
        /*
            Method dump skipped, instructions count: 332
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.a1.t.a(int, int, int, int, int[], int, int):void");
    }

    /* loaded from: classes.dex */
    public static class d implements b {

        /* renamed from: a, reason: collision with root package name */
        public final l[] f1238a;

        /* renamed from: b, reason: collision with root package name */
        public final z f1239b;

        /* renamed from: c, reason: collision with root package name */
        public final c0 f1240c;

        public d(l... lVarArr) {
            l[] lVarArr2 = new l[lVarArr.length + 2];
            this.f1238a = lVarArr2;
            System.arraycopy(lVarArr, 0, lVarArr2, 0, lVarArr.length);
            this.f1239b = new z();
            c0 c0Var = new c0();
            this.f1240c = c0Var;
            l[] lVarArr3 = this.f1238a;
            lVarArr3[lVarArr.length] = this.f1239b;
            lVarArr3[lVarArr.length + 1] = c0Var;
        }

        @Override // c.d.a.a.a1.t.b
        public n0 a(n0 n0Var) {
            this.f1239b.j = n0Var.f2499c;
            c0 c0Var = this.f1240c;
            float f = n0Var.f2497a;
            if (c0Var != null) {
                float a2 = c.d.a.a.m1.c0.a(f, 0.1f, 8.0f);
                if (c0Var.f1178c != a2) {
                    c0Var.f1178c = a2;
                    c0Var.i = true;
                }
                c0 c0Var2 = this.f1240c;
                float f2 = n0Var.f2498b;
                if (c0Var2 != null) {
                    float a3 = c.d.a.a.m1.c0.a(f2, 0.1f, 8.0f);
                    if (c0Var2.f1179d != a3) {
                        c0Var2.f1179d = a3;
                        c0Var2.i = true;
                    }
                    return new n0(a2, a3, n0Var.f2499c);
                }
                throw null;
            }
            throw null;
        }

        @Override // c.d.a.a.a1.t.b
        public l[] a() {
            return this.f1238a;
        }

        @Override // c.d.a.a.a1.t.b
        public long b() {
            return this.f1239b.q;
        }

        @Override // c.d.a.a.a1.t.b
        public long a(long j) {
            c0 c0Var = this.f1240c;
            long j2 = c0Var.o;
            if (j2 < 1024) {
                return (long) (c0Var.f1178c * j);
            }
            int i = c0Var.h.f1205a;
            int i2 = c0Var.g.f1205a;
            long j3 = c0Var.n;
            return i == i2 ? c.d.a.a.m1.c0.c(j, j3, j2) : c.d.a.a.m1.c0.c(j, j3 * i, j2 * i2);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:125:0x00c9, code lost:
    
        if (r11 != false) goto L52;
     */
    /* JADX WARN: Code restructure failed: missing block: B:127:0x00cc, code lost:
    
        if (r11 == false) goto L52;
     */
    /* JADX WARN: Removed duplicated region for block: B:100:0x023f  */
    /* JADX WARN: Removed duplicated region for block: B:103:0x0258  */
    /* JADX WARN: Removed duplicated region for block: B:106:0x025f  */
    /* JADX WARN: Removed duplicated region for block: B:113:0x01f8  */
    /* JADX WARN: Removed duplicated region for block: B:42:0x0112  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x01a7 A[Catch: Exception -> 0x01b0, TRY_LEAVE, TryCatch #0 {Exception -> 0x01b0, blocks: (B:70:0x0182, B:72:0x01a7), top: B:69:0x0182 }] */
    /* JADX WARN: Removed duplicated region for block: B:77:0x01c6 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:80:0x01ce  */
    /* JADX WARN: Removed duplicated region for block: B:95:0x0226  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public long a(boolean r26) {
        /*
            Method dump skipped, instructions count: 659
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.a1.t.a(boolean):long");
    }

    /* JADX WARN: Code restructure failed: missing block: B:50:0x00e4, code lost:
    
        if (r15 < r14) goto L54;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void b(java.nio.ByteBuffer r13, long r14) {
        /*
            Method dump skipped, instructions count: 299
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.a1.t.b(java.nio.ByteBuffer, long):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:209:0x01cb, code lost:
    
        if (r4.a() == 0) goto L80;
     */
    /* JADX WARN: Failed to find 'out' block for switch in B:96:0x0219. Please report as an issue. */
    /* JADX WARN: Removed duplicated region for block: B:112:0x035d A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:80:0x01ef A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:81:0x01f1  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean a(java.nio.ByteBuffer r24, long r25) {
        /*
            Method dump skipped, instructions count: 1128
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.a1.t.a(java.nio.ByteBuffer, long):boolean");
    }

    public boolean a(int i, int i2) {
        if (c.d.a.a.m1.c0.e(i2)) {
            return i2 != 4 || c.d.a.a.m1.c0.f2426a >= 21;
        }
        j jVar = this.f1228a;
        if (jVar != null) {
            if ((Arrays.binarySearch(jVar.f1202a, i2) >= 0) && (i == -1 || i <= this.f1228a.f1203b)) {
                return true;
            }
        }
        return false;
    }
}
