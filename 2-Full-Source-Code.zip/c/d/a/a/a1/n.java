package c.d.a.a.a1;

/* loaded from: classes.dex */
public interface n {

    /* loaded from: classes.dex */
    public static final class a extends Exception {
        public a(String str) {
            super(str);
        }

        public a(Throwable th) {
            super(th);
        }
    }

    /* loaded from: classes.dex */
    public static final class b extends Exception {
        public b(int i, int i2, int i3, int i4) {
            super("AudioTrack init failed: " + i + ", Config(" + i2 + ", " + i3 + ", " + i4 + ")");
        }
    }

    /* loaded from: classes.dex */
    public interface c {
        void a(int i);

        void a(int i, long j, long j2);

        void c();
    }

    /* loaded from: classes.dex */
    public static final class d extends Exception {
        public d(int i) {
            super(c.a.b.a.a.a("AudioTrack write failed: ", i));
        }
    }
}
