package c.d.a.a.a1;

import c.d.a.a.a1.m;

/* compiled from: lambda */
/* loaded from: classes.dex */
public final /* synthetic */ class c implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    private final /* synthetic */ m.a f1175b;

    /* renamed from: c, reason: collision with root package name */
    private final /* synthetic */ c.d.a.a.b1.d f1176c;

    public /* synthetic */ c(m.a aVar, c.d.a.a.b1.d dVar) {
        this.f1175b = aVar;
        this.f1176c = dVar;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f1175b.c(this.f1176c);
    }
}
