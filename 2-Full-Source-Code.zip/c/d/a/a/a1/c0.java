package c.d.a.a.a1;

import c.d.a.a.a1.l;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.ShortBuffer;

/* loaded from: classes.dex */
public final class c0 implements l {

    /* renamed from: b, reason: collision with root package name */
    public int f1177b;

    /* renamed from: c, reason: collision with root package name */
    public float f1178c = 1.0f;

    /* renamed from: d, reason: collision with root package name */
    public float f1179d = 1.0f;
    public l.a e;
    public l.a f;
    public l.a g;
    public l.a h;
    public boolean i;
    public b0 j;
    public ByteBuffer k;
    public ShortBuffer l;
    public ByteBuffer m;
    public long n;
    public long o;
    public boolean p;

    public c0() {
        l.a aVar = l.a.e;
        this.e = aVar;
        this.f = aVar;
        this.g = aVar;
        this.h = aVar;
        ByteBuffer byteBuffer = l.f1204a;
        this.k = byteBuffer;
        this.l = byteBuffer.asShortBuffer();
        this.m = l.f1204a;
        this.f1177b = -1;
    }

    @Override // c.d.a.a.a1.l
    public l.a a(l.a aVar) {
        if (aVar.f1207c != 2) {
            throw new l.b(aVar);
        }
        int i = this.f1177b;
        if (i == -1) {
            i = aVar.f1205a;
        }
        this.e = aVar;
        l.a aVar2 = new l.a(i, aVar.f1206b, 2);
        this.f = aVar2;
        this.i = true;
        return aVar2;
    }

    @Override // c.d.a.a.a1.l
    public ByteBuffer a() {
        ByteBuffer byteBuffer = this.m;
        this.m = l.f1204a;
        return byteBuffer;
    }

    @Override // c.d.a.a.a1.l
    public void a(ByteBuffer byteBuffer) {
        b0 b0Var = this.j;
        c.d.a.a.m1.e.b(b0Var);
        if (byteBuffer.hasRemaining()) {
            ShortBuffer asShortBuffer = byteBuffer.asShortBuffer();
            int remaining = byteBuffer.remaining();
            this.n += remaining;
            int remaining2 = asShortBuffer.remaining();
            int i = b0Var.f1172b;
            int i2 = remaining2 / i;
            short[] c2 = b0Var.c(b0Var.j, b0Var.k, i2);
            b0Var.j = c2;
            asShortBuffer.get(c2, b0Var.k * b0Var.f1172b, ((i * i2) * 2) / 2);
            b0Var.k += i2;
            b0Var.a();
            byteBuffer.position(byteBuffer.position() + remaining);
        }
        int i3 = b0Var.m * b0Var.f1172b * 2;
        if (i3 > 0) {
            if (this.k.capacity() < i3) {
                ByteBuffer order = ByteBuffer.allocateDirect(i3).order(ByteOrder.nativeOrder());
                this.k = order;
                this.l = order.asShortBuffer();
            } else {
                this.k.clear();
                this.l.clear();
            }
            ShortBuffer shortBuffer = this.l;
            int min = Math.min(shortBuffer.remaining() / b0Var.f1172b, b0Var.m);
            shortBuffer.put(b0Var.l, 0, b0Var.f1172b * min);
            int i4 = b0Var.m - min;
            b0Var.m = i4;
            short[] sArr = b0Var.l;
            int i5 = b0Var.f1172b;
            System.arraycopy(sArr, min * i5, sArr, 0, i4 * i5);
            this.o += i3;
            this.k.limit(i3);
            this.m = this.k;
        }
    }

    @Override // c.d.a.a.a1.l
    public void b() {
        int i;
        b0 b0Var = this.j;
        if (b0Var != null) {
            int i2 = b0Var.k;
            float f = b0Var.f1173c;
            float f2 = b0Var.f1174d;
            int i3 = b0Var.m + ((int) ((((i2 / (f / f2)) + b0Var.o) / (b0Var.e * f2)) + 0.5f));
            b0Var.j = b0Var.c(b0Var.j, i2, (b0Var.h * 2) + i2);
            int i4 = 0;
            while (true) {
                i = b0Var.h * 2;
                int i5 = b0Var.f1172b;
                if (i4 >= i * i5) {
                    break;
                }
                b0Var.j[(i5 * i2) + i4] = 0;
                i4++;
            }
            b0Var.k = i + b0Var.k;
            b0Var.a();
            if (b0Var.m > i3) {
                b0Var.m = i3;
            }
            b0Var.k = 0;
            b0Var.r = 0;
            b0Var.o = 0;
        }
        this.p = true;
    }

    @Override // c.d.a.a.a1.l
    public boolean c() {
        return this.f.f1205a != -1 && (Math.abs(this.f1178c - 1.0f) >= 0.01f || Math.abs(this.f1179d - 1.0f) >= 0.01f || this.f.f1205a != this.e.f1205a);
    }

    @Override // c.d.a.a.a1.l
    public boolean d() {
        b0 b0Var;
        return this.p && ((b0Var = this.j) == null || (b0Var.m * b0Var.f1172b) * 2 == 0);
    }

    @Override // c.d.a.a.a1.l
    public void f() {
        this.f1178c = 1.0f;
        this.f1179d = 1.0f;
        l.a aVar = l.a.e;
        this.e = aVar;
        this.f = aVar;
        this.g = aVar;
        this.h = aVar;
        ByteBuffer byteBuffer = l.f1204a;
        this.k = byteBuffer;
        this.l = byteBuffer.asShortBuffer();
        this.m = l.f1204a;
        this.f1177b = -1;
        this.i = false;
        this.j = null;
        this.n = 0L;
        this.o = 0L;
        this.p = false;
    }

    @Override // c.d.a.a.a1.l
    public void flush() {
        if (c()) {
            l.a aVar = this.e;
            this.g = aVar;
            l.a aVar2 = this.f;
            this.h = aVar2;
            if (this.i) {
                this.j = new b0(aVar.f1205a, aVar.f1206b, this.f1178c, this.f1179d, aVar2.f1205a);
            } else {
                b0 b0Var = this.j;
                if (b0Var != null) {
                    b0Var.k = 0;
                    b0Var.m = 0;
                    b0Var.o = 0;
                    b0Var.p = 0;
                    b0Var.q = 0;
                    b0Var.r = 0;
                    b0Var.s = 0;
                    b0Var.t = 0;
                    b0Var.u = 0;
                    b0Var.v = 0;
                }
            }
        }
        this.m = l.f1204a;
        this.n = 0L;
        this.o = 0L;
        this.p = false;
    }
}
