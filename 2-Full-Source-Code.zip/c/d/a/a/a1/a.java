package c.d.a.a.a1;

import c.d.a.a.a1.m;
import c.d.a.a.f0;

/* compiled from: lambda */
/* loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    private final /* synthetic */ m.a f1165b;

    /* renamed from: c, reason: collision with root package name */
    private final /* synthetic */ f0 f1166c;

    public /* synthetic */ a(m.a aVar, f0 f0Var) {
        this.f1165b = aVar;
        this.f1166c = f0Var;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f1165b.a(this.f1166c);
    }
}
