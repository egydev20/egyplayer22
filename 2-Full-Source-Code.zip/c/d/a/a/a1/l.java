package c.d.a.a.a1;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public interface l {

    /* renamed from: a, reason: collision with root package name */
    public static final ByteBuffer f1204a = ByteBuffer.allocateDirect(0).order(ByteOrder.nativeOrder());

    /* loaded from: classes.dex */
    public static final class a {
        public static final a e = new a(-1, -1, -1);

        /* renamed from: a, reason: collision with root package name */
        public final int f1205a;

        /* renamed from: b, reason: collision with root package name */
        public final int f1206b;

        /* renamed from: c, reason: collision with root package name */
        public final int f1207c;

        /* renamed from: d, reason: collision with root package name */
        public final int f1208d;

        public a(int i, int i2, int i3) {
            this.f1205a = i;
            this.f1206b = i2;
            this.f1207c = i3;
            this.f1208d = c.d.a.a.m1.c0.e(i3) ? c.d.a.a.m1.c0.b(i3, i2) : -1;
        }

        public String toString() {
            StringBuilder a2 = c.a.b.a.a.a("AudioFormat[sampleRate=");
            a2.append(this.f1205a);
            a2.append(", channelCount=");
            a2.append(this.f1206b);
            a2.append(", encoding=");
            a2.append(this.f1207c);
            a2.append(']');
            return a2.toString();
        }
    }

    /* loaded from: classes.dex */
    public static final class b extends Exception {
        public b(a aVar) {
            super("Unhandled format: " + aVar);
        }
    }

    a a(a aVar);

    ByteBuffer a();

    void a(ByteBuffer byteBuffer);

    void b();

    boolean c();

    boolean d();

    void f();

    void flush();
}
