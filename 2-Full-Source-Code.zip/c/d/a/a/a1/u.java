package c.d.a.a.a1;

import android.media.AudioTrack;

/* loaded from: classes.dex */
public class u extends Thread {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ AudioTrack f1245b;

    public u(t tVar, AudioTrack audioTrack) {
        this.f1245b = audioTrack;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        this.f1245b.release();
    }
}
