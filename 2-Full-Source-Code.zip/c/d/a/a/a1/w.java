package c.d.a.a.a1;

import c.d.a.a.a1.l;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public final class w extends r {
    public static final int i = Float.floatToIntBits(Float.NaN);

    public static void a(int i2, ByteBuffer byteBuffer) {
        int floatToIntBits = Float.floatToIntBits((float) (i2 * 4.656612875245797E-10d));
        if (floatToIntBits == i) {
            floatToIntBits = Float.floatToIntBits(0.0f);
        }
        byteBuffer.putInt(floatToIntBits);
    }

    @Override // c.d.a.a.a1.l
    public void a(ByteBuffer byteBuffer) {
        c.d.a.a.m1.e.b(c.d.a.a.m1.c0.d(this.f1225b.f1207c));
        boolean z = this.f1225b.f1207c == 805306368;
        int position = byteBuffer.position();
        int limit = byteBuffer.limit();
        int i2 = limit - position;
        if (!z) {
            i2 = (i2 / 3) * 4;
        }
        ByteBuffer a2 = a(i2);
        if (z) {
            while (position < limit) {
                a((byteBuffer.get(position) & 255) | ((byteBuffer.get(position + 1) & 255) << 8) | ((byteBuffer.get(position + 2) & 255) << 16) | ((byteBuffer.get(position + 3) & 255) << 24), a2);
                position += 4;
            }
        } else {
            while (position < limit) {
                a(((byteBuffer.get(position) & 255) << 8) | ((byteBuffer.get(position + 1) & 255) << 16) | ((byteBuffer.get(position + 2) & 255) << 24), a2);
                position += 3;
            }
        }
        byteBuffer.position(byteBuffer.limit());
        a2.flip();
    }

    @Override // c.d.a.a.a1.r
    public l.a b(l.a aVar) {
        if (c.d.a.a.m1.c0.d(aVar.f1207c)) {
            return c.d.a.a.m1.c0.d(aVar.f1207c) ? new l.a(aVar.f1205a, aVar.f1206b, 4) : l.a.e;
        }
        throw new l.b(aVar);
    }
}
