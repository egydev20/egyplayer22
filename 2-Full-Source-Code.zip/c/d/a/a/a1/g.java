package c.d.a.a.a1;

import org.videolan.libvlc.MediaPlayer;
import org.videolan.libvlc.interfaces.IMediaList;

/* loaded from: classes.dex */
public final class g {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f1187a = {1, 2, 3, 6};

    /* renamed from: b, reason: collision with root package name */
    public static final int[] f1188b = {48000, 44100, 32000};

    /* renamed from: c, reason: collision with root package name */
    public static final int[] f1189c = {24000, 22050, 16000};

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f1190d = {2, 1, 2, 3, 3, 4, 4, 5};
    public static final int[] e = {32, 40, 48, 56, 64, 80, 96, b.a.j.AppCompatTheme_tooltipForegroundColor, 128, 160, 192, 224, 256, 320, 384, 448, IMediaList.Event.ItemAdded, 576, 640};
    public static final int[] f = {69, 87, b.a.j.AppCompatTheme_textAppearancePopupMenuHeader, b.a.j.AppCompatTheme_windowFixedWidthMinor, 139, 174, 208, 243, MediaPlayer.Event.ESSelected, 348, 417, 487, 557, 696, 835, 975, 1114, 1253, 1393};

    public static int a(int i, int i2) {
        int i3 = i2 / 2;
        if (i < 0) {
            return -1;
        }
        int[] iArr = f1188b;
        if (i >= iArr.length || i2 < 0) {
            return -1;
        }
        int[] iArr2 = f;
        if (i3 >= iArr2.length) {
            return -1;
        }
        int i4 = iArr[i];
        if (i4 == 44100) {
            return ((i2 % 2) + iArr2[i3]) * 2;
        }
        int i5 = e[i3];
        return i4 == 32000 ? i5 * 6 : i5 * 4;
    }
}
