package c.d.a.a.a1;

/* loaded from: classes.dex */
public final class q {

    /* renamed from: a, reason: collision with root package name */
    public final int f1223a;

    /* renamed from: b, reason: collision with root package name */
    public final float f1224b;

    public q(int i, float f) {
        this.f1223a = i;
        this.f1224b = f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || q.class != obj.getClass()) {
            return false;
        }
        q qVar = (q) obj;
        return this.f1223a == qVar.f1223a && Float.compare(qVar.f1224b, this.f1224b) == 0;
    }

    public int hashCode() {
        return Float.floatToIntBits(this.f1224b) + ((527 + this.f1223a) * 31);
    }
}
