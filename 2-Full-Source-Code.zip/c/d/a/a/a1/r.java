package c.d.a.a.a1;

import c.d.a.a.a1.l;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/* loaded from: classes.dex */
public abstract class r implements l {

    /* renamed from: b, reason: collision with root package name */
    public l.a f1225b;

    /* renamed from: c, reason: collision with root package name */
    public l.a f1226c;

    /* renamed from: d, reason: collision with root package name */
    public l.a f1227d;
    public l.a e;
    public ByteBuffer f;
    public ByteBuffer g;
    public boolean h;

    public r() {
        ByteBuffer byteBuffer = l.f1204a;
        this.f = byteBuffer;
        this.g = byteBuffer;
        l.a aVar = l.a.e;
        this.f1227d = aVar;
        this.e = aVar;
        this.f1225b = aVar;
        this.f1226c = aVar;
    }

    @Override // c.d.a.a.a1.l
    public final l.a a(l.a aVar) {
        this.f1227d = aVar;
        this.e = b(aVar);
        return c() ? this.e : l.a.e;
    }

    @Override // c.d.a.a.a1.l
    public ByteBuffer a() {
        ByteBuffer byteBuffer = this.g;
        this.g = l.f1204a;
        return byteBuffer;
    }

    public final ByteBuffer a(int i) {
        if (this.f.capacity() < i) {
            this.f = ByteBuffer.allocateDirect(i).order(ByteOrder.nativeOrder());
        } else {
            this.f.clear();
        }
        ByteBuffer byteBuffer = this.f;
        this.g = byteBuffer;
        return byteBuffer;
    }

    public abstract l.a b(l.a aVar);

    @Override // c.d.a.a.a1.l
    public final void b() {
        this.h = true;
        g();
    }

    @Override // c.d.a.a.a1.l
    public boolean c() {
        return this.e != l.a.e;
    }

    @Override // c.d.a.a.a1.l
    public boolean d() {
        return this.h && this.g == l.f1204a;
    }

    public void e() {
    }

    @Override // c.d.a.a.a1.l
    public final void f() {
        flush();
        this.f = l.f1204a;
        l.a aVar = l.a.e;
        this.f1227d = aVar;
        this.e = aVar;
        this.f1225b = aVar;
        this.f1226c = aVar;
        h();
    }

    @Override // c.d.a.a.a1.l
    public final void flush() {
        this.g = l.f1204a;
        this.h = false;
        this.f1225b = this.f1227d;
        this.f1226c = this.e;
        e();
    }

    public void g() {
    }

    public void h() {
    }
}
