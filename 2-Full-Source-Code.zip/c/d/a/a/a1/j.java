package c.d.a.a.a1;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.provider.Settings;
import java.util.Arrays;

@TargetApi(21)
/* loaded from: classes.dex */
public final class j {

    /* renamed from: c, reason: collision with root package name */
    public static final j f1200c = new j(new int[]{2}, 8);

    /* renamed from: d, reason: collision with root package name */
    public static final j f1201d = new j(new int[]{2, 5, 6}, 8);

    /* renamed from: a, reason: collision with root package name */
    public final int[] f1202a;

    /* renamed from: b, reason: collision with root package name */
    public final int f1203b;

    public j(int[] iArr, int i) {
        if (iArr != null) {
            int[] copyOf = Arrays.copyOf(iArr, iArr.length);
            this.f1202a = copyOf;
            Arrays.sort(copyOf);
        } else {
            this.f1202a = new int[0];
        }
        this.f1203b = i;
    }

    public static j a(Context context) {
        Intent registerReceiver = context.registerReceiver(null, new IntentFilter("android.media.action.HDMI_AUDIO_PLUG"));
        return ((c.d.a.a.m1.c0.f2426a >= 17 && "Amazon".equals(c.d.a.a.m1.c0.f2428c)) && Settings.Global.getInt(context.getContentResolver(), "external_surround_sound_enabled", 0) == 1) ? f1201d : (registerReceiver == null || registerReceiver.getIntExtra("android.media.extra.AUDIO_PLUG_STATE", 0) == 0) ? f1200c : new j(registerReceiver.getIntArrayExtra("android.media.extra.ENCODINGS"), registerReceiver.getIntExtra("android.media.extra.MAX_CHANNEL_COUNT", 8));
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof j)) {
            return false;
        }
        j jVar = (j) obj;
        return Arrays.equals(this.f1202a, jVar.f1202a) && this.f1203b == jVar.f1203b;
    }

    public int hashCode() {
        return (Arrays.hashCode(this.f1202a) * 31) + this.f1203b;
    }

    public String toString() {
        StringBuilder a2 = c.a.b.a.a.a("AudioCapabilities[maxChannelCount=");
        a2.append(this.f1203b);
        a2.append(", supportedEncodings=");
        a2.append(Arrays.toString(this.f1202a));
        a2.append("]");
        return a2.toString();
    }
}
