package c.d.a.a.a1;

import android.os.Handler;
import c.d.a.a.a1.m;
import c.d.a.a.f0;

/* loaded from: classes.dex */
public interface m {

    /* loaded from: classes.dex */
    public static final class a {

        /* renamed from: a, reason: collision with root package name */
        public final Handler f1209a;

        /* renamed from: b, reason: collision with root package name */
        public final m f1210b;

        public a(Handler handler, m mVar) {
            if (mVar == null) {
                handler = null;
            } else if (handler == null) {
                throw null;
            }
            this.f1209a = handler;
            this.f1210b = mVar;
        }

        public /* synthetic */ void a(int i) {
            m mVar = this.f1210b;
            c.d.a.a.m1.c0.a(mVar);
            mVar.a(i);
        }

        public void a(final int i, final long j, final long j2) {
            Handler handler = this.f1209a;
            if (handler != null) {
                handler.post(new Runnable() { // from class: c.d.a.a.a1.f
                    @Override // java.lang.Runnable
                    public final void run() {
                        m.a.this.b(i, j, j2);
                    }
                });
            }
        }

        public void a(final c.d.a.a.b1.d dVar) {
            dVar.a();
            Handler handler = this.f1209a;
            if (handler != null) {
                handler.post(new Runnable() { // from class: c.d.a.a.a1.e
                    @Override // java.lang.Runnable
                    public final void run() {
                        m.a.this.b(dVar);
                    }
                });
            }
        }

        public /* synthetic */ void a(f0 f0Var) {
            m mVar = this.f1210b;
            c.d.a.a.m1.c0.a(mVar);
            mVar.b(f0Var);
        }

        public void a(final String str, final long j, final long j2) {
            Handler handler = this.f1209a;
            if (handler != null) {
                handler.post(new Runnable() { // from class: c.d.a.a.a1.b
                    @Override // java.lang.Runnable
                    public final void run() {
                        m.a.this.b(str, j, j2);
                    }
                });
            }
        }

        public /* synthetic */ void b(int i, long j, long j2) {
            m mVar = this.f1210b;
            c.d.a.a.m1.c0.a(mVar);
            mVar.a(i, j, j2);
        }

        public /* synthetic */ void b(c.d.a.a.b1.d dVar) {
            dVar.a();
            m mVar = this.f1210b;
            c.d.a.a.m1.c0.a(mVar);
            mVar.a(dVar);
        }

        public /* synthetic */ void b(String str, long j, long j2) {
            m mVar = this.f1210b;
            c.d.a.a.m1.c0.a(mVar);
            mVar.a(str, j, j2);
        }

        public /* synthetic */ void c(c.d.a.a.b1.d dVar) {
            m mVar = this.f1210b;
            c.d.a.a.m1.c0.a(mVar);
            mVar.b(dVar);
        }
    }

    void a(int i);

    void a(int i, long j, long j2);

    void a(c.d.a.a.b1.d dVar);

    void a(String str, long j, long j2);

    void b(c.d.a.a.b1.d dVar);

    void b(f0 f0Var);
}
