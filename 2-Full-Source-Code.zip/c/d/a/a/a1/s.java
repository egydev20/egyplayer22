package c.d.a.a.a1;

import c.d.a.a.a1.l;
import java.nio.ByteBuffer;

/* loaded from: classes.dex */
public final class s extends r {
    public int[] i;
    public int[] j;

    @Override // c.d.a.a.a1.l
    public void a(ByteBuffer byteBuffer) {
        int[] iArr = this.j;
        c.d.a.a.m1.e.b(iArr);
        int[] iArr2 = iArr;
        int position = byteBuffer.position();
        int limit = byteBuffer.limit();
        ByteBuffer a2 = a(((limit - position) / this.f1225b.f1208d) * this.f1226c.f1208d);
        while (position < limit) {
            for (int i : iArr2) {
                a2.putShort(byteBuffer.getShort((i * 2) + position));
            }
            position += this.f1225b.f1208d;
        }
        byteBuffer.position(limit);
        a2.flip();
    }

    @Override // c.d.a.a.a1.r
    public l.a b(l.a aVar) {
        int[] iArr = this.i;
        if (iArr == null) {
            return l.a.e;
        }
        if (aVar.f1207c != 2) {
            throw new l.b(aVar);
        }
        boolean z = aVar.f1206b != iArr.length;
        int i = 0;
        while (i < iArr.length) {
            int i2 = iArr[i];
            if (i2 >= aVar.f1206b) {
                throw new l.b(aVar);
            }
            z |= i2 != i;
            i++;
        }
        return z ? new l.a(aVar.f1205a, iArr.length, 2) : l.a.e;
    }

    @Override // c.d.a.a.a1.r
    public void e() {
        this.j = this.i;
    }

    @Override // c.d.a.a.a1.r
    public void h() {
        this.j = null;
        this.i = null;
    }
}
