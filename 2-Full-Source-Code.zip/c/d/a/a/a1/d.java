package c.d.a.a.a1;

import c.d.a.a.a1.m;

/* compiled from: lambda */
/* loaded from: classes.dex */
public final /* synthetic */ class d implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    private final /* synthetic */ m.a f1180b;

    /* renamed from: c, reason: collision with root package name */
    private final /* synthetic */ int f1181c;

    public /* synthetic */ d(m.a aVar, int i) {
        this.f1180b = aVar;
        this.f1181c = i;
    }

    @Override // java.lang.Runnable
    public final void run() {
        this.f1180b.a(this.f1181c);
    }
}
