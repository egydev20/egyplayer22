package c.d.a.a.a1;

/* loaded from: classes.dex */
public interface k {
    void a(float f);

    void a(int i);
}
