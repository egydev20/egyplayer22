package c.d.a.a;

import android.os.Handler;
import android.os.HandlerThread;
import android.util.Log;
import android.util.Pair;
import c.d.a.a.h1.s;
import c.d.a.a.h1.t;
import c.d.a.a.j1.j;
import c.d.a.a.r0;
import c.d.a.a.x;
import c.d.a.a.x0;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;

/* loaded from: classes.dex */
public final class d0 implements Handler.Callback, s.a, j.a, t.b, x.a, r0.a {
    public boolean A;
    public int B;
    public boolean C;
    public boolean D;
    public int E;
    public e F;
    public long G;
    public int H;
    public boolean I;

    /* renamed from: b, reason: collision with root package name */
    public final t0[] f1314b;

    /* renamed from: c, reason: collision with root package name */
    public final s[] f1315c;

    /* renamed from: d, reason: collision with root package name */
    public final c.d.a.a.j1.j f1316d;
    public final c.d.a.a.j1.k e;
    public final w f;
    public final c.d.a.a.l1.f g;
    public final c.d.a.a.m1.z h;
    public final HandlerThread i;
    public final Handler j;
    public final x0.c k;
    public final x0.b l;
    public final long m;
    public final boolean n;
    public final x o;
    public final ArrayList<c> q;
    public final c.d.a.a.m1.f r;
    public m0 u;
    public c.d.a.a.h1.t v;
    public t0[] w;
    public boolean x;
    public boolean y;
    public boolean z;
    public final k0 s = new k0();
    public v0 t = v0.f2598d;
    public final d p = new d(null);

    /* loaded from: classes.dex */
    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        public final c.d.a.a.h1.t f1317a;

        /* renamed from: b, reason: collision with root package name */
        public final x0 f1318b;

        public b(c.d.a.a.h1.t tVar, x0 x0Var) {
            this.f1317a = tVar;
            this.f1318b = x0Var;
        }
    }

    /* loaded from: classes.dex */
    public static final class c implements Comparable<c> {

        /* renamed from: b, reason: collision with root package name */
        public final r0 f1319b;

        /* renamed from: c, reason: collision with root package name */
        public int f1320c;

        /* renamed from: d, reason: collision with root package name */
        public long f1321d;
        public Object e;

        public c(r0 r0Var) {
            this.f1319b = r0Var;
        }

        @Override // java.lang.Comparable
        public int compareTo(c cVar) {
            c cVar2 = cVar;
            if ((this.e == null) != (cVar2.e == null)) {
                return this.e != null ? -1 : 1;
            }
            if (this.e == null) {
                return 0;
            }
            int i = this.f1320c - cVar2.f1320c;
            return i != 0 ? i : c.d.a.a.m1.c0.b(this.f1321d, cVar2.f1321d);
        }
    }

    /* loaded from: classes.dex */
    public static final class d {

        /* renamed from: a, reason: collision with root package name */
        public m0 f1322a;

        /* renamed from: b, reason: collision with root package name */
        public int f1323b;

        /* renamed from: c, reason: collision with root package name */
        public boolean f1324c;

        /* renamed from: d, reason: collision with root package name */
        public int f1325d;

        public /* synthetic */ d(a aVar) {
        }

        public void a(int i) {
            this.f1323b += i;
        }

        public void b(int i) {
            if (this.f1324c && this.f1325d != 4) {
                c.d.a.a.m1.e.a(i == 4);
            } else {
                this.f1324c = true;
                this.f1325d = i;
            }
        }
    }

    /* loaded from: classes.dex */
    public static final class e {

        /* renamed from: a, reason: collision with root package name */
        public final x0 f1326a;

        /* renamed from: b, reason: collision with root package name */
        public final int f1327b;

        /* renamed from: c, reason: collision with root package name */
        public final long f1328c;

        public e(x0 x0Var, int i, long j) {
            this.f1326a = x0Var;
            this.f1327b = i;
            this.f1328c = j;
        }
    }

    public d0(t0[] t0VarArr, c.d.a.a.j1.j jVar, c.d.a.a.j1.k kVar, w wVar, c.d.a.a.l1.f fVar, boolean z, int i, boolean z2, Handler handler, c.d.a.a.m1.f fVar2) {
        this.f1314b = t0VarArr;
        this.f1316d = jVar;
        this.e = kVar;
        this.f = wVar;
        this.g = fVar;
        this.y = z;
        this.B = i;
        this.C = z2;
        this.j = handler;
        this.r = fVar2;
        this.m = wVar.i;
        this.n = wVar.j;
        this.u = m0.a(-9223372036854775807L, kVar);
        this.f1315c = new s[t0VarArr.length];
        for (int i2 = 0; i2 < t0VarArr.length; i2++) {
            t0VarArr[i2].a(i2);
            this.f1315c[i2] = t0VarArr[i2].n();
        }
        this.o = new x(this, fVar2);
        this.q = new ArrayList<>();
        this.w = new t0[0];
        this.k = new x0.c();
        this.l = new x0.b();
        jVar.f2289a = this;
        jVar.f2290b = fVar;
        HandlerThread handlerThread = new HandlerThread("ExoPlayerImplInternal:Handler", -16);
        this.i = handlerThread;
        handlerThread.start();
        this.h = fVar2.a(this.i.getLooper(), this);
        this.I = true;
    }

    public static f0[] a(c.d.a.a.j1.g gVar) {
        int length = gVar != null ? gVar.length() : 0;
        f0[] f0VarArr = new f0[length];
        for (int i = 0; i < length; i++) {
            f0VarArr[i] = gVar.a(i);
        }
        return f0VarArr;
    }

    public final Pair<Object, Long> a(x0 x0Var, int i, long j) {
        return x0Var.a(this.k, this.l, i, j);
    }

    public final m0 a(t.a aVar, long j, long j2) {
        this.I = true;
        return this.u.a(aVar, j, j2, b());
    }

    public final Object a(Object obj, x0 x0Var, x0 x0Var2) {
        int a2 = x0Var.a(obj);
        int c2 = x0Var.c();
        int i = a2;
        int i2 = -1;
        for (int i3 = 0; i3 < c2 && i2 == -1; i3++) {
            i = x0Var.a(i, this.l, this.k, this.B, this.C);
            if (i == -1) {
                break;
            }
            i2 = x0Var2.a(x0Var.a(i));
        }
        if (i2 == -1) {
            return null;
        }
        return x0Var2.a(i2);
    }

    @Override // c.d.a.a.h1.s.a
    /* renamed from: a, reason: avoid collision after fix types in other method */
    public void a2(c.d.a.a.h1.s sVar) {
        this.h.a(9, sVar).sendToTarget();
    }

    @Override // c.d.a.a.h1.t.b
    public void a(c.d.a.a.h1.t tVar, x0 x0Var) {
        this.h.a(8, new b(tVar, x0Var)).sendToTarget();
    }

    public final void a(r0 r0Var) {
        r0Var.b();
        try {
            r0Var.f2584a.a(r0Var.f2587d, r0Var.e);
        } finally {
            r0Var.a(true);
        }
    }

    public final void a(boolean z, AtomicBoolean atomicBoolean) {
        if (this.D != z) {
            this.D = z;
            if (!z) {
                for (t0 t0Var : this.f1314b) {
                    if (t0Var.getState() == 0) {
                        t0Var.f();
                    }
                }
            }
        }
        if (atomicBoolean != null) {
            synchronized (this) {
                atomicBoolean.set(true);
                notifyAll();
            }
        }
    }

    public final long b() {
        return a(this.u.k);
    }

    public final void b(c.d.a.a.h1.s sVar) {
        i0 i0Var = this.s.i;
        if (i0Var != null && i0Var.f2102a == sVar) {
            this.s.a(this.G);
            g();
        }
    }

    public final void c() {
        if (this.u.e != 1) {
            b(4);
        }
        a(false, false, true, false, true);
    }

    public final void c(c.d.a.a.h1.s sVar) {
        i0 i0Var = this.s.i;
        if (i0Var != null && i0Var.f2102a == sVar) {
            i0 i0Var2 = this.s.i;
            float f = this.o.a().f2497a;
            x0 x0Var = this.u.f2411a;
            i0Var2.f2105d = true;
            i0Var2.l = i0Var2.f2102a.f();
            long a2 = i0Var2.a(i0Var2.a(f, x0Var), i0Var2.f.f2242b, false, new boolean[i0Var2.h.length]);
            long j = i0Var2.n;
            j0 j0Var = i0Var2.f;
            long j2 = j0Var.f2242b;
            i0Var2.n = (j2 - a2) + j;
            if (a2 != j2) {
                j0Var = new j0(j0Var.f2241a, a2, j0Var.f2243c, j0Var.f2244d, j0Var.e, j0Var.f, j0Var.g);
            }
            i0Var2.f = j0Var;
            a(i0Var2.l, i0Var2.m);
            if (i0Var2 == this.s.g) {
                b(i0Var2.f.f2242b);
                a((i0) null);
            }
            g();
        }
    }

    public final void c(boolean z) {
        this.z = false;
        this.y = z;
        if (!z) {
            n();
            p();
            return;
        }
        int i = this.u.e;
        if (i == 3) {
            m();
        } else if (i != 2) {
            return;
        }
        this.h.a(2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x0028, code lost:
    
        return false;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean d() {
        /*
            r6 = this;
            c.d.a.a.k0 r0 = r6.s
            c.d.a.a.i0 r0 = r0.h
            boolean r1 = r0.f2105d
            r2 = 0
            if (r1 != 0) goto La
            return r2
        La:
            r1 = 0
        Lb:
            c.d.a.a.t0[] r3 = r6.f1314b
            int r4 = r3.length
            if (r1 >= r4) goto L29
            r3 = r3[r1]
            c.d.a.a.h1.z[] r4 = r0.f2104c
            r4 = r4[r1]
            c.d.a.a.h1.z r5 = r3.o()
            if (r5 != r4) goto L28
            if (r4 == 0) goto L25
            boolean r3 = r3.j()
            if (r3 != 0) goto L25
            goto L28
        L25:
            int r1 = r1 + 1
            goto Lb
        L28:
            return r2
        L29:
            r0 = 1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.d0.d():boolean");
    }

    public final boolean e() {
        i0 i0Var = this.s.i;
        if (i0Var == null) {
            return false;
        }
        return (!i0Var.f2105d ? 0L : i0Var.f2102a.e()) != Long.MIN_VALUE;
    }

    public final boolean f() {
        i0 i0Var = this.s.g;
        long j = i0Var.f.e;
        return i0Var.f2105d && (j == -9223372036854775807L || this.u.m < j);
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x0060, code lost:
    
        if (r5 == false) goto L30;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void g() {
        /*
            r12 = this;
            boolean r0 = r12.e()
            r1 = 0
            if (r0 != 0) goto L8
            goto L66
        L8:
            c.d.a.a.k0 r0 = r12.s
            c.d.a.a.i0 r0 = r0.i
            boolean r2 = r0.f2105d
            if (r2 != 0) goto L13
            r2 = 0
            goto L19
        L13:
            c.d.a.a.h1.s r0 = r0.f2102a
            long r2 = r0.e()
        L19:
            long r2 = r12.a(r2)
            c.d.a.a.x r0 = r12.o
            c.d.a.a.n0 r0 = r0.a()
            float r0 = r0.f2497a
            c.d.a.a.w r4 = r12.f
            c.d.a.a.l1.o r5 = r4.f2601a
            int r5 = r5.b()
            int r6 = r4.k
            r7 = 1
            if (r5 < r6) goto L34
            r5 = 1
            goto L35
        L34:
            r5 = 0
        L35:
            boolean r6 = r4.m
            if (r6 == 0) goto L3c
            long r8 = r4.f2603c
            goto L3e
        L3c:
            long r8 = r4.f2602b
        L3e:
            r6 = 1065353216(0x3f800000, float:1.0)
            int r6 = (r0 > r6 ? 1 : (r0 == r6 ? 0 : -1))
            if (r6 <= 0) goto L4e
            long r8 = c.d.a.a.m1.c0.a(r8, r0)
            long r10 = r4.f2604d
            long r8 = java.lang.Math.min(r8, r10)
        L4e:
            int r0 = (r2 > r8 ? 1 : (r2 == r8 ? 0 : -1))
            if (r0 >= 0) goto L5a
            boolean r0 = r4.h
            if (r0 != 0) goto L58
            if (r5 != 0) goto L62
        L58:
            r1 = 1
            goto L62
        L5a:
            long r6 = r4.f2604d
            int r0 = (r2 > r6 ? 1 : (r2 == r6 ? 0 : -1))
            if (r0 >= 0) goto L62
            if (r5 == 0) goto L64
        L62:
            r4.l = r1
        L64:
            boolean r1 = r4.l
        L66:
            r12.A = r1
            if (r1 == 0) goto L7f
            c.d.a.a.k0 r0 = r12.s
            c.d.a.a.i0 r0 = r0.i
            long r1 = r12.G
            boolean r3 = r0.e()
            c.d.a.a.m1.e.b(r3)
            long r3 = r0.n
            long r1 = r1 - r3
            c.d.a.a.h1.s r0 = r0.f2102a
            r0.a(r1)
        L7f:
            r12.o()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.d0.g():void");
    }

    public final void h() {
        d dVar = this.p;
        if (this.u != dVar.f1322a || dVar.f1323b > 0 || dVar.f1324c) {
            Handler handler = this.j;
            d dVar2 = this.p;
            handler.obtainMessage(0, dVar2.f1323b, dVar2.f1324c ? dVar2.f1325d : -1, this.u).sendToTarget();
            d dVar3 = this.p;
            dVar3.f1322a = this.u;
            dVar3.f1323b = 0;
            dVar3.f1324c = false;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:82:0x00c9  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x00d1  */
    @Override // android.os.Handler.Callback
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean handleMessage(android.os.Message r9) {
        /*
            Method dump skipped, instructions count: 402
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.d0.handleMessage(android.os.Message):boolean");
    }

    public synchronized void i() {
        if (!this.x && this.i.isAlive()) {
            this.h.a(7);
            boolean z = false;
            while (!this.x) {
                try {
                    wait();
                } catch (InterruptedException unused) {
                    z = true;
                }
            }
            if (z) {
                Thread.currentThread().interrupt();
            }
        }
    }

    public final void j() {
        a(true, true, true, true, false);
        this.f.a(true);
        b(1);
        this.i.quit();
        synchronized (this) {
            this.x = true;
            notifyAll();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:19:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x0049 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void k() {
        /*
            Method dump skipped, instructions count: 279
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.d0.k():void");
    }

    public final void l() {
        for (t0 t0Var : this.f1314b) {
            if (t0Var.o() != null) {
                t0Var.g();
            }
        }
    }

    public final void m() {
        this.z = false;
        x xVar = this.o;
        xVar.g = true;
        xVar.f2609b.c();
        for (t0 t0Var : this.w) {
            t0Var.start();
        }
    }

    public final void n() {
        x xVar = this.o;
        xVar.g = false;
        c.d.a.a.m1.x xVar2 = xVar.f2609b;
        if (xVar2.f2493c) {
            xVar2.a(xVar2.b());
            xVar2.f2493c = false;
        }
        for (t0 t0Var : this.w) {
            if (t0Var.getState() == 2) {
                t0Var.stop();
            }
        }
    }

    public final void o() {
        i0 i0Var = this.s.i;
        boolean z = this.A || (i0Var != null && i0Var.f2102a.b());
        m0 m0Var = this.u;
        if (z != m0Var.g) {
            this.u = new m0(m0Var.f2411a, m0Var.f2412b, m0Var.f2413c, m0Var.f2414d, m0Var.e, m0Var.f, z, m0Var.h, m0Var.i, m0Var.j, m0Var.k, m0Var.l, m0Var.m);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:104:0x0170, code lost:
    
        r10 = r3.H + 1;
        r3.H = r10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:105:0x017b, code lost:
    
        if (r10 >= r3.q.size()) goto L128;
     */
    /* JADX WARN: Code restructure failed: missing block: B:106:0x017d, code lost:
    
        r10 = r3.q.get(r3.H);
     */
    /* JADX WARN: Code restructure failed: missing block: B:110:0x015e, code lost:
    
        r10 = r3.q.get(r3.H);
     */
    /* JADX WARN: Code restructure failed: missing block: B:54:0x015a, code lost:
    
        if (r3.H >= r3.q.size()) goto L78;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x015d, code lost:
    
        r10 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x015e, code lost:
    
        if (r10 == null) goto L129;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x0162, code lost:
    
        if (r10.e == null) goto L126;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x0164, code lost:
    
        r11 = r10.f1320c;
     */
    /* JADX WARN: Code restructure failed: missing block: B:61:0x0166, code lost:
    
        if (r11 < r0) goto L87;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x0168, code lost:
    
        if (r11 != r0) goto L127;
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x016e, code lost:
    
        if (r10.f1321d > r5) goto L130;
     */
    /* JADX WARN: Code restructure failed: missing block: B:67:0x0188, code lost:
    
        if (r10 == null) goto L132;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x018c, code lost:
    
        if (r10.e == null) goto L133;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x0190, code lost:
    
        if (r10.f1320c != r0) goto L134;
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x0192, code lost:
    
        r11 = r10.f1321d;
     */
    /* JADX WARN: Code restructure failed: missing block: B:73:0x0196, code lost:
    
        if (r11 <= r5) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x019a, code lost:
    
        if (r11 > r8) goto L136;
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x019c, code lost:
    
        r3.e(r10.f1319b);
     */
    /* JADX WARN: Code restructure failed: missing block: B:82:0x01bf, code lost:
    
        if (r3.H >= r3.q.size()) goto L137;
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x01cc, code lost:
    
        r10 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:88:0x01c1, code lost:
    
        r10 = r3.q.get(r3.H);
     */
    /* JADX WARN: Code restructure failed: missing block: B:92:0x01ce, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x01cf, code lost:
    
        r1 = r10.f1319b;
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x01d3, code lost:
    
        if (r1.i == false) goto L111;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x01d5, code lost:
    
        r1.b();
        r3.H++;
     */
    /* JADX WARN: Code restructure failed: missing block: B:96:0x01e5, code lost:
    
        throw r0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:97:0x01de, code lost:
    
        r3.q.remove(r3.H);
     */
    /* JADX WARN: Removed duplicated region for block: B:47:0x012b  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:54:0x013f -> B:44:0x0145). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:67:0x017b -> B:57:0x015d). Please report as a decompilation issue!!! */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void p() {
        /*
            Method dump skipped, instructions count: 511
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.d0.p():void");
    }

    public /* synthetic */ void b(r0 r0Var) {
        try {
            a(r0Var);
        } catch (z e2) {
            Log.e("ExoPlayerImplInternal", "Unexpected error delivering message on external thread.", e2);
            throw new RuntimeException(e2);
        }
    }

    public final void d(r0 r0Var) {
        if (r0Var.h == -9223372036854775807L) {
            e(r0Var);
            return;
        }
        if (this.v == null || this.E > 0) {
            this.q.add(new c(r0Var));
            return;
        }
        c cVar = new c(r0Var);
        if (!a(cVar)) {
            r0Var.a(false);
        } else {
            this.q.add(cVar);
            Collections.sort(this.q);
        }
    }

    public final void e(r0 r0Var) {
        if (r0Var.f.getLooper() != this.h.f2495a.getLooper()) {
            this.h.a(16, r0Var).sendToTarget();
            return;
        }
        a(r0Var);
        int i = this.u.e;
        if (i == 3 || i == 2) {
            this.h.a(2);
        }
    }

    public final void f(final r0 r0Var) {
        Handler handler = r0Var.f;
        if (handler.getLooper().getThread().isAlive()) {
            handler.post(new Runnable() { // from class: c.d.a.a.o
                @Override // java.lang.Runnable
                public final void run() {
                    d0.this.b(r0Var);
                }
            });
        } else {
            Log.w("TAG", "Trying to send message on a dead thread.");
            r0Var.a(false);
        }
    }

    public final void a(t0 t0Var) {
        x xVar = this.o;
        if (t0Var == xVar.f2611d) {
            xVar.e = null;
            xVar.f2611d = null;
            xVar.f = true;
        }
        if (t0Var.getState() == 2) {
            t0Var.stop();
        }
        t0Var.e();
    }

    public final void b(long j) {
        i0 i0Var = this.s.g;
        if (i0Var != null) {
            j += i0Var.n;
        }
        this.G = j;
        this.o.f2609b.a(j);
        for (t0 t0Var : this.w) {
            t0Var.a(this.G);
        }
        for (i0 i0Var2 = this.s.g; i0Var2 != null; i0Var2 = i0Var2.k) {
            for (c.d.a.a.j1.g gVar : i0Var2.m.f2293c.a()) {
                if (gVar != null) {
                    gVar.i();
                }
            }
        }
    }

    public final void d(boolean z) {
        this.C = z;
        k0 k0Var = this.s;
        k0Var.f = z;
        if (!k0Var.b()) {
            b(true);
        }
        a(false);
    }

    /* JADX WARN: Code restructure failed: missing block: B:120:0x037f, code lost:
    
        if ((r9 <= 0 || r4 >= r9 || (!r0.h && r0.f2601a.b() >= r0.k)) != false) goto L245;
     */
    /* JADX WARN: Code restructure failed: missing block: B:173:0x00b0, code lost:
    
        if (r9 != (-9223372036854775807L)) goto L45;
     */
    /* JADX WARN: Removed duplicated region for block: B:177:0x00db  */
    /* JADX WARN: Removed duplicated region for block: B:182:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:184:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x03b9  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x03ca  */
    /* JADX WARN: Removed duplicated region for block: B:85:0x03e2 A[ADDED_TO_REGION] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a() {
        /*
            Method dump skipped, instructions count: 1021
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.d0.a():void");
    }

    public final void b(boolean z) {
        t.a aVar = this.s.g.f.f2241a;
        long a2 = a(aVar, this.u.m, true);
        if (a2 != this.u.m) {
            this.u = a(aVar, a2, this.u.f2414d);
            if (z) {
                this.p.b(4);
            }
        }
    }

    public synchronized void c(r0 r0Var) {
        if (!this.x && this.i.isAlive()) {
            this.h.a(15, r0Var).sendToTarget();
            return;
        }
        Log.w("ExoPlayerImplInternal", "Ignoring messages sent after release.");
        r0Var.a(false);
    }

    public final void b(int i) {
        m0 m0Var = this.u;
        if (m0Var.e != i) {
            this.u = new m0(m0Var.f2411a, m0Var.f2412b, m0Var.f2413c, m0Var.f2414d, i, m0Var.f, m0Var.g, m0Var.h, m0Var.i, m0Var.j, m0Var.k, m0Var.l, m0Var.m);
        }
    }

    public final void a(boolean[] zArr, int i) {
        int i2;
        c.d.a.a.m1.p pVar;
        this.w = new t0[i];
        c.d.a.a.j1.k kVar = this.s.g.m;
        for (int i3 = 0; i3 < this.f1314b.length; i3++) {
            if (!kVar.a(i3)) {
                this.f1314b[i3].f();
            }
        }
        int i4 = 0;
        int i5 = 0;
        while (i4 < this.f1314b.length) {
            if (kVar.a(i4)) {
                boolean z = zArr[i4];
                int i6 = i5 + 1;
                i0 i0Var = this.s.g;
                t0 t0Var = this.f1314b[i4];
                this.w[i5] = t0Var;
                if (t0Var.getState() == 0) {
                    c.d.a.a.j1.k kVar2 = i0Var.m;
                    u0 u0Var = kVar2.f2292b[i4];
                    f0[] a2 = a(kVar2.f2293c.f2280b[i4]);
                    boolean z2 = this.y && this.u.e == 3;
                    boolean z3 = !z && z2;
                    i2 = i4;
                    t0Var.a(u0Var, a2, i0Var.f2104c[i4], this.G, z3, i0Var.n);
                    x xVar = this.o;
                    if (xVar != null) {
                        c.d.a.a.m1.p l = t0Var.l();
                        if (l != null && l != (pVar = xVar.e)) {
                            if (pVar == null) {
                                xVar.e = l;
                                xVar.f2611d = t0Var;
                                l.a(xVar.f2609b.f);
                            } else {
                                throw new z(2, new IllegalStateException("Multiple renderer media clocks enabled."));
                            }
                        }
                        if (z2) {
                            t0Var.start();
                        }
                    } else {
                        throw null;
                    }
                } else {
                    i2 = i4;
                }
                i5 = i6;
            } else {
                i2 = i4;
            }
            i4 = i2 + 1;
        }
    }

    public final long a(long j) {
        i0 i0Var = this.s.i;
        if (i0Var == null) {
            return 0L;
        }
        return Math.max(0L, j - (this.G - i0Var.n));
    }

    public final void a(boolean z) {
        i0 i0Var;
        boolean z2;
        d0 d0Var = this;
        i0 i0Var2 = d0Var.s.i;
        t.a aVar = i0Var2 == null ? d0Var.u.f2412b : i0Var2.f.f2241a;
        boolean z3 = !d0Var.u.j.equals(aVar);
        if (z3) {
            m0 m0Var = d0Var.u;
            z2 = z3;
            i0Var = i0Var2;
            d0Var = this;
            d0Var.u = new m0(m0Var.f2411a, m0Var.f2412b, m0Var.f2413c, m0Var.f2414d, m0Var.e, m0Var.f, m0Var.g, m0Var.h, m0Var.i, aVar, m0Var.k, m0Var.l, m0Var.m);
        } else {
            i0Var = i0Var2;
            z2 = z3;
        }
        m0 m0Var2 = d0Var.u;
        m0Var2.k = i0Var == null ? m0Var2.m : i0Var.c();
        d0Var.u.l = b();
        if ((z2 || z) && i0Var != null) {
            i0 i0Var3 = i0Var;
            if (i0Var3.f2105d) {
                d0Var.a(i0Var3.l, i0Var3.m);
            }
        }
    }

    public final void a(n0 n0Var, boolean z) {
        this.j.obtainMessage(1, z ? 1 : 0, 0, n0Var).sendToTarget();
        float f = n0Var.f2497a;
        for (i0 i0Var = this.s.g; i0Var != null; i0Var = i0Var.k) {
            for (c.d.a.a.j1.g gVar : i0Var.m.f2293c.a()) {
                if (gVar != null) {
                    gVar.a(f);
                }
            }
        }
        for (t0 t0Var : this.f1314b) {
            if (t0Var != null) {
                t0Var.a(n0Var.f2497a);
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:78:0x0258, code lost:
    
        r12 = true;
     */
    /* JADX WARN: Removed duplicated region for block: B:106:0x026b A[LOOP:3: B:106:0x026b->B:113:0x026b, LOOP_START, PHI: r0
      0x026b: PHI (r0v21 c.d.a.a.i0) = (r0v15 c.d.a.a.i0), (r0v22 c.d.a.a.i0) binds: [B:105:0x0269, B:113:0x026b] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:118:0x028b  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x0294  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x0296  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a(c.d.a.a.d0.b r36) {
        /*
            Method dump skipped, instructions count: 681
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.d0.a(c.d.a.a.d0$b):void");
    }

    @Override // c.d.a.a.h1.a0.a
    public void a(c.d.a.a.h1.s sVar) {
        this.h.a(10, sVar).sendToTarget();
    }

    public final void a(c.d.a.a.h1.t tVar, boolean z, boolean z2) {
        this.E++;
        a(false, true, z, z2, true);
        this.f.a(false);
        this.v = tVar;
        b(2);
        tVar.a(this, this.g.b());
        this.h.a(2);
    }

    /* JADX WARN: Removed duplicated region for block: B:36:0x009f  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00c8  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:49:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:52:0x00f4  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x0102  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:61:0x0114  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0117  */
    /* JADX WARN: Removed duplicated region for block: B:72:0x010d  */
    /* JADX WARN: Removed duplicated region for block: B:73:0x0104  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x00f7  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x00eb  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x00e1  */
    /* JADX WARN: Removed duplicated region for block: B:77:0x00d3  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a(boolean r24, boolean r25, boolean r26, boolean r27, boolean r28) {
        /*
            Method dump skipped, instructions count: 310
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.d0.a(boolean, boolean, boolean, boolean, boolean):void");
    }

    public final boolean a(c cVar) {
        Object obj = cVar.e;
        if (obj == null) {
            r0 r0Var = cVar.f1319b;
            x0 x0Var = r0Var.f2586c;
            int i = r0Var.g;
            long a2 = t.a(r0Var.h);
            x0 x0Var2 = this.u.f2411a;
            Pair<Object, Long> pair = null;
            if (!x0Var2.e()) {
                if (x0Var.e()) {
                    x0Var = x0Var2;
                }
                try {
                    Pair<Object, Long> a3 = x0Var.a(this.k, this.l, i, a2);
                    if (x0Var2 == x0Var || x0Var2.a(a3.first) != -1) {
                        pair = a3;
                    }
                } catch (IndexOutOfBoundsException unused) {
                }
            }
            if (pair == null) {
                return false;
            }
            int a4 = this.u.f2411a.a(pair.first);
            long longValue = ((Long) pair.second).longValue();
            Object obj2 = pair.first;
            cVar.f1320c = a4;
            cVar.f1321d = longValue;
            cVar.e = obj2;
            return true;
        }
        int a5 = this.u.f2411a.a(obj);
        if (a5 == -1) {
            return false;
        }
        cVar.f1320c = a5;
        return true;
    }

    public final Pair<Object, Long> a(e eVar, boolean z) {
        Pair<Object, Long> a2;
        Object a3;
        x0 x0Var = this.u.f2411a;
        x0 x0Var2 = eVar.f1326a;
        if (x0Var.e()) {
            return null;
        }
        if (x0Var2.e()) {
            x0Var2 = x0Var;
        }
        try {
            a2 = x0Var2.a(this.k, this.l, eVar.f1327b, eVar.f1328c);
        } catch (IndexOutOfBoundsException unused) {
        }
        if (x0Var == x0Var2 || x0Var.a(a2.first) != -1) {
            return a2;
        }
        if (z && (a3 = a(a2.first, x0Var2, x0Var)) != null) {
            return a(x0Var, x0Var.a(x0Var.a(a3), this.l, true).f2614b, -9223372036854775807L);
        }
        return null;
    }

    public final void a(long j, long j2) {
        this.h.f2495a.removeMessages(2);
        this.h.f2495a.sendEmptyMessageAtTime(2, j + j2);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:20:0x00e8  */
    /* JADX WARN: Removed duplicated region for block: B:23:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Type inference failed for: r8v1 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a(c.d.a.a.d0.e r17) {
        /*
            Method dump skipped, instructions count: 261
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.d.a.a.d0.a(c.d.a.a.d0$e):void");
    }

    public final long a(t.a aVar, long j, boolean z) {
        n();
        this.z = false;
        m0 m0Var = this.u;
        if (m0Var.e != 1 && !m0Var.f2411a.e()) {
            b(2);
        }
        i0 i0Var = this.s.g;
        i0 i0Var2 = i0Var;
        while (true) {
            if (i0Var2 == null) {
                break;
            }
            if (aVar.equals(i0Var2.f.f2241a) && i0Var2.f2105d) {
                this.s.a(i0Var2);
                break;
            }
            i0Var2 = this.s.a();
        }
        if (z || i0Var != i0Var2 || (i0Var2 != null && i0Var2.n + j < 0)) {
            for (t0 t0Var : this.w) {
                a(t0Var);
            }
            this.w = new t0[0];
            i0Var = null;
            if (i0Var2 != null) {
                i0Var2.n = 0L;
            }
        }
        if (i0Var2 != null) {
            a(i0Var);
            if (i0Var2.e) {
                long c2 = i0Var2.f2102a.c(j);
                i0Var2.f2102a.a(c2 - this.m, this.n);
                j = c2;
            }
            b(j);
            g();
        } else {
            this.s.a(true);
            this.u = this.u.a(c.d.a.a.h1.d0.e, this.e);
            b(j);
        }
        a(false);
        this.h.a(2);
        return j;
    }

    public final void a(n0 n0Var) {
        this.o.a(n0Var);
        this.h.f2495a.obtainMessage(17, 1, 0, this.o.a()).sendToTarget();
    }

    public final void a(int i) {
        this.B = i;
        k0 k0Var = this.s;
        k0Var.e = i;
        if (!k0Var.b()) {
            b(true);
        }
        a(false);
    }

    public final void a(boolean z, boolean z2, boolean z3) {
        a(z || !this.D, true, z2, z2, z2);
        this.p.a(this.E + (z3 ? 1 : 0));
        this.E = 0;
        this.f.a(true);
        b(1);
    }

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Failed to find 'out' block for switch in B:20:0x003c. Please report as an issue. */
    public final void a(c.d.a.a.h1.d0 d0Var, c.d.a.a.j1.k kVar) {
        boolean z;
        w wVar = this.f;
        t0[] t0VarArr = this.f1314b;
        c.d.a.a.j1.h hVar = kVar.f2293c;
        if (wVar == null) {
            throw null;
        }
        int i = 0;
        while (true) {
            if (i >= t0VarArr.length) {
                z = false;
                break;
            } else {
                if (t0VarArr[i].m() == 2 && hVar.f2280b[i] != null) {
                    z = true;
                    break;
                }
                i++;
            }
        }
        wVar.m = z;
        int i2 = wVar.g;
        if (i2 == -1) {
            i2 = 0;
            for (int i3 = 0; i3 < t0VarArr.length; i3++) {
                if (hVar.f2280b[i3] != null) {
                    int i4 = 131072;
                    switch (t0VarArr[i3].m()) {
                        case 0:
                            i4 = 36438016;
                            i2 += i4;
                            break;
                        case 1:
                            i4 = 3538944;
                            i2 += i4;
                            break;
                        case 2:
                            i4 = 32768000;
                            i2 += i4;
                            break;
                        case 3:
                        case 4:
                        case 5:
                            i2 += i4;
                            break;
                        case 6:
                            i4 = 0;
                            i2 += i4;
                            break;
                        default:
                            throw new IllegalArgumentException();
                    }
                }
            }
        }
        wVar.k = i2;
        wVar.f2601a.a(i2);
    }

    public final void a(i0 i0Var) {
        i0 i0Var2 = this.s.g;
        if (i0Var2 == null || i0Var == i0Var2) {
            return;
        }
        boolean[] zArr = new boolean[this.f1314b.length];
        int i = 0;
        int i2 = 0;
        while (true) {
            t0[] t0VarArr = this.f1314b;
            if (i < t0VarArr.length) {
                t0 t0Var = t0VarArr[i];
                zArr[i] = t0Var.getState() != 0;
                if (i0Var2.m.a(i)) {
                    i2++;
                }
                if (zArr[i] && (!i0Var2.m.a(i) || (t0Var.k() && t0Var.o() == i0Var.f2104c[i]))) {
                    a(t0Var);
                }
                i++;
            } else {
                this.u = this.u.a(i0Var2.l, i0Var2.m);
                a(zArr, i2);
                return;
            }
        }
    }
}
