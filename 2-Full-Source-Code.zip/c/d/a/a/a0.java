package c.d.a.a;

/* loaded from: classes.dex */
public interface a0 extends q0 {
}
