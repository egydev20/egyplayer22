package c.d.a.a;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import c.d.a.a.q0;
import c.d.a.a.r;

/* loaded from: classes.dex */
public class b0 extends Handler {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ c0 f1252a;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b0(c0 c0Var, Looper looper) {
        super(looper);
        this.f1252a = c0Var;
    }

    @Override // android.os.Handler
    public void handleMessage(Message message) {
        c0 c0Var = this.f1252a;
        if (c0Var != null) {
            int i = message.what;
            if (i != 0) {
                if (i != 1) {
                    throw new IllegalStateException();
                }
                final n0 n0Var = (n0) message.obj;
                if (message.arg1 != 0) {
                    c0Var.r--;
                }
                if (c0Var.r != 0 || c0Var.s.equals(n0Var)) {
                    return;
                }
                c0Var.s = n0Var;
                c0Var.a(new r.b() { // from class: c.d.a.a.m
                    @Override // c.d.a.a.r.b
                    public final void a(q0.a aVar) {
                        aVar.a(n0.this);
                    }
                });
                return;
            }
            m0 m0Var = (m0) message.obj;
            int i2 = message.arg1;
            boolean z = message.arg2 != -1;
            int i3 = message.arg2;
            int i4 = c0Var.o - i2;
            c0Var.o = i4;
            if (i4 == 0) {
                m0 a2 = m0Var.f2413c == -9223372036854775807L ? m0Var.a(m0Var.f2412b, 0L, m0Var.f2414d, m0Var.l) : m0Var;
                if (!c0Var.t.f2411a.e() && a2.f2411a.e()) {
                    c0Var.v = 0;
                    c0Var.u = 0;
                    c0Var.w = 0L;
                }
                int i5 = c0Var.p ? 0 : 2;
                boolean z2 = c0Var.q;
                c0Var.p = false;
                c0Var.q = false;
                c0Var.a(a2, z, i3, i5, z2);
                return;
            }
            return;
        }
        throw null;
    }
}
