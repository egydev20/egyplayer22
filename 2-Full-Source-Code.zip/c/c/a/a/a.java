package c.c.a.a;

/* loaded from: classes.dex */
public final class a {
    public static final int marked_item_animation = 2130771994;
    public static final int unmarked_item_animation = 2130771995;
}
