package c.c.a.a;

/* loaded from: classes.dex */
public final class e {
    public static final int ic_directory_parent = 2131558400;
    public static final int ic_type_file = 2131558402;
    public static final int ic_type_folder = 2131558403;
}
