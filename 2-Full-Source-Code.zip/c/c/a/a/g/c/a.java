package c.c.a.a.g.c;

import android.content.Context;
import android.view.View;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import c.c.a.a.c;
import com.github.angads25.filepicker.widget.MaterialCheckbox;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class a extends BaseAdapter {

    /* renamed from: b, reason: collision with root package name */
    public ArrayList<c.c.a.a.h.b> f1138b;

    /* renamed from: c, reason: collision with root package name */
    public Context f1139c;

    /* renamed from: d, reason: collision with root package name */
    public c.c.a.a.h.a f1140d;
    public c.c.a.a.g.b e;

    /* renamed from: c.c.a.a.g.c.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class C0032a implements c.c.a.a.k.a {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ c.c.a.a.h.b f1141a;

        public C0032a(c.c.a.a.h.b bVar) {
            this.f1141a = bVar;
        }
    }

    /* loaded from: classes.dex */
    public class b {

        /* renamed from: a, reason: collision with root package name */
        public ImageView f1143a;

        /* renamed from: b, reason: collision with root package name */
        public TextView f1144b;

        /* renamed from: c, reason: collision with root package name */
        public TextView f1145c;

        /* renamed from: d, reason: collision with root package name */
        public MaterialCheckbox f1146d;

        public b(a aVar, View view) {
            this.f1144b = (TextView) view.findViewById(c.fname);
            this.f1145c = (TextView) view.findViewById(c.ftype);
            this.f1143a = (ImageView) view.findViewById(c.image_type);
            this.f1146d = (MaterialCheckbox) view.findViewById(c.file_mark);
        }
    }

    public a(ArrayList<c.c.a.a.h.b> arrayList, Context context, c.c.a.a.h.a aVar) {
        this.f1138b = arrayList;
        this.f1139c = context;
        this.f1140d = aVar;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        return this.f1138b.size();
    }

    @Override // android.widget.Adapter
    public Object getItem(int i) {
        return this.f1138b.get(i);
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x007d, code lost:
    
        if (r11.f1140d.f1148b == 0) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x00bd, code lost:
    
        r14.f1146d.setVisibility(0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00b7, code lost:
    
        r14.f1146d.setVisibility(4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:40:0x00b5, code lost:
    
        if (r11.f1140d.f1148b == 1) goto L25;
     */
    @Override // android.widget.Adapter
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.view.View getView(int r12, android.view.View r13, android.view.ViewGroup r14) {
        /*
            Method dump skipped, instructions count: 370
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: c.c.a.a.g.c.a.getView(int, android.view.View, android.view.ViewGroup):android.view.View");
    }
}
