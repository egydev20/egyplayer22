package c.c.a.a.g;

/* loaded from: classes.dex */
public interface a {
}
