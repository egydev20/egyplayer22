package c.c.a.a.k;

/* loaded from: classes.dex */
public interface a {
}
