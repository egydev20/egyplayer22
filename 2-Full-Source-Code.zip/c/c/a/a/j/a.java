package c.c.a.a.j;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import b.a.j;
import c.b.f1;
import c.b.p0;
import c.b.q0;
import c.c.a.a.d;
import c.c.a.a.f;
import com.github.angads25.filepicker.widget.MaterialCheckbox;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

/* loaded from: classes.dex */
public class a extends Dialog implements AdapterView.OnItemClickListener {

    /* renamed from: b, reason: collision with root package name */
    public Context f1157b;

    /* renamed from: c, reason: collision with root package name */
    public ListView f1158c;

    /* renamed from: d, reason: collision with root package name */
    public TextView f1159d;
    public TextView e;
    public TextView f;
    public c.c.a.a.h.a g;
    public c.c.a.a.g.a h;
    public ArrayList<c.c.a.a.h.b> i;
    public c.c.a.a.i.a j;
    public c.c.a.a.g.c.a k;
    public Button l;
    public String m;
    public String n;
    public String o;

    /* renamed from: c.c.a.a.j.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class ViewOnClickListenerC0033a implements View.OnClickListener {
        public ViewOnClickListenerC0033a() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            final String str;
            int lastIndexOf;
            Set<String> keySet = c.c.a.a.h.c.f1154a.keySet();
            int size = keySet.size();
            String[] strArr = new String[size];
            Iterator<String> it = keySet.iterator();
            int i = 0;
            while (it.hasNext()) {
                strArr[i] = it.next();
                i++;
            }
            c.c.a.a.g.a aVar = a.this.h;
            if (aVar != null) {
                q0.e eVar = (q0.e) aVar;
                String str2 = null;
                if (size > 0) {
                    final String str3 = strArr[0];
                    String b2 = p0.b(str3);
                    if (b2 == null) {
                        str = null;
                    } else {
                        int lastIndexOf2 = b2.lastIndexOf(".");
                        if (lastIndexOf2 >= 0) {
                            b2 = b2.substring(0, lastIndexOf2);
                        }
                        str = b2;
                    }
                    String b3 = p0.b(str3);
                    if (b3 != null && (lastIndexOf = b3.lastIndexOf(".")) >= 0) {
                        str2 = b3.substring(lastIndexOf);
                    }
                    final String str4 = str2;
                    final f1 f1Var = q0.this.f1097c;
                    final int i2 = eVar.f1103a;
                    Handler handler = f1Var.k;
                    if (handler != null) {
                        handler.post(new Runnable() { // from class: c.b.d0
                            @Override // java.lang.Runnable
                            public final void run() {
                                f1.this.a(str3, i2, str, str4);
                            }
                        });
                    }
                }
            }
            a.this.dismiss();
        }
    }

    /* loaded from: classes.dex */
    public class b implements View.OnClickListener {
        public b() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            a.this.dismiss();
        }
    }

    /* loaded from: classes.dex */
    public class c implements c.c.a.a.g.b {
        public c() {
        }
    }

    public a(Context context, c.c.a.a.h.a aVar) {
        super(context);
        this.m = null;
        this.n = null;
        this.o = null;
        this.f1157b = context;
        this.g = aVar;
        this.j = new c.c.a.a.i.a(aVar);
        this.i = new ArrayList<>();
    }

    public final void a() {
        TextView textView = this.f;
        if (textView == null || this.f1159d == null) {
            return;
        }
        String str = this.m;
        int visibility = textView.getVisibility();
        if (str == null) {
            if (visibility == 0) {
                this.f.setVisibility(4);
            }
            if (this.f1159d.getVisibility() == 4) {
                this.f1159d.setVisibility(0);
                return;
            }
            return;
        }
        if (visibility == 4) {
            this.f.setVisibility(0);
        }
        this.f.setText(this.m);
        if (this.f1159d.getVisibility() == 0) {
            this.f1159d.setVisibility(4);
        }
    }

    @Override // android.app.Dialog, android.content.DialogInterface
    public void dismiss() {
        c.c.a.a.h.c.a();
        this.i.clear();
        super.dismiss();
    }

    @Override // android.app.Dialog
    public void onBackPressed() {
        String charSequence = this.f1159d.getText().toString();
        if (this.i.size() <= 0) {
            super.onBackPressed();
            return;
        }
        File file = new File(this.i.get(0).f1152c);
        if (charSequence.equals(this.g.f1149c.getName())) {
            super.onBackPressed();
        } else {
            this.f1159d.setText(file.getName());
            this.e.setText(file.getAbsolutePath());
            this.i.clear();
            if (!file.getName().equals(this.g.f1149c.getName())) {
                c.c.a.a.h.b bVar = new c.c.a.a.h.b();
                bVar.f1151b = this.f1157b.getString(f.label_parent_dir);
                bVar.f1153d = true;
                bVar.f1152c = file.getParentFile().getAbsolutePath();
                bVar.f = file.lastModified();
                this.i.add(bVar);
            }
            this.i = a.a.a.a.a.a(this.i, file, this.j);
            this.k.notifyDataSetChanged();
        }
        a();
    }

    @Override // android.app.Dialog
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(d.dialog_main);
        this.f1158c = (ListView) findViewById(c.c.a.a.c.fileList);
        this.l = (Button) findViewById(c.c.a.a.c.select);
        if (c.c.a.a.h.c.b() == 0) {
            this.l.setEnabled(false);
            int color = Build.VERSION.SDK_INT >= 23 ? this.f1157b.getResources().getColor(c.c.a.a.b.colorAccent, this.f1157b.getTheme()) : this.f1157b.getResources().getColor(c.c.a.a.b.colorAccent);
            this.l.setTextColor(Color.argb(128, Color.red(color), Color.green(color), Color.blue(color)));
        }
        this.f1159d = (TextView) findViewById(c.c.a.a.c.dname);
        this.f = (TextView) findViewById(c.c.a.a.c.title);
        this.e = (TextView) findViewById(c.c.a.a.c.dir_path);
        Button button = (Button) findViewById(c.c.a.a.c.cancel);
        String str = this.o;
        if (str != null) {
            button.setText(str);
        }
        this.l.setOnClickListener(new ViewOnClickListenerC0033a());
        button.setOnClickListener(new b());
        c.c.a.a.g.c.a aVar = new c.c.a.a.g.c.a(this.i, this.f1157b, this.g);
        this.k = aVar;
        aVar.e = new c();
        this.f1158c.setAdapter((ListAdapter) this.k);
        a();
    }

    @Override // android.widget.AdapterView.OnItemClickListener
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
        if (this.i.size() > i) {
            c.c.a.a.h.b bVar = this.i.get(i);
            if (!bVar.f1153d) {
                ((MaterialCheckbox) view.findViewById(c.c.a.a.c.file_mark)).performClick();
                return;
            }
            if (!new File(bVar.f1152c).canRead()) {
                Toast.makeText(this.f1157b, f.error_dir_access, 0).show();
                return;
            }
            File file = new File(bVar.f1152c);
            this.f1159d.setText(file.getName());
            a();
            this.e.setText(file.getAbsolutePath());
            this.i.clear();
            if (!file.getName().equals(this.g.f1149c.getName())) {
                c.c.a.a.h.b bVar2 = new c.c.a.a.h.b();
                bVar2.f1151b = this.f1157b.getString(f.label_parent_dir);
                bVar2.f1153d = true;
                bVar2.f1152c = file.getParentFile().getAbsolutePath();
                bVar2.f = file.lastModified();
                this.i.add(bVar2);
            }
            this.i = a.a.a.a.a.a(this.i, file, this.j);
            this.k.notifyDataSetChanged();
        }
    }

    @Override // android.app.Dialog
    public void onStart() {
        File file;
        super.onStart();
        String str = this.n;
        if (str == null) {
            str = this.f1157b.getResources().getString(f.choose_button_label);
        }
        this.n = str;
        this.l.setText(str);
        if (a.a.a.a.a.a(this.f1157b)) {
            this.i.clear();
            if (this.g.e.isDirectory()) {
                String absolutePath = this.g.e.getAbsolutePath();
                String absolutePath2 = this.g.f1149c.getAbsolutePath();
                if (!absolutePath.equals(absolutePath2) && absolutePath.contains(absolutePath2)) {
                    file = new File(this.g.e.getAbsolutePath());
                    c.c.a.a.h.b bVar = new c.c.a.a.h.b();
                    bVar.f1151b = this.f1157b.getString(f.label_parent_dir);
                    bVar.f1153d = true;
                    bVar.f1152c = file.getParentFile().getAbsolutePath();
                    bVar.f = file.lastModified();
                    this.i.add(bVar);
                    this.f1159d.setText(file.getName());
                    this.e.setText(file.getAbsolutePath());
                    a();
                    this.i = a.a.a.a.a.a(this.i, file, this.j);
                    this.k.notifyDataSetChanged();
                    this.f1158c.setOnItemClickListener(this);
                }
            }
            file = (this.g.f1149c.exists() && this.g.f1149c.isDirectory()) ? new File(this.g.f1149c.getAbsolutePath()) : new File(this.g.f1150d.getAbsolutePath());
            this.f1159d.setText(file.getName());
            this.e.setText(file.getAbsolutePath());
            a();
            this.i = a.a.a.a.a.a(this.i, file, this.j);
            this.k.notifyDataSetChanged();
            this.f1158c.setOnItemClickListener(this);
        }
    }

    @Override // android.app.Dialog
    public void setTitle(CharSequence charSequence) {
        this.m = charSequence != null ? charSequence.toString() : null;
        a();
    }

    @Override // android.app.Dialog
    public void show() {
        if (!a.a.a.a.a.a(this.f1157b)) {
            if (Build.VERSION.SDK_INT >= 23) {
                ((Activity) this.f1157b).requestPermissions(new String[]{"android.permission.READ_EXTERNAL_STORAGE"}, j.AppCompatTheme_tooltipForegroundColor);
                return;
            }
            return;
        }
        super.show();
        String str = this.n;
        if (str == null) {
            str = this.f1157b.getResources().getString(f.choose_button_label);
        }
        this.n = str;
        this.l.setText(str);
        int b2 = c.c.a.a.h.c.b();
        if (b2 == 0) {
            this.l.setText(this.n);
            return;
        }
        this.l.setText(this.n + " (" + b2 + ") ");
    }
}
