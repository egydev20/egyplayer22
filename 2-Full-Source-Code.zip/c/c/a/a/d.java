package c.c.a.a;

/* loaded from: classes.dex */
public final class d {
    public static final int dialog_file_list = 2131492894;
    public static final int dialog_file_list_item = 2131492895;
    public static final int dialog_footer = 2131492896;
    public static final int dialog_header = 2131492897;
    public static final int dialog_main = 2131492898;
}
