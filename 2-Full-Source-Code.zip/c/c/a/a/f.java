package c.c.a.a;

/* loaded from: classes.dex */
public final class f {
    public static final int cancel_button_label = 2131689502;
    public static final int choose_button_label = 2131689503;
    public static final int default_dir = 2131689512;
    public static final int error_dir_access = 2131689513;
    public static final int label_parent_dir = 2131689554;
    public static final int label_parent_directory = 2131689555;
    public static final int last_edit = 2131689556;
}
