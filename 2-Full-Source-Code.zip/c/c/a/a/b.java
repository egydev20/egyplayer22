package c.c.a.a;

/* loaded from: classes.dex */
public final class b {
    public static final int colorAccent = 2131034153;
    public static final int colorHeader = 2131034154;
    public static final int colorPrimary = 2131034155;
    public static final int colorPrimaryDark = 2131034156;
    public static final int textColorPrimary = 2131034263;
    public static final int textColorSecondary = 2131034264;
}
