package c.c.a.a.i;

import java.io.File;
import java.io.FileFilter;
import java.util.Locale;

/* loaded from: classes.dex */
public class a implements FileFilter {

    /* renamed from: a, reason: collision with root package name */
    public final String[] f1155a;

    /* renamed from: b, reason: collision with root package name */
    public c.c.a.a.h.a f1156b;

    public a(c.c.a.a.h.a aVar) {
        String[] strArr = aVar.f;
        if (strArr != null) {
            this.f1155a = strArr;
        } else {
            this.f1155a = new String[]{""};
        }
        this.f1156b = aVar;
    }

    @Override // java.io.FileFilter
    public boolean accept(File file) {
        if (file.isDirectory() && file.canRead()) {
            return true;
        }
        if (this.f1156b.f1148b == 1) {
            return false;
        }
        String lowerCase = file.getName().toLowerCase(Locale.getDefault());
        for (String str : this.f1155a) {
            if (lowerCase.endsWith(str)) {
                return true;
            }
        }
        return false;
    }
}
