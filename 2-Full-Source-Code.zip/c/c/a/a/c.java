package c.c.a.a;

/* loaded from: classes.dex */
public final class c {
    public static final int cancel = 2131296353;
    public static final int dir_path = 2131296396;
    public static final int dir_select = 2131296397;
    public static final int dname = 2131296399;
    public static final int fileList = 2131296436;
    public static final int file_dir_select = 2131296437;
    public static final int file_mark = 2131296438;
    public static final int file_select = 2131296439;
    public static final int fname = 2131296446;
    public static final int footer = 2131296447;
    public static final int ftype = 2131296450;
    public static final int header = 2131296478;
    public static final int imageView = 2131296486;
    public static final int image_type = 2131296487;
    public static final int linearLayout = 2131296532;
    public static final int multi_mode = 2131296558;
    public static final int select = 2131296612;
    public static final int single_mode = 2131296621;
    public static final int title = 2131296655;
}
