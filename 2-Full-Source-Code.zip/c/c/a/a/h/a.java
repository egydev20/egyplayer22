package c.c.a.a.h;

import java.io.File;

/* loaded from: classes.dex */
public class a {

    /* renamed from: a, reason: collision with root package name */
    public int f1147a = 0;

    /* renamed from: b, reason: collision with root package name */
    public int f1148b = 0;

    /* renamed from: c, reason: collision with root package name */
    public File f1149c = new File("/mnt");

    /* renamed from: d, reason: collision with root package name */
    public File f1150d = new File("/mnt");
    public File e = new File("/mnt");
    public String[] f = null;
}
