package c.c.a.a.h;

import java.util.HashMap;

/* loaded from: classes.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    public static HashMap<String, b> f1154a = new HashMap<>();

    public static void a() {
        f1154a = new HashMap<>();
    }

    public static void a(b bVar) {
        HashMap<String, b> hashMap = new HashMap<>();
        f1154a = hashMap;
        hashMap.put(bVar.f1152c, bVar);
    }

    public static int b() {
        return f1154a.size();
    }
}
