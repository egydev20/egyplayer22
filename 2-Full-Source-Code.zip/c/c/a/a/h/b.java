package c.c.a.a.h;

import java.util.Locale;

/* loaded from: classes.dex */
public class b implements Comparable<b> {

    /* renamed from: b, reason: collision with root package name */
    public String f1151b;

    /* renamed from: c, reason: collision with root package name */
    public String f1152c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f1153d;
    public boolean e;
    public long f;

    @Override // java.lang.Comparable
    public int compareTo(b bVar) {
        b bVar2 = bVar;
        if (!(bVar2.f1153d && this.f1153d) && (bVar2.f1153d || this.f1153d)) {
            return (!bVar2.f1153d || this.f1153d) ? -1 : 1;
        }
        return this.f1151b.toLowerCase().compareTo(bVar2.f1151b.toLowerCase(Locale.getDefault()));
    }
}
