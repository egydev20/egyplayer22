package androidx.appcompat.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import b.a.j;
import b.a.k.a;
import b.a.o.d.k;
import b.a.o.d.p;
import b.a.p.c0;
import b.a.p.h;
import b.a.p.j0;
import b.a.p.l0;
import b.a.p.n;
import b.a.p.q;
import b.d.k.l;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class Toolbar extends ViewGroup {
    public ColorStateList A;
    public ColorStateList B;
    public boolean C;
    public boolean D;
    public final ArrayList<View> E;
    public final ArrayList<View> F;
    public final int[] G;
    public f H;
    public final ActionMenuView.e I;
    public l0 J;
    public b.a.p.c K;
    public d L;
    public boolean M;
    public final Runnable N;

    /* renamed from: b, reason: collision with root package name */
    public ActionMenuView f81b;

    /* renamed from: c, reason: collision with root package name */
    public TextView f82c;

    /* renamed from: d, reason: collision with root package name */
    public TextView f83d;
    public ImageButton e;
    public ImageView f;
    public Drawable g;
    public CharSequence h;
    public ImageButton i;
    public View j;
    public Context k;
    public int l;
    public int m;
    public int n;
    public int o;
    public int p;
    public int q;
    public int r;
    public int s;
    public int t;
    public c0 u;
    public int v;
    public int w;
    public int x;
    public CharSequence y;
    public CharSequence z;

    /* loaded from: classes.dex */
    public class a implements ActionMenuView.e {
        public a() {
        }
    }

    /* loaded from: classes.dex */
    public class b implements Runnable {
        public b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            Toolbar.this.g();
        }
    }

    /* loaded from: classes.dex */
    public class c implements View.OnClickListener {
        public c() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            d dVar = Toolbar.this.L;
            b.a.o.d.g gVar = dVar == null ? null : dVar.f88c;
            if (gVar != null) {
                gVar.collapseActionView();
            }
        }
    }

    /* loaded from: classes.dex */
    public class d implements k {

        /* renamed from: b, reason: collision with root package name */
        public b.a.o.d.f f87b;

        /* renamed from: c, reason: collision with root package name */
        public b.a.o.d.g f88c;

        public d() {
        }

        @Override // b.a.o.d.k
        public void a(Context context, b.a.o.d.f fVar) {
            b.a.o.d.g gVar;
            b.a.o.d.f fVar2 = this.f87b;
            if (fVar2 != null && (gVar = this.f88c) != null) {
                fVar2.a(gVar);
            }
            this.f87b = fVar;
        }

        @Override // b.a.o.d.k
        public void a(b.a.o.d.f fVar, boolean z) {
        }

        @Override // b.a.o.d.k
        public void a(k.a aVar) {
        }

        @Override // b.a.o.d.k
        public void a(boolean z) {
            if (this.f88c != null) {
                b.a.o.d.f fVar = this.f87b;
                boolean z2 = false;
                if (fVar != null) {
                    int size = fVar.size();
                    int i = 0;
                    while (true) {
                        if (i >= size) {
                            break;
                        }
                        if (this.f87b.getItem(i) == this.f88c) {
                            z2 = true;
                            break;
                        }
                        i++;
                    }
                }
                if (z2) {
                    return;
                }
                a(this.f87b, this.f88c);
            }
        }

        @Override // b.a.o.d.k
        public boolean a(b.a.o.d.f fVar, b.a.o.d.g gVar) {
            KeyEvent.Callback callback = Toolbar.this.j;
            if (callback instanceof b.a.o.a) {
                ((b.a.o.a) callback).b();
            }
            Toolbar toolbar = Toolbar.this;
            toolbar.removeView(toolbar.j);
            Toolbar toolbar2 = Toolbar.this;
            toolbar2.removeView(toolbar2.i);
            Toolbar toolbar3 = Toolbar.this;
            toolbar3.j = null;
            int size = toolbar3.F.size();
            while (true) {
                size--;
                if (size < 0) {
                    toolbar3.F.clear();
                    this.f88c = null;
                    Toolbar.this.requestLayout();
                    gVar.C = false;
                    gVar.n.b(false);
                    return true;
                }
                toolbar3.addView(toolbar3.F.get(size));
            }
        }

        @Override // b.a.o.d.k
        public boolean a(p pVar) {
            return false;
        }

        @Override // b.a.o.d.k
        public boolean b() {
            return false;
        }

        @Override // b.a.o.d.k
        public boolean b(b.a.o.d.f fVar, b.a.o.d.g gVar) {
            Toolbar.this.a();
            ViewParent parent = Toolbar.this.i.getParent();
            Toolbar toolbar = Toolbar.this;
            if (parent != toolbar) {
                if (parent instanceof ViewGroup) {
                    ((ViewGroup) parent).removeView(toolbar.i);
                }
                Toolbar toolbar2 = Toolbar.this;
                toolbar2.addView(toolbar2.i);
            }
            Toolbar.this.j = gVar.getActionView();
            this.f88c = gVar;
            ViewParent parent2 = Toolbar.this.j.getParent();
            Toolbar toolbar3 = Toolbar.this;
            if (parent2 != toolbar3) {
                if (parent2 instanceof ViewGroup) {
                    ((ViewGroup) parent2).removeView(toolbar3.j);
                }
                e generateDefaultLayoutParams = Toolbar.this.generateDefaultLayoutParams();
                Toolbar toolbar4 = Toolbar.this;
                generateDefaultLayoutParams.f244a = 8388611 | (toolbar4.o & j.AppCompatTheme_tooltipForegroundColor);
                generateDefaultLayoutParams.f90b = 2;
                toolbar4.j.setLayoutParams(generateDefaultLayoutParams);
                Toolbar toolbar5 = Toolbar.this;
                toolbar5.addView(toolbar5.j);
            }
            Toolbar toolbar6 = Toolbar.this;
            int childCount = toolbar6.getChildCount();
            while (true) {
                childCount--;
                if (childCount < 0) {
                    break;
                }
                View childAt = toolbar6.getChildAt(childCount);
                if (((e) childAt.getLayoutParams()).f90b != 2 && childAt != toolbar6.f81b) {
                    toolbar6.removeViewAt(childCount);
                    toolbar6.F.add(childAt);
                }
            }
            Toolbar.this.requestLayout();
            gVar.C = true;
            gVar.n.b(false);
            KeyEvent.Callback callback = Toolbar.this.j;
            if (callback instanceof b.a.o.a) {
                ((b.a.o.a) callback).a();
            }
            return true;
        }
    }

    /* loaded from: classes.dex */
    public static class e extends a.C0004a {

        /* renamed from: b, reason: collision with root package name */
        public int f90b;

        public e(int i, int i2) {
            super(i, i2);
            this.f90b = 0;
            this.f244a = 8388627;
        }

        public e(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f90b = 0;
        }

        public e(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f90b = 0;
        }

        public e(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f90b = 0;
            ((ViewGroup.MarginLayoutParams) this).leftMargin = marginLayoutParams.leftMargin;
            ((ViewGroup.MarginLayoutParams) this).topMargin = marginLayoutParams.topMargin;
            ((ViewGroup.MarginLayoutParams) this).rightMargin = marginLayoutParams.rightMargin;
            ((ViewGroup.MarginLayoutParams) this).bottomMargin = marginLayoutParams.bottomMargin;
        }

        public e(e eVar) {
            super((a.C0004a) eVar);
            this.f90b = 0;
            this.f90b = eVar.f90b;
        }

        public e(a.C0004a c0004a) {
            super(c0004a);
            this.f90b = 0;
        }
    }

    /* loaded from: classes.dex */
    public interface f {
        boolean onMenuItemClick(MenuItem menuItem);
    }

    /* loaded from: classes.dex */
    public static class g extends b.f.a.a {
        public static final Parcelable.Creator<g> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        public int f91d;
        public boolean e;

        /* loaded from: classes.dex */
        public static class a implements Parcelable.ClassLoaderCreator<g> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new g(parcel, null);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i) {
                return new g[i];
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            public g createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new g(parcel, classLoader);
            }
        }

        public g(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f91d = parcel.readInt();
            this.e = parcel.readInt() != 0;
        }

        public g(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // b.f.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f669b, i);
            parcel.writeInt(this.f91d);
            parcel.writeInt(this.e ? 1 : 0);
        }
    }

    public Toolbar(Context context) {
        this(context, null);
    }

    public Toolbar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.a.a.toolbarStyle);
    }

    public Toolbar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.x = 8388627;
        this.E = new ArrayList<>();
        this.F = new ArrayList<>();
        this.G = new int[2];
        this.I = new a();
        this.N = new b();
        j0 a2 = j0.a(getContext(), attributeSet, j.Toolbar, i, 0);
        this.m = a2.e(j.Toolbar_titleTextAppearance, 0);
        this.n = a2.e(j.Toolbar_subtitleTextAppearance, 0);
        this.x = a2.f415b.getInteger(j.Toolbar_android_gravity, this.x);
        this.o = a2.f415b.getInteger(j.Toolbar_buttonGravity, 48);
        int a3 = a2.a(j.Toolbar_titleMargin, 0);
        a3 = a2.e(j.Toolbar_titleMargins) ? a2.a(j.Toolbar_titleMargins, a3) : a3;
        this.t = a3;
        this.s = a3;
        this.r = a3;
        this.q = a3;
        int a4 = a2.a(j.Toolbar_titleMarginStart, -1);
        if (a4 >= 0) {
            this.q = a4;
        }
        int a5 = a2.a(j.Toolbar_titleMarginEnd, -1);
        if (a5 >= 0) {
            this.r = a5;
        }
        int a6 = a2.a(j.Toolbar_titleMarginTop, -1);
        if (a6 >= 0) {
            this.s = a6;
        }
        int a7 = a2.a(j.Toolbar_titleMarginBottom, -1);
        if (a7 >= 0) {
            this.t = a7;
        }
        this.p = a2.b(j.Toolbar_maxButtonHeight, -1);
        int a8 = a2.a(j.Toolbar_contentInsetStart, Integer.MIN_VALUE);
        int a9 = a2.a(j.Toolbar_contentInsetEnd, Integer.MIN_VALUE);
        int b2 = a2.b(j.Toolbar_contentInsetLeft, 0);
        int b3 = a2.b(j.Toolbar_contentInsetRight, 0);
        b();
        c0 c0Var = this.u;
        c0Var.h = false;
        if (b2 != Integer.MIN_VALUE) {
            c0Var.e = b2;
            c0Var.f368a = b2;
        }
        if (b3 != Integer.MIN_VALUE) {
            c0Var.f = b3;
            c0Var.f369b = b3;
        }
        if (a8 != Integer.MIN_VALUE || a9 != Integer.MIN_VALUE) {
            this.u.a(a8, a9);
        }
        this.v = a2.a(j.Toolbar_contentInsetStartWithNavigation, Integer.MIN_VALUE);
        this.w = a2.a(j.Toolbar_contentInsetEndWithActions, Integer.MIN_VALUE);
        this.g = a2.b(j.Toolbar_collapseIcon);
        this.h = a2.d(j.Toolbar_collapseContentDescription);
        CharSequence d2 = a2.d(j.Toolbar_title);
        if (!TextUtils.isEmpty(d2)) {
            setTitle(d2);
        }
        CharSequence d3 = a2.d(j.Toolbar_subtitle);
        if (!TextUtils.isEmpty(d3)) {
            setSubtitle(d3);
        }
        this.k = getContext();
        setPopupTheme(a2.e(j.Toolbar_popupTheme, 0));
        Drawable b4 = a2.b(j.Toolbar_navigationIcon);
        if (b4 != null) {
            setNavigationIcon(b4);
        }
        CharSequence d4 = a2.d(j.Toolbar_navigationContentDescription);
        if (!TextUtils.isEmpty(d4)) {
            setNavigationContentDescription(d4);
        }
        Drawable b5 = a2.b(j.Toolbar_logo);
        if (b5 != null) {
            setLogo(b5);
        }
        CharSequence d5 = a2.d(j.Toolbar_logoDescription);
        if (!TextUtils.isEmpty(d5)) {
            setLogoDescription(d5);
        }
        if (a2.e(j.Toolbar_titleTextColor)) {
            setTitleTextColor(a2.a(j.Toolbar_titleTextColor));
        }
        if (a2.e(j.Toolbar_subtitleTextColor)) {
            setSubtitleTextColor(a2.a(j.Toolbar_subtitleTextColor));
        }
        if (a2.e(j.Toolbar_menu)) {
            getMenuInflater().inflate(a2.e(j.Toolbar_menu, 0), getMenu());
        }
        a2.f415b.recycle();
    }

    private MenuInflater getMenuInflater() {
        return new b.a.o.b(getContext());
    }

    public final int a(View view, int i, int i2, int i3, int i4, int[] iArr) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int i5 = marginLayoutParams.leftMargin - iArr[0];
        int i6 = marginLayoutParams.rightMargin - iArr[1];
        int max = Math.max(0, i6) + Math.max(0, i5);
        iArr[0] = Math.max(0, -i5);
        iArr[1] = Math.max(0, -i6);
        view.measure(ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + max + i2, marginLayoutParams.width), ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height));
        return view.getMeasuredWidth() + max;
    }

    public final int a(View view, int i, int[] iArr, int i2) {
        e eVar = (e) view.getLayoutParams();
        int i3 = ((ViewGroup.MarginLayoutParams) eVar).leftMargin - iArr[0];
        int max = Math.max(0, i3) + i;
        iArr[0] = Math.max(0, -i3);
        int a2 = a(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max, a2, max + measuredWidth, view.getMeasuredHeight() + a2);
        return measuredWidth + ((ViewGroup.MarginLayoutParams) eVar).rightMargin + max;
    }

    public void a() {
        if (this.i == null) {
            h hVar = new h(getContext(), null, b.a.a.toolbarNavigationButtonStyle);
            this.i = hVar;
            hVar.setImageDrawable(this.g);
            this.i.setContentDescription(this.h);
            e generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f244a = 8388611 | (this.o & j.AppCompatTheme_tooltipForegroundColor);
            generateDefaultLayoutParams.f90b = 2;
            this.i.setLayoutParams(generateDefaultLayoutParams);
            this.i.setOnClickListener(new c());
        }
    }

    public final void a(View view, int i, int i2, int i3, int i4, int i5) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        int childMeasureSpec = ViewGroup.getChildMeasureSpec(i, getPaddingRight() + getPaddingLeft() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin + i2, marginLayoutParams.width);
        int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(i3, getPaddingBottom() + getPaddingTop() + marginLayoutParams.topMargin + marginLayoutParams.bottomMargin + i4, marginLayoutParams.height);
        int mode = View.MeasureSpec.getMode(childMeasureSpec2);
        if (mode != 1073741824 && i5 >= 0) {
            if (mode != 0) {
                i5 = Math.min(View.MeasureSpec.getSize(childMeasureSpec2), i5);
            }
            childMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(i5, 1073741824);
        }
        view.measure(childMeasureSpec, childMeasureSpec2);
    }

    public final void a(View view, boolean z) {
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        e generateDefaultLayoutParams = layoutParams == null ? generateDefaultLayoutParams() : !checkLayoutParams(layoutParams) ? generateLayoutParams(layoutParams) : (e) layoutParams;
        generateDefaultLayoutParams.f90b = 1;
        if (!z || this.j == null) {
            addView(view, generateDefaultLayoutParams);
        } else {
            view.setLayoutParams(generateDefaultLayoutParams);
            this.F.add(view);
        }
    }

    public final void a(List<View> list, int i) {
        boolean z = l.g(this) == 1;
        int childCount = getChildCount();
        int absoluteGravity = Gravity.getAbsoluteGravity(i, getLayoutDirection());
        list.clear();
        if (!z) {
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = getChildAt(i2);
                e eVar = (e) childAt.getLayoutParams();
                if (eVar.f90b == 0 && d(childAt) && a(eVar.f244a) == absoluteGravity) {
                    list.add(childAt);
                }
            }
            return;
        }
        for (int i3 = childCount - 1; i3 >= 0; i3--) {
            View childAt2 = getChildAt(i3);
            e eVar2 = (e) childAt2.getLayoutParams();
            if (eVar2.f90b == 0 && d(childAt2) && a(eVar2.f244a) == absoluteGravity) {
                list.add(childAt2);
            }
        }
    }

    public final int b(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.topMargin + marginLayoutParams.bottomMargin;
    }

    public final int b(View view, int i, int[] iArr, int i2) {
        e eVar = (e) view.getLayoutParams();
        int i3 = ((ViewGroup.MarginLayoutParams) eVar).rightMargin - iArr[1];
        int max = i - Math.max(0, i3);
        iArr[1] = Math.max(0, -i3);
        int a2 = a(view, i2);
        int measuredWidth = view.getMeasuredWidth();
        view.layout(max - measuredWidth, a2, max, view.getMeasuredHeight() + a2);
        return max - (measuredWidth + ((ViewGroup.MarginLayoutParams) eVar).leftMargin);
    }

    public final void b() {
        if (this.u == null) {
            this.u = new c0();
        }
    }

    public final void c() {
        d();
        ActionMenuView actionMenuView = this.f81b;
        if (actionMenuView.q == null) {
            b.a.o.d.f fVar = (b.a.o.d.f) actionMenuView.getMenu();
            if (this.L == null) {
                this.L = new d();
            }
            this.f81b.setExpandedActionViewsExclusive(true);
            fVar.a(this.L, this.k);
        }
    }

    public final boolean c(View view) {
        return view.getParent() == this || this.F.contains(view);
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return super.checkLayoutParams(layoutParams) && (layoutParams instanceof e);
    }

    public final void d() {
        if (this.f81b == null) {
            ActionMenuView actionMenuView = new ActionMenuView(getContext());
            this.f81b = actionMenuView;
            actionMenuView.setPopupTheme(this.l);
            this.f81b.setOnMenuItemClickListener(this.I);
            ActionMenuView actionMenuView2 = this.f81b;
            actionMenuView2.v = null;
            actionMenuView2.w = null;
            e generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f244a = 8388613 | (this.o & j.AppCompatTheme_tooltipForegroundColor);
            this.f81b.setLayoutParams(generateDefaultLayoutParams);
            a((View) this.f81b, false);
        }
    }

    public final boolean d(View view) {
        return (view == null || view.getParent() != this || view.getVisibility() == 8) ? false : true;
    }

    public final void e() {
        if (this.e == null) {
            this.e = new h(getContext(), null, b.a.a.toolbarNavigationButtonStyle);
            e generateDefaultLayoutParams = generateDefaultLayoutParams();
            generateDefaultLayoutParams.f244a = 8388611 | (this.o & j.AppCompatTheme_tooltipForegroundColor);
            this.e.setLayoutParams(generateDefaultLayoutParams);
        }
    }

    public boolean f() {
        ActionMenuView actionMenuView = this.f81b;
        if (actionMenuView != null) {
            b.a.p.c cVar = actionMenuView.u;
            if (cVar != null && cVar.e()) {
                return true;
            }
        }
        return false;
    }

    public boolean g() {
        ActionMenuView actionMenuView = this.f81b;
        if (actionMenuView != null) {
            b.a.p.c cVar = actionMenuView.u;
            if (cVar != null && cVar.f()) {
                return true;
            }
        }
        return false;
    }

    @Override // android.view.ViewGroup
    public e generateDefaultLayoutParams() {
        return new e(-2, -2);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return new e(getContext(), attributeSet);
    }

    @Override // android.view.ViewGroup
    public e generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof e ? new e((e) layoutParams) : layoutParams instanceof a.C0004a ? new e((a.C0004a) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new e((ViewGroup.MarginLayoutParams) layoutParams) : new e(layoutParams);
    }

    public CharSequence getCollapseContentDescription() {
        ImageButton imageButton = this.i;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getCollapseIcon() {
        ImageButton imageButton = this.i;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public int getContentInsetEnd() {
        c0 c0Var = this.u;
        if (c0Var != null) {
            return c0Var.g ? c0Var.f368a : c0Var.f369b;
        }
        return 0;
    }

    public int getContentInsetEndWithActions() {
        int i = this.w;
        return i != Integer.MIN_VALUE ? i : getContentInsetEnd();
    }

    public int getContentInsetLeft() {
        c0 c0Var = this.u;
        if (c0Var != null) {
            return c0Var.f368a;
        }
        return 0;
    }

    public int getContentInsetRight() {
        c0 c0Var = this.u;
        if (c0Var != null) {
            return c0Var.f369b;
        }
        return 0;
    }

    public int getContentInsetStart() {
        c0 c0Var = this.u;
        if (c0Var != null) {
            return c0Var.g ? c0Var.f369b : c0Var.f368a;
        }
        return 0;
    }

    public int getContentInsetStartWithNavigation() {
        int i = this.v;
        return i != Integer.MIN_VALUE ? i : getContentInsetStart();
    }

    public int getCurrentContentInsetEnd() {
        b.a.o.d.f fVar;
        ActionMenuView actionMenuView = this.f81b;
        return actionMenuView != null && (fVar = actionMenuView.q) != null && fVar.hasVisibleItems() ? Math.max(getContentInsetEnd(), Math.max(this.w, 0)) : getContentInsetEnd();
    }

    public int getCurrentContentInsetLeft() {
        return l.g(this) == 1 ? getCurrentContentInsetEnd() : getCurrentContentInsetStart();
    }

    public int getCurrentContentInsetRight() {
        return l.g(this) == 1 ? getCurrentContentInsetStart() : getCurrentContentInsetEnd();
    }

    public int getCurrentContentInsetStart() {
        return getNavigationIcon() != null ? Math.max(getContentInsetStart(), Math.max(this.v, 0)) : getContentInsetStart();
    }

    public Drawable getLogo() {
        ImageView imageView = this.f;
        if (imageView != null) {
            return imageView.getDrawable();
        }
        return null;
    }

    public CharSequence getLogoDescription() {
        ImageView imageView = this.f;
        if (imageView != null) {
            return imageView.getContentDescription();
        }
        return null;
    }

    public Menu getMenu() {
        c();
        return this.f81b.getMenu();
    }

    public CharSequence getNavigationContentDescription() {
        ImageButton imageButton = this.e;
        if (imageButton != null) {
            return imageButton.getContentDescription();
        }
        return null;
    }

    public Drawable getNavigationIcon() {
        ImageButton imageButton = this.e;
        if (imageButton != null) {
            return imageButton.getDrawable();
        }
        return null;
    }

    public b.a.p.c getOuterActionMenuPresenter() {
        return this.K;
    }

    public Drawable getOverflowIcon() {
        c();
        return this.f81b.getOverflowIcon();
    }

    public Context getPopupContext() {
        return this.k;
    }

    public int getPopupTheme() {
        return this.l;
    }

    public CharSequence getSubtitle() {
        return this.z;
    }

    public final TextView getSubtitleTextView() {
        return this.f83d;
    }

    public CharSequence getTitle() {
        return this.y;
    }

    public int getTitleMarginBottom() {
        return this.t;
    }

    public int getTitleMarginEnd() {
        return this.r;
    }

    public int getTitleMarginStart() {
        return this.q;
    }

    public int getTitleMarginTop() {
        return this.s;
    }

    public final TextView getTitleTextView() {
        return this.f82c;
    }

    public q getWrapper() {
        if (this.J == null) {
            this.J = new l0(this, true);
        }
        return this.J;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        removeCallbacks(this.N);
    }

    @Override // android.view.View
    public boolean onHoverEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 9) {
            this.D = false;
        }
        if (!this.D) {
            boolean onHoverEvent = super.onHoverEvent(motionEvent);
            if (actionMasked == 9 && !onHoverEvent) {
                this.D = true;
            }
        }
        if (actionMasked == 10 || actionMasked == 3) {
            this.D = false;
        }
        return true;
    }

    /* JADX WARN: Removed duplicated region for block: B:116:0x019b  */
    /* JADX WARN: Removed duplicated region for block: B:121:0x012c  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x0125  */
    /* JADX WARN: Removed duplicated region for block: B:123:0x0113  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x00f6  */
    /* JADX WARN: Removed duplicated region for block: B:14:0x005d  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0072  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x00ad  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00c2  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x00dd  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00fb  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0295 A[LOOP:0: B:45:0x0293->B:46:0x0295, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:50:0x02b7 A[LOOP:1: B:49:0x02b5->B:50:0x02b7, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:54:0x02dc A[LOOP:2: B:53:0x02da->B:54:0x02dc, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x031d  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x032e A[LOOP:3: B:62:0x032c->B:63:0x032e, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0122  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0129  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x015d  */
    /* JADX WARN: Removed duplicated region for block: B:86:0x01ac  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x021b  */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onLayout(boolean r20, int r21, int r22, int r23, int r24) {
        /*
            Method dump skipped, instructions count: 835
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onLayout(boolean, int, int, int, int):void");
    }

    /* JADX WARN: Removed duplicated region for block: B:41:0x0296  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onMeasure(int r18, int r19) {
        /*
            Method dump skipped, instructions count: 667
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onMeasure(int, int):void");
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        MenuItem findItem;
        if (!(parcelable instanceof g)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        g gVar = (g) parcelable;
        super.onRestoreInstanceState(gVar.f669b);
        ActionMenuView actionMenuView = this.f81b;
        b.a.o.d.f fVar = actionMenuView != null ? actionMenuView.q : null;
        int i = gVar.f91d;
        if (i != 0 && this.L != null && fVar != null && (findItem = fVar.findItem(i)) != null) {
            findItem.expandActionView();
        }
        if (gVar.e) {
            removeCallbacks(this.N);
            post(this.N);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x0027, code lost:
    
        if (r1 != Integer.MIN_VALUE) goto L29;
     */
    /* JADX WARN: Code restructure failed: missing block: B:23:0x0035, code lost:
    
        if (r1 != Integer.MIN_VALUE) goto L29;
     */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onRtlPropertiesChanged(int r3) {
        /*
            r2 = this;
            super.onRtlPropertiesChanged(r3)
            r2.b()
            b.a.p.c0 r0 = r2.u
            r1 = 1
            if (r3 != r1) goto Lc
            goto Ld
        Lc:
            r1 = 0
        Ld:
            boolean r3 = r0.g
            if (r1 != r3) goto L12
            goto L40
        L12:
            r0.g = r1
            boolean r3 = r0.h
            if (r3 == 0) goto L38
            r3 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r1 == 0) goto L2a
            int r1 = r0.f371d
            if (r1 == r3) goto L21
            goto L23
        L21:
            int r1 = r0.e
        L23:
            r0.f368a = r1
            int r1 = r0.f370c
            if (r1 == r3) goto L3c
            goto L3e
        L2a:
            int r1 = r0.f370c
            if (r1 == r3) goto L2f
            goto L31
        L2f:
            int r1 = r0.e
        L31:
            r0.f368a = r1
            int r1 = r0.f371d
            if (r1 == r3) goto L3c
            goto L3e
        L38:
            int r3 = r0.e
            r0.f368a = r3
        L3c:
            int r1 = r0.f
        L3e:
            r0.f369b = r1
        L40:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.Toolbar.onRtlPropertiesChanged(int):void");
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        b.a.o.d.g gVar;
        g gVar2 = new g(super.onSaveInstanceState());
        d dVar = this.L;
        if (dVar != null && (gVar = dVar.f88c) != null) {
            gVar2.f91d = gVar.f327a;
        }
        gVar2.e = f();
        return gVar2;
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        int actionMasked = motionEvent.getActionMasked();
        if (actionMasked == 0) {
            this.C = false;
        }
        if (!this.C) {
            boolean onTouchEvent = super.onTouchEvent(motionEvent);
            if (actionMasked == 0 && !onTouchEvent) {
                this.C = true;
            }
        }
        if (actionMasked == 1 || actionMasked == 3) {
            this.C = false;
        }
        return true;
    }

    public void setCollapseContentDescription(int i) {
        setCollapseContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setCollapseContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            a();
        }
        ImageButton imageButton = this.i;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setCollapseIcon(int i) {
        setCollapseIcon(b.a.l.a.a.c(getContext(), i));
    }

    public void setCollapseIcon(Drawable drawable) {
        if (drawable != null) {
            a();
            this.i.setImageDrawable(drawable);
        } else {
            ImageButton imageButton = this.i;
            if (imageButton != null) {
                imageButton.setImageDrawable(this.g);
            }
        }
    }

    public void setCollapsible(boolean z) {
        this.M = z;
        requestLayout();
    }

    public void setContentInsetEndWithActions(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.w) {
            this.w = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setContentInsetStartWithNavigation(int i) {
        if (i < 0) {
            i = Integer.MIN_VALUE;
        }
        if (i != this.v) {
            this.v = i;
            if (getNavigationIcon() != null) {
                requestLayout();
            }
        }
    }

    public void setLogo(int i) {
        setLogo(b.a.l.a.a.c(getContext(), i));
    }

    public void setLogo(Drawable drawable) {
        if (drawable != null) {
            if (this.f == null) {
                this.f = new b.a.p.j(getContext(), null, 0);
            }
            if (!c(this.f)) {
                a((View) this.f, true);
            }
        } else {
            ImageView imageView = this.f;
            if (imageView != null && c(imageView)) {
                removeView(this.f);
                this.F.remove(this.f);
            }
        }
        ImageView imageView2 = this.f;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
        }
    }

    public void setLogoDescription(int i) {
        setLogoDescription(getContext().getText(i));
    }

    public void setLogoDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence) && this.f == null) {
            this.f = new b.a.p.j(getContext(), null, 0);
        }
        ImageView imageView = this.f;
        if (imageView != null) {
            imageView.setContentDescription(charSequence);
        }
    }

    public void setNavigationContentDescription(int i) {
        setNavigationContentDescription(i != 0 ? getContext().getText(i) : null);
    }

    public void setNavigationContentDescription(CharSequence charSequence) {
        if (!TextUtils.isEmpty(charSequence)) {
            e();
        }
        ImageButton imageButton = this.e;
        if (imageButton != null) {
            imageButton.setContentDescription(charSequence);
        }
    }

    public void setNavigationIcon(int i) {
        setNavigationIcon(b.a.l.a.a.c(getContext(), i));
    }

    public void setNavigationIcon(Drawable drawable) {
        if (drawable != null) {
            e();
            if (!c(this.e)) {
                a((View) this.e, true);
            }
        } else {
            ImageButton imageButton = this.e;
            if (imageButton != null && c(imageButton)) {
                removeView(this.e);
                this.F.remove(this.e);
            }
        }
        ImageButton imageButton2 = this.e;
        if (imageButton2 != null) {
            imageButton2.setImageDrawable(drawable);
        }
    }

    public void setNavigationOnClickListener(View.OnClickListener onClickListener) {
        e();
        this.e.setOnClickListener(onClickListener);
    }

    public void setOnMenuItemClickListener(f fVar) {
        this.H = fVar;
    }

    public void setOverflowIcon(Drawable drawable) {
        c();
        this.f81b.setOverflowIcon(drawable);
    }

    public void setPopupTheme(int i) {
        if (this.l != i) {
            this.l = i;
            if (i == 0) {
                this.k = getContext();
            } else {
                this.k = new ContextThemeWrapper(getContext(), i);
            }
        }
    }

    public void setSubtitle(int i) {
        setSubtitle(getContext().getText(i));
    }

    public void setSubtitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.f83d;
            if (textView != null && c(textView)) {
                removeView(this.f83d);
                this.F.remove(this.f83d);
            }
        } else {
            if (this.f83d == null) {
                Context context = getContext();
                n nVar = new n(context);
                this.f83d = nVar;
                nVar.setSingleLine();
                this.f83d.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.n;
                if (i != 0) {
                    this.f83d.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.B;
                if (colorStateList != null) {
                    this.f83d.setTextColor(colorStateList);
                }
            }
            if (!c(this.f83d)) {
                a((View) this.f83d, true);
            }
        }
        TextView textView2 = this.f83d;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.z = charSequence;
    }

    public void setSubtitleTextColor(int i) {
        setSubtitleTextColor(ColorStateList.valueOf(i));
    }

    public void setSubtitleTextColor(ColorStateList colorStateList) {
        this.B = colorStateList;
        TextView textView = this.f83d;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public void setTitle(int i) {
        setTitle(getContext().getText(i));
    }

    public void setTitle(CharSequence charSequence) {
        if (TextUtils.isEmpty(charSequence)) {
            TextView textView = this.f82c;
            if (textView != null && c(textView)) {
                removeView(this.f82c);
                this.F.remove(this.f82c);
            }
        } else {
            if (this.f82c == null) {
                Context context = getContext();
                n nVar = new n(context);
                this.f82c = nVar;
                nVar.setSingleLine();
                this.f82c.setEllipsize(TextUtils.TruncateAt.END);
                int i = this.m;
                if (i != 0) {
                    this.f82c.setTextAppearance(context, i);
                }
                ColorStateList colorStateList = this.A;
                if (colorStateList != null) {
                    this.f82c.setTextColor(colorStateList);
                }
            }
            if (!c(this.f82c)) {
                a((View) this.f82c, true);
            }
        }
        TextView textView2 = this.f82c;
        if (textView2 != null) {
            textView2.setText(charSequence);
        }
        this.y = charSequence;
    }

    public void setTitleMarginBottom(int i) {
        this.t = i;
        requestLayout();
    }

    public void setTitleMarginEnd(int i) {
        this.r = i;
        requestLayout();
    }

    public void setTitleMarginStart(int i) {
        this.q = i;
        requestLayout();
    }

    public void setTitleMarginTop(int i) {
        this.s = i;
        requestLayout();
    }

    public void setTitleTextColor(int i) {
        setTitleTextColor(ColorStateList.valueOf(i));
    }

    public void setTitleTextColor(ColorStateList colorStateList) {
        this.A = colorStateList;
        TextView textView = this.f82c;
        if (textView != null) {
            textView.setTextColor(colorStateList);
        }
    }

    public final int a(int i) {
        int g2 = l.g(this);
        int absoluteGravity = Gravity.getAbsoluteGravity(i, g2) & 7;
        return (absoluteGravity == 1 || absoluteGravity == 3 || absoluteGravity == 5) ? absoluteGravity : g2 == 1 ? 5 : 3;
    }

    public final int a(View view, int i) {
        e eVar = (e) view.getLayoutParams();
        int measuredHeight = view.getMeasuredHeight();
        int i2 = i > 0 ? (measuredHeight - i) / 2 : 0;
        int i3 = eVar.f244a & j.AppCompatTheme_tooltipForegroundColor;
        if (i3 != 16 && i3 != 48 && i3 != 80) {
            i3 = this.x & j.AppCompatTheme_tooltipForegroundColor;
        }
        if (i3 == 48) {
            return getPaddingTop() - i2;
        }
        if (i3 == 80) {
            return (((getHeight() - getPaddingBottom()) - measuredHeight) - ((ViewGroup.MarginLayoutParams) eVar).bottomMargin) - i2;
        }
        int paddingTop = getPaddingTop();
        int paddingBottom = getPaddingBottom();
        int height = getHeight();
        int i4 = (((height - paddingTop) - paddingBottom) - measuredHeight) / 2;
        int i5 = ((ViewGroup.MarginLayoutParams) eVar).topMargin;
        if (i4 < i5) {
            i4 = i5;
        } else {
            int i6 = (((height - paddingBottom) - measuredHeight) - i4) - paddingTop;
            int i7 = ((ViewGroup.MarginLayoutParams) eVar).bottomMargin;
            if (i6 < i7) {
                i4 = Math.max(0, i4 - (i7 - i6));
            }
        }
        return paddingTop + i4;
    }

    public final int a(View view) {
        ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        return marginLayoutParams.getMarginStart() + marginLayoutParams.getMarginEnd();
    }
}
