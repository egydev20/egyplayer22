package androidx.appcompat.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.widget.FrameLayout;
import b.a.k.d;
import b.a.k.f;
import b.a.p.p;

/* loaded from: classes.dex */
public class ContentFrameLayout extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    public TypedValue f57b;

    /* renamed from: c, reason: collision with root package name */
    public TypedValue f58c;

    /* renamed from: d, reason: collision with root package name */
    public TypedValue f59d;
    public TypedValue e;
    public TypedValue f;
    public TypedValue g;
    public final Rect h;
    public a i;

    /* loaded from: classes.dex */
    public interface a {
    }

    public ContentFrameLayout(Context context) {
        this(context, null);
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ContentFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.h = new Rect();
    }

    public void a(Rect rect) {
        fitSystemWindows(rect);
    }

    public TypedValue getFixedHeightMajor() {
        if (this.f == null) {
            this.f = new TypedValue();
        }
        return this.f;
    }

    public TypedValue getFixedHeightMinor() {
        if (this.g == null) {
            this.g = new TypedValue();
        }
        return this.g;
    }

    public TypedValue getFixedWidthMajor() {
        if (this.f59d == null) {
            this.f59d = new TypedValue();
        }
        return this.f59d;
    }

    public TypedValue getFixedWidthMinor() {
        if (this.e == null) {
            this.e = new TypedValue();
        }
        return this.e;
    }

    public TypedValue getMinWidthMajor() {
        if (this.f57b == null) {
            this.f57b = new TypedValue();
        }
        return this.f57b;
    }

    public TypedValue getMinWidthMinor() {
        if (this.f58c == null) {
            this.f58c = new TypedValue();
        }
        return this.f58c;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        a aVar = this.i;
        if (aVar != null && ((f) aVar) == null) {
            throw null;
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        b.a.o.d.f fVar;
        super.onDetachedFromWindow();
        a aVar = this.i;
        if (aVar != null) {
            d dVar = ((f) aVar).f253a;
            p pVar = dVar.e;
            if (pVar != null) {
                pVar.a();
            }
            if (dVar.f != null) {
                dVar.f249d.getDecorView().removeCallbacks(dVar.g);
                if (dVar.f.isShowing()) {
                    try {
                        dVar.f.dismiss();
                    } catch (IllegalArgumentException unused) {
                    }
                }
                dVar.f = null;
            }
            dVar.a();
            d.b a2 = dVar.a(0);
            if (a2 == null || (fVar = a2.f251a) == null) {
                return;
            }
            fVar.a(true);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:17:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x00ab  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00b8  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00cc  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x00d6  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:50:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:51:0x00be  */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00ae  */
    @Override // android.widget.FrameLayout, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onMeasure(int r14, int r15) {
        /*
            Method dump skipped, instructions count: 226
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.appcompat.widget.ContentFrameLayout.onMeasure(int, int):void");
    }

    public void setAttachListener(a aVar) {
        this.i = aVar;
    }
}
