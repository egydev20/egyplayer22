package androidx.appcompat.view.menu;

import android.R;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import b.a.a;
import b.a.f;
import b.a.h;
import b.a.j;
import b.a.o.d.g;
import b.a.o.d.l;
import b.a.p.j0;

/* loaded from: classes.dex */
public class ListMenuItemView extends LinearLayout implements l.a, AbsListView.SelectionBoundsAdjuster {

    /* renamed from: b, reason: collision with root package name */
    public g f38b;

    /* renamed from: c, reason: collision with root package name */
    public ImageView f39c;

    /* renamed from: d, reason: collision with root package name */
    public RadioButton f40d;
    public TextView e;
    public CheckBox f;
    public TextView g;
    public ImageView h;
    public ImageView i;
    public LinearLayout j;
    public Drawable k;
    public int l;
    public Context m;
    public boolean n;
    public Drawable o;
    public boolean p;
    public LayoutInflater q;
    public boolean r;

    public ListMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, a.listMenuViewStyle);
    }

    public ListMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet);
        j0 a2 = j0.a(getContext(), attributeSet, j.MenuView, i, 0);
        this.k = a2.b(j.MenuView_android_itemBackground);
        this.l = a2.e(j.MenuView_android_itemTextAppearance, -1);
        this.n = a2.a(j.MenuView_preserveIconSpacing, false);
        this.m = context;
        this.o = a2.b(j.MenuView_subMenuArrow);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, new int[]{R.attr.divider}, a.dropDownListViewStyle, 0);
        this.p = obtainStyledAttributes.hasValue(0);
        a2.f415b.recycle();
        obtainStyledAttributes.recycle();
    }

    private LayoutInflater getInflater() {
        if (this.q == null) {
            this.q = LayoutInflater.from(getContext());
        }
        return this.q;
    }

    private void setSubMenuArrowVisible(boolean z) {
        ImageView imageView = this.h;
        if (imageView != null) {
            imageView.setVisibility(z ? 0 : 8);
        }
    }

    @Override // b.a.o.d.l.a
    public void a(g gVar, int i) {
        int i2;
        String sb;
        this.f38b = gVar;
        setVisibility(gVar.isVisible() ? 0 : 8);
        setTitle(c() ? gVar.getTitleCondensed() : gVar.e);
        setCheckable(gVar.isCheckable());
        boolean f = gVar.f();
        gVar.b();
        int i3 = (f && this.f38b.f()) ? 0 : 8;
        if (i3 == 0) {
            TextView textView = this.g;
            g gVar2 = this.f38b;
            char b2 = gVar2.b();
            if (b2 == 0) {
                sb = "";
            } else {
                Resources resources = gVar2.n.f323a.getResources();
                StringBuilder sb2 = new StringBuilder();
                if (ViewConfiguration.get(gVar2.n.f323a).hasPermanentMenuKey()) {
                    sb2.append(resources.getString(h.abc_prepend_shortcut_label));
                }
                int i4 = gVar2.n.e() ? gVar2.k : gVar2.i;
                g.a(sb2, i4, 65536, resources.getString(h.abc_menu_meta_shortcut_label));
                g.a(sb2, i4, 4096, resources.getString(h.abc_menu_ctrl_shortcut_label));
                g.a(sb2, i4, 2, resources.getString(h.abc_menu_alt_shortcut_label));
                g.a(sb2, i4, 1, resources.getString(h.abc_menu_shift_shortcut_label));
                g.a(sb2, i4, 4, resources.getString(h.abc_menu_sym_shortcut_label));
                g.a(sb2, i4, 8, resources.getString(h.abc_menu_function_shortcut_label));
                if (b2 == '\b') {
                    i2 = h.abc_menu_delete_shortcut_label;
                } else if (b2 == '\n') {
                    i2 = h.abc_menu_enter_shortcut_label;
                } else if (b2 != ' ') {
                    sb2.append(b2);
                    sb = sb2.toString();
                } else {
                    i2 = h.abc_menu_space_shortcut_label;
                }
                sb2.append(resources.getString(i2));
                sb = sb2.toString();
            }
            textView.setText(sb);
        }
        if (this.g.getVisibility() != i3) {
            this.g.setVisibility(i3);
        }
        setIcon(gVar.getIcon());
        setEnabled(gVar.isEnabled());
        setSubMenuArrowVisible(gVar.hasSubMenu());
        setContentDescription(gVar.q);
    }

    @Override // android.widget.AbsListView.SelectionBoundsAdjuster
    public void adjustListItemSelectionBounds(Rect rect) {
        ImageView imageView = this.i;
        if (imageView == null || imageView.getVisibility() != 0) {
            return;
        }
        LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) this.i.getLayoutParams();
        rect.top = this.i.getHeight() + layoutParams.topMargin + layoutParams.bottomMargin + rect.top;
    }

    public final void b() {
        RadioButton radioButton = (RadioButton) getInflater().inflate(b.a.g.abc_list_menu_item_radio, (ViewGroup) this, false);
        this.f40d = radioButton;
        LinearLayout linearLayout = this.j;
        if (linearLayout != null) {
            linearLayout.addView(radioButton, -1);
        } else {
            addView(radioButton, -1);
        }
    }

    @Override // b.a.o.d.l.a
    public boolean c() {
        return false;
    }

    @Override // b.a.o.d.l.a
    public g getItemData() {
        return this.f38b;
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        b.d.k.l.a(this, this.k);
        TextView textView = (TextView) findViewById(f.title);
        this.e = textView;
        int i = this.l;
        if (i != -1) {
            textView.setTextAppearance(this.m, i);
        }
        this.g = (TextView) findViewById(f.shortcut);
        ImageView imageView = (ImageView) findViewById(f.submenuarrow);
        this.h = imageView;
        if (imageView != null) {
            imageView.setImageDrawable(this.o);
        }
        this.i = (ImageView) findViewById(f.group_divider);
        this.j = (LinearLayout) findViewById(f.content);
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i, int i2) {
        if (this.f39c != null && this.n) {
            ViewGroup.LayoutParams layoutParams = getLayoutParams();
            LinearLayout.LayoutParams layoutParams2 = (LinearLayout.LayoutParams) this.f39c.getLayoutParams();
            int i3 = layoutParams.height;
            if (i3 > 0 && layoutParams2.width <= 0) {
                layoutParams2.width = i3;
            }
        }
        super.onMeasure(i, i2);
    }

    public void setCheckable(boolean z) {
        CompoundButton compoundButton;
        CompoundButton compoundButton2;
        if (!z && this.f40d == null && this.f == null) {
            return;
        }
        if (this.f38b.e()) {
            if (this.f40d == null) {
                b();
            }
            compoundButton = this.f40d;
            compoundButton2 = this.f;
        } else {
            if (this.f == null) {
                a();
            }
            compoundButton = this.f;
            compoundButton2 = this.f40d;
        }
        if (z) {
            compoundButton.setChecked(this.f38b.isChecked());
            if (compoundButton.getVisibility() != 0) {
                compoundButton.setVisibility(0);
            }
            if (compoundButton2 == null || compoundButton2.getVisibility() == 8) {
                return;
            }
            compoundButton2.setVisibility(8);
            return;
        }
        CheckBox checkBox = this.f;
        if (checkBox != null) {
            checkBox.setVisibility(8);
        }
        RadioButton radioButton = this.f40d;
        if (radioButton != null) {
            radioButton.setVisibility(8);
        }
    }

    public void setChecked(boolean z) {
        CompoundButton compoundButton;
        if (this.f38b.e()) {
            if (this.f40d == null) {
                b();
            }
            compoundButton = this.f40d;
        } else {
            if (this.f == null) {
                a();
            }
            compoundButton = this.f;
        }
        compoundButton.setChecked(z);
    }

    public void setForceShowIcon(boolean z) {
        this.r = z;
        this.n = z;
    }

    public void setGroupDividerEnabled(boolean z) {
        ImageView imageView = this.i;
        if (imageView != null) {
            imageView.setVisibility((this.p || !z) ? 8 : 0);
        }
    }

    public void setIcon(Drawable drawable) {
        boolean z = this.f38b.n.s || this.r;
        if (z || this.n) {
            if (this.f39c == null && drawable == null && !this.n) {
                return;
            }
            if (this.f39c == null) {
                ImageView imageView = (ImageView) getInflater().inflate(b.a.g.abc_list_menu_item_icon, (ViewGroup) this, false);
                this.f39c = imageView;
                LinearLayout linearLayout = this.j;
                if (linearLayout != null) {
                    linearLayout.addView(imageView, 0);
                } else {
                    addView(imageView, 0);
                }
            }
            if (drawable == null && !this.n) {
                this.f39c.setVisibility(8);
                return;
            }
            ImageView imageView2 = this.f39c;
            if (!z) {
                drawable = null;
            }
            imageView2.setImageDrawable(drawable);
            if (this.f39c.getVisibility() != 0) {
                this.f39c.setVisibility(0);
            }
        }
    }

    public void setTitle(CharSequence charSequence) {
        int i;
        TextView textView;
        if (charSequence != null) {
            this.e.setText(charSequence);
            if (this.e.getVisibility() == 0) {
                return;
            }
            textView = this.e;
            i = 0;
        } else {
            i = 8;
            if (this.e.getVisibility() == 8) {
                return;
            } else {
                textView = this.e;
            }
        }
        textView.setVisibility(i);
    }

    public final void a() {
        CheckBox checkBox = (CheckBox) getInflater().inflate(b.a.g.abc_list_menu_item_checkbox, (ViewGroup) this, false);
        this.f = checkBox;
        LinearLayout linearLayout = this.j;
        if (linearLayout != null) {
            linearLayout.addView(checkBox, -1);
        } else {
            addView(checkBox, -1);
        }
    }
}
