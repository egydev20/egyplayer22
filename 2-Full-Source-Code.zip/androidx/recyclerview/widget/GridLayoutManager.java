package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.LinearLayoutManager;
import b.d.k.r.b;
import b.j.c.m;
import b.j.c.t;

/* loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {
    public boolean G;
    public int H;
    public int[] I;
    public View[] J;
    public final SparseIntArray K;
    public final SparseIntArray L;
    public c M;
    public final Rect N;

    /* loaded from: classes.dex */
    public static final class a extends c {
    }

    /* loaded from: classes.dex */
    public static class b extends t.m {
        public int e;
        public int f;

        public b(int i, int i2) {
            super(i, i2);
            this.e = -1;
            this.f = 0;
        }

        public b(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.e = -1;
            this.f = 0;
        }

        public b(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.e = -1;
            this.f = 0;
        }

        public b(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.e = -1;
            this.f = 0;
        }
    }

    /* loaded from: classes.dex */
    public static abstract class c {

        /* renamed from: a, reason: collision with root package name */
        public final SparseIntArray f209a = new SparseIntArray();

        /* renamed from: b, reason: collision with root package name */
        public boolean f210b = false;

        public int a(int i, int i2) {
            if (!this.f210b) {
                return i % i2;
            }
            int i3 = this.f209a.get(i, -1);
            if (i3 != -1) {
                return i3;
            }
            int i4 = i % i2;
            this.f209a.put(i, i4);
            return i4;
        }

        public int b(int i, int i2) {
            int i3 = 0;
            int i4 = 0;
            for (int i5 = 0; i5 < i; i5++) {
                i3++;
                if (i3 == i2) {
                    i4++;
                    i3 = 0;
                } else if (i3 > i2) {
                    i4++;
                    i3 = 1;
                }
            }
            return i3 + 1 > i2 ? i4 + 1 : i4;
        }
    }

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i, i2);
        this.G = false;
        this.H = -1;
        this.K = new SparseIntArray();
        this.L = new SparseIntArray();
        this.M = new a();
        this.N = new Rect();
        int i3 = t.l.a(context, attributeSet, i, i2).f831b;
        if (i3 == this.H) {
            return;
        }
        this.G = true;
        if (i3 < 1) {
            throw new IllegalArgumentException(c.a.b.a.a.a("Span count should be at least 1. Provided ", i3));
        }
        this.H = i3;
        this.M.f209a.clear();
        r();
    }

    public final void A() {
        View[] viewArr = this.J;
        if (viewArr == null || viewArr.length != this.H) {
            this.J = new View[this.H];
        }
    }

    public final void B() {
        int j;
        int m;
        if (this.s == 1) {
            j = this.q - l();
            m = k();
        } else {
            j = this.r - j();
            m = m();
        }
        j(j - m);
    }

    @Override // b.j.c.t.l
    public int a(t.r rVar, t.w wVar) {
        if (this.s == 1) {
            return this.H;
        }
        if (wVar.a() < 1) {
            return 0;
        }
        return a(rVar, wVar, wVar.a() - 1) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public View a(t.r rVar, t.w wVar, int i, int i2, int i3) {
        u();
        int f = this.u.f();
        int b2 = this.u.b();
        int i4 = i2 > i ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i != i2) {
            View c2 = c(i);
            int j = j(c2);
            if (j >= 0 && j < i3 && b(rVar, wVar, j) == 0) {
                if (((t.m) c2.getLayoutParams()).d()) {
                    if (view2 == null) {
                        view2 = c2;
                    }
                } else {
                    if (this.u.d(c2) < b2 && this.u.a(c2) >= f) {
                        return c2;
                    }
                    if (view == null) {
                        view = c2;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    @Override // b.j.c.t.l
    public t.m a(Context context, AttributeSet attributeSet) {
        return new b(context, attributeSet);
    }

    @Override // b.j.c.t.l
    public t.m a(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new b((ViewGroup.MarginLayoutParams) layoutParams) : new b(layoutParams);
    }

    public final void a(View view, int i, int i2, boolean z) {
        t.m mVar = (t.m) view.getLayoutParams();
        if (z ? b(view, i, i2, mVar) : a(view, i, i2, mVar)) {
            view.measure(i, i2);
        }
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void a(t.w wVar, LinearLayoutManager.c cVar, t.l.c cVar2) {
        int i = this.H;
        for (int i2 = 0; i2 < this.H && cVar.a(wVar) && i > 0; i2++) {
            ((m.b) cVar2).a(cVar.f222d, Math.max(0, cVar.g));
            if (((a) this.M) == null) {
                throw null;
            }
            i--;
            cVar.f222d += cVar.e;
        }
    }

    @Override // b.j.c.t.l
    public boolean a(t.m mVar) {
        return mVar instanceof b;
    }

    @Override // b.j.c.t.l
    public int b(t.r rVar, t.w wVar) {
        if (this.s == 0) {
            return this.H;
        }
        if (wVar.a() < 1) {
            return 0;
        }
        return a(rVar, wVar, wVar.a() - 1) + 1;
    }

    public final int b(t.r rVar, t.w wVar, int i) {
        if (!wVar.g) {
            return this.M.a(i, this.H);
        }
        int i2 = this.L.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        int a2 = rVar.a(i);
        if (a2 != -1) {
            return this.M.a(a2, this.H);
        }
        c.a.b.a.a.a("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:", i, "GridLayoutManager");
        return 0;
    }

    public final int c(t.r rVar, t.w wVar, int i) {
        if (!wVar.g) {
            if (((a) this.M) != null) {
                return 1;
            }
            throw null;
        }
        int i2 = this.K.get(i, -1);
        if (i2 != -1) {
            return i2;
        }
        if (rVar.a(i) == -1) {
            c.a.b.a.a.a("Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:", i, "GridLayoutManager");
            return 1;
        }
        if (((a) this.M) != null) {
            return 1;
        }
        throw null;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, b.j.c.t.l
    public t.m c() {
        return this.s == 0 ? new b(-2, -1) : new b(-1, -2);
    }

    public int f(int i, int i2) {
        if (this.s != 1 || !x()) {
            int[] iArr = this.I;
            return iArr[i2 + i] - iArr[i];
        }
        int[] iArr2 = this.I;
        int i3 = this.H;
        return iArr2[i3 - i] - iArr2[(i3 - i) - i2];
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, b.j.c.t.l
    public void g(t.w wVar) {
        this.C = null;
        this.A = -1;
        this.B = Integer.MIN_VALUE;
        this.D.b();
        this.G = false;
    }

    public final void j(int i) {
        int i2;
        int[] iArr = this.I;
        int i3 = this.H;
        if (iArr == null || iArr.length != i3 + 1 || iArr[iArr.length - 1] != i) {
            iArr = new int[i3 + 1];
        }
        int i4 = 0;
        iArr[0] = 0;
        int i5 = i / i3;
        int i6 = i % i3;
        int i7 = 0;
        for (int i8 = 1; i8 <= i3; i8++) {
            i4 += i6;
            if (i4 <= 0 || i3 - i4 >= i6) {
                i2 = i5;
            } else {
                i2 = i5 + 1;
                i4 -= i3;
            }
            i7 += i2;
            iArr[i8] = i7;
        }
        this.I = iArr;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, b.j.c.t.l
    public boolean t() {
        return this.C == null && !this.G;
    }

    public final int a(t.r rVar, t.w wVar, int i) {
        if (!wVar.g) {
            return this.M.b(i, this.H);
        }
        int a2 = rVar.a(i);
        if (a2 != -1) {
            return this.M.b(a2, this.H);
        }
        c.a.b.a.a.a("Cannot find span size for pre layout position. ", i, "GridLayoutManager");
        return 0;
    }

    public final void b(View view, int i, boolean z) {
        int i2;
        int i3;
        b bVar = (b) view.getLayoutParams();
        Rect rect = bVar.f835b;
        int i4 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) bVar).topMargin + ((ViewGroup.MarginLayoutParams) bVar).bottomMargin;
        int i5 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) bVar).leftMargin + ((ViewGroup.MarginLayoutParams) bVar).rightMargin;
        int f = f(bVar.e, bVar.f);
        if (this.s == 1) {
            i3 = t.l.a(f, i, i5, ((ViewGroup.MarginLayoutParams) bVar).width, false);
            i2 = t.l.a(this.u.g(), this.p, i4, ((ViewGroup.MarginLayoutParams) bVar).height, true);
        } else {
            int a2 = t.l.a(f, i, i4, ((ViewGroup.MarginLayoutParams) bVar).height, false);
            int a3 = t.l.a(this.u.g(), this.o, i5, ((ViewGroup.MarginLayoutParams) bVar).width, true);
            i2 = a2;
            i3 = a3;
        }
        a(view, i3, i2, z);
    }

    /* JADX WARN: Code restructure failed: missing block: B:30:0x009f, code lost:
    
        r22.f216b = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:31:0x00a1, code lost:
    
        return;
     */
    @Override // androidx.recyclerview.widget.LinearLayoutManager
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void a(b.j.c.t.r r19, b.j.c.t.w r20, androidx.recyclerview.widget.LinearLayoutManager.c r21, androidx.recyclerview.widget.LinearLayoutManager.b r22) {
        /*
            Method dump skipped, instructions count: 622
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.a(b.j.c.t$r, b.j.c.t$w, androidx.recyclerview.widget.LinearLayoutManager$c, androidx.recyclerview.widget.LinearLayoutManager$b):void");
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, b.j.c.t.l
    public void c(t.r rVar, t.w wVar) {
        if (wVar.g) {
            int d2 = d();
            for (int i = 0; i < d2; i++) {
                b bVar = (b) c(i).getLayoutParams();
                int b2 = bVar.b();
                this.K.put(b2, bVar.f);
                this.L.put(b2, bVar.e);
            }
        }
        super.c(rVar, wVar);
        this.K.clear();
        this.L.clear();
    }

    @Override // b.j.c.t.l
    public void b(t tVar, int i, int i2) {
        this.M.f209a.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, b.j.c.t.l
    public int b(int i, t.r rVar, t.w wVar) {
        B();
        A();
        if (this.s == 0) {
            return 0;
        }
        return c(i, rVar, wVar);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void a(t.r rVar, t.w wVar, LinearLayoutManager.a aVar, int i) {
        B();
        if (wVar.a() > 0 && !wVar.g) {
            boolean z = i == 1;
            int b2 = b(rVar, wVar, aVar.f212b);
            if (z) {
                while (b2 > 0) {
                    int i2 = aVar.f212b;
                    if (i2 <= 0) {
                        break;
                    }
                    int i3 = i2 - 1;
                    aVar.f212b = i3;
                    b2 = b(rVar, wVar, i3);
                }
            } else {
                int a2 = wVar.a() - 1;
                int i4 = aVar.f212b;
                while (i4 < a2) {
                    int i5 = i4 + 1;
                    int b3 = b(rVar, wVar, i5);
                    if (b3 <= b2) {
                        break;
                    }
                    i4 = i5;
                    b2 = b3;
                }
                aVar.f212b = i4;
            }
        }
        A();
    }

    /* JADX WARN: Code restructure failed: missing block: B:67:0x00d2, code lost:
    
        if (r13 == (r2 > r15)) goto L49;
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x00ff, code lost:
    
        if (r13 == (r2 > r8)) goto L70;
     */
    /* JADX WARN: Removed duplicated region for block: B:52:0x010a  */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, b.j.c.t.l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.view.View a(android.view.View r23, int r24, b.j.c.t.r r25, b.j.c.t.w r26) {
        /*
            Method dump skipped, instructions count: 332
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.a(android.view.View, int, b.j.c.t$r, b.j.c.t$w):android.view.View");
    }

    @Override // b.j.c.t.l
    public void a(t.r rVar, t.w wVar, View view, b.d.k.r.b bVar) {
        int i;
        int i2;
        int i3;
        boolean z;
        boolean z2;
        int i4;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof b)) {
            super.a(view, bVar);
            return;
        }
        b bVar2 = (b) layoutParams;
        int a2 = a(rVar, wVar, bVar2.b());
        if (this.s == 0) {
            int i5 = bVar2.e;
            i = bVar2.f;
            i3 = 1;
            int i6 = this.H;
            z = i6 > 1 && i == i6;
            z2 = false;
            i4 = i5;
            i2 = a2;
        } else {
            i = 1;
            i2 = bVar2.e;
            i3 = bVar2.f;
            int i7 = this.H;
            z = i7 > 1 && i3 == i7;
            z2 = false;
            i4 = a2;
        }
        bVar.a(b.C0019b.a(i4, i, i2, i3, z, z2));
    }

    @Override // b.j.c.t.l
    public void a(t tVar, int i, int i2) {
        this.M.f209a.clear();
    }

    @Override // b.j.c.t.l
    public void a(t tVar) {
        this.M.f209a.clear();
    }

    @Override // b.j.c.t.l
    public void a(t tVar, int i, int i2, int i3) {
        this.M.f209a.clear();
    }

    @Override // b.j.c.t.l
    public void a(t tVar, int i, int i2, Object obj) {
        this.M.f209a.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, b.j.c.t.l
    public int a(int i, t.r rVar, t.w wVar) {
        B();
        A();
        if (this.s == 1) {
            return 0;
        }
        return c(i, rVar, wVar);
    }

    @Override // b.j.c.t.l
    public void a(Rect rect, int i, int i2) {
        int a2;
        int a3;
        if (this.I == null) {
            super.a(rect, i, i2);
        }
        int l = l() + k();
        int j = j() + m();
        if (this.s == 1) {
            a3 = t.l.a(i2, rect.height() + j, h());
            int[] iArr = this.I;
            a2 = t.l.a(i, iArr[iArr.length - 1] + l, i());
        } else {
            a2 = t.l.a(i, rect.width() + l, i());
            int[] iArr2 = this.I;
            a3 = t.l.a(i2, iArr2[iArr2.length - 1] + j, h());
        }
        this.f825b.setMeasuredDimension(a2, a3);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public void a(boolean z) {
        if (!z) {
            a((String) null);
            if (this.y) {
                this.y = false;
                r();
                return;
            }
            return;
        }
        throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
    }
}
