package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import b.d.k.r.b;
import b.j.c.m;
import b.j.c.n;
import b.j.c.s;
import b.j.c.t;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

/* loaded from: classes.dex */
public class StaggeredGridLayoutManager extends t.l implements t.v.b {
    public BitSet B;
    public boolean G;
    public boolean H;
    public e I;
    public int J;
    public int[] O;
    public int s;
    public f[] t;
    public s u;
    public s v;
    public int w;
    public int x;
    public final n y;
    public boolean z;
    public boolean A = false;
    public int C = -1;
    public int D = Integer.MIN_VALUE;
    public d E = new d();
    public int F = 2;
    public final Rect K = new Rect();
    public final b L = new b();
    public boolean M = false;
    public boolean N = true;
    public final Runnable P = new a();

    /* loaded from: classes.dex */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            StaggeredGridLayoutManager.this.u();
        }
    }

    /* loaded from: classes.dex */
    public class b {

        /* renamed from: a, reason: collision with root package name */
        public int f227a;

        /* renamed from: b, reason: collision with root package name */
        public int f228b;

        /* renamed from: c, reason: collision with root package name */
        public boolean f229c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f230d;
        public boolean e;
        public int[] f;

        public b() {
            b();
        }

        public void a() {
            this.f228b = this.f229c ? StaggeredGridLayoutManager.this.u.b() : StaggeredGridLayoutManager.this.u.f();
        }

        public void b() {
            this.f227a = -1;
            this.f228b = Integer.MIN_VALUE;
            this.f229c = false;
            this.f230d = false;
            this.e = false;
            int[] iArr = this.f;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
        }
    }

    /* loaded from: classes.dex */
    public static class c extends t.m {
        public f e;
        public boolean f;

        public c(int i, int i2) {
            super(i, i2);
        }

        public c(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public c(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public c(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }
    }

    /* loaded from: classes.dex */
    public static class e implements Parcelable {
        public static final Parcelable.Creator<e> CREATOR = new a();

        /* renamed from: b, reason: collision with root package name */
        public int f236b;

        /* renamed from: c, reason: collision with root package name */
        public int f237c;

        /* renamed from: d, reason: collision with root package name */
        public int f238d;
        public int[] e;
        public int f;
        public int[] g;
        public List<d.a> h;
        public boolean i;
        public boolean j;
        public boolean k;

        /* loaded from: classes.dex */
        public static class a implements Parcelable.Creator<e> {
            @Override // android.os.Parcelable.Creator
            public e createFromParcel(Parcel parcel) {
                return new e(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public e[] newArray(int i) {
                return new e[i];
            }
        }

        public e() {
        }

        public e(Parcel parcel) {
            this.f236b = parcel.readInt();
            this.f237c = parcel.readInt();
            int readInt = parcel.readInt();
            this.f238d = readInt;
            if (readInt > 0) {
                int[] iArr = new int[readInt];
                this.e = iArr;
                parcel.readIntArray(iArr);
            }
            int readInt2 = parcel.readInt();
            this.f = readInt2;
            if (readInt2 > 0) {
                int[] iArr2 = new int[readInt2];
                this.g = iArr2;
                parcel.readIntArray(iArr2);
            }
            this.i = parcel.readInt() == 1;
            this.j = parcel.readInt() == 1;
            this.k = parcel.readInt() == 1;
            this.h = parcel.readArrayList(d.a.class.getClassLoader());
        }

        public e(e eVar) {
            this.f238d = eVar.f238d;
            this.f236b = eVar.f236b;
            this.f237c = eVar.f237c;
            this.e = eVar.e;
            this.f = eVar.f;
            this.g = eVar.g;
            this.i = eVar.i;
            this.j = eVar.j;
            this.k = eVar.k;
            this.h = eVar.h;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f236b);
            parcel.writeInt(this.f237c);
            parcel.writeInt(this.f238d);
            if (this.f238d > 0) {
                parcel.writeIntArray(this.e);
            }
            parcel.writeInt(this.f);
            if (this.f > 0) {
                parcel.writeIntArray(this.g);
            }
            parcel.writeInt(this.i ? 1 : 0);
            parcel.writeInt(this.j ? 1 : 0);
            parcel.writeInt(this.k ? 1 : 0);
            parcel.writeList(this.h);
        }
    }

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.s = -1;
        this.z = false;
        t.l.d a2 = t.l.a(context, attributeSet, i, i2);
        int i3 = a2.f830a;
        if (i3 != 0 && i3 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        a((String) null);
        if (i3 != this.w) {
            this.w = i3;
            s sVar = this.u;
            this.u = this.v;
            this.v = sVar;
            r();
        }
        int i4 = a2.f831b;
        a((String) null);
        if (i4 != this.s) {
            this.E.a();
            r();
            this.s = i4;
            this.B = new BitSet(this.s);
            this.t = new f[this.s];
            for (int i5 = 0; i5 < this.s; i5++) {
                this.t[i5] = new f(i5);
            }
            r();
        }
        boolean z = a2.f832c;
        a((String) null);
        e eVar = this.I;
        if (eVar != null && eVar.i != z) {
            eVar.i = z;
        }
        this.z = z;
        r();
        this.y = new n();
        this.u = s.a(this, this.w);
        this.v = s.a(this, 1 - this.w);
    }

    @Override // b.j.c.t.l
    public int a(int i, t.r rVar, t.w wVar) {
        return c(i, rVar, wVar);
    }

    @Override // b.j.c.t.l
    public int a(t.r rVar, t.w wVar) {
        return this.w == 1 ? this.s : super.a(rVar, wVar);
    }

    @Override // b.j.c.t.l
    public int a(t.w wVar) {
        return h(wVar);
    }

    @Override // b.j.c.t.v.b
    public PointF a(int i) {
        int i2 = i(i);
        PointF pointF = new PointF();
        if (i2 == 0) {
            return null;
        }
        if (this.w == 0) {
            pointF.x = i2;
            pointF.y = 0.0f;
        } else {
            pointF.x = 0.0f;
            pointF.y = i2;
        }
        return pointF;
    }

    public View a(boolean z) {
        int f2 = this.u.f();
        int b2 = this.u.b();
        View view = null;
        for (int d2 = d() - 1; d2 >= 0; d2--) {
            View c2 = c(d2);
            int d3 = this.u.d(c2);
            int a2 = this.u.a(c2);
            if (a2 > f2 && d3 < b2) {
                if (a2 <= b2 || !z) {
                    return c2;
                }
                if (view == null) {
                    view = c2;
                }
            }
        }
        return view;
    }

    @Override // b.j.c.t.l
    public t.m a(Context context, AttributeSet attributeSet) {
        return new c(context, attributeSet);
    }

    @Override // b.j.c.t.l
    public t.m a(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new c((ViewGroup.MarginLayoutParams) layoutParams) : new c(layoutParams);
    }

    public void a(int i, t.w wVar) {
        int v;
        int i2;
        if (i > 0) {
            v = w();
            i2 = 1;
        } else {
            v = v();
            i2 = -1;
        }
        this.y.f802a = true;
        b(v, wVar);
        m(i2);
        n nVar = this.y;
        nVar.f804c = v + nVar.f805d;
        nVar.f803b = Math.abs(i);
    }

    @Override // b.j.c.t.l
    public void a(Parcelable parcelable) {
        if (parcelable instanceof e) {
            this.I = (e) parcelable;
            r();
        }
    }

    public final void a(View view, int i, int i2, boolean z) {
        a(view, this.K);
        c cVar = (c) view.getLayoutParams();
        int i3 = ((ViewGroup.MarginLayoutParams) cVar).leftMargin;
        Rect rect = this.K;
        int d2 = d(i, i3 + rect.left, ((ViewGroup.MarginLayoutParams) cVar).rightMargin + rect.right);
        int i4 = ((ViewGroup.MarginLayoutParams) cVar).topMargin;
        Rect rect2 = this.K;
        int d3 = d(i2, i4 + rect2.top, ((ViewGroup.MarginLayoutParams) cVar).bottomMargin + rect2.bottom);
        if (z ? b(view, d2, d3, cVar) : a(view, d2, d3, cVar)) {
            view.measure(d2, d3);
        }
    }

    @Override // b.j.c.t.l
    public void a(AccessibilityEvent accessibilityEvent) {
        super.a(accessibilityEvent);
        if (d() > 0) {
            View b2 = b(false);
            View a2 = a(false);
            if (b2 == null || a2 == null) {
                return;
            }
            int j = j(b2);
            int j2 = j(a2);
            if (j < j2) {
                accessibilityEvent.setFromIndex(j);
                accessibilityEvent.setToIndex(j2);
            } else {
                accessibilityEvent.setFromIndex(j2);
                accessibilityEvent.setToIndex(j);
            }
        }
    }

    public final void a(t.r rVar, int i) {
        for (int d2 = d() - 1; d2 >= 0; d2--) {
            View c2 = c(d2);
            if (this.u.d(c2) < i || this.u.f(c2) < i) {
                return;
            }
            c cVar = (c) c2.getLayoutParams();
            if (cVar.f) {
                for (int i2 = 0; i2 < this.s; i2++) {
                    if (this.t[i2].f239a.size() == 1) {
                        return;
                    }
                }
                for (int i3 = 0; i3 < this.s; i3++) {
                    this.t[i3].f();
                }
            } else if (cVar.e.f239a.size() == 1) {
                return;
            } else {
                cVar.e.f();
            }
            b(c2, rVar);
        }
    }

    public final void a(t.r rVar, t.w wVar, boolean z) {
        int b2;
        int j = j(Integer.MIN_VALUE);
        if (j != Integer.MIN_VALUE && (b2 = this.u.b() - j) > 0) {
            int i = b2 - (-c(-b2, rVar, wVar));
            if (!z || i <= 0) {
                return;
            }
            this.u.a(i);
        }
    }

    @Override // b.j.c.t.l
    public void a(t tVar) {
        this.E.a();
        r();
    }

    @Override // b.j.c.t.l
    public void a(t tVar, int i, int i2) {
        c(i, i2, 1);
    }

    @Override // b.j.c.t.l
    public void a(t tVar, int i, int i2, int i3) {
        c(i, i2, 8);
    }

    @Override // b.j.c.t.l
    public void a(t tVar, int i, int i2, Object obj) {
        c(i, i2, 4);
    }

    @Override // b.j.c.t.l
    public void a(String str) {
        t tVar;
        if (this.I != null || (tVar = this.f825b) == null) {
            return;
        }
        tVar.a(str);
    }

    @Override // b.j.c.t.l
    public boolean a() {
        return this.w == 0;
    }

    @Override // b.j.c.t.l
    public boolean a(t.m mVar) {
        return mVar instanceof c;
    }

    @Override // b.j.c.t.l
    public int b(int i, t.r rVar, t.w wVar) {
        return c(i, rVar, wVar);
    }

    @Override // b.j.c.t.l
    public int b(t.r rVar, t.w wVar) {
        return this.w == 0 ? this.s : super.b(rVar, wVar);
    }

    @Override // b.j.c.t.l
    public int b(t.w wVar) {
        return i(wVar);
    }

    public View b(boolean z) {
        int f2 = this.u.f();
        int b2 = this.u.b();
        int d2 = d();
        View view = null;
        for (int i = 0; i < d2; i++) {
            View c2 = c(i);
            int d3 = this.u.d(c2);
            if (this.u.a(c2) > f2 && d3 < b2) {
                if (d3 >= f2 || !z) {
                    return c2;
                }
                if (view == null) {
                    view = c2;
                }
            }
        }
        return view;
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x003b  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0052  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void b(int r5, b.j.c.t.w r6) {
        /*
            r4 = this;
            b.j.c.n r0 = r4.y
            r1 = 0
            r0.f803b = r1
            r0.f804c = r5
            boolean r0 = r4.p()
            r2 = 1
            if (r0 == 0) goto L2c
            int r6 = r6.f858a
            r0 = -1
            if (r6 == r0) goto L2c
            boolean r0 = r4.A
            if (r6 >= r5) goto L19
            r5 = 1
            goto L1a
        L19:
            r5 = 0
        L1a:
            if (r0 != r5) goto L23
            b.j.c.s r5 = r4.u
            int r5 = r5.g()
            goto L2d
        L23:
            b.j.c.s r5 = r4.u
            int r5 = r5.g()
            r6 = r5
            r5 = 0
            goto L2e
        L2c:
            r5 = 0
        L2d:
            r6 = 0
        L2e:
            b.j.c.t r0 = r4.f825b
            if (r0 == 0) goto L38
            boolean r0 = r0.h
            if (r0 == 0) goto L38
            r0 = 1
            goto L39
        L38:
            r0 = 0
        L39:
            if (r0 == 0) goto L52
            b.j.c.n r0 = r4.y
            b.j.c.s r3 = r4.u
            int r3 = r3.f()
            int r3 = r3 - r6
            r0.f = r3
            b.j.c.n r6 = r4.y
            b.j.c.s r0 = r4.u
            int r0 = r0.b()
            int r0 = r0 + r5
            r6.g = r0
            goto L62
        L52:
            b.j.c.n r0 = r4.y
            b.j.c.s r3 = r4.u
            int r3 = r3.a()
            int r3 = r3 + r5
            r0.g = r3
            b.j.c.n r5 = r4.y
            int r6 = -r6
            r5.f = r6
        L62:
            b.j.c.n r5 = r4.y
            r5.h = r1
            r5.f802a = r2
            b.j.c.s r6 = r4.u
            int r6 = r6.d()
            if (r6 != 0) goto L79
            b.j.c.s r6 = r4.u
            int r6 = r6.a()
            if (r6 != 0) goto L79
            r1 = 1
        L79:
            r5.i = r1
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.b(int, b.j.c.t$w):void");
    }

    public final void b(t.r rVar, int i) {
        while (d() > 0) {
            View c2 = c(0);
            if (this.u.a(c2) > i || this.u.e(c2) > i) {
                return;
            }
            c cVar = (c) c2.getLayoutParams();
            if (cVar.f) {
                for (int i2 = 0; i2 < this.s; i2++) {
                    if (this.t[i2].f239a.size() == 1) {
                        return;
                    }
                }
                for (int i3 = 0; i3 < this.s; i3++) {
                    this.t[i3].g();
                }
            } else if (cVar.e.f239a.size() == 1) {
                return;
            } else {
                cVar.e.g();
            }
            b(c2, rVar);
        }
    }

    public final void b(t.r rVar, t.w wVar, boolean z) {
        int f2;
        int k = k(Integer.MAX_VALUE);
        if (k != Integer.MAX_VALUE && (f2 = k - this.u.f()) > 0) {
            int c2 = f2 - c(f2, rVar, wVar);
            if (!z || c2 <= 0) {
                return;
            }
            this.u.a(-c2);
        }
    }

    @Override // b.j.c.t.l
    public void b(t tVar, int i, int i2) {
        c(i, i2, 2);
    }

    @Override // b.j.c.t.l
    public boolean b() {
        return this.w == 1;
    }

    public int c(int i, t.r rVar, t.w wVar) {
        if (d() == 0 || i == 0) {
            return 0;
        }
        a(i, wVar);
        int a2 = a(rVar, this.y, wVar);
        if (this.y.f803b >= a2) {
            i = i < 0 ? -a2 : a2;
        }
        this.u.a(-i);
        this.G = this.A;
        n nVar = this.y;
        nVar.f803b = 0;
        a(rVar, nVar);
        return i;
    }

    @Override // b.j.c.t.l
    public int c(t.w wVar) {
        return j(wVar);
    }

    @Override // b.j.c.t.l
    public t.m c() {
        return this.w == 0 ? new c(-2, -1) : new c(-1, -2);
    }

    public final void c(int i, int i2) {
        for (int i3 = 0; i3 < this.s; i3++) {
            if (!this.t[i3].f239a.isEmpty()) {
                a(this.t[i3], i, i2);
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0025  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0043 A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:18:0x0044  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x003c  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void c(int r7, int r8, int r9) {
        /*
            r6 = this;
            boolean r0 = r6.A
            if (r0 == 0) goto L9
            int r0 = r6.w()
            goto Ld
        L9:
            int r0 = r6.v()
        Ld:
            r1 = 8
            if (r9 != r1) goto L1a
            if (r7 >= r8) goto L16
            int r2 = r8 + 1
            goto L1c
        L16:
            int r2 = r7 + 1
            r3 = r8
            goto L1d
        L1a:
            int r2 = r7 + r8
        L1c:
            r3 = r7
        L1d:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r4 = r6.E
            r4.d(r3)
            r4 = 1
            if (r9 == r4) goto L3c
            r5 = 2
            if (r9 == r5) goto L36
            if (r9 == r1) goto L2b
            goto L41
        L2b:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.E
            r9.b(r7, r4)
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r7 = r6.E
            r7.a(r8, r4)
            goto L41
        L36:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.E
            r9.b(r7, r8)
            goto L41
        L3c:
            androidx.recyclerview.widget.StaggeredGridLayoutManager$d r9 = r6.E
            r9.a(r7, r8)
        L41:
            if (r2 > r0) goto L44
            return
        L44:
            boolean r7 = r6.A
            if (r7 == 0) goto L4d
            int r7 = r6.v()
            goto L51
        L4d:
            int r7 = r6.w()
        L51:
            if (r3 > r7) goto L56
            r6.r()
        L56:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.c(int, int, int):void");
    }

    @Override // b.j.c.t.l
    public void c(t.r rVar, t.w wVar) {
        c(rVar, wVar, true);
    }

    /* JADX WARN: Code restructure failed: missing block: B:271:0x0403, code lost:
    
        if (u() != false) goto L262;
     */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01ae  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void c(b.j.c.t.r r13, b.j.c.t.w r14, boolean r15) {
        /*
            Method dump skipped, instructions count: 1061
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.c(b.j.c.t$r, b.j.c.t$w, boolean):void");
    }

    public final int d(int i, int i2, int i3) {
        if (i2 == 0 && i3 == 0) {
            return i;
        }
        int mode = View.MeasureSpec.getMode(i);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i) - i2) - i3), mode) : i;
    }

    @Override // b.j.c.t.l
    public int d(t.w wVar) {
        return h(wVar);
    }

    @Override // b.j.c.t.l
    public void d(int i) {
        super.d(i);
        for (int i2 = 0; i2 < this.s; i2++) {
            f fVar = this.t[i2];
            int i3 = fVar.f240b;
            if (i3 != Integer.MIN_VALUE) {
                fVar.f240b = i3 + i;
            }
            int i4 = fVar.f241c;
            if (i4 != Integer.MIN_VALUE) {
                fVar.f241c = i4 + i;
            }
        }
    }

    @Override // b.j.c.t.l
    public int e(t.w wVar) {
        return i(wVar);
    }

    @Override // b.j.c.t.l
    public void e(int i) {
        super.e(i);
        for (int i2 = 0; i2 < this.s; i2++) {
            f fVar = this.t[i2];
            int i3 = fVar.f240b;
            if (i3 != Integer.MIN_VALUE) {
                fVar.f240b = i3 + i;
            }
            int i4 = fVar.f241c;
            if (i4 != Integer.MIN_VALUE) {
                fVar.f241c = i4 + i;
            }
        }
    }

    @Override // b.j.c.t.l
    public int f(t.w wVar) {
        return j(wVar);
    }

    @Override // b.j.c.t.l
    public void f(int i) {
        if (i == 0) {
            u();
        }
    }

    @Override // b.j.c.t.l
    public void g(t.w wVar) {
        this.C = -1;
        this.D = Integer.MIN_VALUE;
        this.I = null;
        this.L.b();
    }

    public final int h(t.w wVar) {
        if (d() == 0) {
            return 0;
        }
        return a.a.a.a.a.a(wVar, this.u, b(!this.N), a(!this.N), this, this.N);
    }

    @Override // b.j.c.t.l
    public void h(int i) {
        e eVar = this.I;
        if (eVar != null && eVar.f236b != i) {
            eVar.e = null;
            eVar.f238d = 0;
            eVar.f236b = -1;
            eVar.f237c = -1;
        }
        this.C = i;
        this.D = Integer.MIN_VALUE;
        r();
    }

    public final int i(int i) {
        if (d() == 0) {
            return this.A ? 1 : -1;
        }
        return (i < v()) != this.A ? -1 : 1;
    }

    public final int i(t.w wVar) {
        if (d() == 0) {
            return 0;
        }
        return a.a.a.a.a.a(wVar, this.u, b(!this.N), a(!this.N), this, this.N, this.A);
    }

    public final int j(int i) {
        int a2 = this.t[0].a(i);
        for (int i2 = 1; i2 < this.s; i2++) {
            int a3 = this.t[i2].a(i);
            if (a3 > a2) {
                a2 = a3;
            }
        }
        return a2;
    }

    public final int j(t.w wVar) {
        if (d() == 0) {
            return 0;
        }
        return a.a.a.a.a.b(wVar, this.u, b(!this.N), a(!this.N), this, this.N);
    }

    public final int k(int i) {
        int b2 = this.t[0].b(i);
        for (int i2 = 1; i2 < this.s; i2++) {
            int b3 = this.t[i2].b(i);
            if (b3 < b2) {
                b2 = b3;
            }
        }
        return b2;
    }

    public final boolean l(int i) {
        if (this.w == 0) {
            return (i == -1) != this.A;
        }
        return ((i == -1) == this.A) == y();
    }

    public final void m(int i) {
        n nVar = this.y;
        nVar.e = i;
        nVar.f805d = this.A != (i == -1) ? -1 : 1;
    }

    @Override // b.j.c.t.l
    public boolean o() {
        return this.F != 0;
    }

    @Override // b.j.c.t.l
    public Parcelable q() {
        int b2;
        int f2;
        int[] iArr;
        if (this.I != null) {
            return new e(this.I);
        }
        e eVar = new e();
        eVar.i = this.z;
        eVar.j = this.G;
        eVar.k = this.H;
        d dVar = this.E;
        if (dVar == null || (iArr = dVar.f231a) == null) {
            eVar.f = 0;
        } else {
            eVar.g = iArr;
            eVar.f = iArr.length;
            eVar.h = dVar.f232b;
        }
        if (d() > 0) {
            eVar.f236b = this.G ? w() : v();
            View a2 = this.A ? a(true) : b(true);
            eVar.f237c = a2 != null ? j(a2) : -1;
            int i = this.s;
            eVar.f238d = i;
            eVar.e = new int[i];
            for (int i2 = 0; i2 < this.s; i2++) {
                if (this.G) {
                    b2 = this.t[i2].a(Integer.MIN_VALUE);
                    if (b2 != Integer.MIN_VALUE) {
                        f2 = this.u.b();
                        b2 -= f2;
                        eVar.e[i2] = b2;
                    } else {
                        eVar.e[i2] = b2;
                    }
                } else {
                    b2 = this.t[i2].b(Integer.MIN_VALUE);
                    if (b2 != Integer.MIN_VALUE) {
                        f2 = this.u.f();
                        b2 -= f2;
                        eVar.e[i2] = b2;
                    } else {
                        eVar.e[i2] = b2;
                    }
                }
            }
        } else {
            eVar.f236b = -1;
            eVar.f237c = -1;
            eVar.f238d = 0;
        }
        return eVar;
    }

    @Override // b.j.c.t.l
    public boolean t() {
        return this.I == null;
    }

    public boolean u() {
        int v;
        int w;
        if (d() == 0 || this.F == 0 || !this.i) {
            return false;
        }
        if (this.A) {
            v = w();
            w = v();
        } else {
            v = v();
            w = w();
        }
        if (v == 0 && x() != null) {
            this.E.a();
        } else {
            if (!this.M) {
                return false;
            }
            int i = this.A ? -1 : 1;
            int i2 = w + 1;
            d.a a2 = this.E.a(v, i2, i, true);
            if (a2 == null) {
                this.M = false;
                this.E.b(i2);
                return false;
            }
            d.a a3 = this.E.a(v, a2.f233b, i * (-1), true);
            if (a3 == null) {
                this.E.b(a2.f233b);
            } else {
                this.E.b(a3.f233b + 1);
            }
        }
        this.h = true;
        r();
        return true;
    }

    public int v() {
        if (d() == 0) {
            return 0;
        }
        return j(c(0));
    }

    public int w() {
        int d2 = d();
        if (d2 == 0) {
            return 0;
        }
        return j(c(d2 - 1));
    }

    /* JADX WARN: Code restructure failed: missing block: B:44:0x00b9, code lost:
    
        if (r11 == r12) goto L55;
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00cf, code lost:
    
        r11 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00cd, code lost:
    
        r11 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00cb, code lost:
    
        if (r11 == r12) goto L55;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.view.View x() {
        /*
            Method dump skipped, instructions count: 243
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.x():android.view.View");
    }

    public boolean y() {
        return g() == 1;
    }

    public final void z() {
        this.A = (this.w == 1 || !y()) ? this.z : !this.z;
    }

    /* loaded from: classes.dex */
    public static class d {

        /* renamed from: a, reason: collision with root package name */
        public int[] f231a;

        /* renamed from: b, reason: collision with root package name */
        public List<a> f232b;

        /* loaded from: classes.dex */
        public static class a implements Parcelable {
            public static final Parcelable.Creator<a> CREATOR = new C0003a();

            /* renamed from: b, reason: collision with root package name */
            public int f233b;

            /* renamed from: c, reason: collision with root package name */
            public int f234c;

            /* renamed from: d, reason: collision with root package name */
            public int[] f235d;
            public boolean e;

            /* renamed from: androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a$a, reason: collision with other inner class name */
            /* loaded from: classes.dex */
            public static class C0003a implements Parcelable.Creator<a> {
                @Override // android.os.Parcelable.Creator
                public a createFromParcel(Parcel parcel) {
                    return new a(parcel);
                }

                @Override // android.os.Parcelable.Creator
                public a[] newArray(int i) {
                    return new a[i];
                }
            }

            public a() {
            }

            public a(Parcel parcel) {
                this.f233b = parcel.readInt();
                this.f234c = parcel.readInt();
                this.e = parcel.readInt() == 1;
                int readInt = parcel.readInt();
                if (readInt > 0) {
                    int[] iArr = new int[readInt];
                    this.f235d = iArr;
                    parcel.readIntArray(iArr);
                }
            }

            @Override // android.os.Parcelable
            public int describeContents() {
                return 0;
            }

            public String toString() {
                StringBuilder a2 = c.a.b.a.a.a("FullSpanItem{mPosition=");
                a2.append(this.f233b);
                a2.append(", mGapDir=");
                a2.append(this.f234c);
                a2.append(", mHasUnwantedGapAfter=");
                a2.append(this.e);
                a2.append(", mGapPerSpan=");
                a2.append(Arrays.toString(this.f235d));
                a2.append('}');
                return a2.toString();
            }

            @Override // android.os.Parcelable
            public void writeToParcel(Parcel parcel, int i) {
                parcel.writeInt(this.f233b);
                parcel.writeInt(this.f234c);
                parcel.writeInt(this.e ? 1 : 0);
                int[] iArr = this.f235d;
                if (iArr == null || iArr.length <= 0) {
                    parcel.writeInt(0);
                } else {
                    parcel.writeInt(iArr.length);
                    parcel.writeIntArray(this.f235d);
                }
            }
        }

        public a a(int i, int i2, int i3, boolean z) {
            List<a> list = this.f232b;
            if (list == null) {
                return null;
            }
            int size = list.size();
            for (int i4 = 0; i4 < size; i4++) {
                a aVar = this.f232b.get(i4);
                int i5 = aVar.f233b;
                if (i5 >= i2) {
                    return null;
                }
                if (i5 >= i && (i3 == 0 || aVar.f234c == i3 || (z && aVar.e))) {
                    return aVar;
                }
            }
            return null;
        }

        public void a() {
            int[] iArr = this.f231a;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            this.f232b = null;
        }

        public void a(int i) {
            int[] iArr = this.f231a;
            if (iArr == null) {
                int[] iArr2 = new int[Math.max(i, 10) + 1];
                this.f231a = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i >= iArr.length) {
                int length = iArr.length;
                while (length <= i) {
                    length *= 2;
                }
                int[] iArr3 = new int[length];
                this.f231a = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
                int[] iArr4 = this.f231a;
                Arrays.fill(iArr4, iArr.length, iArr4.length, -1);
            }
        }

        public void a(a aVar) {
            if (this.f232b == null) {
                this.f232b = new ArrayList();
            }
            int size = this.f232b.size();
            for (int i = 0; i < size; i++) {
                a aVar2 = this.f232b.get(i);
                if (aVar2.f233b == aVar.f233b) {
                    this.f232b.remove(i);
                }
                if (aVar2.f233b >= aVar.f233b) {
                    this.f232b.add(i, aVar);
                    return;
                }
            }
            this.f232b.add(aVar);
        }

        public int b(int i) {
            List<a> list = this.f232b;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    if (this.f232b.get(size).f233b >= i) {
                        this.f232b.remove(size);
                    }
                }
            }
            return d(i);
        }

        public void b(int i, int i2) {
            int[] iArr = this.f231a;
            if (iArr == null || i >= iArr.length) {
                return;
            }
            int i3 = i + i2;
            a(i3);
            int[] iArr2 = this.f231a;
            System.arraycopy(iArr2, i3, iArr2, i, (iArr2.length - i) - i2);
            int[] iArr3 = this.f231a;
            Arrays.fill(iArr3, iArr3.length - i2, iArr3.length, -1);
            List<a> list = this.f232b;
            if (list == null) {
                return;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.f232b.get(size);
                int i4 = aVar.f233b;
                if (i4 >= i) {
                    if (i4 < i3) {
                        this.f232b.remove(size);
                    } else {
                        aVar.f233b = i4 - i2;
                    }
                }
            }
        }

        public a c(int i) {
            List<a> list = this.f232b;
            if (list == null) {
                return null;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.f232b.get(size);
                if (aVar.f233b == i) {
                    return aVar;
                }
            }
            return null;
        }

        /* JADX WARN: Removed duplicated region for block: B:12:0x0048  */
        /* JADX WARN: Removed duplicated region for block: B:14:0x0052  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public int d(int r5) {
            /*
                r4 = this;
                int[] r0 = r4.f231a
                r1 = -1
                if (r0 != 0) goto L6
                return r1
            L6:
                int r0 = r0.length
                if (r5 < r0) goto La
                return r1
            La:
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f232b
                if (r0 != 0) goto L10
            Le:
                r0 = -1
                goto L46
            L10:
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r0 = r4.c(r5)
                if (r0 == 0) goto L1b
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r2 = r4.f232b
                r2.remove(r0)
            L1b:
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f232b
                int r0 = r0.size()
                r2 = 0
            L22:
                if (r2 >= r0) goto L34
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r3 = r4.f232b
                java.lang.Object r3 = r3.get(r2)
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r3 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.d.a) r3
                int r3 = r3.f233b
                if (r3 < r5) goto L31
                goto L35
            L31:
                int r2 = r2 + 1
                goto L22
            L34:
                r2 = -1
            L35:
                if (r2 == r1) goto Le
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r0 = r4.f232b
                java.lang.Object r0 = r0.get(r2)
                androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a r0 = (androidx.recyclerview.widget.StaggeredGridLayoutManager.d.a) r0
                java.util.List<androidx.recyclerview.widget.StaggeredGridLayoutManager$d$a> r3 = r4.f232b
                r3.remove(r2)
                int r0 = r0.f233b
            L46:
                if (r0 != r1) goto L52
                int[] r0 = r4.f231a
                int r2 = r0.length
                java.util.Arrays.fill(r0, r5, r2, r1)
                int[] r5 = r4.f231a
                int r5 = r5.length
                return r5
            L52:
                int[] r2 = r4.f231a
                int r0 = r0 + 1
                java.util.Arrays.fill(r2, r5, r0, r1)
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.d.d(int):int");
        }

        public void a(int i, int i2) {
            int[] iArr = this.f231a;
            if (iArr == null || i >= iArr.length) {
                return;
            }
            int i3 = i + i2;
            a(i3);
            int[] iArr2 = this.f231a;
            System.arraycopy(iArr2, i, iArr2, i3, (iArr2.length - i) - i2);
            Arrays.fill(this.f231a, i, i3, -1);
            List<a> list = this.f232b;
            if (list == null) {
                return;
            }
            for (int size = list.size() - 1; size >= 0; size--) {
                a aVar = this.f232b.get(size);
                int i4 = aVar.f233b;
                if (i4 >= i) {
                    aVar.f233b = i4 + i2;
                }
            }
        }
    }

    /* loaded from: classes.dex */
    public class f {

        /* renamed from: a, reason: collision with root package name */
        public ArrayList<View> f239a = new ArrayList<>();

        /* renamed from: b, reason: collision with root package name */
        public int f240b = Integer.MIN_VALUE;

        /* renamed from: c, reason: collision with root package name */
        public int f241c = Integer.MIN_VALUE;

        /* renamed from: d, reason: collision with root package name */
        public int f242d = 0;
        public final int e;

        public f(int i) {
            this.e = i;
        }

        public int a(int i) {
            int i2 = this.f241c;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.f239a.size() == 0) {
                return i;
            }
            a();
            return this.f241c;
        }

        public View a(int i, int i2) {
            View view = null;
            if (i2 != -1) {
                int size = this.f239a.size() - 1;
                while (size >= 0) {
                    View view2 = this.f239a.get(size);
                    StaggeredGridLayoutManager staggeredGridLayoutManager = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager.z && staggeredGridLayoutManager.j(view2) >= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager2 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager2.z && staggeredGridLayoutManager2.j(view2) <= i) || !view2.hasFocusable()) {
                        break;
                    }
                    size--;
                    view = view2;
                }
            } else {
                int size2 = this.f239a.size();
                int i3 = 0;
                while (i3 < size2) {
                    View view3 = this.f239a.get(i3);
                    StaggeredGridLayoutManager staggeredGridLayoutManager3 = StaggeredGridLayoutManager.this;
                    if (staggeredGridLayoutManager3.z && staggeredGridLayoutManager3.j(view3) <= i) {
                        break;
                    }
                    StaggeredGridLayoutManager staggeredGridLayoutManager4 = StaggeredGridLayoutManager.this;
                    if ((!staggeredGridLayoutManager4.z && staggeredGridLayoutManager4.j(view3) >= i) || !view3.hasFocusable()) {
                        break;
                    }
                    i3++;
                    view = view3;
                }
            }
            return view;
        }

        public void a() {
            d.a c2;
            ArrayList<View> arrayList = this.f239a;
            View view = arrayList.get(arrayList.size() - 1);
            c b2 = b(view);
            this.f241c = StaggeredGridLayoutManager.this.u.a(view);
            if (b2.f && (c2 = StaggeredGridLayoutManager.this.E.c(b2.b())) != null && c2.f234c == 1) {
                int i = this.f241c;
                int i2 = this.e;
                int[] iArr = c2.f235d;
                this.f241c = i + (iArr == null ? 0 : iArr[i2]);
            }
        }

        public void a(View view) {
            c b2 = b(view);
            b2.e = this;
            this.f239a.add(view);
            this.f241c = Integer.MIN_VALUE;
            if (this.f239a.size() == 1) {
                this.f240b = Integer.MIN_VALUE;
            }
            if (b2.d() || b2.c()) {
                this.f242d = StaggeredGridLayoutManager.this.u.b(view) + this.f242d;
            }
        }

        public int b(int i) {
            int i2 = this.f240b;
            if (i2 != Integer.MIN_VALUE) {
                return i2;
            }
            if (this.f239a.size() == 0) {
                return i;
            }
            b();
            return this.f240b;
        }

        public c b(View view) {
            return (c) view.getLayoutParams();
        }

        public void b() {
            d.a c2;
            View view = this.f239a.get(0);
            c b2 = b(view);
            this.f240b = StaggeredGridLayoutManager.this.u.d(view);
            if (b2.f && (c2 = StaggeredGridLayoutManager.this.E.c(b2.b())) != null && c2.f234c == -1) {
                int i = this.f240b;
                int i2 = this.e;
                int[] iArr = c2.f235d;
                this.f240b = i - (iArr != null ? iArr[i2] : 0);
            }
        }

        public void c() {
            this.f239a.clear();
            this.f240b = Integer.MIN_VALUE;
            this.f241c = Integer.MIN_VALUE;
            this.f242d = 0;
        }

        public void c(View view) {
            c b2 = b(view);
            b2.e = this;
            this.f239a.add(0, view);
            this.f240b = Integer.MIN_VALUE;
            if (this.f239a.size() == 1) {
                this.f241c = Integer.MIN_VALUE;
            }
            if (b2.d() || b2.c()) {
                this.f242d = StaggeredGridLayoutManager.this.u.b(view) + this.f242d;
            }
        }

        public int d() {
            int i;
            int size;
            if (StaggeredGridLayoutManager.this.z) {
                i = this.f239a.size() - 1;
                size = -1;
            } else {
                i = 0;
                size = this.f239a.size();
            }
            return a(i, size, true);
        }

        public int e() {
            int size;
            int i;
            if (StaggeredGridLayoutManager.this.z) {
                size = 0;
                i = this.f239a.size();
            } else {
                size = this.f239a.size() - 1;
                i = -1;
            }
            return a(size, i, true);
        }

        public void f() {
            int size = this.f239a.size();
            View remove = this.f239a.remove(size - 1);
            c b2 = b(remove);
            b2.e = null;
            if (b2.d() || b2.c()) {
                this.f242d -= StaggeredGridLayoutManager.this.u.b(remove);
            }
            if (size == 1) {
                this.f240b = Integer.MIN_VALUE;
            }
            this.f241c = Integer.MIN_VALUE;
        }

        public void g() {
            View remove = this.f239a.remove(0);
            c b2 = b(remove);
            b2.e = null;
            if (this.f239a.size() == 0) {
                this.f241c = Integer.MIN_VALUE;
            }
            if (b2.d() || b2.c()) {
                this.f242d -= StaggeredGridLayoutManager.this.u.b(remove);
            }
            this.f240b = Integer.MIN_VALUE;
        }

        public int a(int i, int i2, boolean z) {
            int f = StaggeredGridLayoutManager.this.u.f();
            int b2 = StaggeredGridLayoutManager.this.u.b();
            int i3 = i2 > i ? 1 : -1;
            while (i != i2) {
                View view = this.f239a.get(i);
                int d2 = StaggeredGridLayoutManager.this.u.d(view);
                int a2 = StaggeredGridLayoutManager.this.u.a(view);
                boolean z2 = false;
                boolean z3 = !z ? d2 >= b2 : d2 > b2;
                if (!z ? a2 > f : a2 >= f) {
                    z2 = true;
                }
                if (z3 && z2 && (d2 < f || a2 > b2)) {
                    return StaggeredGridLayoutManager.this.j(view);
                }
                i += i3;
            }
            return -1;
        }
    }

    @Override // b.j.c.t.l
    public void a(int i, int i2, t.w wVar, t.l.c cVar) {
        int a2;
        int i3;
        if (this.w != 0) {
            i = i2;
        }
        if (d() == 0 || i == 0) {
            return;
        }
        a(i, wVar);
        int[] iArr = this.O;
        if (iArr == null || iArr.length < this.s) {
            this.O = new int[this.s];
        }
        int i4 = 0;
        for (int i5 = 0; i5 < this.s; i5++) {
            n nVar = this.y;
            if (nVar.f805d == -1) {
                a2 = nVar.f;
                i3 = this.t[i5].b(a2);
            } else {
                a2 = this.t[i5].a(nVar.g);
                i3 = this.y.g;
            }
            int i6 = a2 - i3;
            if (i6 >= 0) {
                this.O[i4] = i6;
                i4++;
            }
        }
        Arrays.sort(this.O, 0, i4);
        for (int i7 = 0; i7 < i4; i7++) {
            int i8 = this.y.f804c;
            if (!(i8 >= 0 && i8 < wVar.a())) {
                return;
            }
            ((m.b) cVar).a(this.y.f804c, this.O[i7]);
            n nVar2 = this.y;
            nVar2.f804c += nVar2.f805d;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:102:0x0328  */
    /* JADX WARN: Removed duplicated region for block: B:105:0x0342  */
    /* JADX WARN: Removed duplicated region for block: B:109:0x034c  */
    /* JADX WARN: Removed duplicated region for block: B:110:0x0352  */
    /* JADX WARN: Removed duplicated region for block: B:115:0x0330  */
    /* JADX WARN: Removed duplicated region for block: B:116:0x0318  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x02e7  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x02ee  */
    /* JADX WARN: Removed duplicated region for block: B:124:0x029a  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x01c8  */
    /* JADX WARN: Removed duplicated region for block: B:58:0x017f  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x0213  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x0282  */
    /* JADX WARN: Removed duplicated region for block: B:91:0x02b7  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x0309  */
    /* JADX WARN: Type inference failed for: r10v0 */
    /* JADX WARN: Type inference failed for: r10v1, types: [int, boolean] */
    /* JADX WARN: Type inference failed for: r10v13 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final int a(b.j.c.t.r r19, b.j.c.n r20, b.j.c.t.w r21) {
        /*
            Method dump skipped, instructions count: 927
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.a(b.j.c.t$r, b.j.c.n, b.j.c.t$w):int");
    }

    @Override // b.j.c.t.l
    public void a(t tVar, t.r rVar) {
        Runnable runnable = this.P;
        t tVar2 = this.f825b;
        if (tVar2 != null) {
            tVar2.removeCallbacks(runnable);
        }
        for (int i = 0; i < this.s; i++) {
            this.t[i].c();
        }
        tVar.requestLayout();
    }

    /* JADX WARN: Code restructure failed: missing block: B:115:0x003c, code lost:
    
        if (r9.w == 1) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:118:0x0042, code lost:
    
        if (r9.w == 0) goto L30;
     */
    /* JADX WARN: Code restructure failed: missing block: B:122:0x004e, code lost:
    
        if (y() == false) goto L23;
     */
    /* JADX WARN: Code restructure failed: missing block: B:126:0x005a, code lost:
    
        if (y() == false) goto L30;
     */
    @Override // b.j.c.t.l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.view.View a(android.view.View r10, int r11, b.j.c.t.r r12, b.j.c.t.w r13) {
        /*
            Method dump skipped, instructions count: 332
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.a(android.view.View, int, b.j.c.t$r, b.j.c.t$w):android.view.View");
    }

    @Override // b.j.c.t.l
    public void a(t.r rVar, t.w wVar, View view, b.d.k.r.b bVar) {
        b.C0019b a2;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof c)) {
            super.a(view, bVar);
            return;
        }
        c cVar = (c) layoutParams;
        if (this.w == 0) {
            f fVar = cVar.e;
            a2 = b.C0019b.a(fVar == null ? -1 : fVar.e, cVar.f ? this.s : 1, -1, -1, cVar.f, false);
        } else {
            f fVar2 = cVar.e;
            a2 = b.C0019b.a(-1, -1, fVar2 == null ? -1 : fVar2.e, cVar.f ? this.s : 1, cVar.f, false);
        }
        bVar.a(a2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:8:0x0011, code lost:
    
        if (r6.e == (-1)) goto L11;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a(b.j.c.t.r r5, b.j.c.n r6) {
        /*
            r4 = this;
            boolean r0 = r6.f802a
            if (r0 == 0) goto L7c
            boolean r0 = r6.i
            if (r0 == 0) goto La
            goto L7c
        La:
            int r0 = r6.f803b
            r1 = -1
            if (r0 != 0) goto L1f
            int r0 = r6.e
            if (r0 != r1) goto L19
        L13:
            int r6 = r6.g
        L15:
            r4.a(r5, r6)
            goto L7c
        L19:
            int r6 = r6.f
        L1b:
            r4.b(r5, r6)
            goto L7c
        L1f:
            int r0 = r6.e
            r2 = 0
            r3 = 1
            if (r0 != r1) goto L50
            int r0 = r6.f
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r1 = r4.t
            r1 = r1[r2]
            int r1 = r1.b(r0)
        L2f:
            int r2 = r4.s
            if (r3 >= r2) goto L41
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r2 = r4.t
            r2 = r2[r3]
            int r2 = r2.b(r0)
            if (r2 <= r1) goto L3e
            r1 = r2
        L3e:
            int r3 = r3 + 1
            goto L2f
        L41:
            int r0 = r0 - r1
            if (r0 >= 0) goto L45
            goto L13
        L45:
            int r1 = r6.g
            int r6 = r6.f803b
            int r6 = java.lang.Math.min(r0, r6)
            int r6 = r1 - r6
            goto L15
        L50:
            int r0 = r6.g
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r1 = r4.t
            r1 = r1[r2]
            int r1 = r1.a(r0)
        L5a:
            int r2 = r4.s
            if (r3 >= r2) goto L6c
            androidx.recyclerview.widget.StaggeredGridLayoutManager$f[] r2 = r4.t
            r2 = r2[r3]
            int r2 = r2.a(r0)
            if (r2 >= r1) goto L69
            r1 = r2
        L69:
            int r3 = r3 + 1
            goto L5a
        L6c:
            int r0 = r6.g
            int r1 = r1 - r0
            if (r1 >= 0) goto L72
            goto L19
        L72:
            int r0 = r6.f
            int r6 = r6.f803b
            int r6 = java.lang.Math.min(r1, r6)
            int r6 = r6 + r0
            goto L1b
        L7c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.a(b.j.c.t$r, b.j.c.n):void");
    }

    @Override // b.j.c.t.l
    public void a(Rect rect, int i, int i2) {
        int a2;
        int a3;
        int l = l() + k();
        int j = j() + m();
        if (this.w == 1) {
            a3 = t.l.a(i2, rect.height() + j, h());
            a2 = t.l.a(i, (this.x * this.s) + l, i());
        } else {
            a2 = t.l.a(i, rect.width() + l, i());
            a3 = t.l.a(i2, (this.x * this.s) + j, h());
        }
        this.f825b.setMeasuredDimension(a2, a3);
    }

    public final void a(f fVar, int i, int i2) {
        int i3 = fVar.f242d;
        if (i == -1) {
            int i4 = fVar.f240b;
            if (i4 == Integer.MIN_VALUE) {
                fVar.b();
                i4 = fVar.f240b;
            }
            if (i4 + i3 > i2) {
                return;
            }
        } else {
            int i5 = fVar.f241c;
            if (i5 == Integer.MIN_VALUE) {
                fVar.a();
                i5 = fVar.f241c;
            }
            if (i5 - i3 < i2) {
                return;
            }
        }
        this.B.set(fVar.e, false);
    }
}
