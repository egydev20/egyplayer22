package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import b.j.c.m;
import b.j.c.s;
import b.j.c.t;
import java.util.List;

/* loaded from: classes.dex */
public class LinearLayoutManager extends t.l implements t.v.b {
    public int s;
    public c t;
    public s u;
    public boolean v;
    public boolean w;
    public boolean x = false;
    public boolean y = false;
    public boolean z = true;
    public int A = -1;
    public int B = Integer.MIN_VALUE;
    public d C = null;
    public final a D = new a();
    public final b E = new b();
    public int F = 2;

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public s f211a;

        /* renamed from: b, reason: collision with root package name */
        public int f212b;

        /* renamed from: c, reason: collision with root package name */
        public int f213c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f214d;
        public boolean e;

        public a() {
            b();
        }

        public void a() {
            this.f213c = this.f214d ? this.f211a.b() : this.f211a.f();
        }

        public void a(View view, int i) {
            if (this.f214d) {
                this.f213c = this.f211a.h() + this.f211a.a(view);
            } else {
                this.f213c = this.f211a.d(view);
            }
            this.f212b = i;
        }

        public void b() {
            this.f212b = -1;
            this.f213c = Integer.MIN_VALUE;
            this.f214d = false;
            this.e = false;
        }

        public void b(View view, int i) {
            int min;
            int h = this.f211a.h();
            if (h >= 0) {
                a(view, i);
                return;
            }
            this.f212b = i;
            if (this.f214d) {
                int b2 = (this.f211a.b() - h) - this.f211a.a(view);
                this.f213c = this.f211a.b() - b2;
                if (b2 <= 0) {
                    return;
                }
                int b3 = this.f213c - this.f211a.b(view);
                int f = this.f211a.f();
                int min2 = b3 - (Math.min(this.f211a.d(view) - f, 0) + f);
                if (min2 >= 0) {
                    return;
                }
                min = Math.min(b2, -min2) + this.f213c;
            } else {
                int d2 = this.f211a.d(view);
                int f2 = d2 - this.f211a.f();
                this.f213c = d2;
                if (f2 <= 0) {
                    return;
                }
                int b4 = (this.f211a.b() - Math.min(0, (this.f211a.b() - h) - this.f211a.a(view))) - (this.f211a.b(view) + d2);
                if (b4 >= 0) {
                    return;
                } else {
                    min = this.f213c - Math.min(f2, -b4);
                }
            }
            this.f213c = min;
        }

        public String toString() {
            StringBuilder a2 = c.a.b.a.a.a("AnchorInfo{mPosition=");
            a2.append(this.f212b);
            a2.append(", mCoordinate=");
            a2.append(this.f213c);
            a2.append(", mLayoutFromEnd=");
            a2.append(this.f214d);
            a2.append(", mValid=");
            a2.append(this.e);
            a2.append('}');
            return a2.toString();
        }
    }

    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public int f215a;

        /* renamed from: b, reason: collision with root package name */
        public boolean f216b;

        /* renamed from: c, reason: collision with root package name */
        public boolean f217c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f218d;
    }

    /* loaded from: classes.dex */
    public static class d implements Parcelable {
        public static final Parcelable.Creator<d> CREATOR = new a();

        /* renamed from: b, reason: collision with root package name */
        public int f223b;

        /* renamed from: c, reason: collision with root package name */
        public int f224c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f225d;

        /* loaded from: classes.dex */
        public static class a implements Parcelable.Creator<d> {
            @Override // android.os.Parcelable.Creator
            public d createFromParcel(Parcel parcel) {
                return new d(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public d[] newArray(int i) {
                return new d[i];
            }
        }

        public d() {
        }

        public d(Parcel parcel) {
            this.f223b = parcel.readInt();
            this.f224c = parcel.readInt();
            this.f225d = parcel.readInt() == 1;
        }

        public d(d dVar) {
            this.f223b = dVar.f223b;
            this.f224c = dVar.f224c;
            this.f225d = dVar.f225d;
        }

        public boolean c() {
            return this.f223b >= 0;
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f223b);
            parcel.writeInt(this.f224c);
            parcel.writeInt(this.f225d ? 1 : 0);
        }
    }

    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i, int i2) {
        this.s = 1;
        this.w = false;
        t.l.d a2 = t.l.a(context, attributeSet, i, i2);
        int i3 = a2.f830a;
        if (i3 != 0 && i3 != 1) {
            throw new IllegalArgumentException(c.a.b.a.a.a("invalid orientation:", i3));
        }
        a((String) null);
        if (i3 != this.s || this.u == null) {
            s a3 = s.a(this, i3);
            this.u = a3;
            this.D.f211a = a3;
            this.s = i3;
            r();
        }
        boolean z = a2.f832c;
        a((String) null);
        if (z != this.w) {
            this.w = z;
            r();
        }
        a(a2.f833d);
    }

    @Override // b.j.c.t.l
    public int a(int i, t.r rVar, t.w wVar) {
        if (this.s == 1) {
            return 0;
        }
        return c(i, rVar, wVar);
    }

    public final int a(int i, t.r rVar, t.w wVar, boolean z) {
        int b2;
        int b3 = this.u.b() - i;
        if (b3 <= 0) {
            return 0;
        }
        int i2 = -c(-b3, rVar, wVar);
        int i3 = i + i2;
        if (!z || (b2 = this.u.b() - i3) <= 0) {
            return i2;
        }
        this.u.a(b2);
        return b2 + i2;
    }

    @Override // b.j.c.t.l
    public int a(t.w wVar) {
        return h(wVar);
    }

    @Override // b.j.c.t.v.b
    public PointF a(int i) {
        if (d() == 0) {
            return null;
        }
        int i2 = (i < j(c(0))) != this.x ? -1 : 1;
        return this.s == 0 ? new PointF(i2, 0.0f) : new PointF(0.0f, i2);
    }

    public View a(int i, int i2, boolean z, boolean z2) {
        u();
        return (this.s == 0 ? this.e : this.f).a(i, i2, z ? 24579 : 320, z2 ? 320 : 0);
    }

    public View a(t.r rVar, t.w wVar, int i, int i2, int i3) {
        u();
        int f = this.u.f();
        int b2 = this.u.b();
        int i4 = i2 > i ? 1 : -1;
        View view = null;
        View view2 = null;
        while (i != i2) {
            View c2 = c(i);
            int j = j(c2);
            if (j >= 0 && j < i3) {
                if (((t.m) c2.getLayoutParams()).d()) {
                    if (view2 == null) {
                        view2 = c2;
                    }
                } else {
                    if (this.u.d(c2) < b2 && this.u.a(c2) >= f) {
                        return c2;
                    }
                    if (view == null) {
                        view = c2;
                    }
                }
            }
            i += i4;
        }
        return view != null ? view : view2;
    }

    public final View a(boolean z, boolean z2) {
        int d2;
        int i;
        if (this.x) {
            d2 = 0;
            i = d();
        } else {
            d2 = d() - 1;
            i = -1;
        }
        return a(d2, i, z, z2);
    }

    @Override // b.j.c.t.l
    public void a(int i, int i2, t.w wVar, t.l.c cVar) {
        if (this.s != 0) {
            i = i2;
        }
        if (d() == 0 || i == 0) {
            return;
        }
        u();
        a(i > 0 ? 1 : -1, Math.abs(i), true, wVar);
        a(wVar, this.t, cVar);
    }

    public final void a(int i, int i2, boolean z, t.w wVar) {
        int f;
        this.t.l = y();
        this.t.h = k(wVar);
        c cVar = this.t;
        cVar.f = i;
        if (i == 1) {
            cVar.h = this.u.c() + cVar.h;
            View v = v();
            this.t.e = this.x ? -1 : 1;
            c cVar2 = this.t;
            int j = j(v);
            c cVar3 = this.t;
            cVar2.f222d = j + cVar3.e;
            cVar3.f220b = this.u.a(v);
            f = this.u.a(v) - this.u.b();
        } else {
            View w = w();
            c cVar4 = this.t;
            cVar4.h = this.u.f() + cVar4.h;
            this.t.e = this.x ? 1 : -1;
            c cVar5 = this.t;
            int j2 = j(w);
            c cVar6 = this.t;
            cVar5.f222d = j2 + cVar6.e;
            cVar6.f220b = this.u.d(w);
            f = (-this.u.d(w)) + this.u.f();
        }
        c cVar7 = this.t;
        cVar7.f221c = i2;
        if (z) {
            cVar7.f221c = i2 - f;
        }
        this.t.g = f;
    }

    @Override // b.j.c.t.l
    public void a(int i, t.l.c cVar) {
        boolean z;
        int i2;
        d dVar = this.C;
        if (dVar == null || !dVar.c()) {
            z();
            z = this.x;
            i2 = this.A;
            if (i2 == -1) {
                i2 = z ? i - 1 : 0;
            }
        } else {
            d dVar2 = this.C;
            z = dVar2.f225d;
            i2 = dVar2.f223b;
        }
        int i3 = z ? -1 : 1;
        for (int i4 = 0; i4 < this.F && i2 >= 0 && i2 < i; i4++) {
            ((m.b) cVar).a(i2, 0);
            i2 += i3;
        }
    }

    @Override // b.j.c.t.l
    public void a(Parcelable parcelable) {
        if (parcelable instanceof d) {
            this.C = (d) parcelable;
            r();
        }
    }

    public final void a(t.r rVar, int i, int i2) {
        if (i == i2) {
            return;
        }
        if (i2 <= i) {
            while (i > i2) {
                a(i, rVar);
                i--;
            }
        } else {
            for (int i3 = i2 - 1; i3 >= i; i3--) {
                a(i3, rVar);
            }
        }
    }

    public void a(t.r rVar, t.w wVar, a aVar, int i) {
    }

    public void a(t.w wVar, c cVar, t.l.c cVar2) {
        int i = cVar.f222d;
        if (i < 0 || i >= wVar.a()) {
            return;
        }
        ((m.b) cVar2).a(i, Math.max(0, cVar.g));
    }

    @Override // b.j.c.t.l
    public void a(t tVar, t.r rVar) {
    }

    @Override // b.j.c.t.l
    public void a(String str) {
        t tVar;
        if (this.C != null || (tVar = this.f825b) == null) {
            return;
        }
        tVar.a(str);
    }

    public void a(boolean z) {
        a((String) null);
        if (this.y == z) {
            return;
        }
        this.y = z;
        r();
    }

    @Override // b.j.c.t.l
    public boolean a() {
        return this.s == 0;
    }

    @Override // b.j.c.t.l
    public int b(int i, t.r rVar, t.w wVar) {
        if (this.s == 0) {
            return 0;
        }
        return c(i, rVar, wVar);
    }

    public final int b(int i, t.r rVar, t.w wVar, boolean z) {
        int f;
        int f2 = i - this.u.f();
        if (f2 <= 0) {
            return 0;
        }
        int i2 = -c(f2, rVar, wVar);
        int i3 = i + i2;
        if (!z || (f = i3 - this.u.f()) <= 0) {
            return i2;
        }
        this.u.a(-f);
        return i2 - f;
    }

    @Override // b.j.c.t.l
    public int b(t.w wVar) {
        return i(wVar);
    }

    @Override // b.j.c.t.l
    public View b(int i) {
        int d2 = d();
        if (d2 == 0) {
            return null;
        }
        int j = i - j(c(0));
        if (j >= 0 && j < d2) {
            View c2 = c(j);
            if (j(c2) == i) {
                return c2;
            }
        }
        return super.b(i);
    }

    public final View b(boolean z, boolean z2) {
        int i;
        int d2;
        if (this.x) {
            i = d() - 1;
            d2 = -1;
        } else {
            i = 0;
            d2 = d();
        }
        return a(i, d2, z, z2);
    }

    @Override // b.j.c.t.l
    public boolean b() {
        return this.s == 1;
    }

    public int c(int i, t.r rVar, t.w wVar) {
        if (d() == 0 || i == 0) {
            return 0;
        }
        this.t.f219a = true;
        u();
        int i2 = i > 0 ? 1 : -1;
        int abs = Math.abs(i);
        a(i2, abs, true, wVar);
        c cVar = this.t;
        int a2 = a(rVar, cVar, wVar, false) + cVar.g;
        if (a2 < 0) {
            return 0;
        }
        if (abs > a2) {
            i = i2 * a2;
        }
        this.u.a(-i);
        this.t.j = i;
        return i;
    }

    @Override // b.j.c.t.l
    public int c(t.w wVar) {
        return j(wVar);
    }

    public View c(int i, int i2) {
        int i3;
        int i4;
        u();
        if ((i2 > i ? (char) 1 : i2 < i ? (char) 65535 : (char) 0) == 0) {
            return c(i);
        }
        if (this.u.d(c(i)) < this.u.f()) {
            i3 = 16644;
            i4 = 16388;
        } else {
            i3 = 4161;
            i4 = 4097;
        }
        return (this.s == 0 ? this.e : this.f).a(i, i2, i3, i4);
    }

    @Override // b.j.c.t.l
    public t.m c() {
        return new t.m(-2, -2);
    }

    /* JADX WARN: Removed duplicated region for block: B:132:0x0177  */
    /* JADX WARN: Removed duplicated region for block: B:147:0x0224  */
    @Override // b.j.c.t.l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void c(b.j.c.t.r r17, b.j.c.t.w r18) {
        /*
            Method dump skipped, instructions count: 1053
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.LinearLayoutManager.c(b.j.c.t$r, b.j.c.t$w):void");
    }

    @Override // b.j.c.t.l
    public int d(t.w wVar) {
        return h(wVar);
    }

    public final View d(t.r rVar, t.w wVar) {
        return a(rVar, wVar, 0, d(), wVar.a());
    }

    public final void d(int i, int i2) {
        this.t.f221c = this.u.b() - i2;
        this.t.e = this.x ? -1 : 1;
        c cVar = this.t;
        cVar.f222d = i;
        cVar.f = 1;
        cVar.f220b = i2;
        cVar.g = Integer.MIN_VALUE;
    }

    @Override // b.j.c.t.l
    public int e(t.w wVar) {
        return i(wVar);
    }

    public final View e(t.r rVar, t.w wVar) {
        return a(rVar, wVar, d() - 1, -1, wVar.a());
    }

    public final void e(int i, int i2) {
        this.t.f221c = i2 - this.u.f();
        c cVar = this.t;
        cVar.f222d = i;
        cVar.e = this.x ? 1 : -1;
        c cVar2 = this.t;
        cVar2.f = -1;
        cVar2.f220b = i2;
        cVar2.g = Integer.MIN_VALUE;
    }

    @Override // b.j.c.t.l
    public int f(t.w wVar) {
        return j(wVar);
    }

    @Override // b.j.c.t.l
    public void g(t.w wVar) {
        this.C = null;
        this.A = -1;
        this.B = Integer.MIN_VALUE;
        this.D.b();
    }

    public final int h(t.w wVar) {
        if (d() == 0) {
            return 0;
        }
        u();
        return a.a.a.a.a.a(wVar, this.u, b(!this.z, true), a(!this.z, true), this, this.z);
    }

    @Override // b.j.c.t.l
    public void h(int i) {
        this.A = i;
        this.B = Integer.MIN_VALUE;
        d dVar = this.C;
        if (dVar != null) {
            dVar.f223b = -1;
        }
        r();
    }

    public int i(int i) {
        return i != 1 ? i != 2 ? i != 17 ? i != 33 ? i != 66 ? (i == 130 && this.s == 1) ? 1 : Integer.MIN_VALUE : this.s == 0 ? 1 : Integer.MIN_VALUE : this.s == 1 ? -1 : Integer.MIN_VALUE : this.s == 0 ? -1 : Integer.MIN_VALUE : (this.s != 1 && x()) ? -1 : 1 : (this.s != 1 && x()) ? 1 : -1;
    }

    public final int i(t.w wVar) {
        if (d() == 0) {
            return 0;
        }
        u();
        return a.a.a.a.a.a(wVar, this.u, b(!this.z, true), a(!this.z, true), this, this.z, this.x);
    }

    public final int j(t.w wVar) {
        if (d() == 0) {
            return 0;
        }
        u();
        return a.a.a.a.a.b(wVar, this.u, b(!this.z, true), a(!this.z, true), this, this.z);
    }

    public int k(t.w wVar) {
        if (wVar.f858a != -1) {
            return this.u.g();
        }
        return 0;
    }

    @Override // b.j.c.t.l
    public boolean o() {
        return true;
    }

    @Override // b.j.c.t.l
    public Parcelable q() {
        if (this.C != null) {
            return new d(this.C);
        }
        d dVar = new d();
        if (d() > 0) {
            u();
            boolean z = this.v ^ this.x;
            dVar.f225d = z;
            if (z) {
                View v = v();
                dVar.f224c = this.u.b() - this.u.a(v);
                dVar.f223b = j(v);
            } else {
                View w = w();
                dVar.f223b = j(w);
                dVar.f224c = this.u.d(w) - this.u.f();
            }
        } else {
            dVar.f223b = -1;
        }
        return dVar;
    }

    @Override // b.j.c.t.l
    public boolean s() {
        boolean z;
        if (this.p != 1073741824 && this.o != 1073741824) {
            int d2 = d();
            int i = 0;
            while (true) {
                if (i >= d2) {
                    z = false;
                    break;
                }
                ViewGroup.LayoutParams layoutParams = c(i).getLayoutParams();
                if (layoutParams.width < 0 && layoutParams.height < 0) {
                    z = true;
                    break;
                }
                i++;
            }
            if (z) {
                return true;
            }
        }
        return false;
    }

    @Override // b.j.c.t.l
    public boolean t() {
        return this.C == null && this.v == this.y;
    }

    public void u() {
        if (this.t == null) {
            this.t = new c();
        }
    }

    public final View v() {
        return c(this.x ? 0 : d() - 1);
    }

    public final View w() {
        return c(this.x ? d() - 1 : 0);
    }

    public boolean x() {
        return g() == 1;
    }

    public boolean y() {
        return this.u.d() == 0 && this.u.a() == 0;
    }

    public final void z() {
        this.x = (this.s == 1 || !x()) ? this.w : !this.w;
    }

    /* loaded from: classes.dex */
    public static class c {

        /* renamed from: b, reason: collision with root package name */
        public int f220b;

        /* renamed from: c, reason: collision with root package name */
        public int f221c;

        /* renamed from: d, reason: collision with root package name */
        public int f222d;
        public int e;
        public int f;
        public int g;
        public boolean i;
        public int j;
        public boolean l;

        /* renamed from: a, reason: collision with root package name */
        public boolean f219a = true;
        public int h = 0;
        public List<t.z> k = null;

        public void a(View view) {
            int b2;
            int size = this.k.size();
            View view2 = null;
            int i = Integer.MAX_VALUE;
            for (int i2 = 0; i2 < size; i2++) {
                View view3 = this.k.get(i2).f865a;
                t.m mVar = (t.m) view3.getLayoutParams();
                if (view3 != view && !mVar.d() && (b2 = (mVar.b() - this.f222d) * this.e) >= 0 && b2 < i) {
                    view2 = view3;
                    if (b2 == 0) {
                        break;
                    } else {
                        i = b2;
                    }
                }
            }
            this.f222d = view2 == null ? -1 : ((t.m) view2.getLayoutParams()).b();
        }

        public boolean a(t.w wVar) {
            int i = this.f222d;
            return i >= 0 && i < wVar.a();
        }

        public View a(t.r rVar) {
            List<t.z> list = this.k;
            if (list != null) {
                int size = list.size();
                for (int i = 0; i < size; i++) {
                    View view = this.k.get(i).f865a;
                    t.m mVar = (t.m) view.getLayoutParams();
                    if (!mVar.d() && this.f222d == mVar.b()) {
                        a(view);
                        return view;
                    }
                }
                return null;
            }
            View b2 = rVar.b(this.f222d);
            this.f222d += this.e;
            return b2;
        }
    }

    public int a(t.r rVar, c cVar, t.w wVar, boolean z) {
        int i = cVar.f221c;
        int i2 = cVar.g;
        if (i2 != Integer.MIN_VALUE) {
            if (i < 0) {
                cVar.g = i2 + i;
            }
            a(rVar, cVar);
        }
        int i3 = cVar.f221c + cVar.h;
        b bVar = this.E;
        while (true) {
            if ((!cVar.l && i3 <= 0) || !cVar.a(wVar)) {
                break;
            }
            bVar.f215a = 0;
            bVar.f216b = false;
            bVar.f217c = false;
            bVar.f218d = false;
            a(rVar, wVar, cVar, bVar);
            if (!bVar.f216b) {
                cVar.f220b = (bVar.f215a * cVar.f) + cVar.f220b;
                if (!bVar.f217c || this.t.k != null || !wVar.g) {
                    int i4 = cVar.f221c;
                    int i5 = bVar.f215a;
                    cVar.f221c = i4 - i5;
                    i3 -= i5;
                }
                int i6 = cVar.g;
                if (i6 != Integer.MIN_VALUE) {
                    int i7 = i6 + bVar.f215a;
                    cVar.g = i7;
                    int i8 = cVar.f221c;
                    if (i8 < 0) {
                        cVar.g = i7 + i8;
                    }
                    a(rVar, cVar);
                }
                if (z && bVar.f218d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i - cVar.f221c;
    }

    public void a(t.r rVar, t.w wVar, c cVar, b bVar) {
        int i;
        int i2;
        int i3;
        int i4;
        int c2;
        View a2 = cVar.a(rVar);
        if (a2 == null) {
            bVar.f216b = true;
            return;
        }
        t.m mVar = (t.m) a2.getLayoutParams();
        if (cVar.k == null) {
            if (this.x == (cVar.f == -1)) {
                a(a2, -1, false);
            } else {
                a(a2, 0, false);
            }
        } else {
            if (this.x == (cVar.f == -1)) {
                a(a2, -1, true);
            } else {
                a(a2, 0, true);
            }
        }
        t.m mVar2 = (t.m) a2.getLayoutParams();
        Rect d2 = this.f825b.d(a2);
        int i5 = d2.left + d2.right + 0;
        int i6 = d2.top + d2.bottom + 0;
        int a3 = t.l.a(this.q, this.o, l() + k() + ((ViewGroup.MarginLayoutParams) mVar2).leftMargin + ((ViewGroup.MarginLayoutParams) mVar2).rightMargin + i5, ((ViewGroup.MarginLayoutParams) mVar2).width, a());
        int a4 = t.l.a(this.r, this.p, j() + m() + ((ViewGroup.MarginLayoutParams) mVar2).topMargin + ((ViewGroup.MarginLayoutParams) mVar2).bottomMargin + i6, ((ViewGroup.MarginLayoutParams) mVar2).height, b());
        if (a(a2, a3, a4, mVar2)) {
            a2.measure(a3, a4);
        }
        bVar.f215a = this.u.b(a2);
        if (this.s == 1) {
            if (x()) {
                c2 = this.q - l();
                i4 = c2 - this.u.c(a2);
            } else {
                i4 = k();
                c2 = this.u.c(a2) + i4;
            }
            int i7 = cVar.f;
            int i8 = cVar.f220b;
            if (i7 == -1) {
                i3 = i8;
                i2 = c2;
                i = i8 - bVar.f215a;
            } else {
                i = i8;
                i2 = c2;
                i3 = bVar.f215a + i8;
            }
        } else {
            int m = m();
            int c3 = this.u.c(a2) + m;
            int i9 = cVar.f;
            int i10 = cVar.f220b;
            if (i9 == -1) {
                i2 = i10;
                i = m;
                i3 = c3;
                i4 = i10 - bVar.f215a;
            } else {
                i = m;
                i2 = bVar.f215a + i10;
                i3 = c3;
                i4 = i10;
            }
        }
        a(a2, i4, i, i2, i3);
        if (mVar.d() || mVar.c()) {
            bVar.f217c = true;
        }
        bVar.f218d = a2.hasFocusable();
    }

    @Override // b.j.c.t.l
    public View a(View view, int i, t.r rVar, t.w wVar) {
        int i2;
        View c2;
        z();
        if (d() == 0 || (i2 = i(i)) == Integer.MIN_VALUE) {
            return null;
        }
        u();
        u();
        a(i2, (int) (this.u.g() * 0.33333334f), false, wVar);
        c cVar = this.t;
        cVar.g = Integer.MIN_VALUE;
        cVar.f219a = false;
        a(rVar, cVar, wVar, true);
        if (i2 == -1) {
            if (this.x) {
                c2 = c(d() - 1, -1);
            } else {
                c2 = c(0, d());
            }
        } else if (this.x) {
            c2 = c(0, d());
        } else {
            c2 = c(d() - 1, -1);
        }
        View w = i2 == -1 ? w() : v();
        if (!w.hasFocusable()) {
            return c2;
        }
        if (c2 == null) {
            return null;
        }
        return w;
    }

    @Override // b.j.c.t.l
    public void a(AccessibilityEvent accessibilityEvent) {
        super.a(accessibilityEvent);
        if (d() > 0) {
            View a2 = a(0, d(), false, true);
            accessibilityEvent.setFromIndex(a2 == null ? -1 : j(a2));
            View a3 = a(d() - 1, -1, false, true);
            accessibilityEvent.setToIndex(a3 != null ? j(a3) : -1);
        }
    }

    public final void a(t.r rVar, c cVar) {
        if (!cVar.f219a || cVar.l) {
            return;
        }
        int i = cVar.f;
        int i2 = cVar.g;
        if (i != -1) {
            if (i2 < 0) {
                return;
            }
            int d2 = d();
            if (!this.x) {
                for (int i3 = 0; i3 < d2; i3++) {
                    View c2 = c(i3);
                    if (this.u.a(c2) > i2 || this.u.e(c2) > i2) {
                        a(rVar, 0, i3);
                        return;
                    }
                }
                return;
            }
            int i4 = d2 - 1;
            for (int i5 = i4; i5 >= 0; i5--) {
                View c3 = c(i5);
                if (this.u.a(c3) > i2 || this.u.e(c3) > i2) {
                    a(rVar, i4, i5);
                    return;
                }
            }
            return;
        }
        int d3 = d();
        if (i2 < 0) {
            return;
        }
        int a2 = this.u.a() - i2;
        if (this.x) {
            for (int i6 = 0; i6 < d3; i6++) {
                View c4 = c(i6);
                if (this.u.d(c4) < a2 || this.u.f(c4) < a2) {
                    a(rVar, 0, i6);
                    return;
                }
            }
            return;
        }
        int i7 = d3 - 1;
        for (int i8 = i7; i8 >= 0; i8--) {
            View c5 = c(i8);
            if (this.u.d(c5) < a2 || this.u.f(c5) < a2) {
                a(rVar, i7, i8);
                return;
            }
        }
    }
}
