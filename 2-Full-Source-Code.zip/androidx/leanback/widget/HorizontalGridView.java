package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import b.g.l;
import b.g.n.a;
import b.g.n.e;

/* loaded from: classes.dex */
public class HorizontalGridView extends a {
    public boolean R0;
    public boolean S0;
    public Paint T0;
    public Bitmap U0;
    public LinearGradient V0;
    public int W0;
    public int X0;
    public Bitmap Y0;
    public LinearGradient Z0;
    public int a1;
    public int b1;
    public Rect c1;

    public HorizontalGridView(Context context) {
        this(context, null);
    }

    public HorizontalGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public HorizontalGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.T0 = new Paint();
        this.c1 = new Rect();
        this.H0.p(0);
        a(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.lbHorizontalGridView);
        setRowHeight(obtainStyledAttributes);
        setNumRows(obtainStyledAttributes.getInt(l.lbHorizontalGridView_numberOfRows, 1));
        obtainStyledAttributes.recycle();
        y();
        Paint paint = new Paint();
        this.T0 = paint;
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
    }

    private Bitmap getTempBitmapHigh() {
        Bitmap bitmap = this.Y0;
        if (bitmap == null || bitmap.getWidth() != this.a1 || this.Y0.getHeight() != getHeight()) {
            this.Y0 = Bitmap.createBitmap(this.a1, getHeight(), Bitmap.Config.ARGB_8888);
        }
        return this.Y0;
    }

    private Bitmap getTempBitmapLow() {
        Bitmap bitmap = this.U0;
        if (bitmap == null || bitmap.getWidth() != this.W0 || this.U0.getHeight() != getHeight()) {
            this.U0 = Bitmap.createBitmap(this.W0, getHeight(), Bitmap.Config.ARGB_8888);
        }
        return this.U0;
    }

    @Override // b.j.c.t, android.view.View
    public void draw(Canvas canvas) {
        boolean z;
        boolean z2 = true;
        if (this.R0) {
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = getChildAt(i);
                if (this.H0 != null) {
                    e.d dVar = (e.d) childAt.getLayoutParams();
                    if (dVar != null) {
                        if (childAt.getLeft() + dVar.e < getPaddingLeft() - this.X0) {
                            z = true;
                            break;
                        }
                    } else {
                        throw null;
                    }
                } else {
                    throw null;
                }
            }
        }
        z = false;
        if (this.S0) {
            for (int childCount2 = getChildCount() - 1; childCount2 >= 0; childCount2--) {
                View childAt2 = getChildAt(childCount2);
                if (this.H0 != null) {
                    e.d dVar2 = (e.d) childAt2.getLayoutParams();
                    if (dVar2 != null) {
                        if (childAt2.getRight() - dVar2.g > (getWidth() - getPaddingRight()) + this.b1) {
                            break;
                        }
                    } else {
                        throw null;
                    }
                } else {
                    throw null;
                }
            }
        }
        z2 = false;
        if (!z) {
            this.U0 = null;
        }
        if (!z2) {
            this.Y0 = null;
        }
        if (!z && !z2) {
            super.draw(canvas);
            return;
        }
        int paddingLeft = this.R0 ? (getPaddingLeft() - this.X0) - this.W0 : 0;
        int width = this.S0 ? (getWidth() - getPaddingRight()) + this.b1 + this.a1 : getWidth();
        int save = canvas.save();
        canvas.clipRect((this.R0 ? this.W0 : 0) + paddingLeft, 0, width - (this.S0 ? this.a1 : 0), getHeight());
        super.draw(canvas);
        canvas.restoreToCount(save);
        Canvas canvas2 = new Canvas();
        Rect rect = this.c1;
        rect.top = 0;
        rect.bottom = getHeight();
        if (z && this.W0 > 0) {
            Bitmap tempBitmapLow = getTempBitmapLow();
            tempBitmapLow.eraseColor(0);
            canvas2.setBitmap(tempBitmapLow);
            int save2 = canvas2.save();
            canvas2.clipRect(0, 0, this.W0, getHeight());
            float f = -paddingLeft;
            canvas2.translate(f, 0.0f);
            super.draw(canvas2);
            canvas2.restoreToCount(save2);
            this.T0.setShader(this.V0);
            canvas2.drawRect(0.0f, 0.0f, this.W0, getHeight(), this.T0);
            Rect rect2 = this.c1;
            rect2.left = 0;
            rect2.right = this.W0;
            canvas.translate(paddingLeft, 0.0f);
            Rect rect3 = this.c1;
            canvas.drawBitmap(tempBitmapLow, rect3, rect3, (Paint) null);
            canvas.translate(f, 0.0f);
        }
        if (!z2 || this.a1 <= 0) {
            return;
        }
        Bitmap tempBitmapHigh = getTempBitmapHigh();
        tempBitmapHigh.eraseColor(0);
        canvas2.setBitmap(tempBitmapHigh);
        int save3 = canvas2.save();
        canvas2.clipRect(0, 0, this.a1, getHeight());
        canvas2.translate(-(width - this.a1), 0.0f);
        super.draw(canvas2);
        canvas2.restoreToCount(save3);
        this.T0.setShader(this.Z0);
        canvas2.drawRect(0.0f, 0.0f, this.a1, getHeight(), this.T0);
        Rect rect4 = this.c1;
        rect4.left = 0;
        rect4.right = this.a1;
        canvas.translate(width - r5, 0.0f);
        Rect rect5 = this.c1;
        canvas.drawBitmap(tempBitmapHigh, rect5, rect5, (Paint) null);
        canvas.translate(-(width - this.a1), 0.0f);
    }

    public final boolean getFadingLeftEdge() {
        return this.R0;
    }

    public final int getFadingLeftEdgeLength() {
        return this.W0;
    }

    public final int getFadingLeftEdgeOffset() {
        return this.X0;
    }

    public final boolean getFadingRightEdge() {
        return this.S0;
    }

    public final int getFadingRightEdgeLength() {
        return this.a1;
    }

    public final int getFadingRightEdgeOffset() {
        return this.b1;
    }

    public final void setFadingLeftEdge(boolean z) {
        if (this.R0 != z) {
            this.R0 = z;
            if (!z) {
                this.U0 = null;
            }
            invalidate();
            y();
        }
    }

    public final void setFadingLeftEdgeLength(int i) {
        if (this.W0 != i) {
            this.W0 = i;
            this.V0 = i != 0 ? new LinearGradient(0.0f, 0.0f, this.W0, 0.0f, 0, -16777216, Shader.TileMode.CLAMP) : null;
            invalidate();
        }
    }

    public final void setFadingLeftEdgeOffset(int i) {
        if (this.X0 != i) {
            this.X0 = i;
            invalidate();
        }
    }

    public final void setFadingRightEdge(boolean z) {
        if (this.S0 != z) {
            this.S0 = z;
            if (!z) {
                this.Y0 = null;
            }
            invalidate();
            y();
        }
    }

    public final void setFadingRightEdgeLength(int i) {
        if (this.a1 != i) {
            this.a1 = i;
            this.Z0 = i != 0 ? new LinearGradient(0.0f, 0.0f, this.a1, 0.0f, -16777216, 0, Shader.TileMode.CLAMP) : null;
            invalidate();
        }
    }

    public final void setFadingRightEdgeOffset(int i) {
        if (this.b1 != i) {
            this.b1 = i;
            invalidate();
        }
    }

    public void setNumRows(int i) {
        e eVar = this.H0;
        if (eVar == null) {
            throw null;
        }
        if (i >= 0) {
            eVar.Y = i;
            requestLayout();
            return;
        }
        throw new IllegalArgumentException();
    }

    public void setRowHeight(int i) {
        this.H0.q(i);
        requestLayout();
    }

    public void setRowHeight(TypedArray typedArray) {
        if (typedArray.peekValue(l.lbHorizontalGridView_rowHeight) != null) {
            setRowHeight(typedArray.getLayoutDimension(l.lbHorizontalGridView_rowHeight, 0));
        }
    }

    public final void y() {
        if (this.R0 || this.S0) {
            setLayerType(2, null);
            setWillNotDraw(false);
        } else {
            setLayerType(0, null);
            setWillNotDraw(true);
        }
    }
}
