package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class ControlBar extends LinearLayout {

    /* renamed from: b, reason: collision with root package name */
    public int f127b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f128c;

    public ControlBar(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f127b = -1;
        this.f128c = true;
    }

    public ControlBar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f127b = -1;
        this.f128c = true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i, int i2) {
        int childCount;
        if (i != 33 && i != 130) {
            super.addFocusables(arrayList, i, i2);
            return;
        }
        int i3 = this.f127b;
        if (i3 >= 0 && i3 < getChildCount()) {
            childCount = this.f127b;
        } else if (getChildCount() <= 0) {
            return;
        } else {
            childCount = this.f128c ? getChildCount() / 2 : 0;
        }
        arrayList.add(getChildAt(childCount));
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
    }

    @Override // android.view.ViewGroup
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        int childCount;
        if (getChildCount() > 0) {
            int i2 = this.f127b;
            if (i2 < 0 || i2 >= getChildCount()) {
                childCount = this.f128c ? getChildCount() / 2 : 0;
            } else {
                childCount = this.f127b;
            }
            if (getChildAt(childCount).requestFocus(i, rect)) {
                return true;
            }
        }
        return super.onRequestFocusInDescendants(i, rect);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        this.f127b = indexOfChild(view);
    }
}
