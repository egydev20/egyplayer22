package androidx.leanback.widget;

import android.animation.ArgbEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import b.g.d;
import b.g.e;
import b.g.f;
import b.g.g;
import b.g.h;
import b.g.l;

/* loaded from: classes.dex */
public class SearchOrbView extends FrameLayout implements View.OnClickListener {

    /* renamed from: b, reason: collision with root package name */
    public View.OnClickListener f175b;

    /* renamed from: c, reason: collision with root package name */
    public View f176c;

    /* renamed from: d, reason: collision with root package name */
    public View f177d;
    public ImageView e;
    public Drawable f;
    public c g;
    public final float h;
    public final int i;
    public final int j;
    public final float k;
    public final float l;
    public ValueAnimator m;
    public boolean n;
    public boolean o;
    public final ArgbEvaluator p;
    public final ValueAnimator.AnimatorUpdateListener q;
    public ValueAnimator r;
    public final ValueAnimator.AnimatorUpdateListener s;

    /* loaded from: classes.dex */
    public class a implements ValueAnimator.AnimatorUpdateListener {
        public a() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            SearchOrbView.this.setOrbViewColor(((Integer) valueAnimator.getAnimatedValue()).intValue());
        }
    }

    /* loaded from: classes.dex */
    public class b implements ValueAnimator.AnimatorUpdateListener {
        public b() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            SearchOrbView.this.setSearchOrbZ(valueAnimator.getAnimatedFraction());
        }
    }

    /* loaded from: classes.dex */
    public static class c {

        /* renamed from: a, reason: collision with root package name */
        public int f180a;

        /* renamed from: b, reason: collision with root package name */
        public int f181b;

        /* renamed from: c, reason: collision with root package name */
        public int f182c;

        public c(int i, int i2, int i3) {
            this.f180a = i;
            if (i2 == i) {
                i2 = Color.argb((int) ((Color.alpha(i) * 0.85f) + 38.25f), (int) ((Color.red(i) * 0.85f) + 38.25f), (int) ((Color.green(i) * 0.85f) + 38.25f), (int) ((Color.blue(i) * 0.85f) + 38.25f));
            }
            this.f181b = i2;
            this.f182c = i3;
        }
    }

    public SearchOrbView(Context context) {
        this(context, null);
    }

    public SearchOrbView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.g.a.searchOrbViewStyle);
    }

    public SearchOrbView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.p = new ArgbEvaluator();
        this.q = new a();
        this.s = new b();
        Resources resources = context.getResources();
        View inflate = ((LayoutInflater) context.getSystemService("layout_inflater")).inflate(getLayoutResourceId(), (ViewGroup) this, true);
        this.f176c = inflate;
        this.f177d = inflate.findViewById(f.search_orb);
        this.e = (ImageView) this.f176c.findViewById(f.icon);
        this.h = context.getResources().getFraction(e.lb_search_orb_focused_zoom, 1, 1);
        this.i = context.getResources().getInteger(g.lb_search_orb_pulse_duration_ms);
        this.j = context.getResources().getInteger(g.lb_search_orb_scale_duration_ms);
        this.l = context.getResources().getDimensionPixelSize(b.g.c.lb_search_orb_focused_z);
        this.k = context.getResources().getDimensionPixelSize(b.g.c.lb_search_orb_unfocused_z);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.lbSearchOrbView, i, 0);
        Drawable drawable = obtainStyledAttributes.getDrawable(l.lbSearchOrbView_searchOrbIcon);
        setOrbIcon(drawable == null ? resources.getDrawable(d.lb_ic_in_app_search) : drawable);
        int color = obtainStyledAttributes.getColor(l.lbSearchOrbView_searchOrbColor, resources.getColor(b.g.b.lb_default_search_color));
        setOrbColors(new c(color, obtainStyledAttributes.getColor(l.lbSearchOrbView_searchOrbBrightColor, color), obtainStyledAttributes.getColor(l.lbSearchOrbView_searchOrbIconColor, 0)));
        obtainStyledAttributes.recycle();
        setFocusable(true);
        setClipChildren(false);
        setOnClickListener(this);
        setSoundEffectsEnabled(false);
        setSearchOrbZ(0.0f);
        b.d.k.l.a(this.e, this.l);
    }

    public final void a() {
        ValueAnimator valueAnimator = this.m;
        if (valueAnimator != null) {
            valueAnimator.end();
            this.m = null;
        }
        if (this.n && this.o) {
            ValueAnimator ofObject = ValueAnimator.ofObject(this.p, Integer.valueOf(this.g.f180a), Integer.valueOf(this.g.f181b), Integer.valueOf(this.g.f180a));
            this.m = ofObject;
            ofObject.setRepeatCount(-1);
            this.m.setDuration(this.i * 2);
            this.m.addUpdateListener(this.q);
            this.m.start();
        }
    }

    public void a(float f) {
        this.f177d.setScaleX(f);
        this.f177d.setScaleY(f);
    }

    public void a(boolean z) {
        float f = z ? this.h : 1.0f;
        this.f176c.animate().scaleX(f).scaleY(f).setDuration(this.j).start();
        int i = this.j;
        if (this.r == null) {
            ValueAnimator ofFloat = ValueAnimator.ofFloat(0.0f, 1.0f);
            this.r = ofFloat;
            ofFloat.addUpdateListener(this.s);
        }
        ValueAnimator valueAnimator = this.r;
        if (z) {
            valueAnimator.start();
        } else {
            valueAnimator.reverse();
        }
        this.r.setDuration(i);
        this.n = z;
        a();
    }

    public float getFocusedZoom() {
        return this.h;
    }

    public int getLayoutResourceId() {
        return h.lb_search_orb;
    }

    public int getOrbColor() {
        return this.g.f180a;
    }

    public c getOrbColors() {
        return this.g;
    }

    public Drawable getOrbIcon() {
        return this.f;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.o = true;
        a();
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        View.OnClickListener onClickListener = this.f175b;
        if (onClickListener != null) {
            onClickListener.onClick(view);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        this.o = false;
        a();
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        a(z);
    }

    public void setOnOrbClickedListener(View.OnClickListener onClickListener) {
        this.f175b = onClickListener;
    }

    public void setOrbColor(int i) {
        setOrbColors(new c(i, i, 0));
    }

    public void setOrbColors(c cVar) {
        this.g = cVar;
        this.e.setColorFilter(cVar.f182c);
        if (this.m == null) {
            setOrbViewColor(this.g.f180a);
        } else {
            this.n = true;
            a();
        }
    }

    public void setOrbIcon(Drawable drawable) {
        this.f = drawable;
        this.e.setImageDrawable(drawable);
    }

    public void setOrbViewColor(int i) {
        if (this.f177d.getBackground() instanceof GradientDrawable) {
            ((GradientDrawable) this.f177d.getBackground()).setColor(i);
        }
    }

    public void setSearchOrbZ(float f) {
        View view = this.f177d;
        float f2 = this.k;
        b.d.k.l.a(view, ((this.l - f2) * f) + f2);
    }
}
