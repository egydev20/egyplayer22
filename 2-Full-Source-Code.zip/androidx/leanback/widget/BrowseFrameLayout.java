package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.widget.FrameLayout;

/* loaded from: classes.dex */
public class BrowseFrameLayout extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    public b f122b;

    /* renamed from: c, reason: collision with root package name */
    public a f123c;

    /* renamed from: d, reason: collision with root package name */
    public View.OnKeyListener f124d;

    /* loaded from: classes.dex */
    public interface a {
        void a(View view, View view2);

        boolean a(int i, Rect rect);
    }

    /* loaded from: classes.dex */
    public interface b {
        View a(View view, int i);
    }

    public BrowseFrameLayout(Context context) {
        this(context, null, 0);
    }

    public BrowseFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public BrowseFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        boolean dispatchKeyEvent = super.dispatchKeyEvent(keyEvent);
        View.OnKeyListener onKeyListener = this.f124d;
        return (onKeyListener == null || dispatchKeyEvent) ? dispatchKeyEvent : onKeyListener.onKey(getRootView(), keyEvent.getKeyCode(), keyEvent);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public View focusSearch(View view, int i) {
        View a2;
        b bVar = this.f122b;
        return (bVar == null || (a2 = bVar.a(view, i)) == null) ? super.focusSearch(view, i) : a2;
    }

    public a getOnChildFocusListener() {
        return this.f123c;
    }

    public b getOnFocusSearchListener() {
        return this.f122b;
    }

    @Override // android.view.ViewGroup
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        a aVar = this.f123c;
        if (aVar == null || !aVar.a(i, rect)) {
            return super.onRequestFocusInDescendants(i, rect);
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View view, View view2) {
        a aVar = this.f123c;
        if (aVar != null) {
            aVar.a(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    public void setOnChildFocusListener(a aVar) {
        this.f123c = aVar;
    }

    public void setOnDispatchKeyListener(View.OnKeyListener onKeyListener) {
        this.f124d = onKeyListener;
    }

    public void setOnFocusSearchListener(b bVar) {
        this.f122b = bVar;
    }
}
