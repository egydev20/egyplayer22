package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import b.g.c;

/* loaded from: classes.dex */
public class ThumbsBar extends LinearLayout {

    /* renamed from: b, reason: collision with root package name */
    public int f186b;

    /* renamed from: c, reason: collision with root package name */
    public int f187c;

    /* renamed from: d, reason: collision with root package name */
    public int f188d;
    public int e;
    public int f;
    public int g;
    public boolean h;

    public ThumbsBar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ThumbsBar(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f186b = -1;
        new SparseArray();
        this.h = false;
        this.f187c = context.getResources().getDimensionPixelSize(c.lb_playback_transport_thumbs_width);
        this.f188d = context.getResources().getDimensionPixelSize(c.lb_playback_transport_thumbs_height);
        this.f = context.getResources().getDimensionPixelSize(c.lb_playback_transport_hero_thumbs_width);
        this.e = context.getResources().getDimensionPixelSize(c.lb_playback_transport_hero_thumbs_height);
        this.g = context.getResources().getDimensionPixelSize(c.lb_playback_transport_thumbs_margin);
    }

    public final void a() {
        int i;
        while (getChildCount() > this.f186b) {
            removeView(getChildAt(getChildCount() - 1));
        }
        while (getChildCount() < this.f186b) {
            addView(new ImageView(getContext()), new LinearLayout.LayoutParams(this.f187c, this.f188d));
        }
        int heroIndex = getHeroIndex();
        for (int i2 = 0; i2 < getChildCount(); i2++) {
            View childAt = getChildAt(i2);
            LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams) childAt.getLayoutParams();
            if (heroIndex == i2) {
                layoutParams.width = this.e;
                i = this.f;
            } else {
                layoutParams.width = this.f187c;
                i = this.f188d;
            }
            layoutParams.height = i;
            childAt.setLayoutParams(layoutParams);
        }
    }

    public int getHeroIndex() {
        return getChildCount() / 2;
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        int heroIndex = getHeroIndex();
        View childAt = getChildAt(heroIndex);
        int width = (getWidth() / 2) - (childAt.getMeasuredWidth() / 2);
        int measuredWidth = (childAt.getMeasuredWidth() / 2) + (getWidth() / 2);
        childAt.layout(width, getPaddingTop(), measuredWidth, childAt.getMeasuredHeight() + getPaddingTop());
        int measuredHeight = (childAt.getMeasuredHeight() / 2) + getPaddingTop();
        for (int i5 = heroIndex - 1; i5 >= 0; i5--) {
            int i6 = width - this.g;
            View childAt2 = getChildAt(i5);
            childAt2.layout(i6 - childAt2.getMeasuredWidth(), measuredHeight - (childAt2.getMeasuredHeight() / 2), i6, (childAt2.getMeasuredHeight() / 2) + measuredHeight);
            width = i6 - childAt2.getMeasuredWidth();
        }
        while (true) {
            heroIndex++;
            if (heroIndex >= this.f186b) {
                return;
            }
            int i7 = measuredWidth + this.g;
            View childAt3 = getChildAt(heroIndex);
            childAt3.layout(i7, measuredHeight - (childAt3.getMeasuredHeight() / 2), childAt3.getMeasuredWidth() + i7, (childAt3.getMeasuredHeight() / 2) + measuredHeight);
            measuredWidth = i7 + childAt3.getMeasuredWidth();
        }
    }

    @Override // android.widget.LinearLayout, android.view.View
    public void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        int measuredWidth = getMeasuredWidth();
        if (this.h) {
            return;
        }
        int i3 = measuredWidth - this.e;
        int i4 = ((i3 + r3) - 1) / (this.f187c + this.g);
        if (i4 < 2) {
            i4 = 2;
        } else if ((i4 & 1) != 0) {
            i4++;
        }
        int i5 = i4 + 1;
        if (this.f186b != i5) {
            this.f186b = i5;
            a();
        }
    }

    public void setNumberOfThumbs(int i) {
        this.h = true;
        this.f186b = i;
        a();
    }

    public void setThumbSpace(int i) {
        this.g = i;
        requestLayout();
    }
}
