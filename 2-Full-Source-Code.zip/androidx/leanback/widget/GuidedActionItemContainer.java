package androidx.leanback.widget;

import a.a.a.a.a;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import b.g.n.l;

/* loaded from: classes.dex */
public class GuidedActionItemContainer extends l {
    public boolean e;

    public GuidedActionItemContainer(Context context) {
        this(context, null);
    }

    public GuidedActionItemContainer(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public GuidedActionItemContainer(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.e = true;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public View focusSearch(View view, int i) {
        if (this.e || !a.a(this, view)) {
            return super.focusSearch(view, i);
        }
        View focusSearch = super.focusSearch(view, i);
        if (a.a(this, focusSearch)) {
            return focusSearch;
        }
        return null;
    }
}
