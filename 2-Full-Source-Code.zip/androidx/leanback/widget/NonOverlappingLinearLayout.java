package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class NonOverlappingLinearLayout extends LinearLayout {

    /* renamed from: b, reason: collision with root package name */
    public boolean f141b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f142c;

    /* renamed from: d, reason: collision with root package name */
    public final ArrayList<ArrayList<View>> f143d;

    public NonOverlappingLinearLayout(Context context) {
        this(context, null);
    }

    public NonOverlappingLinearLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NonOverlappingLinearLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f141b = false;
        this.f143d = new ArrayList<>();
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void focusableViewAvailable(View view) {
        int i;
        if (!this.f142c) {
            super.focusableViewAvailable(view);
            return;
        }
        for (View view2 = view; view2 != this && view2 != null; view2 = (View) view2.getParent()) {
            if (view2.getParent() == this) {
                i = indexOfChild(view2);
                break;
            }
        }
        i = -1;
        if (i != -1) {
            this.f143d.get(i).add(view);
        }
    }

    @Override // android.view.View
    public boolean hasOverlappingRendering() {
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [boolean] */
    /* JADX WARN: Type inference failed for: r0v1, types: [int] */
    /* JADX WARN: Type inference failed for: r0v6 */
    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        boolean z2;
        int size;
        ?? r0 = 0;
        int i5 = 0;
        try {
            boolean z3 = this.f141b && getOrientation() == 0 && getLayoutDirection() == 1;
            this.f142c = z3;
            if (z3) {
                while (this.f143d.size() > getChildCount()) {
                    this.f143d.remove(this.f143d.size() - 1);
                }
                while (this.f143d.size() < getChildCount()) {
                    this.f143d.add(new ArrayList<>());
                }
            }
            super.onLayout(z, i, i2, i3, i4);
            if (this.f142c) {
                for (int i6 = 0; i6 < this.f143d.size(); i6++) {
                    for (int i7 = 0; i7 < this.f143d.get(i6).size(); i7++) {
                        super.focusableViewAvailable(this.f143d.get(i6).get(i7));
                    }
                }
            }
            if (z2) {
                while (true) {
                    if (i5 >= size) {
                        return;
                    }
                }
            }
        } finally {
            if (this.f142c) {
                this.f142c = false;
                while (r0 < this.f143d.size()) {
                    this.f143d.get(r0).clear();
                    r0++;
                }
            }
        }
    }

    public void setFocusableViewAvailableFixEnabled(boolean z) {
        this.f141b = z;
    }
}
