package androidx.leanback.widget.picker;

import android.content.Context;
import android.content.res.TypedArray;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import androidx.leanback.widget.VerticalGridView;
import b.g.l;
import b.g.n.b0.b;
import b.g.n.b0.c;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;

/* loaded from: classes.dex */
public class DatePicker extends b.g.n.b0.a {
    public static final int[] F = {5, 2, 1};
    public c.a A;
    public Calendar B;
    public Calendar C;
    public Calendar D;
    public Calendar E;
    public String s;
    public b t;
    public b u;
    public b v;
    public int w;
    public int x;
    public int y;
    public final DateFormat z;

    /* loaded from: classes.dex */
    public class a implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ boolean f192b;

        public a(boolean z) {
            this.f192b = z;
        }

        @Override // java.lang.Runnable
        public void run() {
            int actualMinimum;
            boolean z;
            int actualMaximum;
            boolean z2;
            DatePicker datePicker = DatePicker.this;
            boolean z3 = this.f192b;
            int[] iArr = {datePicker.x, datePicker.w, datePicker.y};
            boolean z4 = true;
            boolean z5 = true;
            for (int length = DatePicker.F.length - 1; length >= 0; length--) {
                if (iArr[length] >= 0) {
                    int i = DatePicker.F[length];
                    int i2 = iArr[length];
                    ArrayList<b> arrayList = datePicker.e;
                    b bVar = arrayList == null ? null : arrayList.get(i2);
                    if (!z4 ? (actualMinimum = datePicker.D.getActualMinimum(i)) == bVar.f690b : (actualMinimum = datePicker.B.get(i)) == bVar.f690b) {
                        z = false;
                    } else {
                        bVar.f690b = actualMinimum;
                        z = true;
                    }
                    boolean z6 = z | false;
                    if (!z5 ? (actualMaximum = datePicker.D.getActualMaximum(i)) == bVar.f691c : (actualMaximum = datePicker.C.get(i)) == bVar.f691c) {
                        z2 = false;
                    } else {
                        bVar.f691c = actualMaximum;
                        z2 = true;
                    }
                    boolean z7 = z6 | z2;
                    z4 &= datePicker.D.get(i) == datePicker.B.get(i);
                    z5 &= datePicker.D.get(i) == datePicker.C.get(i);
                    if (z7) {
                        datePicker.a(iArr[length], bVar);
                    }
                    int i3 = iArr[length];
                    int i4 = datePicker.D.get(i);
                    b bVar2 = datePicker.e.get(i3);
                    if (bVar2.f689a != i4) {
                        bVar2.f689a = i4;
                        VerticalGridView verticalGridView = datePicker.f685d.get(i3);
                        if (verticalGridView != null) {
                            int i5 = i4 - datePicker.e.get(i3).f690b;
                            if (z3) {
                                verticalGridView.setSelectedPositionSmooth(i5);
                            } else {
                                verticalGridView.setSelectedPosition(i5);
                            }
                        }
                    }
                }
            }
        }
    }

    public DatePicker(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public DatePicker(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.z = new SimpleDateFormat("MM/dd/yyyy");
        Locale locale = Locale.getDefault();
        getContext().getResources();
        c.a aVar = new c.a(locale);
        this.A = aVar;
        this.E = c.a(this.E, aVar.f693a);
        this.B = c.a(this.B, this.A.f693a);
        this.C = c.a(this.C, this.A.f693a);
        this.D = c.a(this.D, this.A.f693a);
        b bVar = this.t;
        if (bVar != null) {
            bVar.f692d = this.A.f694b;
            a(this.w, bVar);
        }
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.lbDatePicker);
        String string = obtainStyledAttributes.getString(l.lbDatePicker_android_minDate);
        String string2 = obtainStyledAttributes.getString(l.lbDatePicker_android_maxDate);
        this.E.clear();
        if (TextUtils.isEmpty(string) || !a(string, this.E)) {
            this.E.set(1900, 0, 1);
        }
        this.B.setTimeInMillis(this.E.getTimeInMillis());
        this.E.clear();
        if (TextUtils.isEmpty(string2) || !a(string2, this.E)) {
            this.E.set(2100, 0, 1);
        }
        this.C.setTimeInMillis(this.E.getTimeInMillis());
        String string3 = obtainStyledAttributes.getString(l.lbDatePicker_datePickerFormat);
        setDatePickerFormat(TextUtils.isEmpty(string3) ? new String(android.text.format.DateFormat.getDateFormatOrder(context)) : string3);
    }

    @Override // b.g.n.b0.a
    public final void a(int i, int i2) {
        Calendar calendar;
        Calendar calendar2;
        this.E.setTimeInMillis(this.D.getTimeInMillis());
        ArrayList<b> arrayList = this.e;
        int i3 = (arrayList == null ? null : arrayList.get(i)).f689a;
        if (i == this.x) {
            this.E.add(5, i2 - i3);
        } else if (i == this.w) {
            this.E.add(2, i2 - i3);
        } else {
            if (i != this.y) {
                throw new IllegalArgumentException();
            }
            this.E.add(1, i2 - i3);
        }
        this.D.set(this.E.get(1), this.E.get(2), this.E.get(5));
        if (!this.D.before(this.B)) {
            if (this.D.after(this.C)) {
                calendar = this.D;
                calendar2 = this.C;
            }
            a(false);
        }
        calendar = this.D;
        calendar2 = this.B;
        calendar.setTimeInMillis(calendar2.getTimeInMillis());
        a(false);
    }

    public final void a(boolean z) {
        post(new a(z));
    }

    public final boolean a(String str, Calendar calendar) {
        try {
            calendar.setTime(this.z.parse(str));
            return true;
        } catch (ParseException unused) {
            Log.w("DatePicker", "Date: " + str + " not in format: MM/dd/yyyy");
            return false;
        }
    }

    public long getDate() {
        return this.D.getTimeInMillis();
    }

    public String getDatePickerFormat() {
        return this.s;
    }

    public long getMaxDate() {
        return this.C.getTimeInMillis();
    }

    public long getMinDate() {
        return this.B.getTimeInMillis();
    }

    public void setDatePickerFormat(String str) {
        if (TextUtils.isEmpty(str)) {
            str = new String(android.text.format.DateFormat.getDateFormatOrder(getContext()));
        }
        if (TextUtils.equals(this.s, str)) {
            return;
        }
        this.s = str;
        String bestDateTimePattern = android.text.format.DateFormat.getBestDateTimePattern(this.A.f693a, str);
        if (TextUtils.isEmpty(bestDateTimePattern)) {
            bestDateTimePattern = "MM/dd/yyyy";
        }
        ArrayList arrayList = new ArrayList();
        StringBuilder sb = new StringBuilder();
        char[] cArr = {'Y', 'y', 'M', 'm', 'D', 'd'};
        int i = 0;
        boolean z = false;
        char c2 = 0;
        while (true) {
            boolean z2 = true;
            if (i >= bestDateTimePattern.length()) {
                break;
            }
            char charAt = bestDateTimePattern.charAt(i);
            if (charAt != ' ') {
                if (charAt != '\'') {
                    if (!z) {
                        int i2 = 0;
                        while (true) {
                            if (i2 >= 6) {
                                z2 = false;
                                break;
                            } else if (charAt == cArr[i2]) {
                                break;
                            } else {
                                i2++;
                            }
                        }
                        if (z2) {
                            if (charAt != c2) {
                                arrayList.add(sb.toString());
                                sb.setLength(0);
                            }
                            c2 = charAt;
                        }
                    }
                    sb.append(charAt);
                    c2 = charAt;
                } else if (z) {
                    z = false;
                } else {
                    sb.setLength(0);
                    z = true;
                }
            }
            i++;
        }
        arrayList.add(sb.toString());
        if (arrayList.size() != str.length() + 1) {
            StringBuilder a2 = c.a.b.a.a.a("Separators size: ");
            a2.append(arrayList.size());
            a2.append(" must equal");
            a2.append(" the size of datePickerFormat: ");
            a2.append(str.length());
            a2.append(" + 1");
            throw new IllegalStateException(a2.toString());
        }
        setSeparators(arrayList);
        this.u = null;
        this.t = null;
        this.v = null;
        this.w = -1;
        this.x = -1;
        this.y = -1;
        String upperCase = str.toUpperCase();
        ArrayList arrayList2 = new ArrayList(3);
        for (int i3 = 0; i3 < upperCase.length(); i3++) {
            char charAt2 = upperCase.charAt(i3);
            if (charAt2 == 'D') {
                if (this.u != null) {
                    throw new IllegalArgumentException("datePicker format error");
                }
                b bVar = new b();
                this.u = bVar;
                arrayList2.add(bVar);
                this.u.e = "%02d";
                this.x = i3;
            } else if (charAt2 != 'M') {
                if (charAt2 != 'Y') {
                    throw new IllegalArgumentException("datePicker format error");
                }
                if (this.v == null) {
                    b bVar2 = new b();
                    this.v = bVar2;
                    arrayList2.add(bVar2);
                    this.y = i3;
                    this.v.e = "%d";
                } else {
                    throw new IllegalArgumentException("datePicker format error");
                }
            } else {
                if (this.t != null) {
                    throw new IllegalArgumentException("datePicker format error");
                }
                b bVar3 = new b();
                this.t = bVar3;
                arrayList2.add(bVar3);
                this.t.f692d = this.A.f694b;
                this.w = i3;
            }
        }
        setColumns(arrayList2);
        a(false);
    }

    public void setMaxDate(long j) {
        this.E.setTimeInMillis(j);
        if (this.E.get(1) != this.C.get(1) || this.E.get(6) == this.C.get(6)) {
            this.C.setTimeInMillis(j);
            if (this.D.after(this.C)) {
                this.D.setTimeInMillis(this.C.getTimeInMillis());
            }
            a(false);
        }
    }

    public void setMinDate(long j) {
        this.E.setTimeInMillis(j);
        if (this.E.get(1) != this.B.get(1) || this.E.get(6) == this.B.get(6)) {
            this.B.setTimeInMillis(j);
            if (this.D.before(this.B)) {
                this.D.setTimeInMillis(this.B.getTimeInMillis());
            }
            a(false);
        }
    }
}
