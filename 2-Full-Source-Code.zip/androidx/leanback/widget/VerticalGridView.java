package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import b.g.l;
import b.g.n.a;
import b.g.n.e;

/* loaded from: classes.dex */
public class VerticalGridView extends a {
    public VerticalGridView(Context context) {
        this(context, null);
    }

    public VerticalGridView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public VerticalGridView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.H0.p(1);
        a(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.lbVerticalGridView);
        setColumnWidth(obtainStyledAttributes);
        setNumColumns(obtainStyledAttributes.getInt(l.lbVerticalGridView_numberOfColumns, 1));
        obtainStyledAttributes.recycle();
    }

    public void setColumnWidth(int i) {
        this.H0.q(i);
        requestLayout();
    }

    public void setColumnWidth(TypedArray typedArray) {
        if (typedArray.peekValue(l.lbVerticalGridView_columnWidth) != null) {
            setColumnWidth(typedArray.getLayoutDimension(l.lbVerticalGridView_columnWidth, 0));
        }
    }

    public void setNumColumns(int i) {
        e eVar = this.H0;
        if (eVar == null) {
            throw null;
        }
        if (i >= 0) {
            eVar.Y = i;
            requestLayout();
            return;
        }
        throw new IllegalArgumentException();
    }
}
