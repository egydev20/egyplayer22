package androidx.leanback.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.KeyEvent;
import androidx.leanback.widget.SearchBar;
import b.g.k;
import b.g.n.x;

/* loaded from: classes.dex */
public class SearchEditText extends x {
    public a i;

    /* loaded from: classes.dex */
    public interface a {
    }

    public SearchEditText(Context context) {
        this(context, null);
    }

    public SearchEditText(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, k.TextAppearance_Leanback_SearchTextEdit);
    }

    public SearchEditText(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
    }

    @Override // android.widget.TextView, android.view.View
    public boolean onKeyPreIme(int i, KeyEvent keyEvent) {
        SearchBar searchBar;
        SearchBar.j jVar;
        if (keyEvent.getKeyCode() != 4) {
            return super.onKeyPreIme(i, keyEvent);
        }
        a aVar = this.i;
        if (aVar == null || (jVar = (searchBar = SearchBar.this).f158b) == null) {
            return false;
        }
        jVar.b(searchBar.f);
        return false;
    }

    @Override // b.g.n.x, android.widget.TextView
    public /* bridge */ /* synthetic */ void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(callback);
    }

    @Override // b.g.n.x
    public /* bridge */ /* synthetic */ void setFinalRecognizedText(CharSequence charSequence) {
        super.setFinalRecognizedText(charSequence);
    }

    public void setOnKeyboardDismissListener(a aVar) {
        this.i = aVar;
    }
}
