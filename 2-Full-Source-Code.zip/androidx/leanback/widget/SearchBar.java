package androidx.leanback.widget;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognitionListener;
import android.speech.SpeechRecognizer;
import android.text.Editable;
import android.text.SpannableStringBuilder;
import android.text.SpannedString;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import androidx.leanback.widget.SearchEditText;
import androidx.leanback.widget.SearchOrbView;
import b.g.n.s;
import b.g.n.u;
import b.g.n.x;
import java.util.ArrayList;
import java.util.regex.Matcher;

/* loaded from: classes.dex */
public class SearchBar extends RelativeLayout {
    public static final String C = SearchBar.class.getSimpleName();
    public final Context A;
    public k B;

    /* renamed from: b, reason: collision with root package name */
    public j f158b;

    /* renamed from: c, reason: collision with root package name */
    public SearchEditText f159c;

    /* renamed from: d, reason: collision with root package name */
    public SpeechOrbView f160d;
    public ImageView e;
    public String f;
    public String g;
    public String h;
    public Drawable i;
    public final Handler j;
    public final InputMethodManager k;
    public boolean l;
    public Drawable m;
    public final int n;
    public final int o;
    public final int p;
    public final int q;
    public int r;
    public int s;
    public int t;
    public SpeechRecognizer u;
    public u v;
    public boolean w;
    public SoundPool x;
    public SparseIntArray y;
    public boolean z;

    /* loaded from: classes.dex */
    public class a implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ int f161b;

        public a(int i) {
            this.f161b = i;
        }

        @Override // java.lang.Runnable
        public void run() {
            SearchBar.this.x.play(SearchBar.this.y.get(this.f161b), 1.0f, 1.0f, 1, 0, 1.0f);
        }
    }

    /* loaded from: classes.dex */
    public class b implements View.OnFocusChangeListener {
        public b() {
        }

        @Override // android.view.View.OnFocusChangeListener
        public void onFocusChange(View view, boolean z) {
            SearchBar searchBar = SearchBar.this;
            if (z) {
                searchBar.j.post(new s(searchBar));
            } else {
                searchBar.a();
            }
            SearchBar.this.a(z);
        }
    }

    /* loaded from: classes.dex */
    public class c implements Runnable {
        public c() {
        }

        @Override // java.lang.Runnable
        public void run() {
            SearchBar searchBar = SearchBar.this;
            searchBar.setSearchQueryInternal(searchBar.f159c.getText().toString());
        }
    }

    /* loaded from: classes.dex */
    public class d implements TextWatcher {

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ Runnable f165b;

        public d(Runnable runnable) {
            this.f165b = runnable;
        }

        @Override // android.text.TextWatcher
        public void afterTextChanged(Editable editable) {
        }

        @Override // android.text.TextWatcher
        public void beforeTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        }

        @Override // android.text.TextWatcher
        public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
            SearchBar searchBar = SearchBar.this;
            if (searchBar.z) {
                return;
            }
            searchBar.j.removeCallbacks(this.f165b);
            SearchBar.this.j.post(this.f165b);
        }
    }

    /* loaded from: classes.dex */
    public class e implements SearchEditText.a {
        public e() {
        }
    }

    /* loaded from: classes.dex */
    public class f implements TextView.OnEditorActionListener {

        /* loaded from: classes.dex */
        public class a implements Runnable {
            public a() {
            }

            @Override // java.lang.Runnable
            public void run() {
                j jVar;
                SearchBar searchBar = SearchBar.this;
                if (TextUtils.isEmpty(searchBar.f) || (jVar = searchBar.f158b) == null) {
                    return;
                }
                jVar.a(searchBar.f);
            }
        }

        /* loaded from: classes.dex */
        public class b implements Runnable {
            public b() {
            }

            @Override // java.lang.Runnable
            public void run() {
                SearchBar searchBar = SearchBar.this;
                searchBar.f158b.b(searchBar.f);
            }
        }

        /* loaded from: classes.dex */
        public class c implements Runnable {
            public c() {
            }

            @Override // java.lang.Runnable
            public void run() {
                SearchBar searchBar = SearchBar.this;
                searchBar.l = true;
                searchBar.f160d.requestFocus();
            }
        }

        public f() {
        }

        @Override // android.widget.TextView.OnEditorActionListener
        public boolean onEditorAction(TextView textView, int i, KeyEvent keyEvent) {
            Handler handler;
            Runnable aVar;
            if (3 == i || i == 0) {
                SearchBar searchBar = SearchBar.this;
                if (searchBar.f158b != null) {
                    searchBar.a();
                    handler = SearchBar.this.j;
                    aVar = new a();
                    handler.postDelayed(aVar, 500L);
                    return true;
                }
            }
            if (1 == i) {
                SearchBar searchBar2 = SearchBar.this;
                if (searchBar2.f158b != null) {
                    searchBar2.a();
                    handler = SearchBar.this.j;
                    aVar = new b();
                    handler.postDelayed(aVar, 500L);
                    return true;
                }
            }
            if (2 != i) {
                return false;
            }
            SearchBar.this.a();
            handler = SearchBar.this.j;
            aVar = new c();
            handler.postDelayed(aVar, 500L);
            return true;
        }
    }

    /* loaded from: classes.dex */
    public class g implements View.OnClickListener {
        public g() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            SearchBar searchBar = SearchBar.this;
            if (searchBar.z) {
                searchBar.d();
            } else {
                searchBar.c();
            }
        }
    }

    /* loaded from: classes.dex */
    public class h implements View.OnFocusChangeListener {
        public h() {
        }

        @Override // android.view.View.OnFocusChangeListener
        public void onFocusChange(View view, boolean z) {
            SearchBar searchBar = SearchBar.this;
            if (z) {
                searchBar.a();
                SearchBar searchBar2 = SearchBar.this;
                if (searchBar2.l) {
                    searchBar2.c();
                    SearchBar.this.l = false;
                }
            } else {
                searchBar.d();
            }
            SearchBar.this.a(z);
        }
    }

    /* loaded from: classes.dex */
    public class i implements RecognitionListener {
        public i() {
        }

        @Override // android.speech.RecognitionListener
        public void onBeginningOfSpeech() {
        }

        @Override // android.speech.RecognitionListener
        public void onBufferReceived(byte[] bArr) {
        }

        @Override // android.speech.RecognitionListener
        public void onEndOfSpeech() {
        }

        @Override // android.speech.RecognitionListener
        public void onError(int i) {
            String str;
            String str2;
            switch (i) {
                case 1:
                    str = SearchBar.C;
                    str2 = "recognizer network timeout";
                    Log.w(str, str2);
                    break;
                case 2:
                    str = SearchBar.C;
                    str2 = "recognizer network error";
                    Log.w(str, str2);
                    break;
                case 3:
                    str = SearchBar.C;
                    str2 = "recognizer audio error";
                    Log.w(str, str2);
                    break;
                case 4:
                    str = SearchBar.C;
                    str2 = "recognizer server error";
                    Log.w(str, str2);
                    break;
                case 5:
                    str = SearchBar.C;
                    str2 = "recognizer client error";
                    Log.w(str, str2);
                    break;
                case 6:
                    str = SearchBar.C;
                    str2 = "recognizer speech timeout";
                    Log.w(str, str2);
                    break;
                case 7:
                    str = SearchBar.C;
                    str2 = "recognizer no match";
                    Log.w(str, str2);
                    break;
                case 8:
                    str = SearchBar.C;
                    str2 = "recognizer busy";
                    Log.w(str, str2);
                    break;
                case 9:
                    str = SearchBar.C;
                    str2 = "recognizer insufficient permissions";
                    Log.w(str, str2);
                    break;
                default:
                    Log.d(SearchBar.C, "recognizer other error");
                    break;
            }
            SearchBar.this.d();
            SearchBar.this.a(b.g.i.lb_voice_failure);
        }

        @Override // android.speech.RecognitionListener
        public void onEvent(int i, Bundle bundle) {
        }

        @Override // android.speech.RecognitionListener
        public void onPartialResults(Bundle bundle) {
            ArrayList<String> stringArrayList = bundle.getStringArrayList("results_recognition");
            if (stringArrayList == null || stringArrayList.size() == 0) {
                return;
            }
            String str = stringArrayList.get(0);
            String str2 = stringArrayList.size() > 1 ? stringArrayList.get(1) : null;
            SearchEditText searchEditText = SearchBar.this.f159c;
            if (searchEditText != null) {
                if (str == null) {
                    str = "";
                }
                SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder(str);
                if (str2 != null) {
                    int length = spannableStringBuilder.length();
                    spannableStringBuilder.append((CharSequence) str2);
                    Matcher matcher = x.g.matcher(str2);
                    while (matcher.find()) {
                        int start = matcher.start() + length;
                        spannableStringBuilder.setSpan(new x.b(str2.charAt(matcher.start()), start), start, matcher.end() + length, 33);
                    }
                }
                searchEditText.e = Math.max(str.length(), searchEditText.e);
                searchEditText.setText(new SpannedString(spannableStringBuilder));
                searchEditText.bringPointIntoView(searchEditText.length());
                ObjectAnimator objectAnimator = searchEditText.f;
                if (objectAnimator != null) {
                    objectAnimator.cancel();
                }
                int streamPosition = searchEditText.getStreamPosition();
                int length2 = searchEditText.length();
                int i = length2 - streamPosition;
                if (i > 0) {
                    if (searchEditText.f == null) {
                        ObjectAnimator objectAnimator2 = new ObjectAnimator();
                        searchEditText.f = objectAnimator2;
                        objectAnimator2.setTarget(searchEditText);
                        searchEditText.f.setProperty(x.h);
                    }
                    searchEditText.f.setIntValues(streamPosition, length2);
                    searchEditText.f.setDuration(i * 50);
                    searchEditText.f.start();
                    return;
                }
                return;
            }
            throw null;
        }

        @Override // android.speech.RecognitionListener
        public void onReadyForSpeech(Bundle bundle) {
            SpeechOrbView speechOrbView = SearchBar.this.f160d;
            speechOrbView.setOrbColors(speechOrbView.u);
            speechOrbView.setOrbIcon(speechOrbView.getResources().getDrawable(b.g.d.lb_ic_search_mic));
            speechOrbView.a(true);
            speechOrbView.n = false;
            speechOrbView.a();
            speechOrbView.a(1.0f);
            speechOrbView.w = 0;
            speechOrbView.x = true;
            SearchBar.this.a(b.g.i.lb_voice_open);
        }

        @Override // android.speech.RecognitionListener
        public void onResults(Bundle bundle) {
            j jVar;
            ArrayList<String> stringArrayList = bundle.getStringArrayList("results_recognition");
            if (stringArrayList != null) {
                SearchBar.this.f = stringArrayList.get(0);
                SearchBar searchBar = SearchBar.this;
                searchBar.f159c.setText(searchBar.f);
                SearchBar searchBar2 = SearchBar.this;
                if (!TextUtils.isEmpty(searchBar2.f) && (jVar = searchBar2.f158b) != null) {
                    jVar.a(searchBar2.f);
                }
            }
            SearchBar.this.d();
            SearchBar.this.a(b.g.i.lb_voice_success);
        }

        @Override // android.speech.RecognitionListener
        public void onRmsChanged(float f) {
            SearchBar.this.f160d.setSoundLevel(f < 0.0f ? 0 : (int) (f * 10.0f));
        }
    }

    /* loaded from: classes.dex */
    public interface j {
        void a(String str);

        void b(String str);

        void c(String str);
    }

    /* loaded from: classes.dex */
    public interface k {
        void a();
    }

    public SearchBar(Context context) {
        this(context, null);
    }

    public SearchBar(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SearchBar(Context context, AttributeSet attributeSet, int i2) {
        super(context, attributeSet, i2);
        this.j = new Handler();
        this.l = false;
        this.y = new SparseIntArray();
        this.z = false;
        this.A = context;
        Resources resources = getResources();
        LayoutInflater.from(getContext()).inflate(b.g.h.lb_search_bar, (ViewGroup) this, true);
        this.t = getResources().getDimensionPixelSize(b.g.c.lb_search_bar_height);
        RelativeLayout.LayoutParams layoutParams = new RelativeLayout.LayoutParams(-1, this.t);
        layoutParams.addRule(10, -1);
        setLayoutParams(layoutParams);
        setBackgroundColor(0);
        setClipChildren(false);
        this.f = "";
        this.k = (InputMethodManager) context.getSystemService("input_method");
        this.o = resources.getColor(b.g.b.lb_search_bar_text_speech_mode);
        this.n = resources.getColor(b.g.b.lb_search_bar_text);
        this.s = resources.getInteger(b.g.g.lb_search_bar_speech_mode_background_alpha);
        this.r = resources.getInteger(b.g.g.lb_search_bar_text_mode_background_alpha);
        this.q = resources.getColor(b.g.b.lb_search_bar_hint_speech_mode);
        this.p = resources.getColor(b.g.b.lb_search_bar_hint);
    }

    public void a() {
        this.k.hideSoftInputFromWindow(this.f159c.getWindowToken(), 0);
    }

    public final void a(int i2) {
        this.j.post(new a(i2));
    }

    public void a(boolean z) {
        SearchEditText searchEditText;
        int i2;
        SearchEditText searchEditText2;
        int i3;
        if (z) {
            this.m.setAlpha(this.s);
            if (b()) {
                searchEditText2 = this.f159c;
                i3 = this.q;
            } else {
                searchEditText2 = this.f159c;
                i3 = this.o;
            }
            searchEditText2.setTextColor(i3);
            searchEditText = this.f159c;
            i2 = this.q;
        } else {
            this.m.setAlpha(this.r);
            this.f159c.setTextColor(this.n);
            searchEditText = this.f159c;
            i2 = this.p;
        }
        searchEditText.setHintTextColor(i2);
        e();
    }

    public final boolean b() {
        return this.f160d.isFocused();
    }

    public void c() {
        k kVar;
        if (this.z) {
            return;
        }
        if (!hasFocus()) {
            requestFocus();
        }
        if (this.v != null) {
            this.f159c.setText("");
            this.f159c.setHint("");
            this.v.a();
            this.z = true;
            return;
        }
        if (this.u == null) {
            return;
        }
        if (getContext().checkCallingOrSelfPermission("android.permission.RECORD_AUDIO") != 0) {
            if (Build.VERSION.SDK_INT < 23 || (kVar = this.B) == null) {
                throw new IllegalStateException("android.permission.RECORD_AUDIO required for search");
            }
            kVar.a();
            return;
        }
        this.z = true;
        this.f159c.setText("");
        Intent intent = new Intent("android.speech.action.RECOGNIZE_SPEECH");
        intent.putExtra("android.speech.extra.LANGUAGE_MODEL", "free_form");
        intent.putExtra("android.speech.extra.PARTIAL_RESULTS", true);
        this.u.setRecognitionListener(new i());
        this.w = true;
        this.u.startListening(intent);
    }

    public void d() {
        if (this.z) {
            this.f159c.setText(this.f);
            this.f159c.setHint(this.g);
            this.z = false;
            if (this.v != null || this.u == null) {
                return;
            }
            this.f160d.b();
            if (this.w) {
                this.u.cancel();
                this.w = false;
            }
            this.u.setRecognitionListener(null);
        }
    }

    public final void e() {
        String string = getResources().getString(b.g.j.lb_search_bar_hint);
        if (!TextUtils.isEmpty(this.h)) {
            string = b() ? getResources().getString(b.g.j.lb_search_bar_hint_with_title_speech, this.h) : getResources().getString(b.g.j.lb_search_bar_hint_with_title, this.h);
        } else if (b()) {
            string = getResources().getString(b.g.j.lb_search_bar_hint_speech);
        }
        this.g = string;
        SearchEditText searchEditText = this.f159c;
        if (searchEditText != null) {
            searchEditText.setHint(string);
        }
    }

    public Drawable getBadgeDrawable() {
        return this.i;
    }

    public CharSequence getHint() {
        return this.g;
    }

    public String getTitle() {
        return this.h;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.x = new SoundPool(2, 1, 0);
        Context context = this.A;
        int[] iArr = {b.g.i.lb_voice_failure, b.g.i.lb_voice_open, b.g.i.lb_voice_no_input, b.g.i.lb_voice_success};
        for (int i2 = 0; i2 < 4; i2++) {
            int i3 = iArr[i2];
            this.y.put(i3, this.x.load(context, i3, 1));
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        d();
        this.x.release();
        super.onDetachedFromWindow();
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        this.m = ((RelativeLayout) findViewById(b.g.f.lb_search_bar_items)).getBackground();
        this.f159c = (SearchEditText) findViewById(b.g.f.lb_search_text_editor);
        ImageView imageView = (ImageView) findViewById(b.g.f.lb_search_bar_badge);
        this.e = imageView;
        Drawable drawable = this.i;
        if (drawable != null) {
            imageView.setImageDrawable(drawable);
        }
        this.f159c.setOnFocusChangeListener(new b());
        this.f159c.addTextChangedListener(new d(new c()));
        this.f159c.setOnKeyboardDismissListener(new e());
        this.f159c.setOnEditorActionListener(new f());
        this.f159c.setPrivateImeOptions("escapeNorth,voiceDismiss");
        SpeechOrbView speechOrbView = (SpeechOrbView) findViewById(b.g.f.lb_search_bar_speech_orb);
        this.f160d = speechOrbView;
        speechOrbView.setOnOrbClickedListener(new g());
        this.f160d.setOnFocusChangeListener(new h());
        a(hasFocus());
        e();
    }

    public void setBadgeDrawable(Drawable drawable) {
        ImageView imageView;
        int i2;
        this.i = drawable;
        ImageView imageView2 = this.e;
        if (imageView2 != null) {
            imageView2.setImageDrawable(drawable);
            if (drawable != null) {
                imageView = this.e;
                i2 = 0;
            } else {
                imageView = this.e;
                i2 = 8;
            }
            imageView.setVisibility(i2);
        }
    }

    @Override // android.view.View
    public void setNextFocusDownId(int i2) {
        this.f160d.setNextFocusDownId(i2);
        this.f159c.setNextFocusDownId(i2);
    }

    public void setPermissionListener(k kVar) {
        this.B = kVar;
    }

    public void setSearchAffordanceColors(SearchOrbView.c cVar) {
        SpeechOrbView speechOrbView = this.f160d;
        if (speechOrbView != null) {
            speechOrbView.setNotListeningOrbColors(cVar);
        }
    }

    public void setSearchAffordanceColorsInListening(SearchOrbView.c cVar) {
        SpeechOrbView speechOrbView = this.f160d;
        if (speechOrbView != null) {
            speechOrbView.setListeningOrbColors(cVar);
        }
    }

    public void setSearchBarListener(j jVar) {
        this.f158b = jVar;
    }

    public void setSearchQuery(String str) {
        d();
        this.f159c.setText(str);
        setSearchQueryInternal(str);
    }

    public void setSearchQueryInternal(String str) {
        if (TextUtils.equals(this.f, str)) {
            return;
        }
        this.f = str;
        j jVar = this.f158b;
        if (jVar != null) {
            jVar.c(str);
        }
    }

    @Deprecated
    public void setSpeechRecognitionCallback(u uVar) {
        this.v = uVar;
        if (uVar != null && this.u != null) {
            throw new IllegalStateException("Can't have speech recognizer and request");
        }
    }

    public void setSpeechRecognizer(SpeechRecognizer speechRecognizer) {
        d();
        SpeechRecognizer speechRecognizer2 = this.u;
        if (speechRecognizer2 != null) {
            speechRecognizer2.setRecognitionListener(null);
            if (this.w) {
                this.u.cancel();
                this.w = false;
            }
        }
        this.u = speechRecognizer;
        if (this.v != null && speechRecognizer != null) {
            throw new IllegalStateException("Can't have speech recognizer and request");
        }
    }

    public void setTitle(String str) {
        this.h = str;
        e();
    }
}
