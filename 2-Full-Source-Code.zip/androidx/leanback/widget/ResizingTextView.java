package androidx.leanback.widget;

import a.a.a.a.a;
import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.widget.TextView;
import b.g.l;

/* loaded from: classes.dex */
public class ResizingTextView extends TextView {

    /* renamed from: b, reason: collision with root package name */
    public int f152b;

    /* renamed from: c, reason: collision with root package name */
    public int f153c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f154d;
    public int e;
    public int f;
    public boolean g;
    public int h;
    public float i;
    public int j;
    public int k;

    public ResizingTextView(Context context) {
        this(context, null);
    }

    public ResizingTextView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    public ResizingTextView(Context context, AttributeSet attributeSet, int i) {
        this(context, attributeSet, i, 0);
    }

    public ResizingTextView(Context context, AttributeSet attributeSet, int i, int i2) {
        super(context, attributeSet, i);
        this.g = false;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.lbResizingTextView, i, i2);
        try {
            this.f152b = obtainStyledAttributes.getInt(l.lbResizingTextView_resizeTrigger, 1);
            this.f153c = obtainStyledAttributes.getDimensionPixelSize(l.lbResizingTextView_resizedTextSize, -1);
            this.f154d = obtainStyledAttributes.getBoolean(l.lbResizingTextView_maintainLineSpacing, false);
            this.e = obtainStyledAttributes.getDimensionPixelOffset(l.lbResizingTextView_resizedPaddingAdjustmentTop, 0);
            this.f = obtainStyledAttributes.getDimensionPixelOffset(l.lbResizingTextView_resizedPaddingAdjustmentBottom, 0);
        } finally {
            obtainStyledAttributes.recycle();
        }
    }

    public final void a(int i, int i2) {
        if (isPaddingRelative()) {
            setPaddingRelative(getPaddingStart(), i, getPaddingEnd(), i2);
        } else {
            setPadding(getPaddingLeft(), i, getPaddingRight(), i2);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:14:0x005c  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x00de  */
    /* JADX WARN: Removed duplicated region for block: B:32:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x009f  */
    @Override // android.widget.TextView, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onMeasure(int r6, int r7) {
        /*
            Method dump skipped, instructions count: 226
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.ResizingTextView.onMeasure(int, int):void");
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(a.a(this, callback));
    }
}
