package androidx.leanback.widget;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import b.g.f;
import b.g.h;

/* loaded from: classes.dex */
public class MediaNowPlayingView extends LinearLayout {

    /* renamed from: b, reason: collision with root package name */
    public final ImageView f135b;

    /* renamed from: c, reason: collision with root package name */
    public final ImageView f136c;

    /* renamed from: d, reason: collision with root package name */
    public final ImageView f137d;
    public final ObjectAnimator e;
    public final ObjectAnimator f;
    public final ObjectAnimator g;
    public final LinearInterpolator h;

    public MediaNowPlayingView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.h = new LinearInterpolator();
        LayoutInflater.from(context).inflate(h.lb_playback_now_playing_bars, (ViewGroup) this, true);
        this.f135b = (ImageView) findViewById(f.bar1);
        this.f136c = (ImageView) findViewById(f.bar2);
        this.f137d = (ImageView) findViewById(f.bar3);
        this.f135b.setPivotY(r4.getDrawable().getIntrinsicHeight());
        this.f136c.setPivotY(r4.getDrawable().getIntrinsicHeight());
        this.f137d.setPivotY(r4.getDrawable().getIntrinsicHeight());
        setDropScale(this.f135b);
        setDropScale(this.f136c);
        setDropScale(this.f137d);
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(this.f135b, "scaleY", 0.41666666f, 0.25f, 0.41666666f, 0.5833333f, 0.75f, 0.8333333f, 0.9166667f, 1.0f, 0.9166667f, 1.0f, 0.8333333f, 0.6666667f, 0.5f, 0.33333334f, 0.16666667f, 0.33333334f, 0.5f, 0.5833333f, 0.75f, 0.9166667f, 0.75f, 0.5833333f, 0.41666666f, 0.25f, 0.41666666f, 0.6666667f, 0.41666666f, 0.25f, 0.33333334f, 0.41666666f);
        this.e = ofFloat;
        ofFloat.setRepeatCount(-1);
        this.e.setDuration(2320L);
        this.e.setInterpolator(this.h);
        ObjectAnimator ofFloat2 = ObjectAnimator.ofFloat(this.f136c, "scaleY", 1.0f, 0.9166667f, 0.8333333f, 0.9166667f, 1.0f, 0.9166667f, 0.75f, 0.5833333f, 0.75f, 0.9166667f, 1.0f, 0.8333333f, 0.6666667f, 0.8333333f, 1.0f, 0.9166667f, 0.75f, 0.41666666f, 0.25f, 0.41666666f, 0.6666667f, 0.8333333f, 1.0f, 0.8333333f, 0.75f, 0.6666667f, 1.0f);
        this.f = ofFloat2;
        ofFloat2.setRepeatCount(-1);
        this.f.setDuration(2080L);
        this.f.setInterpolator(this.h);
        ObjectAnimator ofFloat3 = ObjectAnimator.ofFloat(this.f137d, "scaleY", 0.6666667f, 0.75f, 0.8333333f, 1.0f, 0.9166667f, 0.75f, 0.5833333f, 0.41666666f, 0.5833333f, 0.6666667f, 0.75f, 1.0f, 0.9166667f, 1.0f, 0.75f, 0.5833333f, 0.75f, 0.9166667f, 1.0f, 0.8333333f, 0.6666667f, 0.75f, 0.5833333f, 0.41666666f, 0.25f, 0.6666667f);
        this.g = ofFloat3;
        ofFloat3.setRepeatCount(-1);
        this.g.setDuration(2000L);
        this.g.setInterpolator(this.h);
    }

    public static void setDropScale(View view) {
        view.setScaleY(0.083333336f);
    }

    public final void a() {
        a(this.e);
        a(this.f);
        a(this.g);
        this.f135b.setVisibility(0);
        this.f136c.setVisibility(0);
        this.f137d.setVisibility(0);
    }

    public final void a(Animator animator) {
        if (animator.isStarted()) {
            return;
        }
        animator.start();
    }

    public final void a(Animator animator, View view) {
        if (animator.isStarted()) {
            animator.cancel();
            setDropScale(view);
        }
    }

    public final void b() {
        a(this.e, this.f135b);
        a(this.f, this.f136c);
        a(this.g, this.f137d);
        this.f135b.setVisibility(8);
        this.f136c.setVisibility(8);
        this.f137d.setVisibility(8);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (getVisibility() == 0) {
            a();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        b();
    }

    @Override // android.view.View
    public void setVisibility(int i) {
        super.setVisibility(i);
        if (i == 8) {
            b();
        } else {
            a();
        }
    }
}
