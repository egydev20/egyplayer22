package androidx.leanback.widget;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import b.g.l;

/* loaded from: classes.dex */
public class PagingIndicator extends View {
    public static final TimeInterpolator A = new DecelerateInterpolator();
    public static final Property<d, Float> B = new a(Float.class, "alpha");
    public static final Property<d, Float> C = new b(Float.class, "diameter");
    public static final Property<d, Float> D = new c(Float.class, "translation_x");

    /* renamed from: b, reason: collision with root package name */
    public boolean f144b;

    /* renamed from: c, reason: collision with root package name */
    public final int f145c;

    /* renamed from: d, reason: collision with root package name */
    public final int f146d;
    public final int e;
    public final int f;
    public final int g;
    public final int h;
    public final int i;
    public d[] j;
    public int[] k;
    public int[] l;
    public int[] m;
    public int n;
    public int o;
    public int p;
    public int q;
    public final Paint r;
    public final Paint s;
    public final AnimatorSet t;
    public final AnimatorSet u;
    public final AnimatorSet v;
    public Bitmap w;
    public Paint x;
    public final Rect y;
    public final float z;

    /* loaded from: classes.dex */
    public static class a extends Property<d, Float> {
        public a(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        public Float get(d dVar) {
            return Float.valueOf(dVar.f147a);
        }

        @Override // android.util.Property
        public void set(d dVar, Float f) {
            d dVar2 = dVar;
            dVar2.f147a = f.floatValue();
            dVar2.a();
            PagingIndicator.this.invalidate();
        }
    }

    /* loaded from: classes.dex */
    public static class b extends Property<d, Float> {
        public b(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        public Float get(d dVar) {
            return Float.valueOf(dVar.e);
        }

        @Override // android.util.Property
        public void set(d dVar, Float f) {
            d dVar2 = dVar;
            float floatValue = f.floatValue();
            dVar2.e = floatValue;
            float f2 = floatValue / 2.0f;
            dVar2.f = f2;
            PagingIndicator pagingIndicator = PagingIndicator.this;
            dVar2.g = f2 * pagingIndicator.z;
            pagingIndicator.invalidate();
        }
    }

    /* loaded from: classes.dex */
    public static class c extends Property<d, Float> {
        public c(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        public Float get(d dVar) {
            return Float.valueOf(dVar.f149c);
        }

        @Override // android.util.Property
        public void set(d dVar, Float f) {
            d dVar2 = dVar;
            dVar2.f149c = f.floatValue() * dVar2.h * dVar2.i;
            PagingIndicator.this.invalidate();
        }
    }

    /* loaded from: classes.dex */
    public class d {

        /* renamed from: a, reason: collision with root package name */
        public float f147a;

        /* renamed from: b, reason: collision with root package name */
        public int f148b;

        /* renamed from: c, reason: collision with root package name */
        public float f149c;

        /* renamed from: d, reason: collision with root package name */
        public float f150d;
        public float e;
        public float f;
        public float g;
        public float h = 1.0f;
        public float i;

        public d() {
            this.i = PagingIndicator.this.f144b ? 1.0f : -1.0f;
        }

        public void a() {
            this.f148b = Color.argb(Math.round(this.f147a * 255.0f), Color.red(PagingIndicator.this.q), Color.green(PagingIndicator.this.q), Color.blue(PagingIndicator.this.q));
        }

        public void b() {
            this.f149c = 0.0f;
            this.f150d = 0.0f;
            PagingIndicator pagingIndicator = PagingIndicator.this;
            this.e = pagingIndicator.f145c;
            float f = pagingIndicator.f146d;
            this.f = f;
            this.g = f * pagingIndicator.z;
            this.f147a = 0.0f;
            a();
        }
    }

    public PagingIndicator(Context context) {
        this(context, null, 0);
    }

    public PagingIndicator(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public PagingIndicator(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.v = new AnimatorSet();
        Resources resources = getResources();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.PagingIndicator, i, 0);
        int a2 = a(obtainStyledAttributes, l.PagingIndicator_lbDotRadius, b.g.c.lb_page_indicator_dot_radius);
        this.f146d = a2;
        this.f145c = a2 * 2;
        int a3 = a(obtainStyledAttributes, l.PagingIndicator_arrowRadius, b.g.c.lb_page_indicator_arrow_radius);
        this.g = a3;
        this.f = a3 * 2;
        this.e = a(obtainStyledAttributes, l.PagingIndicator_dotToDotGap, b.g.c.lb_page_indicator_dot_gap);
        this.h = a(obtainStyledAttributes, l.PagingIndicator_dotToArrowGap, b.g.c.lb_page_indicator_arrow_gap);
        int color = obtainStyledAttributes.getColor(l.PagingIndicator_dotBgColor, getResources().getColor(b.g.b.lb_page_indicator_dot));
        Paint paint = new Paint(1);
        this.r = paint;
        paint.setColor(color);
        this.q = obtainStyledAttributes.getColor(l.PagingIndicator_arrowBgColor, getResources().getColor(b.g.b.lb_page_indicator_arrow_background));
        if (this.x == null && obtainStyledAttributes.hasValue(l.PagingIndicator_arrowColor)) {
            setArrowColor(obtainStyledAttributes.getColor(l.PagingIndicator_arrowColor, 0));
        }
        obtainStyledAttributes.recycle();
        this.f144b = resources.getConfiguration().getLayoutDirection() == 0;
        int color2 = resources.getColor(b.g.b.lb_page_indicator_arrow_shadow);
        this.i = resources.getDimensionPixelSize(b.g.c.lb_page_indicator_arrow_shadow_radius);
        this.s = new Paint(1);
        float dimensionPixelSize = resources.getDimensionPixelSize(b.g.c.lb_page_indicator_arrow_shadow_offset);
        this.s.setShadowLayer(this.i, dimensionPixelSize, dimensionPixelSize, color2);
        this.w = d();
        this.y = new Rect(0, 0, this.w.getWidth(), this.w.getHeight());
        this.z = this.w.getWidth() / this.f;
        AnimatorSet animatorSet = new AnimatorSet();
        this.t = animatorSet;
        animatorSet.playTogether(a(0.0f, 1.0f), b(this.f146d * 2, this.g * 2), c());
        AnimatorSet animatorSet2 = new AnimatorSet();
        this.u = animatorSet2;
        animatorSet2.playTogether(a(1.0f, 0.0f), b(this.g * 2, this.f146d * 2), c());
        this.v.playTogether(this.t, this.u);
        setLayerType(1, null);
    }

    private int getDesiredHeight() {
        return getPaddingBottom() + getPaddingTop() + this.f + this.i;
    }

    private int getDesiredWidth() {
        return getPaddingRight() + getPaddingLeft() + getRequiredWidth();
    }

    private int getRequiredWidth() {
        return ((this.o - 3) * this.e) + (this.h * 2) + (this.f146d * 2);
    }

    private void setSelectedPage(int i) {
        if (i == this.p) {
            return;
        }
        this.p = i;
        a();
    }

    public final int a(TypedArray typedArray, int i, int i2) {
        return typedArray.getDimensionPixelOffset(i, getResources().getDimensionPixelOffset(i2));
    }

    public final Animator a(float f, float f2) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat((Object) null, B, f, f2);
        ofFloat.setDuration(167L);
        ofFloat.setInterpolator(A);
        return ofFloat;
    }

    public final void a() {
        int i;
        int i2 = 0;
        while (true) {
            i = this.p;
            if (i2 >= i) {
                break;
            }
            this.j[i2].b();
            d dVar = this.j[i2];
            if (i2 != 0) {
                r2 = 1.0f;
            }
            dVar.h = r2;
            this.j[i2].f150d = this.l[i2];
            i2++;
        }
        d dVar2 = this.j[i];
        dVar2.f149c = 0.0f;
        dVar2.f150d = 0.0f;
        PagingIndicator pagingIndicator = PagingIndicator.this;
        dVar2.e = pagingIndicator.f;
        float f = pagingIndicator.g;
        dVar2.f = f;
        dVar2.g = f * pagingIndicator.z;
        dVar2.f147a = 1.0f;
        dVar2.a();
        d[] dVarArr = this.j;
        int i3 = this.p;
        dVarArr[i3].h = i3 <= 0 ? 1.0f : -1.0f;
        d[] dVarArr2 = this.j;
        int i4 = this.p;
        d dVar3 = dVarArr2[i4];
        int i5 = this.k[i4];
        while (true) {
            dVar3.f150d = i5;
            i4++;
            if (i4 >= this.o) {
                return;
            }
            this.j[i4].b();
            d[] dVarArr3 = this.j;
            dVarArr3[i4].h = 1.0f;
            dVar3 = dVarArr3[i4];
            i5 = this.m[i4];
        }
    }

    public final Animator b(float f, float f2) {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat((Object) null, C, f, f2);
        ofFloat.setDuration(417L);
        ofFloat.setInterpolator(A);
        return ofFloat;
    }

    public final void b() {
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int width = getWidth() - getPaddingRight();
        int requiredWidth = getRequiredWidth();
        int i = (paddingLeft + width) / 2;
        int i2 = this.o;
        int[] iArr = new int[i2];
        this.k = iArr;
        int[] iArr2 = new int[i2];
        this.l = iArr2;
        int[] iArr3 = new int[i2];
        this.m = iArr3;
        int i3 = 1;
        int i4 = requiredWidth / 2;
        if (this.f144b) {
            int i5 = i - i4;
            int i6 = this.f146d;
            int i7 = this.e;
            int i8 = this.h;
            iArr[0] = ((i5 + i6) - i7) + i8;
            iArr2[0] = i5 + i6;
            iArr3[0] = (i8 * 2) + ((i5 + i6) - (i7 * 2));
            while (i3 < this.o) {
                int[] iArr4 = this.k;
                int[] iArr5 = this.l;
                int i9 = i3 - 1;
                int i10 = iArr5[i9];
                int i11 = this.h;
                iArr4[i3] = i10 + i11;
                iArr5[i3] = iArr5[i9] + this.e;
                this.m[i3] = iArr4[i9] + i11;
                i3++;
            }
        } else {
            int i12 = i4 + i;
            int i13 = this.f146d;
            int i14 = this.e;
            int i15 = this.h;
            iArr[0] = ((i12 - i13) + i14) - i15;
            iArr2[0] = i12 - i13;
            iArr3[0] = ((i14 * 2) + (i12 - i13)) - (i15 * 2);
            while (i3 < this.o) {
                int[] iArr6 = this.k;
                int[] iArr7 = this.l;
                int i16 = i3 - 1;
                int i17 = iArr7[i16];
                int i18 = this.h;
                iArr6[i3] = i17 - i18;
                iArr7[i3] = iArr7[i16] - this.e;
                this.m[i3] = iArr6[i16] - i18;
                i3++;
            }
        }
        this.n = paddingTop + this.g;
        a();
    }

    public final Animator c() {
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat((Object) null, D, (-this.h) + this.e, 0.0f);
        ofFloat.setDuration(417L);
        ofFloat.setInterpolator(A);
        return ofFloat;
    }

    public final Bitmap d() {
        Bitmap decodeResource = BitmapFactory.decodeResource(getResources(), b.g.d.lb_ic_nav_arrow);
        if (this.f144b) {
            return decodeResource;
        }
        Matrix matrix = new Matrix();
        matrix.preScale(-1.0f, 1.0f);
        return Bitmap.createBitmap(decodeResource, 0, 0, decodeResource.getWidth(), decodeResource.getHeight(), matrix, false);
    }

    public int[] getDotSelectedLeftX() {
        return this.l;
    }

    public int[] getDotSelectedRightX() {
        return this.m;
    }

    public int[] getDotSelectedX() {
        return this.k;
    }

    public int getPageCount() {
        return this.o;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        for (int i = 0; i < this.o; i++) {
            d dVar = this.j[i];
            float f = dVar.f150d + dVar.f149c;
            canvas.drawCircle(f, r3.n, dVar.f, PagingIndicator.this.r);
            if (dVar.f147a > 0.0f) {
                PagingIndicator.this.s.setColor(dVar.f148b);
                canvas.drawCircle(f, r3.n, dVar.f, PagingIndicator.this.s);
                PagingIndicator pagingIndicator = PagingIndicator.this;
                Bitmap bitmap = pagingIndicator.w;
                Rect rect = pagingIndicator.y;
                float f2 = dVar.g;
                float f3 = PagingIndicator.this.n;
                canvas.drawBitmap(bitmap, rect, new Rect((int) (f - f2), (int) (f3 - f2), (int) (f + f2), (int) (f3 + f2)), PagingIndicator.this.x);
            }
        }
    }

    @Override // android.view.View
    public void onMeasure(int i, int i2) {
        int desiredHeight = getDesiredHeight();
        int mode = View.MeasureSpec.getMode(i2);
        if (mode == Integer.MIN_VALUE) {
            desiredHeight = Math.min(desiredHeight, View.MeasureSpec.getSize(i2));
        } else if (mode == 1073741824) {
            desiredHeight = View.MeasureSpec.getSize(i2);
        }
        int desiredWidth = getDesiredWidth();
        int mode2 = View.MeasureSpec.getMode(i);
        if (mode2 == Integer.MIN_VALUE) {
            desiredWidth = Math.min(desiredWidth, View.MeasureSpec.getSize(i));
        } else if (mode2 == 1073741824) {
            desiredWidth = View.MeasureSpec.getSize(i);
        }
        setMeasuredDimension(desiredWidth, desiredHeight);
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i) {
        super.onRtlPropertiesChanged(i);
        boolean z = i == 0;
        if (this.f144b != z) {
            this.f144b = z;
            this.w = d();
            d[] dVarArr = this.j;
            if (dVarArr != null) {
                for (d dVar : dVarArr) {
                    dVar.i = PagingIndicator.this.f144b ? 1.0f : -1.0f;
                }
            }
            b();
            invalidate();
        }
    }

    @Override // android.view.View
    public void onSizeChanged(int i, int i2, int i3, int i4) {
        setMeasuredDimension(i, i2);
        b();
    }

    public void setArrowBackgroundColor(int i) {
        this.q = i;
    }

    public void setArrowColor(int i) {
        if (this.x == null) {
            this.x = new Paint();
        }
        this.x.setColorFilter(new PorterDuffColorFilter(i, PorterDuff.Mode.SRC_IN));
    }

    public void setDotBackgroundColor(int i) {
        this.r.setColor(i);
    }

    public void setPageCount(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("The page count should be a positive integer");
        }
        this.o = i;
        this.j = new d[i];
        for (int i2 = 0; i2 < this.o; i2++) {
            this.j[i2] = new d();
        }
        b();
        setSelectedPage(0);
    }
}
