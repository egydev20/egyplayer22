package androidx.leanback.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.leanback.widget.SearchOrbView;
import b.g.f;
import b.g.h;
import b.g.n.y;

/* loaded from: classes.dex */
public class TitleView extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    public ImageView f189b;

    /* renamed from: c, reason: collision with root package name */
    public TextView f190c;

    /* renamed from: d, reason: collision with root package name */
    public SearchOrbView f191d;
    public int e;
    public boolean f;
    public final y g;

    /* loaded from: classes.dex */
    public class a extends y {
        public a(TitleView titleView) {
        }
    }

    public TitleView(Context context) {
        this(context, null);
    }

    public TitleView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, b.g.a.browseTitleViewStyle);
    }

    public TitleView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.e = 6;
        this.f = false;
        this.g = new a(this);
        View inflate = LayoutInflater.from(context).inflate(h.lb_title_view, this);
        this.f189b = (ImageView) inflate.findViewById(f.title_badge);
        this.f190c = (TextView) inflate.findViewById(f.title_text);
        this.f191d = (SearchOrbView) inflate.findViewById(f.title_orb);
        setClipToPadding(false);
        setClipChildren(false);
    }

    public final void a() {
        if (this.f189b.getDrawable() != null) {
            this.f189b.setVisibility(0);
            this.f190c.setVisibility(8);
        } else {
            this.f189b.setVisibility(8);
            this.f190c.setVisibility(0);
        }
    }

    public Drawable getBadgeDrawable() {
        return this.f189b.getDrawable();
    }

    public SearchOrbView.c getSearchAffordanceColors() {
        return this.f191d.getOrbColors();
    }

    public View getSearchAffordanceView() {
        return this.f191d;
    }

    public CharSequence getTitle() {
        return this.f190c.getText();
    }

    public y getTitleViewAdapter() {
        return this.g;
    }

    public void setBadgeDrawable(Drawable drawable) {
        this.f189b.setImageDrawable(drawable);
        a();
    }

    public void setOnSearchClickedListener(View.OnClickListener onClickListener) {
        this.f = onClickListener != null;
        this.f191d.setOnOrbClickedListener(onClickListener);
        this.f191d.setVisibility((this.f && (this.e & 4) == 4) ? 0 : 4);
    }

    public void setSearchAffordanceColors(SearchOrbView.c cVar) {
        this.f191d.setOrbColors(cVar);
    }

    public void setTitle(CharSequence charSequence) {
        this.f190c.setText(charSequence);
        a();
    }
}
