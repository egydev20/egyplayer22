package androidx.leanback.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.View;
import b.g.b;

/* loaded from: classes.dex */
public class MediaRowFocusView extends View {

    /* renamed from: b, reason: collision with root package name */
    public final Paint f138b;

    /* renamed from: c, reason: collision with root package name */
    public final RectF f139c;

    /* renamed from: d, reason: collision with root package name */
    public int f140d;

    public MediaRowFocusView(Context context) {
        super(context);
        this.f139c = new RectF();
        this.f138b = a(context);
    }

    public MediaRowFocusView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f139c = new RectF();
        this.f138b = a(context);
    }

    public MediaRowFocusView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f139c = new RectF();
        this.f138b = a(context);
    }

    public final Paint a(Context context) {
        Paint paint = new Paint();
        paint.setColor(context.getResources().getColor(b.lb_playback_media_row_highlight_color));
        return paint;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int height = getHeight() / 2;
        this.f140d = height;
        int height2 = ((height * 2) - getHeight()) / 2;
        this.f139c.set(0.0f, -height2, getWidth(), getHeight() + height2);
        RectF rectF = this.f139c;
        int i = this.f140d;
        canvas.drawRoundRect(rectF, i, i, this.f138b);
    }
}
