package androidx.leanback.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

/* loaded from: classes.dex */
public class ScaleFrameLayout extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    public float f155b;

    /* renamed from: c, reason: collision with root package name */
    public float f156c;

    /* renamed from: d, reason: collision with root package name */
    public float f157d;

    public ScaleFrameLayout(Context context) {
        this(context, null);
    }

    public ScaleFrameLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public ScaleFrameLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f155b = 1.0f;
        this.f156c = 1.0f;
        this.f157d = 1.0f;
    }

    public static int a(int i, float f) {
        return f == 1.0f ? i : View.MeasureSpec.makeMeasureSpec((int) ((View.MeasureSpec.getSize(i) / f) + 0.5f), View.MeasureSpec.getMode(i));
    }

    @Override // android.view.ViewGroup
    public void addView(View view, int i, ViewGroup.LayoutParams layoutParams) {
        super.addView(view, i, layoutParams);
        view.setScaleX(this.f157d);
        view.setScaleY(this.f157d);
    }

    @Override // android.view.ViewGroup
    public boolean addViewInLayout(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z) {
        boolean addViewInLayout = super.addViewInLayout(view, i, layoutParams, z);
        if (addViewInLayout) {
            view.setScaleX(this.f157d);
            view.setScaleY(this.f157d);
        }
        return addViewInLayout;
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x00bc  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x00cc  */
    @Override // android.widget.FrameLayout, android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onLayout(boolean r17, int r18, int r19, int r20, int r21) {
        /*
            Method dump skipped, instructions count: 240
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.leanback.widget.ScaleFrameLayout.onLayout(boolean, int, int, int, int):void");
    }

    @Override // android.widget.FrameLayout, android.view.View
    public void onMeasure(int i, int i2) {
        if (this.f155b == 1.0f && this.f156c == 1.0f) {
            super.onMeasure(i, i2);
        } else {
            super.onMeasure(a(i, this.f155b), a(i2, this.f156c));
            setMeasuredDimension((int) ((getMeasuredWidth() * this.f155b) + 0.5f), (int) ((getMeasuredHeight() * this.f156c) + 0.5f));
        }
    }

    public void setChildScale(float f) {
        if (this.f157d != f) {
            this.f157d = f;
            for (int i = 0; i < getChildCount(); i++) {
                getChildAt(i).setScaleX(f);
                getChildAt(i).setScaleY(f);
            }
        }
    }

    @Override // android.view.View
    public void setForeground(Drawable drawable) {
        throw new UnsupportedOperationException();
    }

    public void setLayoutScaleX(float f) {
        if (f != this.f155b) {
            this.f155b = f;
            requestLayout();
        }
    }

    public void setLayoutScaleY(float f) {
        if (f != this.f156c) {
            this.f156c = f;
            requestLayout();
        }
    }
}
