package androidx.leanback.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import b.g.f;
import b.g.l;

/* loaded from: classes.dex */
public class GuidanceStylingRelativeLayout extends RelativeLayout {

    /* renamed from: b, reason: collision with root package name */
    public float f129b;

    public GuidanceStylingRelativeLayout(Context context) {
        this(context, null);
    }

    public GuidanceStylingRelativeLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public GuidanceStylingRelativeLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f129b = a(context);
    }

    public static float a(Context context) {
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(l.LeanbackGuidedStepTheme);
        float f = obtainStyledAttributes.getFloat(l.LeanbackGuidedStepTheme_guidedStepKeyline, 40.0f);
        obtainStyledAttributes.recycle();
        return f;
    }

    @Override // android.widget.RelativeLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        View findViewById = getRootView().findViewById(f.guidance_title);
        View findViewById2 = getRootView().findViewById(f.guidance_breadcrumb);
        View findViewById3 = getRootView().findViewById(f.guidance_description);
        ImageView imageView = (ImageView) getRootView().findViewById(f.guidance_icon);
        int measuredHeight = (int) ((getMeasuredHeight() * this.f129b) / 100.0f);
        if (findViewById != null && findViewById.getParent() == this) {
            int baseline = (((measuredHeight - findViewById.getBaseline()) - findViewById2.getMeasuredHeight()) - findViewById.getPaddingTop()) - findViewById2.getTop();
            if (findViewById2.getParent() == this) {
                findViewById2.offsetTopAndBottom(baseline);
            }
            findViewById.offsetTopAndBottom(baseline);
            if (findViewById3 != null && findViewById3.getParent() == this) {
                findViewById3.offsetTopAndBottom(baseline);
            }
        }
        if (imageView == null || imageView.getParent() != this || imageView.getDrawable() == null) {
            return;
        }
        imageView.offsetTopAndBottom(measuredHeight - (imageView.getMeasuredHeight() / 2));
    }
}
