package androidx.leanback.widget;

import android.content.Context;
import android.content.res.Resources;
import android.util.AttributeSet;
import androidx.leanback.widget.SearchOrbView;
import b.g.b;
import b.g.d;
import b.g.e;
import b.g.h;

/* loaded from: classes.dex */
public class SpeechOrbView extends SearchOrbView {
    public final float t;
    public SearchOrbView.c u;
    public SearchOrbView.c v;
    public int w;
    public boolean x;

    public SpeechOrbView(Context context) {
        this(context, null);
    }

    public SpeechOrbView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public SpeechOrbView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.w = 0;
        this.x = false;
        Resources resources = context.getResources();
        this.t = resources.getFraction(e.lb_search_bar_speech_orb_max_level_zoom, 1, 1);
        this.v = new SearchOrbView.c(resources.getColor(b.lb_speech_orb_not_recording), resources.getColor(b.lb_speech_orb_not_recording_pulsed), resources.getColor(b.lb_speech_orb_not_recording_icon));
        this.u = new SearchOrbView.c(resources.getColor(b.lb_speech_orb_recording), resources.getColor(b.lb_speech_orb_recording), 0);
        b();
    }

    public void b() {
        setOrbColors(this.v);
        setOrbIcon(getResources().getDrawable(d.lb_ic_search_mic_out));
        a(hasFocus());
        a(1.0f);
        this.x = false;
    }

    @Override // androidx.leanback.widget.SearchOrbView
    public int getLayoutResourceId() {
        return h.lb_speech_orb;
    }

    public void setListeningOrbColors(SearchOrbView.c cVar) {
        this.u = cVar;
    }

    public void setNotListeningOrbColors(SearchOrbView.c cVar) {
        this.v = cVar;
    }

    public void setSoundLevel(int i) {
        if (this.x) {
            int i2 = this.w;
            this.w = i > i2 ? ((i - i2) / 2) + i2 : (int) (i2 * 0.7f);
            a((((this.t - getFocusedZoom()) * this.w) / 100.0f) + 1.0f);
        }
    }
}
