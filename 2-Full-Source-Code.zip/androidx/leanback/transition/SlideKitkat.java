package androidx.leanback.transition;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.TypedArray;
import android.transition.TransitionValues;
import android.transition.Visibility;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import b.g.l;

/* loaded from: classes.dex */
public class SlideKitkat extends Visibility {

    /* renamed from: c, reason: collision with root package name */
    public static final TimeInterpolator f115c = new DecelerateInterpolator();

    /* renamed from: d, reason: collision with root package name */
    public static final TimeInterpolator f116d = new AccelerateInterpolator();
    public static final g e = new a();
    public static final g f = new b();
    public static final g g = new c();
    public static final g h = new d();
    public static final g i = new e();
    public static final g j = new f();

    /* renamed from: b, reason: collision with root package name */
    public g f117b;

    /* loaded from: classes.dex */
    public static class a extends h {
        @Override // androidx.leanback.transition.SlideKitkat.g
        public float a(View view) {
            return view.getTranslationX() - view.getWidth();
        }
    }

    /* loaded from: classes.dex */
    public static class b extends i {
        @Override // androidx.leanback.transition.SlideKitkat.g
        public float a(View view) {
            return view.getTranslationY() - view.getHeight();
        }
    }

    /* loaded from: classes.dex */
    public static class c extends h {
        @Override // androidx.leanback.transition.SlideKitkat.g
        public float a(View view) {
            return view.getTranslationX() + view.getWidth();
        }
    }

    /* loaded from: classes.dex */
    public static class d extends i {
        @Override // androidx.leanback.transition.SlideKitkat.g
        public float a(View view) {
            return view.getTranslationY() + view.getHeight();
        }
    }

    /* loaded from: classes.dex */
    public static class e extends h {
        @Override // androidx.leanback.transition.SlideKitkat.g
        public float a(View view) {
            return view.getLayoutDirection() == 1 ? view.getTranslationX() + view.getWidth() : view.getTranslationX() - view.getWidth();
        }
    }

    /* loaded from: classes.dex */
    public static class f extends h {
        @Override // androidx.leanback.transition.SlideKitkat.g
        public float a(View view) {
            return view.getLayoutDirection() == 1 ? view.getTranslationX() - view.getWidth() : view.getTranslationX() + view.getWidth();
        }
    }

    /* loaded from: classes.dex */
    public interface g {
        float a(View view);

        Property<View, Float> a();

        float b(View view);
    }

    /* loaded from: classes.dex */
    public static abstract class h implements g {
        @Override // androidx.leanback.transition.SlideKitkat.g
        public Property<View, Float> a() {
            return View.TRANSLATION_X;
        }

        @Override // androidx.leanback.transition.SlideKitkat.g
        public float b(View view) {
            return view.getTranslationX();
        }
    }

    /* loaded from: classes.dex */
    public static abstract class i implements g {
        @Override // androidx.leanback.transition.SlideKitkat.g
        public Property<View, Float> a() {
            return View.TRANSLATION_Y;
        }

        @Override // androidx.leanback.transition.SlideKitkat.g
        public float b(View view) {
            return view.getTranslationY();
        }
    }

    /* loaded from: classes.dex */
    public static class j extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        public boolean f118a = false;

        /* renamed from: b, reason: collision with root package name */
        public float f119b;

        /* renamed from: c, reason: collision with root package name */
        public final View f120c;

        /* renamed from: d, reason: collision with root package name */
        public final float f121d;
        public final float e;
        public final int f;
        public final Property<View, Float> g;

        public j(View view, Property<View, Float> property, float f, float f2, int i) {
            this.g = property;
            this.f120c = view;
            this.e = f;
            this.f121d = f2;
            this.f = i;
            view.setVisibility(0);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f120c.setTag(b.g.f.lb_slide_transition_value, new float[]{this.f120c.getTranslationX(), this.f120c.getTranslationY()});
            this.g.set(this.f120c, Float.valueOf(this.e));
            this.f118a = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (!this.f118a) {
                this.g.set(this.f120c, Float.valueOf(this.e));
            }
            this.f120c.setVisibility(this.f);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorPauseListener
        public void onAnimationPause(Animator animator) {
            this.f119b = this.g.get(this.f120c).floatValue();
            this.g.set(this.f120c, Float.valueOf(this.f121d));
            this.f120c.setVisibility(this.f);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorPauseListener
        public void onAnimationResume(Animator animator) {
            this.g.set(this.f120c, Float.valueOf(this.f119b));
            this.f120c.setVisibility(0);
        }
    }

    public SlideKitkat() {
        a(80);
    }

    public SlideKitkat(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.lbSlide);
        a(obtainStyledAttributes.getInt(l.lbSlide_lb_slideEdge, 80));
        long j2 = obtainStyledAttributes.getInt(l.lbSlide_android_duration, -1);
        if (j2 >= 0) {
            setDuration(j2);
        }
        long j3 = obtainStyledAttributes.getInt(l.lbSlide_android_startDelay, -1);
        if (j3 > 0) {
            setStartDelay(j3);
        }
        int resourceId = obtainStyledAttributes.getResourceId(l.lbSlide_android_interpolator, 0);
        if (resourceId > 0) {
            setInterpolator(AnimationUtils.loadInterpolator(context, resourceId));
        }
        obtainStyledAttributes.recycle();
    }

    public final Animator a(View view, Property<View, Float> property, float f2, float f3, float f4, TimeInterpolator timeInterpolator, int i2) {
        float[] fArr = (float[]) view.getTag(b.g.f.lb_slide_transition_value);
        if (fArr != null) {
            f2 = View.TRANSLATION_Y == property ? fArr[1] : fArr[0];
            view.setTag(b.g.f.lb_slide_transition_value, null);
        }
        ObjectAnimator ofFloat = ObjectAnimator.ofFloat(view, property, f2, f3);
        j jVar = new j(view, property, f4, f3, i2);
        ofFloat.addListener(jVar);
        ofFloat.addPauseListener(jVar);
        ofFloat.setInterpolator(timeInterpolator);
        return ofFloat;
    }

    public void a(int i2) {
        g gVar;
        if (i2 == 3) {
            gVar = e;
        } else if (i2 == 5) {
            gVar = g;
        } else if (i2 == 48) {
            gVar = f;
        } else if (i2 == 80) {
            gVar = h;
        } else if (i2 == 8388611) {
            gVar = i;
        } else {
            if (i2 != 8388613) {
                throw new IllegalArgumentException("Invalid slide direction");
            }
            gVar = j;
        }
        this.f117b = gVar;
    }

    @Override // android.transition.Visibility
    public Animator onAppear(ViewGroup viewGroup, TransitionValues transitionValues, int i2, TransitionValues transitionValues2, int i3) {
        View view = transitionValues2 != null ? transitionValues2.view : null;
        if (view == null) {
            return null;
        }
        float b2 = this.f117b.b(view);
        return a(view, this.f117b.a(), this.f117b.a(view), b2, b2, f115c, 0);
    }

    @Override // android.transition.Visibility
    public Animator onDisappear(ViewGroup viewGroup, TransitionValues transitionValues, int i2, TransitionValues transitionValues2, int i3) {
        View view = transitionValues != null ? transitionValues.view : null;
        if (view == null) {
            return null;
        }
        float b2 = this.f117b.b(view);
        return a(view, this.f117b.a(), b2, this.f117b.a(view), b2, f116d, 4);
    }
}
