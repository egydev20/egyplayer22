package androidx.leanback.transition;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.TimeInterpolator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.transition.Fade;
import android.transition.Transition;
import android.transition.TransitionValues;
import android.transition.Visibility;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import b.g.l;

/* loaded from: classes.dex */
public class FadeAndShortSlide extends Visibility {
    public static final TimeInterpolator f = new DecelerateInterpolator();
    public static final g g = new a();
    public static final g h = new b();
    public static final g i = new c();
    public static final g j = new d();
    public static final g k = new e();

    /* renamed from: b, reason: collision with root package name */
    public g f109b;

    /* renamed from: c, reason: collision with root package name */
    public Visibility f110c;

    /* renamed from: d, reason: collision with root package name */
    public float f111d;
    public final g e;

    /* loaded from: classes.dex */
    public static class a extends g {
        @Override // androidx.leanback.transition.FadeAndShortSlide.g
        public float a(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            boolean z = viewGroup.getLayoutDirection() == 1;
            float translationX = view.getTranslationX();
            float a2 = fadeAndShortSlide.a(viewGroup);
            return z ? a2 + translationX : translationX - a2;
        }
    }

    /* loaded from: classes.dex */
    public static class b extends g {
        @Override // androidx.leanback.transition.FadeAndShortSlide.g
        public float a(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            boolean z = viewGroup.getLayoutDirection() == 1;
            float translationX = view.getTranslationX();
            float a2 = fadeAndShortSlide.a(viewGroup);
            return z ? translationX - a2 : translationX + a2;
        }
    }

    /* loaded from: classes.dex */
    public static class c extends g {
        @Override // androidx.leanback.transition.FadeAndShortSlide.g
        public float a(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            int width = (view.getWidth() / 2) + iArr[0];
            viewGroup.getLocationOnScreen(iArr);
            Rect epicenter = fadeAndShortSlide.getEpicenter();
            int width2 = epicenter == null ? (viewGroup.getWidth() / 2) + iArr[0] : epicenter.centerX();
            float translationX = view.getTranslationX();
            float a2 = fadeAndShortSlide.a(viewGroup);
            return width < width2 ? translationX - a2 : a2 + translationX;
        }
    }

    /* loaded from: classes.dex */
    public static class d extends g {
        @Override // androidx.leanback.transition.FadeAndShortSlide.g
        public float b(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return fadeAndShortSlide.b(viewGroup) + view.getTranslationY();
        }
    }

    /* loaded from: classes.dex */
    public static class e extends g {
        @Override // androidx.leanback.transition.FadeAndShortSlide.g
        public float b(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationY() - fadeAndShortSlide.b(viewGroup);
        }
    }

    /* loaded from: classes.dex */
    public class f extends g {
        public f() {
        }

        @Override // androidx.leanback.transition.FadeAndShortSlide.g
        public float b(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            int height = (view.getHeight() / 2) + iArr[1];
            viewGroup.getLocationOnScreen(iArr);
            Rect epicenter = FadeAndShortSlide.this.getEpicenter();
            int height2 = epicenter == null ? (viewGroup.getHeight() / 2) + iArr[1] : epicenter.centerY();
            float translationY = view.getTranslationY();
            float b2 = fadeAndShortSlide.b(viewGroup);
            return height < height2 ? translationY - b2 : b2 + translationY;
        }
    }

    /* loaded from: classes.dex */
    public static abstract class g {
        public float a(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationX();
        }

        public float b(FadeAndShortSlide fadeAndShortSlide, ViewGroup viewGroup, View view, int[] iArr) {
            return view.getTranslationY();
        }
    }

    public FadeAndShortSlide() {
        this(8388611);
    }

    public FadeAndShortSlide(int i2) {
        this.f110c = new Fade();
        this.f111d = -1.0f;
        this.e = new f();
        a(i2);
    }

    public FadeAndShortSlide(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f110c = new Fade();
        this.f111d = -1.0f;
        this.e = new f();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.lbSlide);
        a(obtainStyledAttributes.getInt(l.lbSlide_lb_slideEdge, 8388611));
        obtainStyledAttributes.recycle();
    }

    public float a(ViewGroup viewGroup) {
        float f2 = this.f111d;
        return f2 >= 0.0f ? f2 : viewGroup.getWidth() / 4;
    }

    public void a(int i2) {
        g gVar;
        if (i2 == 48) {
            gVar = k;
        } else if (i2 == 80) {
            gVar = j;
        } else if (i2 == 112) {
            gVar = this.e;
        } else if (i2 == 8388611) {
            gVar = g;
        } else if (i2 == 8388613) {
            gVar = h;
        } else {
            if (i2 != 8388615) {
                throw new IllegalArgumentException("Invalid slide direction");
            }
            gVar = i;
        }
        this.f109b = gVar;
    }

    @Override // android.transition.Transition
    public Transition addListener(Transition.TransitionListener transitionListener) {
        this.f110c.addListener(transitionListener);
        return super.addListener(transitionListener);
    }

    public float b(ViewGroup viewGroup) {
        float f2 = this.f111d;
        return f2 >= 0.0f ? f2 : viewGroup.getHeight() / 4;
    }

    @Override // android.transition.Visibility, android.transition.Transition
    public void captureEndValues(TransitionValues transitionValues) {
        this.f110c.captureEndValues(transitionValues);
        super.captureEndValues(transitionValues);
        int[] iArr = new int[2];
        transitionValues.view.getLocationOnScreen(iArr);
        transitionValues.values.put("android:fadeAndShortSlideTransition:screenPosition", iArr);
    }

    @Override // android.transition.Visibility, android.transition.Transition
    public void captureStartValues(TransitionValues transitionValues) {
        this.f110c.captureStartValues(transitionValues);
        super.captureStartValues(transitionValues);
        int[] iArr = new int[2];
        transitionValues.view.getLocationOnScreen(iArr);
        transitionValues.values.put("android:fadeAndShortSlideTransition:screenPosition", iArr);
    }

    @Override // android.transition.Transition
    public Transition clone() {
        FadeAndShortSlide fadeAndShortSlide = (FadeAndShortSlide) super.clone();
        fadeAndShortSlide.f110c = (Visibility) this.f110c.clone();
        return fadeAndShortSlide;
    }

    @Override // android.transition.Visibility
    public Animator onAppear(ViewGroup viewGroup, View view, TransitionValues transitionValues, TransitionValues transitionValues2) {
        if (transitionValues2 == null || viewGroup == view) {
            return null;
        }
        int[] iArr = (int[]) transitionValues2.values.get("android:fadeAndShortSlideTransition:screenPosition");
        int i2 = iArr[0];
        int i3 = iArr[1];
        float translationX = view.getTranslationX();
        Animator a2 = a.a.a.a.a.a(view, transitionValues2, i2, i3, this.f109b.a(this, viewGroup, view, iArr), this.f109b.b(this, viewGroup, view, iArr), translationX, view.getTranslationY(), f, this);
        Animator onAppear = this.f110c.onAppear(viewGroup, view, transitionValues, transitionValues2);
        if (a2 == null) {
            return onAppear;
        }
        if (onAppear == null) {
            return a2;
        }
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(a2).with(onAppear);
        return animatorSet;
    }

    @Override // android.transition.Visibility
    public Animator onDisappear(ViewGroup viewGroup, View view, TransitionValues transitionValues, TransitionValues transitionValues2) {
        if (transitionValues == null || viewGroup == view) {
            return null;
        }
        int[] iArr = (int[]) transitionValues.values.get("android:fadeAndShortSlideTransition:screenPosition");
        Animator a2 = a.a.a.a.a.a(view, transitionValues, iArr[0], iArr[1], view.getTranslationX(), view.getTranslationY(), this.f109b.a(this, viewGroup, view, iArr), this.f109b.b(this, viewGroup, view, iArr), f, this);
        Animator onDisappear = this.f110c.onDisappear(viewGroup, view, transitionValues, transitionValues2);
        if (a2 == null) {
            return onDisappear;
        }
        if (onDisappear == null) {
            return a2;
        }
        AnimatorSet animatorSet = new AnimatorSet();
        animatorSet.play(a2).with(onDisappear);
        return animatorSet;
    }

    @Override // android.transition.Transition
    public Transition removeListener(Transition.TransitionListener transitionListener) {
        this.f110c.removeListener(transitionListener);
        return super.removeListener(transitionListener);
    }

    @Override // android.transition.Transition
    public void setEpicenterCallback(Transition.EpicenterCallback epicenterCallback) {
        this.f110c.setEpicenterCallback(epicenterCallback);
        super.setEpicenterCallback(epicenterCallback);
    }
}
