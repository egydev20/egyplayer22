package androidx.leanback.app;

import a.a.a.a.a;
import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.widget.LinearLayout;

/* loaded from: classes.dex */
public class GuidedStepRootLayout extends LinearLayout {

    /* renamed from: b, reason: collision with root package name */
    public boolean f107b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f108c;

    public GuidedStepRootLayout(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f107b = false;
        this.f108c = false;
    }

    public GuidedStepRootLayout(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f107b = false;
        this.f108c = false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public View focusSearch(View view, int i) {
        View focusSearch = super.focusSearch(view, i);
        if ((i != 17 && i != 66) || a.a(this, focusSearch)) {
            return focusSearch;
        }
        if (getLayoutDirection() != 0 ? i != 66 : i != 17) {
            if (!this.f108c) {
                return view;
            }
        } else if (!this.f107b) {
            return view;
        }
        return focusSearch;
    }
}
