package androidx.savedstate;

import android.annotation.SuppressLint;
import b.h.a;

@SuppressLint({"RestrictedApi"})
/* loaded from: classes.dex */
public final class Recreator implements a {
}
