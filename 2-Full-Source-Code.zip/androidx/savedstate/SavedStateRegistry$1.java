package androidx.savedstate;

import b.h.a;

/* loaded from: classes.dex */
public class SavedStateRegistry$1 implements a {
}
