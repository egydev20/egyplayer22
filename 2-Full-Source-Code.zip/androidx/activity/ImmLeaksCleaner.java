package androidx.activity;

import b.h.b;

/* loaded from: classes.dex */
public final class ImmLeaksCleaner implements b {
}
