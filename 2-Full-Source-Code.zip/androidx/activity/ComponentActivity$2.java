package androidx.activity;

import b.h.b;

/* loaded from: classes.dex */
public class ComponentActivity$2 implements b {
}
