package androidx.activity;

import b.h.b;

/* loaded from: classes.dex */
public class ComponentActivity$3 implements b {
}
