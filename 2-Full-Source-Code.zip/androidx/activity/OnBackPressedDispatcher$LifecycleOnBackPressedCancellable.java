package androidx.activity;

import b.h.b;

/* loaded from: classes.dex */
public class OnBackPressedDispatcher$LifecycleOnBackPressedCancellable implements b {
}
