package androidx.core.graphics.drawable;

/* loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Code restructure failed: missing block: B:16:0x007c, code lost:
    
        if (r8 != 5) goto L30;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static androidx.core.graphics.drawable.IconCompat read(b.l.a r8) {
        /*
            androidx.core.graphics.drawable.IconCompat r0 = new androidx.core.graphics.drawable.IconCompat
            r0.<init>()
            int r1 = r0.f99a
            r2 = 1
            int r1 = r8.a(r1, r2)
            r0.f99a = r1
            byte[] r1 = r0.f101c
            r3 = 2
            boolean r4 = r8.a(r3)
            if (r4 != 0) goto L18
            goto L2d
        L18:
            r1 = r8
            b.l.b r1 = (b.l.b) r1
            android.os.Parcel r4 = r1.e
            int r4 = r4.readInt()
            if (r4 >= 0) goto L25
            r1 = 0
            goto L2d
        L25:
            byte[] r4 = new byte[r4]
            android.os.Parcel r1 = r1.e
            r1.readByteArray(r4)
            r1 = r4
        L2d:
            r0.f101c = r1
            android.os.Parcelable r1 = r0.f102d
            r4 = 3
            android.os.Parcelable r1 = r8.a(r1, r4)
            r0.f102d = r1
            int r1 = r0.e
            r5 = 4
            int r1 = r8.a(r1, r5)
            r0.e = r1
            int r1 = r0.f
            r6 = 5
            int r1 = r8.a(r1, r6)
            r0.f = r1
            android.content.res.ColorStateList r1 = r0.g
            r7 = 6
            android.os.Parcelable r1 = r8.a(r1, r7)
            android.content.res.ColorStateList r1 = (android.content.res.ColorStateList) r1
            r0.g = r1
            java.lang.String r1 = r0.i
            r7 = 7
            boolean r7 = r8.a(r7)
            if (r7 != 0) goto L5f
            goto L67
        L5f:
            b.l.b r8 = (b.l.b) r8
            android.os.Parcel r8 = r8.e
            java.lang.String r1 = r8.readString()
        L67:
            r0.i = r1
            android.graphics.PorterDuff$Mode r8 = android.graphics.PorterDuff.Mode.valueOf(r1)
            r0.h = r8
            int r8 = r0.f99a
            r1 = -1
            if (r8 == r1) goto La4
            if (r8 == r2) goto L92
            if (r8 == r3) goto L84
            if (r8 == r4) goto L7f
            if (r8 == r5) goto L84
            if (r8 == r6) goto L92
            goto Laa
        L7f:
            byte[] r8 = r0.f101c
            r0.f100b = r8
            goto Laa
        L84:
            java.lang.String r8 = new java.lang.String
            byte[] r1 = r0.f101c
            java.lang.String r2 = "UTF-16"
            java.nio.charset.Charset r2 = java.nio.charset.Charset.forName(r2)
            r8.<init>(r1, r2)
            goto La8
        L92:
            android.os.Parcelable r8 = r0.f102d
            if (r8 == 0) goto L97
            goto La8
        L97:
            byte[] r8 = r0.f101c
            r0.f100b = r8
            r0.f99a = r4
            r1 = 0
            r0.e = r1
            int r8 = r8.length
            r0.f = r8
            goto Laa
        La4:
            android.os.Parcelable r8 = r0.f102d
            if (r8 == 0) goto Lab
        La8:
            r0.f100b = r8
        Laa:
            return r0
        Lab:
            java.lang.IllegalArgumentException r8 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Invalid icon"
            r8.<init>(r0)
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompatParcelizer.read(b.l.a):androidx.core.graphics.drawable.IconCompat");
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x001e, code lost:
    
        if (r0 != 5) goto L16;
     */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0052  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0076  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x007d  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x008b  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:36:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void write(androidx.core.graphics.drawable.IconCompat r8, b.l.a r9) {
        /*
            if (r9 == 0) goto L9f
            android.graphics.PorterDuff$Mode r0 = r8.h
            java.lang.String r0 = r0.name()
            r8.i = r0
            int r0 = r8.f99a
            r1 = 5
            r2 = 4
            r3 = 3
            r4 = 2
            r5 = 1
            r6 = -1
            if (r0 == r6) goto L48
            if (r0 == r5) goto L48
            java.lang.String r7 = "UTF-16"
            if (r0 == r4) goto L39
            if (r0 == r3) goto L32
            if (r0 == r2) goto L21
            if (r0 == r1) goto L48
            goto L4e
        L21:
            java.lang.Object r0 = r8.f100b
            java.lang.String r0 = r0.toString()
            java.nio.charset.Charset r7 = java.nio.charset.Charset.forName(r7)
            byte[] r0 = r0.getBytes(r7)
            r8.f101c = r0
            goto L4e
        L32:
            java.lang.Object r0 = r8.f100b
            byte[] r0 = (byte[]) r0
            r8.f101c = r0
            goto L4e
        L39:
            java.lang.Object r0 = r8.f100b
            java.lang.String r0 = (java.lang.String) r0
            java.nio.charset.Charset r7 = java.nio.charset.Charset.forName(r7)
            byte[] r0 = r0.getBytes(r7)
            r8.f101c = r0
            goto L4e
        L48:
            java.lang.Object r0 = r8.f100b
            android.os.Parcelable r0 = (android.os.Parcelable) r0
            r8.f102d = r0
        L4e:
            int r0 = r8.f99a
            if (r6 == r0) goto L55
            r9.b(r0, r5)
        L55:
            byte[] r0 = r8.f101c
            if (r0 == 0) goto L72
            r9.b(r4)
            r4 = r9
            b.l.b r4 = (b.l.b) r4
            if (r0 == 0) goto L6d
            android.os.Parcel r5 = r4.e
            int r6 = r0.length
            r5.writeInt(r6)
            android.os.Parcel r4 = r4.e
            r4.writeByteArray(r0)
            goto L72
        L6d:
            android.os.Parcel r0 = r4.e
            r0.writeInt(r6)
        L72:
            android.os.Parcelable r0 = r8.f102d
            if (r0 == 0) goto L79
            r9.b(r0, r3)
        L79:
            int r0 = r8.e
            if (r0 == 0) goto L80
            r9.b(r0, r2)
        L80:
            int r0 = r8.f
            if (r0 == 0) goto L87
            r9.b(r0, r1)
        L87:
            android.content.res.ColorStateList r0 = r8.g
            if (r0 == 0) goto L8f
            r1 = 6
            r9.b(r0, r1)
        L8f:
            java.lang.String r8 = r8.i
            if (r8 == 0) goto L9e
            r0 = 7
            r9.b(r0)
            b.l.b r9 = (b.l.b) r9
            android.os.Parcel r9 = r9.e
            r9.writeString(r8)
        L9e:
            return
        L9f:
            r8 = 0
            throw r8
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompatParcelizer.write(androidx.core.graphics.drawable.IconCompat, b.l.a):void");
    }
}
