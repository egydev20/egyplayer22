package androidx.core.app;

import android.app.PendingIntent;
import androidx.core.graphics.drawable.IconCompat;
import b.l.c;

/* loaded from: classes.dex */
public final class RemoteActionCompat implements c {

    /* renamed from: a, reason: collision with root package name */
    public IconCompat f95a;

    /* renamed from: b, reason: collision with root package name */
    public CharSequence f96b;

    /* renamed from: c, reason: collision with root package name */
    public CharSequence f97c;

    /* renamed from: d, reason: collision with root package name */
    public PendingIntent f98d;
    public boolean e;
    public boolean f;
}
