package androidx.versionedparcelable;

import b.l.c;

/* loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements c {
}
