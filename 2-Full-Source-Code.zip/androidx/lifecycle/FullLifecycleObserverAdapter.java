package androidx.lifecycle;

import b.h.b;

/* loaded from: classes.dex */
public class FullLifecycleObserverAdapter implements b {
}
