package androidx.lifecycle;

import b.h.c;

/* loaded from: classes.dex */
public abstract class LiveData<T> {

    /* renamed from: c, reason: collision with root package name */
    public static final Object f194c = new Object();

    /* renamed from: a, reason: collision with root package name */
    public b.b.a.b.a<c<? super T>, LiveData<T>.b> f195a;

    /* renamed from: b, reason: collision with root package name */
    public int f196b;

    /* loaded from: classes.dex */
    public class LifecycleBoundObserver extends LiveData<T>.b implements b.h.a {
    }

    /* loaded from: classes.dex */
    public class a extends LiveData<T>.b {
        public a(LiveData liveData, c<? super T> cVar) {
            super(cVar);
        }
    }

    /* loaded from: classes.dex */
    public abstract class b {

        /* renamed from: a, reason: collision with root package name */
        public final c<? super T> f197a;

        /* renamed from: b, reason: collision with root package name */
        public boolean f198b;

        /* renamed from: c, reason: collision with root package name */
        public int f199c = -1;

        public b(c<? super T> cVar) {
            this.f197a = cVar;
        }

        public void a(boolean z) {
            if (z == this.f198b) {
                return;
            }
            this.f198b = z;
            boolean z2 = LiveData.this.f196b == 0;
            LiveData.this.f196b += this.f198b ? 1 : -1;
            if (z2 && this.f198b) {
                LiveData.this.b();
            }
            LiveData liveData = LiveData.this;
            if (liveData.f196b == 0 && !this.f198b) {
                liveData.c();
            }
            if (this.f198b) {
                LiveData.this.a(this);
            }
        }
    }

    public static void a(String str) {
        if (b.b.a.a.a.b().f478a.a()) {
            return;
        }
        throw new IllegalStateException("Cannot invoke " + str + " on a background thread");
    }

    public abstract T a();

    public abstract void a(LiveData<T>.b bVar);

    public abstract void a(c<? super T> cVar);

    public abstract void b();

    public abstract void c();
}
