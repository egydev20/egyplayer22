package androidx.lifecycle;

import b.h.a;

/* loaded from: classes.dex */
public final class Lifecycling$1 implements a {
}
