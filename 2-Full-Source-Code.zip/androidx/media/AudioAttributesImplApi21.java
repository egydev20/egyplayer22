package androidx.media;

import android.media.AudioAttributes;
import b.i.a;

/* loaded from: classes.dex */
public class AudioAttributesImplApi21 implements a {

    /* renamed from: a, reason: collision with root package name */
    public AudioAttributes f203a;

    /* renamed from: b, reason: collision with root package name */
    public int f204b = -1;

    public boolean equals(Object obj) {
        if (obj instanceof AudioAttributesImplApi21) {
            return this.f203a.equals(((AudioAttributesImplApi21) obj).f203a);
        }
        return false;
    }

    public int hashCode() {
        return this.f203a.hashCode();
    }

    public String toString() {
        StringBuilder a2 = c.a.b.a.a.a("AudioAttributesCompat: audioattributes=");
        a2.append(this.f203a);
        return a2.toString();
    }
}
