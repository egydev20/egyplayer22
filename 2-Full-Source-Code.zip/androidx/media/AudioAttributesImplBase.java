package androidx.media;

import b.i.a;
import java.util.Arrays;
import org.videolan.libvlc.MediaPlayer;

/* loaded from: classes.dex */
public class AudioAttributesImplBase implements a {

    /* renamed from: a, reason: collision with root package name */
    public int f205a = 0;

    /* renamed from: b, reason: collision with root package name */
    public int f206b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f207c = 0;

    /* renamed from: d, reason: collision with root package name */
    public int f208d = -1;

    public boolean equals(Object obj) {
        if (!(obj instanceof AudioAttributesImplBase)) {
            return false;
        }
        AudioAttributesImplBase audioAttributesImplBase = (AudioAttributesImplBase) obj;
        if (this.f206b != audioAttributesImplBase.f206b) {
            return false;
        }
        int i = this.f207c;
        int i2 = audioAttributesImplBase.f207c;
        int i3 = audioAttributesImplBase.f208d;
        if (i3 == -1) {
            i3 = AudioAttributesCompat.a(false, i2, audioAttributesImplBase.f205a);
        }
        if (i3 == 6) {
            i2 |= 4;
        } else if (i3 == 7) {
            i2 |= 1;
        }
        return i == (i2 & MediaPlayer.Event.LengthChanged) && this.f205a == audioAttributesImplBase.f205a && this.f208d == audioAttributesImplBase.f208d;
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{Integer.valueOf(this.f206b), Integer.valueOf(this.f207c), Integer.valueOf(this.f205a), Integer.valueOf(this.f208d)});
    }

    public String toString() {
        StringBuilder sb = new StringBuilder("AudioAttributesCompat:");
        if (this.f208d != -1) {
            sb.append(" stream=");
            sb.append(this.f208d);
            sb.append(" derived");
        }
        sb.append(" usage=");
        sb.append(AudioAttributesCompat.a(this.f205a));
        sb.append(" content=");
        sb.append(this.f206b);
        sb.append(" flags=0x");
        sb.append(Integer.toHexString(this.f207c).toUpperCase());
        return sb.toString();
    }
}
