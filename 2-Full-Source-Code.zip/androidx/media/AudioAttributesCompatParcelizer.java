package androidx.media;

import b.l.a;

/* loaded from: classes.dex */
public class AudioAttributesCompatParcelizer {
    public static AudioAttributesCompat read(a aVar) {
        AudioAttributesCompat audioAttributesCompat = new AudioAttributesCompat();
        Object obj = audioAttributesCompat.f202a;
        if (aVar.a(1)) {
            obj = aVar.c();
        }
        audioAttributesCompat.f202a = (b.i.a) obj;
        return audioAttributesCompat;
    }

    public static void write(AudioAttributesCompat audioAttributesCompat, a aVar) {
        if (aVar != null) {
            b.i.a aVar2 = audioAttributesCompat.f202a;
            aVar.b(1);
            aVar.a(aVar2);
            return;
        }
        throw null;
    }
}
