package androidx.media;

import android.media.AudioAttributes;
import b.l.a;

/* loaded from: classes.dex */
public class AudioAttributesImplApi21Parcelizer {
    public static AudioAttributesImplApi21 read(a aVar) {
        AudioAttributesImplApi21 audioAttributesImplApi21 = new AudioAttributesImplApi21();
        audioAttributesImplApi21.f203a = (AudioAttributes) aVar.a((a) audioAttributesImplApi21.f203a, 1);
        audioAttributesImplApi21.f204b = aVar.a(audioAttributesImplApi21.f204b, 2);
        return audioAttributesImplApi21;
    }

    public static void write(AudioAttributesImplApi21 audioAttributesImplApi21, a aVar) {
        if (aVar == null) {
            throw null;
        }
        aVar.b(audioAttributesImplApi21.f203a, 1);
        aVar.b(audioAttributesImplApi21.f204b, 2);
    }
}
