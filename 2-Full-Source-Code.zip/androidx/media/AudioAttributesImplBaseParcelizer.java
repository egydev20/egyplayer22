package androidx.media;

import b.l.a;

/* loaded from: classes.dex */
public class AudioAttributesImplBaseParcelizer {
    public static AudioAttributesImplBase read(a aVar) {
        AudioAttributesImplBase audioAttributesImplBase = new AudioAttributesImplBase();
        audioAttributesImplBase.f205a = aVar.a(audioAttributesImplBase.f205a, 1);
        audioAttributesImplBase.f206b = aVar.a(audioAttributesImplBase.f206b, 2);
        audioAttributesImplBase.f207c = aVar.a(audioAttributesImplBase.f207c, 3);
        audioAttributesImplBase.f208d = aVar.a(audioAttributesImplBase.f208d, 4);
        return audioAttributesImplBase;
    }

    public static void write(AudioAttributesImplBase audioAttributesImplBase, a aVar) {
        if (aVar == null) {
            throw null;
        }
        aVar.b(audioAttributesImplBase.f205a, 1);
        aVar.b(audioAttributesImplBase.f206b, 2);
        aVar.b(audioAttributesImplBase.f207c, 3);
        aVar.b(audioAttributesImplBase.f208d, 4);
    }
}
