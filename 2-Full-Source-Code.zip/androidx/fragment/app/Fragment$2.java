package androidx.fragment.app;

import b.h.b;

/* loaded from: classes.dex */
public class Fragment$2 implements b {
}
