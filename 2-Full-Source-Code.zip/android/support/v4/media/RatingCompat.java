package android.support.v4.media;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class RatingCompat implements Parcelable {
    public static final Parcelable.Creator<RatingCompat> CREATOR = new a();

    /* renamed from: b, reason: collision with root package name */
    public final int f18b;

    /* renamed from: c, reason: collision with root package name */
    public final float f19c;

    /* loaded from: classes.dex */
    public static class a implements Parcelable.Creator<RatingCompat> {
        @Override // android.os.Parcelable.Creator
        public RatingCompat createFromParcel(Parcel parcel) {
            return new RatingCompat(parcel.readInt(), parcel.readFloat());
        }

        @Override // android.os.Parcelable.Creator
        public RatingCompat[] newArray(int i) {
            return new RatingCompat[i];
        }
    }

    public RatingCompat(int i, float f) {
        this.f18b = i;
        this.f19c = f;
    }

    @Override // android.os.Parcelable
    public int describeContents() {
        return this.f18b;
    }

    public String toString() {
        StringBuilder a2 = c.a.b.a.a.a("Rating:style=");
        a2.append(this.f18b);
        a2.append(" rating=");
        float f = this.f19c;
        a2.append(f < 0.0f ? "unrated" : String.valueOf(f));
        return a2.toString();
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(this.f18b);
        parcel.writeFloat(this.f19c);
    }
}
