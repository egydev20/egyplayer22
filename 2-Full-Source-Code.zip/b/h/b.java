package b.h;

/* loaded from: classes.dex */
public interface b {
}
