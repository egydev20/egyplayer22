package b.h;

@Deprecated
/* loaded from: classes.dex */
public interface a extends b {
}
