package b.h;

/* loaded from: classes.dex */
public interface c<T> {
}
