package b.k.a.a;

import android.animation.TypeEvaluator;

/* loaded from: classes.dex */
public class d implements TypeEvaluator<b.d.f.b[]> {

    /* renamed from: a, reason: collision with root package name */
    public b.d.f.b[] f897a;

    @Override // android.animation.TypeEvaluator
    public b.d.f.b[] evaluate(float f, b.d.f.b[] bVarArr, b.d.f.b[] bVarArr2) {
        b.d.f.b[] bVarArr3 = bVarArr;
        b.d.f.b[] bVarArr4 = bVarArr2;
        if (!a.a.a.a.a.a(bVarArr3, bVarArr4)) {
            throw new IllegalArgumentException("Can't interpolate between two incompatible pathData");
        }
        if (!a.a.a.a.a.a(this.f897a, bVarArr3)) {
            this.f897a = a.a.a.a.a.a(bVarArr3);
        }
        for (int i = 0; i < bVarArr3.length; i++) {
            b.d.f.b bVar = this.f897a[i];
            b.d.f.b bVar2 = bVarArr3[i];
            b.d.f.b bVar3 = bVarArr4[i];
            if (bVar == null) {
                throw null;
            }
            bVar.f550a = bVar2.f550a;
            int i2 = 0;
            while (true) {
                float[] fArr = bVar2.f551b;
                if (i2 < fArr.length) {
                    bVar.f551b[i2] = (bVar3.f551b[i2] * f) + ((1.0f - f) * fArr[i2]);
                    i2++;
                }
            }
        }
        return this.f897a;
    }
}
