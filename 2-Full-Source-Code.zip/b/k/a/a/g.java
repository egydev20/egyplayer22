package b.k.a.a;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.VectorDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public class g extends b.k.a.a.f {
    public static final PorterDuff.Mode k = PorterDuff.Mode.SRC_IN;

    /* renamed from: c, reason: collision with root package name */
    public h f900c;

    /* renamed from: d, reason: collision with root package name */
    public PorterDuffColorFilter f901d;
    public ColorFilter e;
    public boolean f;
    public boolean g;
    public final float[] h;
    public final Matrix i;
    public final Rect j;

    /* loaded from: classes.dex */
    public static class b extends f {
        public b() {
        }

        public b(b bVar) {
            super(bVar);
        }

        @Override // b.k.a.a.g.f
        public boolean b() {
            return true;
        }
    }

    /* loaded from: classes.dex */
    public static class c extends f {
        public int[] e;
        public b.d.e.b.a f;
        public float g;
        public b.d.e.b.a h;
        public float i;
        public float j;
        public float k;
        public float l;
        public float m;
        public Paint.Cap n;
        public Paint.Join o;
        public float p;

        public c() {
            this.g = 0.0f;
            this.i = 1.0f;
            this.j = 1.0f;
            this.k = 0.0f;
            this.l = 1.0f;
            this.m = 0.0f;
            this.n = Paint.Cap.BUTT;
            this.o = Paint.Join.MITER;
            this.p = 4.0f;
        }

        public c(c cVar) {
            super(cVar);
            this.g = 0.0f;
            this.i = 1.0f;
            this.j = 1.0f;
            this.k = 0.0f;
            this.l = 1.0f;
            this.m = 0.0f;
            this.n = Paint.Cap.BUTT;
            this.o = Paint.Join.MITER;
            this.p = 4.0f;
            this.e = cVar.e;
            this.f = cVar.f;
            this.g = cVar.g;
            this.i = cVar.i;
            this.h = cVar.h;
            this.f908c = cVar.f908c;
            this.j = cVar.j;
            this.k = cVar.k;
            this.l = cVar.l;
            this.m = cVar.m;
            this.n = cVar.n;
            this.o = cVar.o;
            this.p = cVar.p;
        }

        @Override // b.k.a.a.g.e
        public boolean a() {
            return this.h.b() || this.f.b();
        }

        @Override // b.k.a.a.g.e
        public boolean a(int[] iArr) {
            return this.f.a(iArr) | this.h.a(iArr);
        }

        public float getFillAlpha() {
            return this.j;
        }

        public int getFillColor() {
            return this.h.f535c;
        }

        public float getStrokeAlpha() {
            return this.i;
        }

        public int getStrokeColor() {
            return this.f.f535c;
        }

        public float getStrokeWidth() {
            return this.g;
        }

        public float getTrimPathEnd() {
            return this.l;
        }

        public float getTrimPathOffset() {
            return this.m;
        }

        public float getTrimPathStart() {
            return this.k;
        }

        public void setFillAlpha(float f) {
            this.j = f;
        }

        public void setFillColor(int i) {
            this.h.f535c = i;
        }

        public void setStrokeAlpha(float f) {
            this.i = f;
        }

        public void setStrokeColor(int i) {
            this.f.f535c = i;
        }

        public void setStrokeWidth(float f) {
            this.g = f;
        }

        public void setTrimPathEnd(float f) {
            this.l = f;
        }

        public void setTrimPathOffset(float f) {
            this.m = f;
        }

        public void setTrimPathStart(float f) {
            this.k = f;
        }
    }

    /* loaded from: classes.dex */
    public static class d extends e {

        /* renamed from: a, reason: collision with root package name */
        public final Matrix f902a;

        /* renamed from: b, reason: collision with root package name */
        public final ArrayList<e> f903b;

        /* renamed from: c, reason: collision with root package name */
        public float f904c;

        /* renamed from: d, reason: collision with root package name */
        public float f905d;
        public float e;
        public float f;
        public float g;
        public float h;
        public float i;
        public final Matrix j;
        public int k;
        public int[] l;
        public String m;

        public d() {
            super(null);
            this.f902a = new Matrix();
            this.f903b = new ArrayList<>();
            this.f904c = 0.0f;
            this.f905d = 0.0f;
            this.e = 0.0f;
            this.f = 1.0f;
            this.g = 1.0f;
            this.h = 0.0f;
            this.i = 0.0f;
            this.j = new Matrix();
            this.m = null;
        }

        public d(d dVar, b.c.a<String, Object> aVar) {
            super(null);
            f bVar;
            this.f902a = new Matrix();
            this.f903b = new ArrayList<>();
            this.f904c = 0.0f;
            this.f905d = 0.0f;
            this.e = 0.0f;
            this.f = 1.0f;
            this.g = 1.0f;
            this.h = 0.0f;
            this.i = 0.0f;
            this.j = new Matrix();
            this.m = null;
            this.f904c = dVar.f904c;
            this.f905d = dVar.f905d;
            this.e = dVar.e;
            this.f = dVar.f;
            this.g = dVar.g;
            this.h = dVar.h;
            this.i = dVar.i;
            this.l = dVar.l;
            String str = dVar.m;
            this.m = str;
            this.k = dVar.k;
            if (str != null) {
                aVar.put(str, this);
            }
            this.j.set(dVar.j);
            ArrayList<e> arrayList = dVar.f903b;
            for (int i = 0; i < arrayList.size(); i++) {
                e eVar = arrayList.get(i);
                if (eVar instanceof d) {
                    this.f903b.add(new d((d) eVar, aVar));
                } else {
                    if (eVar instanceof c) {
                        bVar = new c((c) eVar);
                    } else {
                        if (!(eVar instanceof b)) {
                            throw new IllegalStateException("Unknown object in the tree!");
                        }
                        bVar = new b((b) eVar);
                    }
                    this.f903b.add(bVar);
                    String str2 = bVar.f907b;
                    if (str2 != null) {
                        aVar.put(str2, bVar);
                    }
                }
            }
        }

        @Override // b.k.a.a.g.e
        public boolean a() {
            for (int i = 0; i < this.f903b.size(); i++) {
                if (this.f903b.get(i).a()) {
                    return true;
                }
            }
            return false;
        }

        @Override // b.k.a.a.g.e
        public boolean a(int[] iArr) {
            boolean z = false;
            for (int i = 0; i < this.f903b.size(); i++) {
                z |= this.f903b.get(i).a(iArr);
            }
            return z;
        }

        public final void b() {
            this.j.reset();
            this.j.postTranslate(-this.f905d, -this.e);
            this.j.postScale(this.f, this.g);
            this.j.postRotate(this.f904c, 0.0f, 0.0f);
            this.j.postTranslate(this.h + this.f905d, this.i + this.e);
        }

        public String getGroupName() {
            return this.m;
        }

        public Matrix getLocalMatrix() {
            return this.j;
        }

        public float getPivotX() {
            return this.f905d;
        }

        public float getPivotY() {
            return this.e;
        }

        public float getRotation() {
            return this.f904c;
        }

        public float getScaleX() {
            return this.f;
        }

        public float getScaleY() {
            return this.g;
        }

        public float getTranslateX() {
            return this.h;
        }

        public float getTranslateY() {
            return this.i;
        }

        public void setPivotX(float f) {
            if (f != this.f905d) {
                this.f905d = f;
                b();
            }
        }

        public void setPivotY(float f) {
            if (f != this.e) {
                this.e = f;
                b();
            }
        }

        public void setRotation(float f) {
            if (f != this.f904c) {
                this.f904c = f;
                b();
            }
        }

        public void setScaleX(float f) {
            if (f != this.f) {
                this.f = f;
                b();
            }
        }

        public void setScaleY(float f) {
            if (f != this.g) {
                this.g = f;
                b();
            }
        }

        public void setTranslateX(float f) {
            if (f != this.h) {
                this.h = f;
                b();
            }
        }

        public void setTranslateY(float f) {
            if (f != this.i) {
                this.i = f;
                b();
            }
        }
    }

    /* loaded from: classes.dex */
    public static abstract class e {
        public e() {
        }

        public /* synthetic */ e(a aVar) {
        }

        public boolean a() {
            return false;
        }

        public boolean a(int[] iArr) {
            return false;
        }
    }

    /* loaded from: classes.dex */
    public static abstract class f extends e {

        /* renamed from: a, reason: collision with root package name */
        public b.d.f.b[] f906a;

        /* renamed from: b, reason: collision with root package name */
        public String f907b;

        /* renamed from: c, reason: collision with root package name */
        public int f908c;

        /* renamed from: d, reason: collision with root package name */
        public int f909d;

        public f() {
            super(null);
            this.f906a = null;
            this.f908c = 0;
        }

        public f(f fVar) {
            super(null);
            this.f906a = null;
            this.f908c = 0;
            this.f907b = fVar.f907b;
            this.f909d = fVar.f909d;
            this.f906a = a.a.a.a.a.a(fVar.f906a);
        }

        public boolean b() {
            return false;
        }

        public b.d.f.b[] getPathData() {
            return this.f906a;
        }

        public String getPathName() {
            return this.f907b;
        }

        public void setPathData(b.d.f.b[] bVarArr) {
            if (!a.a.a.a.a.a(this.f906a, bVarArr)) {
                this.f906a = a.a.a.a.a.a(bVarArr);
                return;
            }
            b.d.f.b[] bVarArr2 = this.f906a;
            for (int i = 0; i < bVarArr.length; i++) {
                bVarArr2[i].f550a = bVarArr[i].f550a;
                for (int i2 = 0; i2 < bVarArr[i].f551b.length; i2++) {
                    bVarArr2[i].f551b[i2] = bVarArr[i].f551b[i2];
                }
            }
        }
    }

    /* renamed from: b.k.a.a.g$g, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0031g {
        public static final Matrix q = new Matrix();

        /* renamed from: a, reason: collision with root package name */
        public final Path f910a;

        /* renamed from: b, reason: collision with root package name */
        public final Path f911b;

        /* renamed from: c, reason: collision with root package name */
        public final Matrix f912c;

        /* renamed from: d, reason: collision with root package name */
        public Paint f913d;
        public Paint e;
        public PathMeasure f;
        public int g;
        public final d h;
        public float i;
        public float j;
        public float k;
        public float l;
        public int m;
        public String n;
        public Boolean o;
        public final b.c.a<String, Object> p;

        public C0031g() {
            this.f912c = new Matrix();
            this.i = 0.0f;
            this.j = 0.0f;
            this.k = 0.0f;
            this.l = 0.0f;
            this.m = 255;
            this.n = null;
            this.o = null;
            this.p = new b.c.a<>();
            this.h = new d();
            this.f910a = new Path();
            this.f911b = new Path();
        }

        public C0031g(C0031g c0031g) {
            this.f912c = new Matrix();
            this.i = 0.0f;
            this.j = 0.0f;
            this.k = 0.0f;
            this.l = 0.0f;
            this.m = 255;
            this.n = null;
            this.o = null;
            b.c.a<String, Object> aVar = new b.c.a<>();
            this.p = aVar;
            this.h = new d(c0031g.h, aVar);
            this.f910a = new Path(c0031g.f910a);
            this.f911b = new Path(c0031g.f911b);
            this.i = c0031g.i;
            this.j = c0031g.j;
            this.k = c0031g.k;
            this.l = c0031g.l;
            this.g = c0031g.g;
            this.m = c0031g.m;
            this.n = c0031g.n;
            String str = c0031g.n;
            if (str != null) {
                this.p.put(str, this);
            }
            this.o = c0031g.o;
        }

        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Type inference failed for: r11v0 */
        /* JADX WARN: Type inference failed for: r11v1, types: [boolean] */
        /* JADX WARN: Type inference failed for: r11v11 */
        public final void a(d dVar, Matrix matrix, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            C0031g c0031g;
            C0031g c0031g2 = this;
            dVar.f902a.set(matrix);
            dVar.f902a.preConcat(dVar.j);
            canvas.save();
            ?? r11 = 0;
            int i3 = 0;
            while (i3 < dVar.f903b.size()) {
                e eVar = dVar.f903b.get(i3);
                if (eVar instanceof d) {
                    a((d) eVar, dVar.f902a, canvas, i, i2, colorFilter);
                } else if (eVar instanceof f) {
                    f fVar = (f) eVar;
                    float f = i / c0031g2.k;
                    float f2 = i2 / c0031g2.l;
                    float min = Math.min(f, f2);
                    Matrix matrix2 = dVar.f902a;
                    c0031g2.f912c.set(matrix2);
                    c0031g2.f912c.postScale(f, f2);
                    float[] fArr = {0.0f, 1.0f, 1.0f, 0.0f};
                    matrix2.mapVectors(fArr);
                    float hypot = (float) Math.hypot(fArr[r11], fArr[1]);
                    float hypot2 = (float) Math.hypot(fArr[2], fArr[3]);
                    float f3 = (fArr[r11] * fArr[3]) - (fArr[1] * fArr[2]);
                    float max = Math.max(hypot, hypot2);
                    float abs = max > 0.0f ? Math.abs(f3) / max : 0.0f;
                    if (abs == 0.0f) {
                        c0031g = this;
                    } else {
                        c0031g = this;
                        Path path = c0031g.f910a;
                        if (fVar != null) {
                            path.reset();
                            b.d.f.b[] bVarArr = fVar.f906a;
                            if (bVarArr != null) {
                                b.d.f.b.a(bVarArr, path);
                            }
                            Path path2 = c0031g.f910a;
                            c0031g.f911b.reset();
                            if (fVar.b()) {
                                c0031g.f911b.setFillType(fVar.f908c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                                c0031g.f911b.addPath(path2, c0031g.f912c);
                                canvas.clipPath(c0031g.f911b);
                            } else {
                                c cVar = (c) fVar;
                                if (cVar.k != 0.0f || cVar.l != 1.0f) {
                                    float f4 = cVar.k;
                                    float f5 = cVar.m;
                                    float f6 = (f4 + f5) % 1.0f;
                                    float f7 = (cVar.l + f5) % 1.0f;
                                    if (c0031g.f == null) {
                                        c0031g.f = new PathMeasure();
                                    }
                                    c0031g.f.setPath(c0031g.f910a, r11);
                                    float length = c0031g.f.getLength();
                                    float f8 = f6 * length;
                                    float f9 = f7 * length;
                                    path2.reset();
                                    if (f8 > f9) {
                                        c0031g.f.getSegment(f8, length, path2, true);
                                        c0031g.f.getSegment(0.0f, f9, path2, true);
                                    } else {
                                        c0031g.f.getSegment(f8, f9, path2, true);
                                    }
                                    path2.rLineTo(0.0f, 0.0f);
                                }
                                c0031g.f911b.addPath(path2, c0031g.f912c);
                                b.d.e.b.a aVar = cVar.h;
                                if (aVar.a() || aVar.f535c != 0) {
                                    b.d.e.b.a aVar2 = cVar.h;
                                    if (c0031g.e == null) {
                                        Paint paint = new Paint(1);
                                        c0031g.e = paint;
                                        paint.setStyle(Paint.Style.FILL);
                                    }
                                    Paint paint2 = c0031g.e;
                                    if (aVar2.a()) {
                                        Shader shader = aVar2.f533a;
                                        shader.setLocalMatrix(c0031g.f912c);
                                        paint2.setShader(shader);
                                        paint2.setAlpha(Math.round(cVar.j * 255.0f));
                                    } else {
                                        paint2.setShader(null);
                                        paint2.setAlpha(255);
                                        paint2.setColor(g.a(aVar2.f535c, cVar.j));
                                    }
                                    paint2.setColorFilter(colorFilter);
                                    c0031g.f911b.setFillType(cVar.f908c == 0 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD);
                                    canvas.drawPath(c0031g.f911b, paint2);
                                }
                                b.d.e.b.a aVar3 = cVar.f;
                                if (aVar3.a() || aVar3.f535c != 0) {
                                    b.d.e.b.a aVar4 = cVar.f;
                                    if (c0031g.f913d == null) {
                                        Paint paint3 = new Paint(1);
                                        c0031g.f913d = paint3;
                                        paint3.setStyle(Paint.Style.STROKE);
                                    }
                                    Paint paint4 = c0031g.f913d;
                                    Paint.Join join = cVar.o;
                                    if (join != null) {
                                        paint4.setStrokeJoin(join);
                                    }
                                    Paint.Cap cap = cVar.n;
                                    if (cap != null) {
                                        paint4.setStrokeCap(cap);
                                    }
                                    paint4.setStrokeMiter(cVar.p);
                                    if (aVar4.a()) {
                                        Shader shader2 = aVar4.f533a;
                                        shader2.setLocalMatrix(c0031g.f912c);
                                        paint4.setShader(shader2);
                                        paint4.setAlpha(Math.round(cVar.i * 255.0f));
                                    } else {
                                        paint4.setShader(null);
                                        paint4.setAlpha(255);
                                        paint4.setColor(g.a(aVar4.f535c, cVar.i));
                                    }
                                    paint4.setColorFilter(colorFilter);
                                    paint4.setStrokeWidth(cVar.g * abs * min);
                                    canvas.drawPath(c0031g.f911b, paint4);
                                }
                            }
                        } else {
                            throw null;
                        }
                    }
                    i3++;
                    c0031g2 = c0031g;
                    r11 = 0;
                }
                c0031g = c0031g2;
                i3++;
                c0031g2 = c0031g;
                r11 = 0;
            }
            canvas.restore();
        }

        public float getAlpha() {
            return getRootAlpha() / 255.0f;
        }

        public int getRootAlpha() {
            return this.m;
        }

        public void setAlpha(float f) {
            setRootAlpha((int) (f * 255.0f));
        }

        public void setRootAlpha(int i) {
            this.m = i;
        }
    }

    /* loaded from: classes.dex */
    public static class h extends Drawable.ConstantState {

        /* renamed from: a, reason: collision with root package name */
        public int f914a;

        /* renamed from: b, reason: collision with root package name */
        public C0031g f915b;

        /* renamed from: c, reason: collision with root package name */
        public ColorStateList f916c;

        /* renamed from: d, reason: collision with root package name */
        public PorterDuff.Mode f917d;
        public boolean e;
        public Bitmap f;
        public ColorStateList g;
        public PorterDuff.Mode h;
        public int i;
        public boolean j;
        public boolean k;
        public Paint l;

        public h() {
            this.f916c = null;
            this.f917d = g.k;
            this.f915b = new C0031g();
        }

        public h(h hVar) {
            this.f916c = null;
            this.f917d = g.k;
            if (hVar != null) {
                this.f914a = hVar.f914a;
                C0031g c0031g = new C0031g(hVar.f915b);
                this.f915b = c0031g;
                if (hVar.f915b.e != null) {
                    c0031g.e = new Paint(hVar.f915b.e);
                }
                if (hVar.f915b.f913d != null) {
                    this.f915b.f913d = new Paint(hVar.f915b.f913d);
                }
                this.f916c = hVar.f916c;
                this.f917d = hVar.f917d;
                this.e = hVar.e;
            }
        }

        public boolean a() {
            C0031g c0031g = this.f915b;
            if (c0031g.o == null) {
                c0031g.o = Boolean.valueOf(c0031g.h.a());
            }
            return c0031g.o.booleanValue();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f914a;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            return new g(this);
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            return new g(this);
        }

        public void a(int i, int i2) {
            this.f.eraseColor(0);
            Canvas canvas = new Canvas(this.f);
            C0031g c0031g = this.f915b;
            c0031g.a(c0031g.h, C0031g.q, canvas, i, i2, null);
        }
    }

    /* loaded from: classes.dex */
    public static class i extends Drawable.ConstantState {

        /* renamed from: a, reason: collision with root package name */
        public final Drawable.ConstantState f918a;

        public i(Drawable.ConstantState constantState) {
            this.f918a = constantState;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public boolean canApplyTheme() {
            return this.f918a.canApplyTheme();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f918a.getChangingConfigurations();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            g gVar = new g();
            gVar.f899b = (VectorDrawable) this.f918a.newDrawable();
            return gVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            g gVar = new g();
            gVar.f899b = (VectorDrawable) this.f918a.newDrawable(resources);
            return gVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            g gVar = new g();
            gVar.f899b = (VectorDrawable) this.f918a.newDrawable(resources, theme);
            return gVar;
        }
    }

    public g() {
        this.g = true;
        this.h = new float[9];
        this.i = new Matrix();
        this.j = new Rect();
        this.f900c = new h();
    }

    public g(h hVar) {
        this.g = true;
        this.h = new float[9];
        this.i = new Matrix();
        this.j = new Rect();
        this.f900c = hVar;
        this.f901d = a(hVar.f916c, hVar.f917d);
    }

    public static int a(int i2, float f2) {
        return (i2 & 16777215) | (((int) (Color.alpha(i2) * f2)) << 24);
    }

    public static g a(Resources resources, int i2, Resources.Theme theme) {
        int next;
        if (Build.VERSION.SDK_INT >= 24) {
            g gVar = new g();
            gVar.f899b = resources.getDrawable(i2, theme);
            new i(gVar.f899b.getConstantState());
            return gVar;
        }
        try {
            XmlResourceParser xml = resources.getXml(i2);
            AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
            do {
                next = xml.next();
                if (next == 2) {
                    break;
                }
            } while (next != 1);
            if (next == 2) {
                return createFromXmlInner(resources, (XmlPullParser) xml, asAttributeSet, theme);
            }
            throw new XmlPullParserException("No start tag found");
        } catch (IOException | XmlPullParserException e2) {
            Log.e("VectorDrawableCompat", "parser error", e2);
            return null;
        }
    }

    public static g createFromXmlInner(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        g gVar = new g();
        gVar.inflate(resources, xmlPullParser, attributeSet, theme);
        return gVar;
    }

    public PorterDuffColorFilter a(ColorStateList colorStateList, PorterDuff.Mode mode) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean canApplyTheme() {
        Drawable drawable = this.f899b;
        if (drawable == null) {
            return false;
        }
        drawable.canApplyTheme();
        return false;
    }

    /* JADX WARN: Code restructure failed: missing block: B:34:0x00d3, code lost:
    
        if ((r1 == r7.getWidth() && r3 == r6.f.getHeight()) == false) goto L40;
     */
    @Override // android.graphics.drawable.Drawable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void draw(android.graphics.Canvas r11) {
        /*
            Method dump skipped, instructions count: 364
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.k.a.a.g.draw(android.graphics.Canvas):void");
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.getAlpha();
        }
        return this.f900c.f915b.getRootAlpha();
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.f900c.getChangingConfigurations();
    }

    @Override // android.graphics.drawable.Drawable
    public ColorFilter getColorFilter() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.getColorFilter();
        }
        return this.e;
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        if (this.f899b != null && Build.VERSION.SDK_INT >= 24) {
            return new i(this.f899b.getConstantState());
        }
        this.f900c.f914a = getChangingConfigurations();
        return this.f900c;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.getIntrinsicHeight() : (int) this.f900c.f915b.j;
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.getIntrinsicWidth() : (int) this.f900c.f915b.i;
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.getOpacity();
        }
        return -3;
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.inflate(resources, xmlPullParser, attributeSet);
        } else {
            inflate(resources, xmlPullParser, attributeSet, null);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:131:0x043e  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x00af  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x00bc  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00e1  */
    @Override // android.graphics.drawable.Drawable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void inflate(android.content.res.Resources r28, org.xmlpull.v1.XmlPullParser r29, android.util.AttributeSet r30, android.content.res.Resources.Theme r31) {
        /*
            Method dump skipped, instructions count: 1124
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.k.a.a.g.inflate(android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):void");
    }

    @Override // android.graphics.drawable.Drawable
    public void invalidateSelf() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.invalidateSelf();
        } else {
            super.invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.isAutoMirrored();
        }
        return this.f900c.e;
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        h hVar;
        ColorStateList colorStateList;
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.isStateful() : super.isStateful() || ((hVar = this.f900c) != null && (hVar.a() || ((colorStateList = this.f900c.f916c) != null && colorStateList.isStateful())));
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.mutate();
            return this;
        }
        if (!this.f && super.mutate() == this) {
            this.f900c = new h(this.f900c);
            this.f = true;
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.setBounds(rect);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onStateChange(int[] iArr) {
        PorterDuff.Mode mode;
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.setState(iArr);
        }
        boolean z = false;
        h hVar = this.f900c;
        ColorStateList colorStateList = hVar.f916c;
        if (colorStateList != null && (mode = hVar.f917d) != null) {
            this.f901d = a(colorStateList, mode);
            invalidateSelf();
            z = true;
        }
        if (hVar.a()) {
            boolean a2 = hVar.f915b.h.a(iArr);
            hVar.k |= a2;
            if (a2) {
                invalidateSelf();
                return true;
            }
        }
        return z;
    }

    @Override // android.graphics.drawable.Drawable
    public void scheduleSelf(Runnable runnable, long j) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.scheduleSelf(runnable, j);
        } else {
            super.scheduleSelf(runnable, j);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i2) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.setAlpha(i2);
        } else if (this.f900c.f915b.getRootAlpha() != i2) {
            this.f900c.f915b.setRootAlpha(i2);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.setAutoMirrored(z);
        } else {
            this.f900c.e = z;
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
        } else {
            this.e = colorFilter;
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i2) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            a.a.a.a.a.a(drawable, i2);
        } else {
            setTintList(ColorStateList.valueOf(i2));
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            a.a.a.a.a.a(drawable, colorStateList);
            return;
        }
        h hVar = this.f900c;
        if (hVar.f916c != colorStateList) {
            hVar.f916c = colorStateList;
            this.f901d = a(colorStateList, hVar.f917d);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            a.a.a.a.a.a(drawable, mode);
            return;
        }
        h hVar = this.f900c;
        if (hVar.f917d != mode) {
            hVar.f917d = mode;
            this.f901d = a(hVar.f916c, mode);
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.setVisible(z, z2) : super.setVisible(z, z2);
    }

    @Override // android.graphics.drawable.Drawable
    public void unscheduleSelf(Runnable runnable) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.unscheduleSelf(runnable);
        } else {
            super.unscheduleSelf(runnable);
        }
    }
}
