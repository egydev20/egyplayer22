package b.k.a.a;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public class c extends f implements b.k.a.a.b {

    /* renamed from: c, reason: collision with root package name */
    public b f889c;

    /* renamed from: d, reason: collision with root package name */
    public Context f890d;
    public ArgbEvaluator e;
    public final Drawable.Callback f;

    /* loaded from: classes.dex */
    public class a implements Drawable.Callback {
        public a() {
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void invalidateDrawable(Drawable drawable) {
            c.this.invalidateSelf();
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
            c.this.scheduleSelf(runnable, j);
        }

        @Override // android.graphics.drawable.Drawable.Callback
        public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
            c.this.unscheduleSelf(runnable);
        }
    }

    /* loaded from: classes.dex */
    public static class b extends Drawable.ConstantState {

        /* renamed from: a, reason: collision with root package name */
        public int f892a;

        /* renamed from: b, reason: collision with root package name */
        public g f893b;

        /* renamed from: c, reason: collision with root package name */
        public AnimatorSet f894c;

        /* renamed from: d, reason: collision with root package name */
        public ArrayList<Animator> f895d;
        public b.c.a<Animator, String> e;

        public b(b bVar, Drawable.Callback callback, Resources resources) {
            if (bVar != null) {
                this.f892a = bVar.f892a;
                g gVar = bVar.f893b;
                if (gVar != null) {
                    Drawable.ConstantState constantState = gVar.getConstantState();
                    g gVar2 = (g) (resources != null ? constantState.newDrawable(resources) : constantState.newDrawable());
                    this.f893b = gVar2;
                    gVar2.mutate();
                    this.f893b = gVar2;
                    gVar2.setCallback(callback);
                    this.f893b.setBounds(bVar.f893b.getBounds());
                    this.f893b.g = false;
                }
                ArrayList<Animator> arrayList = bVar.f895d;
                if (arrayList != null) {
                    int size = arrayList.size();
                    this.f895d = new ArrayList<>(size);
                    this.e = new b.c.a<>(size);
                    for (int i = 0; i < size; i++) {
                        Animator animator = bVar.f895d.get(i);
                        Animator clone = animator.clone();
                        String orDefault = bVar.e.getOrDefault(animator, null);
                        clone.setTarget(this.f893b.f900c.f915b.p.getOrDefault(orDefault, null));
                        this.f895d.add(clone);
                        this.e.put(clone, orDefault);
                    }
                    if (this.f894c == null) {
                        this.f894c = new AnimatorSet();
                    }
                    this.f894c.playTogether(this.f895d);
                }
            }
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f892a;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }
    }

    public c() {
        this(null, null, null);
    }

    public c(Context context, b bVar, Resources resources) {
        this.e = null;
        this.f = new a();
        this.f890d = context;
        if (bVar != null) {
            this.f889c = bVar;
        } else {
            this.f889c = new b(bVar, this.f, resources);
        }
    }

    @Override // b.k.a.a.f, android.graphics.drawable.Drawable
    public void applyTheme(Resources.Theme theme) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.applyTheme(theme);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean canApplyTheme() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.canApplyTheme();
        }
        return false;
    }

    @Override // android.graphics.drawable.Drawable
    public void draw(Canvas canvas) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.draw(canvas);
            return;
        }
        this.f889c.f893b.draw(canvas);
        if (this.f889c.f894c.isStarted()) {
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public int getAlpha() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.getAlpha();
        }
        return this.f889c.f893b.getAlpha();
    }

    @Override // android.graphics.drawable.Drawable
    public int getChangingConfigurations() {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.getChangingConfigurations() : super.getChangingConfigurations() | this.f889c.f892a;
    }

    @Override // android.graphics.drawable.Drawable
    public ColorFilter getColorFilter() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.getColorFilter();
        }
        return this.f889c.f893b.getColorFilter();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable.ConstantState getConstantState() {
        if (this.f899b == null || Build.VERSION.SDK_INT < 24) {
            return null;
        }
        return new C0030c(this.f899b.getConstantState());
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicHeight() {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.getIntrinsicHeight() : this.f889c.f893b.getIntrinsicHeight();
    }

    @Override // android.graphics.drawable.Drawable
    public int getIntrinsicWidth() {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.getIntrinsicWidth() : this.f889c.f893b.getIntrinsicWidth();
    }

    @Override // android.graphics.drawable.Drawable
    public int getOpacity() {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.getOpacity() : this.f889c.f893b.getOpacity();
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        inflate(resources, xmlPullParser, attributeSet, null);
    }

    @Override // android.graphics.drawable.Drawable
    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
        TypedArray obtainAttributes;
        String str;
        XmlResourceParser xmlResourceParser;
        Animator a2;
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.inflate(resources, xmlPullParser, attributeSet, theme);
            return;
        }
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        for (int i = 1; eventType != i && (xmlPullParser.getDepth() >= depth || eventType != 3); i = 1) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                if ("animated-vector".equals(name)) {
                    obtainAttributes = a.a.a.a.a.a(resources, theme, attributeSet, b.k.a.a.a.e);
                    int resourceId = obtainAttributes.getResourceId(0, 0);
                    if (resourceId != 0) {
                        g a3 = g.a(resources, resourceId, theme);
                        a3.g = false;
                        a3.setCallback(this.f);
                        g gVar = this.f889c.f893b;
                        if (gVar != null) {
                            gVar.setCallback(null);
                        }
                        this.f889c.f893b = a3;
                    }
                } else if ("target".equals(name)) {
                    obtainAttributes = resources.obtainAttributes(attributeSet, b.k.a.a.a.f);
                    String string = obtainAttributes.getString(0);
                    int resourceId2 = obtainAttributes.getResourceId(i, 0);
                    if (resourceId2 != 0) {
                        Context context = this.f890d;
                        if (context != null) {
                            if (Build.VERSION.SDK_INT >= 24) {
                                a2 = AnimatorInflater.loadAnimator(context, resourceId2);
                            } else {
                                Resources resources2 = context.getResources();
                                Resources.Theme theme2 = context.getTheme();
                                try {
                                    try {
                                        xmlResourceParser = resources2.getAnimation(resourceId2);
                                        try {
                                            try {
                                                str = "Can't load animation resource ID #0x";
                                                try {
                                                    a2 = a.a.a.a.a.a(context, resources2, theme2, xmlResourceParser, Xml.asAttributeSet(xmlResourceParser), null, 0, 1.0f);
                                                    xmlResourceParser.close();
                                                } catch (IOException e) {
                                                    e = e;
                                                    Resources.NotFoundException notFoundException = new Resources.NotFoundException(str + Integer.toHexString(resourceId2));
                                                    notFoundException.initCause(e);
                                                    throw notFoundException;
                                                } catch (XmlPullParserException e2) {
                                                    e = e2;
                                                    Resources.NotFoundException notFoundException2 = new Resources.NotFoundException(str + Integer.toHexString(resourceId2));
                                                    notFoundException2.initCause(e);
                                                    throw notFoundException2;
                                                }
                                            } catch (Throwable th) {
                                                th = th;
                                                if (xmlResourceParser != null) {
                                                    xmlResourceParser.close();
                                                }
                                                throw th;
                                            }
                                        } catch (IOException e3) {
                                            e = e3;
                                            str = "Can't load animation resource ID #0x";
                                        } catch (XmlPullParserException e4) {
                                            e = e4;
                                            str = "Can't load animation resource ID #0x";
                                        }
                                    } catch (Throwable th2) {
                                        th = th2;
                                        xmlResourceParser = null;
                                    }
                                } catch (IOException e5) {
                                    e = e5;
                                    str = "Can't load animation resource ID #0x";
                                } catch (XmlPullParserException e6) {
                                    e = e6;
                                    str = "Can't load animation resource ID #0x";
                                }
                            }
                            a2.setTarget(this.f889c.f893b.f900c.f915b.p.getOrDefault(string, null));
                            b bVar = this.f889c;
                            if (bVar.f895d == null) {
                                bVar.f895d = new ArrayList<>();
                                this.f889c.e = new b.c.a<>();
                            }
                            this.f889c.f895d.add(a2);
                            this.f889c.e.put(a2, string);
                        } else {
                            obtainAttributes.recycle();
                            throw new IllegalStateException("Context can't be null when inflating animators");
                        }
                    }
                } else {
                    continue;
                }
                obtainAttributes.recycle();
            }
            eventType = xmlPullParser.next();
        }
        b bVar2 = this.f889c;
        if (bVar2.f894c == null) {
            bVar2.f894c = new AnimatorSet();
        }
        bVar2.f894c.playTogether(bVar2.f895d);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isAutoMirrored() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.isAutoMirrored();
        }
        return this.f889c.f893b.isAutoMirrored();
    }

    @Override // android.graphics.drawable.Animatable
    public boolean isRunning() {
        Drawable drawable = this.f899b;
        return drawable != null ? ((AnimatedVectorDrawable) drawable).isRunning() : this.f889c.f894c.isRunning();
    }

    @Override // android.graphics.drawable.Drawable
    public boolean isStateful() {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.isStateful() : this.f889c.f893b.isStateful();
    }

    @Override // android.graphics.drawable.Drawable
    public Drawable mutate() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.mutate();
        }
        return this;
    }

    @Override // android.graphics.drawable.Drawable
    public void onBoundsChange(Rect rect) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.setBounds(rect);
        } else {
            this.f889c.f893b.setBounds(rect);
        }
    }

    @Override // b.k.a.a.f, android.graphics.drawable.Drawable
    public boolean onLevelChange(int i) {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.setLevel(i) : this.f889c.f893b.setLevel(i);
    }

    @Override // android.graphics.drawable.Drawable
    public boolean onStateChange(int[] iArr) {
        Drawable drawable = this.f899b;
        return drawable != null ? drawable.setState(iArr) : this.f889c.f893b.setState(iArr);
    }

    @Override // android.graphics.drawable.Drawable
    public void setAlpha(int i) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.setAlpha(i);
        } else {
            this.f889c.f893b.setAlpha(i);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setAutoMirrored(boolean z) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.setAutoMirrored(z);
            return;
        }
        g gVar = this.f889c.f893b;
        Drawable drawable2 = gVar.f899b;
        if (drawable2 != null) {
            drawable2.setAutoMirrored(z);
        } else {
            gVar.f900c.e = z;
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setColorFilter(ColorFilter colorFilter) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            drawable.setColorFilter(colorFilter);
            return;
        }
        g gVar = this.f889c.f893b;
        Drawable drawable2 = gVar.f899b;
        if (drawable2 != null) {
            drawable2.setColorFilter(colorFilter);
        } else {
            gVar.e = colorFilter;
            gVar.invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTint(int i) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            a.a.a.a.a.a(drawable, i);
        } else {
            this.f889c.f893b.setTint(i);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintList(ColorStateList colorStateList) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            a.a.a.a.a.a(drawable, colorStateList);
        } else {
            this.f889c.f893b.setTintList(colorStateList);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public void setTintMode(PorterDuff.Mode mode) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            a.a.a.a.a.a(drawable, mode);
        } else {
            this.f889c.f893b.setTintMode(mode);
        }
    }

    @Override // android.graphics.drawable.Drawable
    public boolean setVisible(boolean z, boolean z2) {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            return drawable.setVisible(z, z2);
        }
        this.f889c.f893b.setVisible(z, z2);
        return super.setVisible(z, z2);
    }

    @Override // android.graphics.drawable.Animatable
    public void start() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).start();
        } else {
            if (this.f889c.f894c.isStarted()) {
                return;
            }
            this.f889c.f894c.start();
            invalidateSelf();
        }
    }

    @Override // android.graphics.drawable.Animatable
    public void stop() {
        Drawable drawable = this.f899b;
        if (drawable != null) {
            ((AnimatedVectorDrawable) drawable).stop();
        } else {
            this.f889c.f894c.end();
        }
    }

    /* renamed from: b.k.a.a.c$c, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0030c extends Drawable.ConstantState {

        /* renamed from: a, reason: collision with root package name */
        public final Drawable.ConstantState f896a;

        public C0030c(Drawable.ConstantState constantState) {
            this.f896a = constantState;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public boolean canApplyTheme() {
            return this.f896a.canApplyTheme();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public int getChangingConfigurations() {
            return this.f896a.getChangingConfigurations();
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            c cVar = new c(null, null, null);
            Drawable newDrawable = this.f896a.newDrawable();
            cVar.f899b = newDrawable;
            newDrawable.setCallback(cVar.f);
            return cVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            c cVar = new c(null, null, null);
            Drawable newDrawable = this.f896a.newDrawable(resources);
            cVar.f899b = newDrawable;
            newDrawable.setCallback(cVar.f);
            return cVar;
        }

        @Override // android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources, Resources.Theme theme) {
            c cVar = new c(null, null, null);
            Drawable newDrawable = this.f896a.newDrawable(resources, theme);
            cVar.f899b = newDrawable;
            newDrawable.setCallback(cVar.f);
            return cVar;
        }
    }
}
