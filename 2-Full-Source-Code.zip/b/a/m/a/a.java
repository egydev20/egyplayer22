package b.a.m.a;

import android.animation.ObjectAnimator;
import android.animation.TimeInterpolator;
import android.annotation.SuppressLint;
import android.content.res.Resources;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.util.StateSet;
import b.a.m.a.b;
import b.a.m.a.d;
import b.c.k;

@SuppressLint({"RestrictedAPI"})
/* loaded from: classes.dex */
public class a extends b.a.m.a.d implements b.d.f.i.a {
    public c p;
    public g q;
    public int r;
    public int s;
    public boolean t;

    /* loaded from: classes.dex */
    public static class b extends g {

        /* renamed from: a, reason: collision with root package name */
        public final Animatable f264a;

        public b(Animatable animatable) {
            super(null);
            this.f264a = animatable;
        }

        @Override // b.a.m.a.a.g
        public void c() {
            this.f264a.start();
        }

        @Override // b.a.m.a.a.g
        public void d() {
            this.f264a.stop();
        }
    }

    /* loaded from: classes.dex */
    public static class c extends d.a {
        public b.c.g<Long> K;
        public k<Integer> L;

        public c(c cVar, a aVar, Resources resources) {
            super(cVar, aVar, resources);
            k<Integer> kVar;
            if (cVar != null) {
                this.K = cVar.K;
                kVar = cVar.L;
            } else {
                this.K = new b.c.g<>();
                kVar = new k<>(10);
            }
            this.L = kVar;
        }

        public static long a(int i, int i2) {
            return i2 | (i << 32);
        }

        public int a(int i, int i2, Drawable drawable, boolean z) {
            int a2 = super.a(drawable);
            long a3 = a(i, i2);
            long j = z ? 8589934592L : 0L;
            long j2 = a2;
            this.K.a(a3, Long.valueOf(j2 | j));
            if (z) {
                this.K.a(a(i2, i), Long.valueOf(4294967296L | j2 | j));
            }
            return a2;
        }

        public int b(int i) {
            if (i < 0) {
                return 0;
            }
            return this.L.b(i, 0).intValue();
        }

        public int b(int[] iArr) {
            int a2 = super.a(iArr);
            return a2 >= 0 ? a2 : super.a(StateSet.WILD_CARD);
        }

        @Override // b.a.m.a.d.a, b.a.m.a.b.c
        public void d() {
            this.K = this.K.m0clone();
            this.L = this.L.m1clone();
        }

        @Override // b.a.m.a.d.a, android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable() {
            return new a(this, null);
        }

        @Override // b.a.m.a.d.a, android.graphics.drawable.Drawable.ConstantState
        public Drawable newDrawable(Resources resources) {
            return new a(this, resources);
        }
    }

    /* loaded from: classes.dex */
    public static class d extends g {

        /* renamed from: a, reason: collision with root package name */
        public final b.k.a.a.c f265a;

        public d(b.k.a.a.c cVar) {
            super(null);
            this.f265a = cVar;
        }

        @Override // b.a.m.a.a.g
        public void c() {
            this.f265a.start();
        }

        @Override // b.a.m.a.a.g
        public void d() {
            this.f265a.stop();
        }
    }

    /* loaded from: classes.dex */
    public static class e extends g {

        /* renamed from: a, reason: collision with root package name */
        public final ObjectAnimator f266a;

        /* renamed from: b, reason: collision with root package name */
        public final boolean f267b;

        public e(AnimationDrawable animationDrawable, boolean z, boolean z2) {
            super(null);
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            int i = z ? numberOfFrames - 1 : 0;
            int i2 = z ? 0 : numberOfFrames - 1;
            f fVar = new f(animationDrawable, z);
            ObjectAnimator ofInt = ObjectAnimator.ofInt(animationDrawable, "currentIndex", i, i2);
            ofInt.setAutoCancel(true);
            ofInt.setDuration(fVar.f270c);
            ofInt.setInterpolator(fVar);
            this.f267b = z2;
            this.f266a = ofInt;
        }

        @Override // b.a.m.a.a.g
        public boolean a() {
            return this.f267b;
        }

        @Override // b.a.m.a.a.g
        public void b() {
            this.f266a.reverse();
        }

        @Override // b.a.m.a.a.g
        public void c() {
            this.f266a.start();
        }

        @Override // b.a.m.a.a.g
        public void d() {
            this.f266a.cancel();
        }
    }

    /* loaded from: classes.dex */
    public static class f implements TimeInterpolator {

        /* renamed from: a, reason: collision with root package name */
        public int[] f268a;

        /* renamed from: b, reason: collision with root package name */
        public int f269b;

        /* renamed from: c, reason: collision with root package name */
        public int f270c;

        public f(AnimationDrawable animationDrawable, boolean z) {
            int numberOfFrames = animationDrawable.getNumberOfFrames();
            this.f269b = numberOfFrames;
            int[] iArr = this.f268a;
            if (iArr == null || iArr.length < numberOfFrames) {
                this.f268a = new int[numberOfFrames];
            }
            int[] iArr2 = this.f268a;
            int i = 0;
            for (int i2 = 0; i2 < numberOfFrames; i2++) {
                int duration = animationDrawable.getDuration(z ? (numberOfFrames - i2) - 1 : i2);
                iArr2[i2] = duration;
                i += duration;
            }
            this.f270c = i;
        }

        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f) {
            int i = (int) ((f * this.f270c) + 0.5f);
            int i2 = this.f269b;
            int[] iArr = this.f268a;
            int i3 = 0;
            while (i3 < i2 && i >= iArr[i3]) {
                i -= iArr[i3];
                i3++;
            }
            return (i3 / i2) + (i3 < i2 ? i / this.f270c : 0.0f);
        }
    }

    /* loaded from: classes.dex */
    public static abstract class g {
        public /* synthetic */ g(C0006a c0006a) {
        }

        public boolean a() {
            return false;
        }

        public void b() {
        }

        public abstract void c();

        public abstract void d();
    }

    public a() {
        this(null, null);
    }

    public a(c cVar, Resources resources) {
        super(null);
        this.r = -1;
        this.s = -1;
        c cVar2 = new c(cVar, this, resources);
        super.a(cVar2);
        this.p = cVar2;
        onStateChange(getState());
        jumpToCurrentState();
    }

    @Override // b.a.m.a.d, b.a.m.a.b
    public b.c a() {
        return new c(this.p, this, null);
    }

    @Override // b.a.m.a.d, b.a.m.a.b
    public void a(b.c cVar) {
        super.a(cVar);
        if (cVar instanceof c) {
            this.p = (c) cVar;
        }
    }

    @Override // b.a.m.a.d, android.graphics.drawable.Drawable
    public boolean isStateful() {
        return true;
    }

    @Override // b.a.m.a.b, android.graphics.drawable.Drawable
    public void jumpToCurrentState() {
        super.jumpToCurrentState();
        g gVar = this.q;
        if (gVar != null) {
            gVar.d();
            this.q = null;
            a(this.r);
            this.r = -1;
            this.s = -1;
        }
    }

    @Override // b.a.m.a.d, b.a.m.a.b, android.graphics.drawable.Drawable
    public Drawable mutate() {
        if (!this.t) {
            super.mutate();
            if (this == this) {
                this.p.d();
                this.t = true;
            }
        }
        return this;
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x00e2  */
    @Override // b.a.m.a.d, android.graphics.drawable.Drawable
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onStateChange(int[] r19) {
        /*
            Method dump skipped, instructions count: 243
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.m.a.a.onStateChange(int[]):boolean");
    }

    @Override // b.a.m.a.b, android.graphics.drawable.Drawable
    public boolean setVisible(boolean z, boolean z2) {
        boolean visible = super.setVisible(z, z2);
        if (this.q != null && (visible || z2)) {
            if (z) {
                this.q.c();
            } else {
                jumpToCurrentState();
            }
        }
        return visible;
    }

    @Override // b.a.m.a.d, b.a.m.a.b
    public d.a a() {
        return new c(this.p, this, null);
    }

    /* JADX WARN: Code restructure failed: missing block: B:43:0x00ea, code lost:
    
        if (r6 == null) goto L37;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00ec, code lost:
    
        r6 = r19.next();
     */
    /* JADX WARN: Code restructure failed: missing block: B:45:0x00f1, code lost:
    
        if (r6 != 4) goto L105;
     */
    /* JADX WARN: Code restructure failed: missing block: B:48:0x00f5, code lost:
    
        if (r6 != 2) goto L95;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x0101, code lost:
    
        if (r19.getName().equals("vector") == false) goto L45;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x0103, code lost:
    
        r6 = b.k.a.a.g.createFromXmlInner(r18, r19, r20, r21);
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x0108, code lost:
    
        r6 = android.graphics.drawable.Drawable.createFromXmlInner(r18, r19, r20, r21);
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x011b, code lost:
    
        throw new org.xmlpull.v1.XmlPullParserException(c.a.b.a.a.a(r19, new java.lang.StringBuilder(), ": <item> tag requires a 'drawable' attribute or child tag defining a drawable"));
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x011c, code lost:
    
        if (r6 == null) goto L91;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x011e, code lost:
    
        r9 = r5.p;
        r6 = r9.a(r6);
        r9.J[r6] = r8;
        r9.L.c(r6, java.lang.Integer.valueOf(r12));
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x0141, code lost:
    
        throw new org.xmlpull.v1.XmlPullParserException(c.a.b.a.a.a(r19, new java.lang.StringBuilder(), ": <item> tag requires a 'drawable' attribute or child tag defining a drawable"));
     */
    /* JADX WARN: Code restructure failed: missing block: B:87:0x01d3, code lost:
    
        throw new org.xmlpull.v1.XmlPullParserException(c.a.b.a.a.a(r19, new java.lang.StringBuilder(), ": <transition> tag requires 'fromId' & 'toId' attributes"));
     */
    /* JADX WARN: Removed duplicated region for block: B:82:0x01b8  */
    /* JADX WARN: Removed duplicated region for block: B:89:0x01d4 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static b.a.m.a.a a(android.content.Context r17, android.content.res.Resources r18, org.xmlpull.v1.XmlPullParser r19, android.util.AttributeSet r20, android.content.res.Resources.Theme r21) {
        /*
            Method dump skipped, instructions count: 525
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.m.a.a.a(android.content.Context, android.content.res.Resources, org.xmlpull.v1.XmlPullParser, android.util.AttributeSet, android.content.res.Resources$Theme):b.a.m.a.a");
    }
}
