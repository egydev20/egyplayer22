package b.a.p;

import android.R;
import android.view.View;
import android.view.Window;

/* loaded from: classes.dex */
public class k0 implements View.OnClickListener {

    /* renamed from: b, reason: collision with root package name */
    public final b.a.o.d.a f417b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ l0 f418c;

    public k0(l0 l0Var) {
        this.f418c = l0Var;
        this.f417b = new b.a.o.d.a(this.f418c.f421a.getContext(), 0, R.id.home, 0, 0, this.f418c.h);
    }

    @Override // android.view.View.OnClickListener
    public void onClick(View view) {
        l0 l0Var = this.f418c;
        Window.Callback callback = l0Var.k;
        if (callback == null || !l0Var.l) {
            return;
        }
        callback.onMenuItemSelected(0, this.f417b);
    }
}
