package b.a.p;

/* loaded from: classes.dex */
public class c0 {

    /* renamed from: a, reason: collision with root package name */
    public int f368a = 0;

    /* renamed from: b, reason: collision with root package name */
    public int f369b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f370c = Integer.MIN_VALUE;

    /* renamed from: d, reason: collision with root package name */
    public int f371d = Integer.MIN_VALUE;
    public int e = 0;
    public int f = 0;
    public boolean g = false;
    public boolean h = false;

    public void a(int i, int i2) {
        this.f370c = i;
        this.f371d = i2;
        this.h = true;
        if (this.g) {
            if (i2 != Integer.MIN_VALUE) {
                this.f368a = i2;
            }
            if (i != Integer.MIN_VALUE) {
                this.f369b = i;
                return;
            }
            return;
        }
        if (i != Integer.MIN_VALUE) {
            this.f368a = i;
        }
        if (i2 != Integer.MIN_VALUE) {
            this.f369b = i2;
        }
    }
}
