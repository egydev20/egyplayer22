package b.a.p;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.ImageView;

/* loaded from: classes.dex */
public class i {

    /* renamed from: a, reason: collision with root package name */
    public final ImageView f409a;

    /* renamed from: b, reason: collision with root package name */
    public h0 f410b;

    /* renamed from: c, reason: collision with root package name */
    public h0 f411c;

    public i(ImageView imageView) {
        this.f409a = imageView;
    }

    public void a() {
        Drawable drawable = this.f409a.getDrawable();
        if (drawable != null) {
            r.b(drawable);
        }
        if (drawable != null) {
            int i = Build.VERSION.SDK_INT;
            boolean z = true;
            if (i <= 21 && i == 21) {
                if (this.f411c == null) {
                    this.f411c = new h0();
                }
                h0 h0Var = this.f411c;
                h0Var.f405a = null;
                h0Var.f408d = false;
                h0Var.f406b = null;
                h0Var.f407c = false;
                ColorStateList imageTintList = this.f409a.getImageTintList();
                if (imageTintList != null) {
                    h0Var.f408d = true;
                    h0Var.f405a = imageTintList;
                }
                PorterDuff.Mode imageTintMode = this.f409a.getImageTintMode();
                if (imageTintMode != null) {
                    h0Var.f407c = true;
                    h0Var.f406b = imageTintMode;
                }
                if (h0Var.f408d || h0Var.f407c) {
                    f.a(drawable, h0Var, this.f409a.getDrawableState());
                } else {
                    z = false;
                }
                if (z) {
                    return;
                }
            }
            h0 h0Var2 = this.f410b;
            if (h0Var2 != null) {
                f.a(drawable, h0Var2, this.f409a.getDrawableState());
            }
        }
    }

    public void a(int i) {
        if (i != 0) {
            Drawable c2 = b.a.l.a.a.c(this.f409a.getContext(), i);
            if (c2 != null) {
                r.b(c2);
            }
            this.f409a.setImageDrawable(c2);
        } else {
            this.f409a.setImageDrawable(null);
        }
        a();
    }

    public void a(ColorStateList colorStateList) {
        if (this.f410b == null) {
            this.f410b = new h0();
        }
        h0 h0Var = this.f410b;
        h0Var.f405a = colorStateList;
        h0Var.f408d = true;
        a();
    }

    public void a(PorterDuff.Mode mode) {
        if (this.f410b == null) {
            this.f410b = new h0();
        }
        h0 h0Var = this.f410b;
        h0Var.f406b = mode;
        h0Var.f407c = true;
        a();
    }

    public void a(AttributeSet attributeSet, int i) {
        Drawable drawable;
        Drawable drawable2;
        int e;
        j0 a2 = j0.a(this.f409a.getContext(), attributeSet, b.a.j.AppCompatImageView, i, 0);
        try {
            Drawable drawable3 = this.f409a.getDrawable();
            if (drawable3 == null && (e = a2.e(b.a.j.AppCompatImageView_srcCompat, -1)) != -1 && (drawable3 = b.a.l.a.a.c(this.f409a.getContext(), e)) != null) {
                this.f409a.setImageDrawable(drawable3);
            }
            if (drawable3 != null) {
                r.b(drawable3);
            }
            if (a2.e(b.a.j.AppCompatImageView_tint)) {
                ImageView imageView = this.f409a;
                imageView.setImageTintList(a2.a(b.a.j.AppCompatImageView_tint));
                if (Build.VERSION.SDK_INT == 21 && (drawable2 = imageView.getDrawable()) != null && imageView.getImageTintList() != null) {
                    if (drawable2.isStateful()) {
                        drawable2.setState(imageView.getDrawableState());
                    }
                    imageView.setImageDrawable(drawable2);
                }
            }
            if (a2.e(b.a.j.AppCompatImageView_tintMode)) {
                ImageView imageView2 = this.f409a;
                imageView2.setImageTintMode(r.a(a2.c(b.a.j.AppCompatImageView_tintMode, -1), null));
                if (Build.VERSION.SDK_INT == 21 && (drawable = imageView2.getDrawable()) != null && imageView2.getImageTintList() != null) {
                    if (drawable.isStateful()) {
                        drawable.setState(imageView2.getDrawableState());
                    }
                    imageView2.setImageDrawable(drawable);
                }
            }
            a2.f415b.recycle();
        } catch (Throwable th) {
            a2.f415b.recycle();
            throw th;
        }
    }
}
