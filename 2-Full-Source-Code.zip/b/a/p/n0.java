package b.a.p;

import android.content.Context;
import android.graphics.Rect;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

/* loaded from: classes.dex */
public class n0 {

    /* renamed from: a, reason: collision with root package name */
    public final Context f442a;

    /* renamed from: b, reason: collision with root package name */
    public final View f443b;

    /* renamed from: c, reason: collision with root package name */
    public final TextView f444c;

    /* renamed from: d, reason: collision with root package name */
    public final WindowManager.LayoutParams f445d = new WindowManager.LayoutParams();
    public final Rect e = new Rect();
    public final int[] f = new int[2];
    public final int[] g = new int[2];

    public n0(Context context) {
        this.f442a = context;
        View inflate = LayoutInflater.from(context).inflate(b.a.g.abc_tooltip, (ViewGroup) null);
        this.f443b = inflate;
        this.f444c = (TextView) inflate.findViewById(b.a.f.message);
        this.f445d.setTitle(n0.class.getSimpleName());
        this.f445d.packageName = this.f442a.getPackageName();
        WindowManager.LayoutParams layoutParams = this.f445d;
        layoutParams.type = 1002;
        layoutParams.width = -2;
        layoutParams.height = -2;
        layoutParams.format = -3;
        layoutParams.windowAnimations = b.a.i.Animation_AppCompat_Tooltip;
        layoutParams.flags = 24;
    }

    public void a() {
        if (this.f443b.getParent() != null) {
            ((WindowManager) this.f442a.getSystemService("window")).removeView(this.f443b);
        }
    }
}
