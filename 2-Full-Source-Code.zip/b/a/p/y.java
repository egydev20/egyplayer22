package b.a.p;

import android.view.MenuItem;

/* loaded from: classes.dex */
public interface y {
    void a(b.a.o.d.f fVar, MenuItem menuItem);

    void b(b.a.o.d.f fVar, MenuItem menuItem);
}
