package b.a.p;

import android.view.textclassifier.TextClassificationManager;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;

/* loaded from: classes.dex */
public final class l {

    /* renamed from: a, reason: collision with root package name */
    public TextView f419a;

    /* renamed from: b, reason: collision with root package name */
    public TextClassifier f420b;

    public l(TextView textView) {
        if (textView == null) {
            throw null;
        }
        this.f419a = textView;
    }

    public TextClassifier a() {
        TextClassifier textClassifier = this.f420b;
        if (textClassifier != null) {
            return textClassifier;
        }
        TextClassificationManager textClassificationManager = (TextClassificationManager) this.f419a.getContext().getSystemService(TextClassificationManager.class);
        return textClassificationManager != null ? textClassificationManager.getTextClassifier() : TextClassifier.NO_OP;
    }
}
