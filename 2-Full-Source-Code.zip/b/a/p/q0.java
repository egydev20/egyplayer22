package b.a.p;

/* loaded from: classes.dex */
public interface q0 {
    CharSequence a();
}
