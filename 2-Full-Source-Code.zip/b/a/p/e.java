package b.a.p;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

/* loaded from: classes.dex */
public class e {

    /* renamed from: a, reason: collision with root package name */
    public final View f380a;

    /* renamed from: d, reason: collision with root package name */
    public h0 f383d;
    public h0 e;
    public h0 f;

    /* renamed from: c, reason: collision with root package name */
    public int f382c = -1;

    /* renamed from: b, reason: collision with root package name */
    public final f f381b = f.a();

    public e(View view) {
        this.f380a = view;
    }

    public void a() {
        Drawable background = this.f380a.getBackground();
        if (background != null) {
            int i = Build.VERSION.SDK_INT;
            boolean z = true;
            if (i <= 21 ? i == 21 : this.f383d != null) {
                if (this.f == null) {
                    this.f = new h0();
                }
                h0 h0Var = this.f;
                h0Var.f405a = null;
                h0Var.f408d = false;
                h0Var.f406b = null;
                h0Var.f407c = false;
                ColorStateList c2 = b.d.k.l.c(this.f380a);
                if (c2 != null) {
                    h0Var.f408d = true;
                    h0Var.f405a = c2;
                }
                PorterDuff.Mode backgroundTintMode = this.f380a.getBackgroundTintMode();
                if (backgroundTintMode != null) {
                    h0Var.f407c = true;
                    h0Var.f406b = backgroundTintMode;
                }
                if (h0Var.f408d || h0Var.f407c) {
                    f.a(background, h0Var, this.f380a.getDrawableState());
                } else {
                    z = false;
                }
                if (z) {
                    return;
                }
            }
            h0 h0Var2 = this.e;
            if (h0Var2 != null) {
                f.a(background, h0Var2, this.f380a.getDrawableState());
                return;
            }
            h0 h0Var3 = this.f383d;
            if (h0Var3 != null) {
                f.a(background, h0Var3, this.f380a.getDrawableState());
            }
        }
    }

    public void a(int i) {
        this.f382c = i;
        f fVar = this.f381b;
        a(fVar != null ? fVar.b(this.f380a.getContext(), i) : null);
        a();
    }

    public void a(ColorStateList colorStateList) {
        if (colorStateList != null) {
            if (this.f383d == null) {
                this.f383d = new h0();
            }
            h0 h0Var = this.f383d;
            h0Var.f405a = colorStateList;
            h0Var.f408d = true;
        } else {
            this.f383d = null;
        }
        a();
    }

    public void a(PorterDuff.Mode mode) {
        if (this.e == null) {
            this.e = new h0();
        }
        h0 h0Var = this.e;
        h0Var.f406b = mode;
        h0Var.f407c = true;
        a();
    }

    public ColorStateList b() {
        h0 h0Var = this.e;
        if (h0Var != null) {
            return h0Var.f405a;
        }
        return null;
    }

    public void b(ColorStateList colorStateList) {
        if (this.e == null) {
            this.e = new h0();
        }
        h0 h0Var = this.e;
        h0Var.f405a = colorStateList;
        h0Var.f408d = true;
        a();
    }

    public PorterDuff.Mode c() {
        h0 h0Var = this.e;
        if (h0Var != null) {
            return h0Var.f406b;
        }
        return null;
    }

    public void d() {
        this.f382c = -1;
        a((ColorStateList) null);
        a();
    }

    public void a(AttributeSet attributeSet, int i) {
        j0 a2 = j0.a(this.f380a.getContext(), attributeSet, b.a.j.ViewBackgroundHelper, i, 0);
        try {
            if (a2.e(b.a.j.ViewBackgroundHelper_android_background)) {
                this.f382c = a2.e(b.a.j.ViewBackgroundHelper_android_background, -1);
                ColorStateList b2 = this.f381b.b(this.f380a.getContext(), this.f382c);
                if (b2 != null) {
                    a(b2);
                }
            }
            if (a2.e(b.a.j.ViewBackgroundHelper_backgroundTint)) {
                b.d.k.l.a(this.f380a, a2.a(b.a.j.ViewBackgroundHelper_backgroundTint));
            }
            if (a2.e(b.a.j.ViewBackgroundHelper_backgroundTintMode)) {
                b.d.k.l.a(this.f380a, r.a(a2.c(b.a.j.ViewBackgroundHelper_backgroundTintMode, -1), null));
            }
        } finally {
            a2.f415b.recycle();
        }
    }
}
