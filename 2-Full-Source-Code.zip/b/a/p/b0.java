package b.a.p;

import android.content.res.Resources;

/* loaded from: classes.dex */
public class b0 extends Resources {
}
