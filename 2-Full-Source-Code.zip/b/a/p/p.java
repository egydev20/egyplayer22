package b.a.p;

/* loaded from: classes.dex */
public interface p {
    void a();
}
