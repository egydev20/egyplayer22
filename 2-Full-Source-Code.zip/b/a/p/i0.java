package b.a.p;

/* loaded from: classes.dex */
public class i0 extends b0 {
}
