package b.a.p;

import android.graphics.drawable.Drawable;
import android.view.Window;

/* loaded from: classes.dex */
public interface q {
    void a();

    void a(int i);

    void a(Window.Callback callback);

    void a(CharSequence charSequence);

    CharSequence getTitle();

    void setIcon(int i);

    void setIcon(Drawable drawable);
}
