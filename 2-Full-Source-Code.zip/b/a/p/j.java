package b.a.p;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.util.AttributeSet;
import android.widget.ImageView;

/* loaded from: classes.dex */
public class j extends ImageView {

    /* renamed from: b, reason: collision with root package name */
    public final e f412b;

    /* renamed from: c, reason: collision with root package name */
    public final i f413c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public j(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        g0.a(context);
        e eVar = new e(this);
        this.f412b = eVar;
        eVar.a(attributeSet, i);
        i iVar = new i(this);
        this.f413c = iVar;
        iVar.a(attributeSet, i);
    }

    @Override // android.widget.ImageView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        e eVar = this.f412b;
        if (eVar != null) {
            eVar.a();
        }
        i iVar = this.f413c;
        if (iVar != null) {
            iVar.a();
        }
    }

    public ColorStateList getSupportBackgroundTintList() {
        e eVar = this.f412b;
        if (eVar != null) {
            return eVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        e eVar = this.f412b;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public ColorStateList getSupportImageTintList() {
        h0 h0Var;
        i iVar = this.f413c;
        if (iVar == null || (h0Var = iVar.f410b) == null) {
            return null;
        }
        return h0Var.f405a;
    }

    public PorterDuff.Mode getSupportImageTintMode() {
        h0 h0Var;
        i iVar = this.f413c;
        if (iVar == null || (h0Var = iVar.f410b) == null) {
            return null;
        }
        return h0Var.f406b;
    }

    @Override // android.widget.ImageView, android.view.View
    public boolean hasOverlappingRendering() {
        return ((this.f413c.f409a.getBackground() instanceof RippleDrawable) ^ true) && super.hasOverlappingRendering();
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        e eVar = this.f412b;
        if (eVar != null) {
            eVar.d();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        e eVar = this.f412b;
        if (eVar != null) {
            eVar.a(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageBitmap(Bitmap bitmap) {
        super.setImageBitmap(bitmap);
        i iVar = this.f413c;
        if (iVar != null) {
            iVar.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageDrawable(Drawable drawable) {
        super.setImageDrawable(drawable);
        i iVar = this.f413c;
        if (iVar != null) {
            iVar.a();
        }
    }

    @Override // android.widget.ImageView
    public void setImageResource(int i) {
        i iVar = this.f413c;
        if (iVar != null) {
            iVar.a(i);
        }
    }

    @Override // android.widget.ImageView
    public void setImageURI(Uri uri) {
        super.setImageURI(uri);
        i iVar = this.f413c;
        if (iVar != null) {
            iVar.a();
        }
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        e eVar = this.f412b;
        if (eVar != null) {
            eVar.b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        e eVar = this.f412b;
        if (eVar != null) {
            eVar.a(mode);
        }
    }

    public void setSupportImageTintList(ColorStateList colorStateList) {
        i iVar = this.f413c;
        if (iVar != null) {
            iVar.a(colorStateList);
        }
    }

    public void setSupportImageTintMode(PorterDuff.Mode mode) {
        i iVar = this.f413c;
        if (iVar != null) {
            iVar.a(mode);
        }
    }
}
