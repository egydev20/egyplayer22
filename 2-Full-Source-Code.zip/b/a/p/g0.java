package b.a.p;

import android.content.Context;
import android.content.ContextWrapper;

/* loaded from: classes.dex */
public class g0 extends ContextWrapper {

    /* renamed from: a, reason: collision with root package name */
    public static final Object f402a = new Object();

    public static Context a(Context context) {
        if (!(context instanceof g0) && !(context.getResources() instanceof i0) && !(context.getResources() instanceof o0)) {
            o0.a();
        }
        return context;
    }
}
