package b.a.p;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.Resources;
import android.graphics.Rect;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityManager;

/* loaded from: classes.dex */
public class m0 implements View.OnLongClickListener, View.OnHoverListener, View.OnAttachStateChangeListener {
    public static m0 k;
    public static m0 l;

    /* renamed from: b, reason: collision with root package name */
    public final View f434b;

    /* renamed from: c, reason: collision with root package name */
    public final CharSequence f435c;

    /* renamed from: d, reason: collision with root package name */
    public final int f436d;
    public final Runnable e = new a();
    public final Runnable f = new b();
    public int g;
    public int h;
    public n0 i;
    public boolean j;

    /* loaded from: classes.dex */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            m0.this.a(false);
        }
    }

    /* loaded from: classes.dex */
    public class b implements Runnable {
        public b() {
        }

        @Override // java.lang.Runnable
        public void run() {
            m0.this.b();
        }
    }

    public m0(View view, CharSequence charSequence) {
        this.f434b = view;
        this.f435c = charSequence;
        this.f436d = b.d.k.m.a(ViewConfiguration.get(view.getContext()));
        a();
        this.f434b.setOnLongClickListener(this);
        this.f434b.setOnHoverListener(this);
    }

    public static void a(m0 m0Var) {
        m0 m0Var2 = k;
        if (m0Var2 != null) {
            m0Var2.f434b.removeCallbacks(m0Var2.e);
        }
        k = m0Var;
        if (m0Var != null) {
            m0Var.f434b.postDelayed(m0Var.e, ViewConfiguration.getLongPressTimeout());
        }
    }

    public final void a() {
        this.g = Integer.MAX_VALUE;
        this.h = Integer.MAX_VALUE;
    }

    public void b() {
        if (l == this) {
            l = null;
            n0 n0Var = this.i;
            if (n0Var != null) {
                n0Var.a();
                this.i = null;
                a();
                this.f434b.removeOnAttachStateChangeListener(this);
            } else {
                Log.e("TooltipCompatHandler", "sActiveHandler.mPopup == null");
            }
        }
        if (k == this) {
            a((m0) null);
        }
        this.f434b.removeCallbacks(this.f);
    }

    @Override // android.view.View.OnHoverListener
    public boolean onHover(View view, MotionEvent motionEvent) {
        boolean z;
        if (this.i != null && this.j) {
            return false;
        }
        AccessibilityManager accessibilityManager = (AccessibilityManager) this.f434b.getContext().getSystemService("accessibility");
        if (accessibilityManager.isEnabled() && accessibilityManager.isTouchExplorationEnabled()) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action != 7) {
            if (action == 10) {
                a();
                b();
            }
        } else if (this.f434b.isEnabled() && this.i == null) {
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (Math.abs(x - this.g) > this.f436d || Math.abs(y - this.h) > this.f436d) {
                this.g = x;
                this.h = y;
                z = true;
            } else {
                z = false;
            }
            if (z) {
                a(this);
            }
        }
        return false;
    }

    @Override // android.view.View.OnLongClickListener
    public boolean onLongClick(View view) {
        this.g = view.getWidth() / 2;
        this.h = view.getHeight() / 2;
        a(true);
        return true;
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewAttachedToWindow(View view) {
    }

    @Override // android.view.View.OnAttachStateChangeListener
    public void onViewDetachedFromWindow(View view) {
        b();
    }

    public void a(boolean z) {
        int height;
        int i;
        long longPressTimeout;
        if (b.d.k.l.l(this.f434b)) {
            a((m0) null);
            m0 m0Var = l;
            if (m0Var != null) {
                m0Var.b();
            }
            l = this;
            this.j = z;
            n0 n0Var = new n0(this.f434b.getContext());
            this.i = n0Var;
            View view = this.f434b;
            int i2 = this.g;
            int i3 = this.h;
            boolean z2 = this.j;
            CharSequence charSequence = this.f435c;
            if (n0Var.f443b.getParent() != null) {
                n0Var.a();
            }
            n0Var.f444c.setText(charSequence);
            WindowManager.LayoutParams layoutParams = n0Var.f445d;
            layoutParams.token = view.getApplicationWindowToken();
            int dimensionPixelOffset = n0Var.f442a.getResources().getDimensionPixelOffset(b.a.d.tooltip_precise_anchor_threshold);
            if (view.getWidth() < dimensionPixelOffset) {
                i2 = view.getWidth() / 2;
            }
            if (view.getHeight() >= dimensionPixelOffset) {
                int dimensionPixelOffset2 = n0Var.f442a.getResources().getDimensionPixelOffset(b.a.d.tooltip_precise_anchor_extra_offset);
                height = i3 + dimensionPixelOffset2;
                i = i3 - dimensionPixelOffset2;
            } else {
                height = view.getHeight();
                i = 0;
            }
            layoutParams.gravity = 49;
            int dimensionPixelOffset3 = n0Var.f442a.getResources().getDimensionPixelOffset(z2 ? b.a.d.tooltip_y_offset_touch : b.a.d.tooltip_y_offset_non_touch);
            View rootView = view.getRootView();
            ViewGroup.LayoutParams layoutParams2 = rootView.getLayoutParams();
            if (!(layoutParams2 instanceof WindowManager.LayoutParams) || ((WindowManager.LayoutParams) layoutParams2).type != 2) {
                Context context = view.getContext();
                while (true) {
                    if (!(context instanceof ContextWrapper)) {
                        break;
                    }
                    if (context instanceof Activity) {
                        rootView = ((Activity) context).getWindow().getDecorView();
                        break;
                    }
                    context = ((ContextWrapper) context).getBaseContext();
                }
            }
            if (rootView == null) {
                Log.e("TooltipPopup", "Cannot find app view");
            } else {
                rootView.getWindowVisibleDisplayFrame(n0Var.e);
                Rect rect = n0Var.e;
                if (rect.left < 0 && rect.top < 0) {
                    Resources resources = n0Var.f442a.getResources();
                    int identifier = resources.getIdentifier("status_bar_height", "dimen", "android");
                    int dimensionPixelSize = identifier != 0 ? resources.getDimensionPixelSize(identifier) : 0;
                    DisplayMetrics displayMetrics = resources.getDisplayMetrics();
                    n0Var.e.set(0, dimensionPixelSize, displayMetrics.widthPixels, displayMetrics.heightPixels);
                }
                rootView.getLocationOnScreen(n0Var.g);
                view.getLocationOnScreen(n0Var.f);
                int[] iArr = n0Var.f;
                int i4 = iArr[0];
                int[] iArr2 = n0Var.g;
                iArr[0] = i4 - iArr2[0];
                iArr[1] = iArr[1] - iArr2[1];
                layoutParams.x = (iArr[0] + i2) - (rootView.getWidth() / 2);
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                n0Var.f443b.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredHeight = n0Var.f443b.getMeasuredHeight();
                int[] iArr3 = n0Var.f;
                int i5 = ((iArr3[1] + i) - dimensionPixelOffset3) - measuredHeight;
                int i6 = iArr3[1] + height + dimensionPixelOffset3;
                if (!z2 ? measuredHeight + i6 <= n0Var.e.height() : i5 < 0) {
                    layoutParams.y = i5;
                } else {
                    layoutParams.y = i6;
                }
            }
            ((WindowManager) n0Var.f442a.getSystemService("window")).addView(n0Var.f443b, n0Var.f445d);
            this.f434b.addOnAttachStateChangeListener(this);
            if (this.j) {
                longPressTimeout = 2500;
            } else {
                longPressTimeout = ((this.f434b.getWindowSystemUiVisibility() & 1) == 1 ? 3000L : 15000L) - ViewConfiguration.getLongPressTimeout();
            }
            this.f434b.removeCallbacks(this.f);
            this.f434b.postDelayed(this.f, longPressTimeout);
        }
    }
}
