package b.a.p;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import b.a.p.f;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public final class a0 {
    public static a0 i;

    /* renamed from: a, reason: collision with root package name */
    public WeakHashMap<Context, b.c.k<ColorStateList>> f358a;

    /* renamed from: b, reason: collision with root package name */
    public b.c.a<String, d> f359b;

    /* renamed from: c, reason: collision with root package name */
    public b.c.k<String> f360c;

    /* renamed from: d, reason: collision with root package name */
    public final WeakHashMap<Context, b.c.g<WeakReference<Drawable.ConstantState>>> f361d = new WeakHashMap<>(0);
    public TypedValue e;
    public boolean f;
    public e g;
    public static final PorterDuff.Mode h = PorterDuff.Mode.SRC_IN;
    public static final c j = new c(6);

    /* loaded from: classes.dex */
    public static class a implements d {
        @Override // b.a.p.a0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return b.a.m.a.a.a(context, context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("AsldcInflateDelegate", "Exception while inflating <animated-selector>", e);
                return null;
            }
        }
    }

    /* loaded from: classes.dex */
    public static class b implements d {
        @Override // b.a.p.a0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                Resources resources = context.getResources();
                b.k.a.a.c cVar = new b.k.a.a.c(context, null, null);
                cVar.inflate(resources, xmlPullParser, attributeSet, theme);
                return cVar;
            } catch (Exception e) {
                Log.e("AvdcInflateDelegate", "Exception while inflating <animated-vector>", e);
                return null;
            }
        }
    }

    /* loaded from: classes.dex */
    public static class c extends b.c.h<Integer, PorterDuffColorFilter> {
        public c(int i) {
            super(i);
        }
    }

    /* loaded from: classes.dex */
    public interface d {
        Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme);
    }

    /* loaded from: classes.dex */
    public interface e {
    }

    /* loaded from: classes.dex */
    public static class f implements d {
        @Override // b.a.p.a0.d
        public Drawable a(Context context, XmlPullParser xmlPullParser, AttributeSet attributeSet, Resources.Theme theme) {
            try {
                return b.k.a.a.g.createFromXmlInner(context.getResources(), xmlPullParser, attributeSet, theme);
            } catch (Exception e) {
                Log.e("VdcInflateDelegate", "Exception while inflating <vector>", e);
                return null;
            }
        }
    }

    public final Drawable a(Context context, int i2) {
        if (this.e == null) {
            this.e = new TypedValue();
        }
        TypedValue typedValue = this.e;
        context.getResources().getValue(i2, typedValue, true);
        long j2 = (typedValue.assetCookie << 32) | typedValue.data;
        Drawable a2 = a(context, j2);
        if (a2 != null) {
            return a2;
        }
        e eVar = this.g;
        LayerDrawable layerDrawable = null;
        if (eVar != null) {
            if (i2 == b.a.e.abc_cab_background_top_material) {
                layerDrawable = new LayerDrawable(new Drawable[]{b(context, b.a.e.abc_cab_background_internal_bg), b(context, b.a.e.abc_cab_background_top_mtrl_alpha)});
            }
        }
        if (layerDrawable != null) {
            layerDrawable.setChangingConfigurations(typedValue.changingConfigurations);
            a(context, j2, layerDrawable);
        }
        return layerDrawable;
    }

    public synchronized void a(e eVar) {
        this.g = eVar;
    }

    public final void a(String str, d dVar) {
        if (this.f359b == null) {
            this.f359b = new b.c.a<>();
        }
        this.f359b.put(str, dVar);
    }

    public final synchronized boolean a(Context context, long j2, Drawable drawable) {
        boolean z;
        Drawable.ConstantState constantState = drawable.getConstantState();
        if (constantState != null) {
            b.c.g<WeakReference<Drawable.ConstantState>> gVar = this.f361d.get(context);
            if (gVar == null) {
                gVar = new b.c.g<>();
                this.f361d.put(context, gVar);
            }
            gVar.c(j2, new WeakReference<>(constantState));
            z = true;
        } else {
            z = false;
        }
        return z;
    }

    public synchronized Drawable b(Context context, int i2) {
        return a(context, i2, false);
    }

    public synchronized ColorStateList c(Context context, int i2) {
        ColorStateList b2;
        b.c.k<ColorStateList> kVar;
        WeakHashMap<Context, b.c.k<ColorStateList>> weakHashMap = this.f358a;
        ColorStateList colorStateList = null;
        b2 = (weakHashMap == null || (kVar = weakHashMap.get(context)) == null) ? null : kVar.b(i2, null);
        if (b2 == null) {
            if (this.g != null) {
                colorStateList = ((f.a) this.g).b(context, i2);
            }
            if (colorStateList != null) {
                if (this.f358a == null) {
                    this.f358a = new WeakHashMap<>();
                }
                b.c.k<ColorStateList> kVar2 = this.f358a.get(context);
                if (kVar2 == null) {
                    kVar2 = new b.c.k<>(10);
                    this.f358a.put(context, kVar2);
                }
                kVar2.a(i2, colorStateList);
            }
            b2 = colorStateList;
        }
        return b2;
    }

    public final Drawable d(Context context, int i2) {
        int next;
        b.c.a<String, d> aVar = this.f359b;
        if (aVar == null || aVar.isEmpty()) {
            return null;
        }
        b.c.k<String> kVar = this.f360c;
        if (kVar != null) {
            String b2 = kVar.b(i2, null);
            if ("appcompat_skip_skip".equals(b2) || (b2 != null && this.f359b.getOrDefault(b2, null) == null)) {
                return null;
            }
        } else {
            this.f360c = new b.c.k<>(10);
        }
        if (this.e == null) {
            this.e = new TypedValue();
        }
        TypedValue typedValue = this.e;
        Resources resources = context.getResources();
        resources.getValue(i2, typedValue, true);
        long j2 = (typedValue.assetCookie << 32) | typedValue.data;
        Drawable a2 = a(context, j2);
        if (a2 != null) {
            return a2;
        }
        CharSequence charSequence = typedValue.string;
        if (charSequence != null && charSequence.toString().endsWith(".xml")) {
            try {
                XmlResourceParser xml = resources.getXml(i2);
                AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
                do {
                    next = xml.next();
                    if (next == 2) {
                        break;
                    }
                } while (next != 1);
                if (next != 2) {
                    throw new XmlPullParserException("No start tag found");
                }
                String name = xml.getName();
                this.f360c.a(i2, name);
                d dVar = this.f359b.get(name);
                if (dVar != null) {
                    a2 = dVar.a(context, xml, asAttributeSet, context.getTheme());
                }
                if (a2 != null) {
                    a2.setChangingConfigurations(typedValue.changingConfigurations);
                    a(context, j2, a2);
                }
            } catch (Exception e2) {
                Log.e("ResourceManagerInternal", "Exception while inflating drawable", e2);
            }
        }
        if (a2 == null) {
            this.f360c.a(i2, "appcompat_skip_skip");
        }
        return a2;
    }

    public static synchronized a0 a() {
        a0 a0Var;
        synchronized (a0.class) {
            if (i == null) {
                a0 a0Var2 = new a0();
                i = a0Var2;
                if (Build.VERSION.SDK_INT < 24) {
                    a0Var2.a("vector", new f());
                    a0Var2.a("animated-vector", new b());
                    a0Var2.a("animated-selector", new a());
                }
            }
            a0Var = i;
        }
        return a0Var;
    }

    public final synchronized Drawable a(Context context, long j2) {
        b.c.g<WeakReference<Drawable.ConstantState>> gVar = this.f361d.get(context);
        if (gVar == null) {
            return null;
        }
        WeakReference<Drawable.ConstantState> b2 = gVar.b(j2, null);
        if (b2 != null) {
            Drawable.ConstantState constantState = b2.get();
            if (constantState != null) {
                return constantState.newDrawable(context.getResources());
            }
            gVar.a(j2);
        }
        return null;
    }

    public synchronized Drawable a(Context context, int i2, boolean z) {
        Drawable d2;
        if (!this.f) {
            boolean z2 = true;
            this.f = true;
            Drawable b2 = b(context, b.a.n.a.abc_vector_test);
            if (b2 != null) {
                if (!(b2 instanceof b.k.a.a.g) && !"android.graphics.drawable.VectorDrawable".equals(b2.getClass().getName())) {
                    z2 = false;
                }
            }
            this.f = false;
            throw new IllegalStateException("This app has been built with an incorrect configuration. Please configure your build for VectorDrawableCompat.");
        }
        d2 = d(context, i2);
        if (d2 == null) {
            d2 = a(context, i2);
        }
        if (d2 == null) {
            d2 = b.d.e.a.b(context, i2);
        }
        if (d2 != null) {
            d2 = a(context, i2, z, d2);
        }
        if (d2 != null) {
            r.b(d2);
        }
        return d2;
    }

    public static synchronized PorterDuffColorFilter a(int i2, PorterDuff.Mode mode) {
        PorterDuffColorFilter a2;
        synchronized (a0.class) {
            c cVar = j;
            if (cVar != null) {
                int i3 = (i2 + 31) * 31;
                a2 = cVar.a((c) Integer.valueOf(mode.hashCode() + i3));
                if (a2 == null) {
                    a2 = new PorterDuffColorFilter(i2, mode);
                    c cVar2 = j;
                    if (cVar2 == null) {
                        throw null;
                    }
                    cVar2.a(Integer.valueOf(mode.hashCode() + i3), a2);
                }
            } else {
                throw null;
            }
        }
        return a2;
    }

    /* JADX WARN: Removed duplicated region for block: B:25:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.graphics.drawable.Drawable a(android.content.Context r10, int r11, boolean r12, android.graphics.drawable.Drawable r13) {
        /*
            r9 = this;
            android.content.res.ColorStateList r0 = r9.c(r10, r11)
            r1 = 0
            if (r0 == 0) goto L2c
            boolean r10 = b.a.p.r.a(r13)
            if (r10 == 0) goto L11
            android.graphics.drawable.Drawable r13 = r13.mutate()
        L11:
            android.graphics.drawable.Drawable r13 = a.a.a.a.a.b(r13)
            r13.setTintList(r0)
            b.a.p.a0$e r10 = r9.g
            if (r10 != 0) goto L1d
            goto L25
        L1d:
            b.a.p.f$a r10 = (b.a.p.f.a) r10
            int r10 = b.a.e.abc_switch_thumb_material
            if (r11 != r10) goto L25
            android.graphics.PorterDuff$Mode r1 = android.graphics.PorterDuff.Mode.MULTIPLY
        L25:
            if (r1 == 0) goto La7
            r13.setTintMode(r1)
            goto La7
        L2c:
            b.a.p.a0$e r0 = r9.g
            if (r0 == 0) goto L9e
            b.a.p.f$a r0 = (b.a.p.f.a) r0
            if (r0 == 0) goto L9d
            int r2 = b.a.e.abc_seekbar_track_material
            r3 = 1
            r4 = 16908301(0x102000d, float:2.3877265E-38)
            r5 = 16908303(0x102000f, float:2.387727E-38)
            r6 = 16908288(0x1020000, float:2.387723E-38)
            if (r11 != r2) goto L72
            r2 = r13
            android.graphics.drawable.LayerDrawable r2 = (android.graphics.drawable.LayerDrawable) r2
            android.graphics.drawable.Drawable r6 = r2.findDrawableByLayerId(r6)
            int r7 = b.a.a.colorControlNormal
            int r7 = b.a.p.f0.b(r10, r7)
            android.graphics.PorterDuff$Mode r8 = b.a.p.f.f388b
            r0.a(r6, r7, r8)
            android.graphics.drawable.Drawable r5 = r2.findDrawableByLayerId(r5)
            int r6 = b.a.a.colorControlNormal
        L59:
            int r6 = b.a.p.f0.b(r10, r6)
            android.graphics.PorterDuff$Mode r7 = b.a.p.f.f388b
            r0.a(r5, r6, r7)
            android.graphics.drawable.Drawable r2 = r2.findDrawableByLayerId(r4)
            int r4 = b.a.a.colorControlActivated
            int r4 = b.a.p.f0.b(r10, r4)
            android.graphics.PorterDuff$Mode r5 = b.a.p.f.f388b
            r0.a(r2, r4, r5)
            goto L9a
        L72:
            int r2 = b.a.e.abc_ratingbar_material
            if (r11 == r2) goto L81
            int r2 = b.a.e.abc_ratingbar_indicator_material
            if (r11 == r2) goto L81
            int r2 = b.a.e.abc_ratingbar_small_material
            if (r11 != r2) goto L7f
            goto L81
        L7f:
            r3 = 0
            goto L9a
        L81:
            r2 = r13
            android.graphics.drawable.LayerDrawable r2 = (android.graphics.drawable.LayerDrawable) r2
            android.graphics.drawable.Drawable r6 = r2.findDrawableByLayerId(r6)
            int r7 = b.a.a.colorControlNormal
            int r7 = b.a.p.f0.a(r10, r7)
            android.graphics.PorterDuff$Mode r8 = b.a.p.f.f388b
            r0.a(r6, r7, r8)
            android.graphics.drawable.Drawable r5 = r2.findDrawableByLayerId(r5)
            int r6 = b.a.a.colorControlActivated
            goto L59
        L9a:
            if (r3 == 0) goto L9e
            goto La7
        L9d:
            throw r1
        L9e:
            boolean r10 = r9.a(r10, r11, r13)
            if (r10 != 0) goto La7
            if (r12 == 0) goto La7
            r13 = r1
        La7:
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.p.a0.a(android.content.Context, int, boolean, android.graphics.drawable.Drawable):android.graphics.drawable.Drawable");
    }

    public static void a(Drawable drawable, h0 h0Var, int[] iArr) {
        if (r.a(drawable) && drawable.mutate() != drawable) {
            Log.d("ResourceManagerInternal", "Mutated drawable is not the same instance as the input.");
            return;
        }
        if (h0Var.f408d || h0Var.f407c) {
            PorterDuffColorFilter porterDuffColorFilter = null;
            ColorStateList colorStateList = h0Var.f408d ? h0Var.f405a : null;
            PorterDuff.Mode mode = h0Var.f407c ? h0Var.f406b : h;
            if (colorStateList != null && mode != null) {
                porterDuffColorFilter = a(colorStateList.getColorForState(iArr, 0), mode);
            }
            drawable.setColorFilter(porterDuffColorFilter);
        } else {
            drawable.clearColorFilter();
        }
        if (Build.VERSION.SDK_INT <= 23) {
            drawable.invalidateSelf();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x004d  */
    /* JADX WARN: Removed duplicated region for block: B:19:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:21:0x0069  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean a(android.content.Context r8, int r9, android.graphics.drawable.Drawable r10) {
        /*
            r7 = this;
            b.a.p.a0$e r0 = r7.g
            r1 = 1
            r2 = 0
            if (r0 == 0) goto L6f
            b.a.p.f$a r0 = (b.a.p.f.a) r0
            if (r0 == 0) goto L6d
            android.graphics.PorterDuff$Mode r3 = b.a.p.f.f388b
            int[] r4 = r0.f391a
            boolean r4 = r0.a(r4, r9)
            r5 = 16842801(0x1010031, float:2.3693695E-38)
            r6 = -1
            if (r4 == 0) goto L1b
            int r5 = b.a.a.colorControlNormal
            goto L44
        L1b:
            int[] r4 = r0.f393c
            boolean r4 = r0.a(r4, r9)
            if (r4 == 0) goto L26
            int r5 = b.a.a.colorControlActivated
            goto L44
        L26:
            int[] r4 = r0.f394d
            boolean r0 = r0.a(r4, r9)
            if (r0 == 0) goto L31
            android.graphics.PorterDuff$Mode r3 = android.graphics.PorterDuff.Mode.MULTIPLY
            goto L44
        L31:
            int r0 = b.a.e.abc_list_divider_mtrl_alpha
            if (r9 != r0) goto L40
            r9 = 16842800(0x1010030, float:2.3693693E-38)
            r0 = 1109603123(0x42233333, float:40.8)
            int r0 = java.lang.Math.round(r0)
            goto L46
        L40:
            int r0 = b.a.e.abc_dialog_material_background
            if (r9 != r0) goto L48
        L44:
            r9 = r5
            r0 = -1
        L46:
            r4 = 1
            goto L4b
        L48:
            r9 = 0
            r0 = -1
            r4 = 0
        L4b:
            if (r4 == 0) goto L69
            boolean r4 = b.a.p.r.a(r10)
            if (r4 == 0) goto L57
            android.graphics.drawable.Drawable r10 = r10.mutate()
        L57:
            int r8 = b.a.p.f0.b(r8, r9)
            android.graphics.PorterDuffColorFilter r8 = b.a.p.f.a(r8, r3)
            r10.setColorFilter(r8)
            if (r0 == r6) goto L67
            r10.setAlpha(r0)
        L67:
            r8 = 1
            goto L6a
        L69:
            r8 = 0
        L6a:
            if (r8 == 0) goto L6f
            goto L70
        L6d:
            r8 = 0
            throw r8
        L6f:
            r1 = 0
        L70:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.p.a0.a(android.content.Context, int, android.graphics.drawable.Drawable):boolean");
    }
}
