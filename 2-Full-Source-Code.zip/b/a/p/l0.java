package b.a.p;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.TextView;
import androidx.appcompat.widget.ActionMenuView;
import androidx.appcompat.widget.Toolbar;

/* loaded from: classes.dex */
public class l0 implements q {

    /* renamed from: a, reason: collision with root package name */
    public Toolbar f421a;

    /* renamed from: b, reason: collision with root package name */
    public int f422b;

    /* renamed from: c, reason: collision with root package name */
    public View f423c;

    /* renamed from: d, reason: collision with root package name */
    public Drawable f424d;
    public Drawable e;
    public Drawable f;
    public boolean g;
    public CharSequence h;
    public CharSequence i;
    public CharSequence j;
    public Window.Callback k;
    public boolean l;
    public int m;
    public int n;
    public Drawable o;

    public l0(Toolbar toolbar, boolean z) {
        int i;
        Drawable drawable;
        int i2 = b.a.h.abc_action_bar_up_description;
        this.m = 0;
        this.n = 0;
        this.f421a = toolbar;
        this.h = toolbar.getTitle();
        this.i = toolbar.getSubtitle();
        this.g = this.h != null;
        this.f = toolbar.getNavigationIcon();
        j0 a2 = j0.a(toolbar.getContext(), null, b.a.j.ActionBar, b.a.a.actionBarStyle, 0);
        this.o = a2.b(b.a.j.ActionBar_homeAsUpIndicator);
        if (z) {
            CharSequence d2 = a2.d(b.a.j.ActionBar_title);
            if (!TextUtils.isEmpty(d2)) {
                this.g = true;
                this.h = d2;
                if ((this.f422b & 8) != 0) {
                    this.f421a.setTitle(d2);
                }
            }
            CharSequence d3 = a2.d(b.a.j.ActionBar_subtitle);
            if (!TextUtils.isEmpty(d3)) {
                this.i = d3;
                if ((this.f422b & 8) != 0) {
                    this.f421a.setSubtitle(d3);
                }
            }
            Drawable b2 = a2.b(b.a.j.ActionBar_logo);
            if (b2 != null) {
                this.e = b2;
                e();
            }
            Drawable b3 = a2.b(b.a.j.ActionBar_icon);
            if (b3 != null) {
                this.f424d = b3;
                e();
            }
            if (this.f == null && (drawable = this.o) != null) {
                this.f = drawable;
                d();
            }
            b(a2.c(b.a.j.ActionBar_displayOptions, 0));
            int e = a2.e(b.a.j.ActionBar_customNavigationLayout, 0);
            if (e != 0) {
                View inflate = LayoutInflater.from(this.f421a.getContext()).inflate(e, (ViewGroup) this.f421a, false);
                View view = this.f423c;
                if (view != null && (this.f422b & 16) != 0) {
                    this.f421a.removeView(view);
                }
                this.f423c = inflate;
                if (inflate != null && (this.f422b & 16) != 0) {
                    this.f421a.addView(inflate);
                }
                b(this.f422b | 16);
            }
            int d4 = a2.d(b.a.j.ActionBar_height, 0);
            if (d4 > 0) {
                ViewGroup.LayoutParams layoutParams = this.f421a.getLayoutParams();
                layoutParams.height = d4;
                this.f421a.setLayoutParams(layoutParams);
            }
            int a3 = a2.a(b.a.j.ActionBar_contentInsetStart, -1);
            int a4 = a2.a(b.a.j.ActionBar_contentInsetEnd, -1);
            if (a3 >= 0 || a4 >= 0) {
                Toolbar toolbar2 = this.f421a;
                int max = Math.max(a3, 0);
                int max2 = Math.max(a4, 0);
                toolbar2.b();
                toolbar2.u.a(max, max2);
            }
            int e2 = a2.e(b.a.j.ActionBar_titleTextStyle, 0);
            if (e2 != 0) {
                Toolbar toolbar3 = this.f421a;
                Context context = toolbar3.getContext();
                toolbar3.m = e2;
                TextView textView = toolbar3.f82c;
                if (textView != null) {
                    textView.setTextAppearance(context, e2);
                }
            }
            int e3 = a2.e(b.a.j.ActionBar_subtitleTextStyle, 0);
            if (e3 != 0) {
                Toolbar toolbar4 = this.f421a;
                Context context2 = toolbar4.getContext();
                toolbar4.n = e3;
                TextView textView2 = toolbar4.f83d;
                if (textView2 != null) {
                    textView2.setTextAppearance(context2, e3);
                }
            }
            int e4 = a2.e(b.a.j.ActionBar_popupTheme, 0);
            if (e4 != 0) {
                this.f421a.setPopupTheme(e4);
            }
        } else {
            if (this.f421a.getNavigationIcon() != null) {
                i = 15;
                this.o = this.f421a.getNavigationIcon();
            } else {
                i = 11;
            }
            this.f422b = i;
        }
        a2.f415b.recycle();
        if (i2 != this.n) {
            this.n = i2;
            if (TextUtils.isEmpty(this.f421a.getNavigationContentDescription())) {
                int i3 = this.n;
                this.j = i3 != 0 ? b().getString(i3) : null;
                c();
            }
        }
        this.j = this.f421a.getNavigationContentDescription();
        this.f421a.setNavigationOnClickListener(new k0(this));
    }

    @Override // b.a.p.q
    public void a() {
        c cVar;
        ActionMenuView actionMenuView = this.f421a.f81b;
        if (actionMenuView == null || (cVar = actionMenuView.u) == null) {
            return;
        }
        cVar.a();
    }

    @Override // b.a.p.q
    public void a(Window.Callback callback) {
        this.k = callback;
    }

    public Context b() {
        return this.f421a.getContext();
    }

    public void b(int i) {
        View view;
        CharSequence charSequence;
        Toolbar toolbar;
        int i2 = this.f422b ^ i;
        this.f422b = i;
        if (i2 != 0) {
            if ((i2 & 4) != 0) {
                if ((i & 4) != 0) {
                    c();
                }
                d();
            }
            if ((i2 & 3) != 0) {
                e();
            }
            if ((i2 & 8) != 0) {
                if ((i & 8) != 0) {
                    this.f421a.setTitle(this.h);
                    toolbar = this.f421a;
                    charSequence = this.i;
                } else {
                    charSequence = null;
                    this.f421a.setTitle((CharSequence) null);
                    toolbar = this.f421a;
                }
                toolbar.setSubtitle(charSequence);
            }
            if ((i2 & 16) == 0 || (view = this.f423c) == null) {
                return;
            }
            if ((i & 16) != 0) {
                this.f421a.addView(view);
            } else {
                this.f421a.removeView(view);
            }
        }
    }

    public final void c() {
        if ((this.f422b & 4) != 0) {
            if (TextUtils.isEmpty(this.j)) {
                this.f421a.setNavigationContentDescription(this.n);
            } else {
                this.f421a.setNavigationContentDescription(this.j);
            }
        }
    }

    public final void d() {
        Toolbar toolbar;
        Drawable drawable;
        if ((this.f422b & 4) != 0) {
            toolbar = this.f421a;
            drawable = this.f;
            if (drawable == null) {
                drawable = this.o;
            }
        } else {
            toolbar = this.f421a;
            drawable = null;
        }
        toolbar.setNavigationIcon(drawable);
    }

    public final void e() {
        Drawable drawable;
        int i = this.f422b;
        if ((i & 2) == 0) {
            drawable = null;
        } else if ((i & 1) == 0 || (drawable = this.e) == null) {
            drawable = this.f424d;
        }
        this.f421a.setLogo(drawable);
    }

    @Override // b.a.p.q
    public CharSequence getTitle() {
        return this.f421a.getTitle();
    }

    @Override // b.a.p.q
    public void setIcon(int i) {
        this.f424d = i != 0 ? b.a.l.a.a.c(b(), i) : null;
        e();
    }

    @Override // b.a.p.q
    public void setIcon(Drawable drawable) {
        this.f424d = drawable;
        e();
    }

    @Override // b.a.p.q
    public void a(int i) {
        this.e = i != 0 ? b.a.l.a.a.c(b(), i) : null;
        e();
    }

    @Override // b.a.p.q
    public void a(CharSequence charSequence) {
        if (this.g) {
            return;
        }
        this.h = charSequence;
        if ((this.f422b & 8) != 0) {
            this.f421a.setTitle(charSequence);
        }
    }
}
