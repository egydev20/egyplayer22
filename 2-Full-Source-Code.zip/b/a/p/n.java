package b.a.p;

import android.R;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.text.TextDirectionHeuristic;
import android.text.TextDirectionHeuristics;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputConnection;
import android.view.textclassifier.TextClassifier;
import android.widget.TextView;
import b.d.i.a;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

/* loaded from: classes.dex */
public class n extends TextView implements b.d.l.e, b.d.l.b {

    /* renamed from: b, reason: collision with root package name */
    public final e f439b;

    /* renamed from: c, reason: collision with root package name */
    public final m f440c;

    /* renamed from: d, reason: collision with root package name */
    public final l f441d;
    public Future<b.d.i.a> e;

    public n(Context context) {
        this(context, null);
    }

    public n(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, R.attr.textViewStyle);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public n(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        g0.a(context);
        e eVar = new e(this);
        this.f439b = eVar;
        eVar.a(attributeSet, i);
        m mVar = new m(this);
        this.f440c = mVar;
        mVar.a(attributeSet, i);
        this.f440c.a();
        this.f441d = new l(this);
    }

    @Override // android.widget.TextView, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        e eVar = this.f439b;
        if (eVar != null) {
            eVar.a();
        }
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a();
        }
    }

    @Override // android.widget.TextView
    public int getAutoSizeMaxTextSize() {
        if (b.d.l.b.f657a) {
            return super.getAutoSizeMaxTextSize();
        }
        m mVar = this.f440c;
        if (mVar != null) {
            return Math.round(mVar.i.e);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeMinTextSize() {
        if (b.d.l.b.f657a) {
            return super.getAutoSizeMinTextSize();
        }
        m mVar = this.f440c;
        if (mVar != null) {
            return Math.round(mVar.i.f449d);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int getAutoSizeStepGranularity() {
        if (b.d.l.b.f657a) {
            return super.getAutoSizeStepGranularity();
        }
        m mVar = this.f440c;
        if (mVar != null) {
            return Math.round(mVar.i.f448c);
        }
        return -1;
    }

    @Override // android.widget.TextView
    public int[] getAutoSizeTextAvailableSizes() {
        if (b.d.l.b.f657a) {
            return super.getAutoSizeTextAvailableSizes();
        }
        m mVar = this.f440c;
        return mVar != null ? mVar.i.f : new int[0];
    }

    @Override // android.widget.TextView
    @SuppressLint({"WrongConstant"})
    public int getAutoSizeTextType() {
        if (b.d.l.b.f657a) {
            return super.getAutoSizeTextType() == 1 ? 1 : 0;
        }
        m mVar = this.f440c;
        if (mVar != null) {
            return mVar.i.f446a;
        }
        return 0;
    }

    @Override // android.widget.TextView
    public int getFirstBaselineToTopHeight() {
        return getPaddingTop() - getPaint().getFontMetricsInt().top;
    }

    @Override // android.widget.TextView
    public int getLastBaselineToBottomHeight() {
        return getPaddingBottom() + getPaint().getFontMetricsInt().bottom;
    }

    public ColorStateList getSupportBackgroundTintList() {
        e eVar = this.f439b;
        if (eVar != null) {
            return eVar.b();
        }
        return null;
    }

    public PorterDuff.Mode getSupportBackgroundTintMode() {
        e eVar = this.f439b;
        if (eVar != null) {
            return eVar.c();
        }
        return null;
    }

    public ColorStateList getSupportCompoundDrawablesTintList() {
        h0 h0Var = this.f440c.h;
        if (h0Var != null) {
            return h0Var.f405a;
        }
        return null;
    }

    public PorterDuff.Mode getSupportCompoundDrawablesTintMode() {
        h0 h0Var = this.f440c.h;
        if (h0Var != null) {
            return h0Var.f406b;
        }
        return null;
    }

    @Override // android.widget.TextView
    public CharSequence getText() {
        Future<b.d.i.a> future = this.e;
        if (future != null) {
            try {
                this.e = null;
                a.a.a.a.a.a((TextView) this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        return super.getText();
    }

    @Override // android.widget.TextView
    public TextClassifier getTextClassifier() {
        l lVar;
        return (Build.VERSION.SDK_INT >= 28 || (lVar = this.f441d) == null) ? super.getTextClassifier() : lVar.a();
    }

    public a.C0017a getTextMetricsParamsCompat() {
        return a.a.a.a.a.a(this);
    }

    @Override // android.widget.TextView, android.view.View
    public InputConnection onCreateInputConnection(EditorInfo editorInfo) {
        InputConnection onCreateInputConnection = super.onCreateInputConnection(editorInfo);
        a.a.a.a.a.a(onCreateInputConnection, editorInfo, this);
        return onCreateInputConnection;
    }

    @Override // android.widget.TextView, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        m mVar = this.f440c;
        if (mVar == null || b.d.l.b.f657a) {
            return;
        }
        mVar.i.a();
    }

    @Override // android.widget.TextView, android.view.View
    public void onMeasure(int i, int i2) {
        Future<b.d.i.a> future = this.e;
        if (future != null) {
            try {
                this.e = null;
                a.a.a.a.a.a((TextView) this, future.get());
            } catch (InterruptedException | ExecutionException unused) {
            }
        }
        super.onMeasure(i, i2);
    }

    @Override // android.widget.TextView
    public void onTextChanged(CharSequence charSequence, int i, int i2, int i3) {
        super.onTextChanged(charSequence, i, i2, i3);
        m mVar = this.f440c;
        if (mVar == null || b.d.l.b.f657a || !mVar.b()) {
            return;
        }
        this.f440c.i.a();
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithConfiguration(int i, int i2, int i3, int i4) {
        if (b.d.l.b.f657a) {
            super.setAutoSizeTextTypeUniformWithConfiguration(i, i2, i3, i4);
            return;
        }
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a(i, i2, i3, i4);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeUniformWithPresetSizes(int[] iArr, int i) {
        if (b.d.l.b.f657a) {
            super.setAutoSizeTextTypeUniformWithPresetSizes(iArr, i);
            return;
        }
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a(iArr, i);
        }
    }

    @Override // android.widget.TextView
    public void setAutoSizeTextTypeWithDefaults(int i) {
        if (b.d.l.b.f657a) {
            super.setAutoSizeTextTypeWithDefaults(i);
            return;
        }
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a(i);
        }
    }

    @Override // android.view.View
    public void setBackgroundDrawable(Drawable drawable) {
        super.setBackgroundDrawable(drawable);
        e eVar = this.f439b;
        if (eVar != null) {
            eVar.d();
        }
    }

    @Override // android.view.View
    public void setBackgroundResource(int i) {
        super.setBackgroundResource(i);
        e eVar = this.f439b;
        if (eVar != null) {
            eVar.a(i);
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawables(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawables(drawable, drawable2, drawable3, drawable4);
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelative(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelative(drawable, drawable2, drawable3, drawable4);
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        setCompoundDrawablesRelativeWithIntrinsicBounds(i != 0 ? b.a.l.a.a.c(context, i) : null, i2 != 0 ? b.a.l.a.a.c(context, i2) : null, i3 != 0 ? b.a.l.a.a.c(context, i3) : null, i4 != 0 ? b.a.l.a.a.c(context, i4) : null);
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(int i, int i2, int i3, int i4) {
        Context context = getContext();
        setCompoundDrawablesWithIntrinsicBounds(i != 0 ? b.a.l.a.a.c(context, i) : null, i2 != 0 ? b.a.l.a.a.c(context, i2) : null, i3 != 0 ? b.a.l.a.a.c(context, i3) : null, i4 != 0 ? b.a.l.a.a.c(context, i4) : null);
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a();
        }
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(a.a.a.a.a.a(this, callback));
    }

    @Override // android.widget.TextView
    public void setFirstBaselineToTopHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setFirstBaselineToTopHeight(i);
        } else {
            a.a.a.a.a.a(this, i);
        }
    }

    @Override // android.widget.TextView
    public void setLastBaselineToBottomHeight(int i) {
        if (Build.VERSION.SDK_INT >= 28) {
            super.setLastBaselineToBottomHeight(i);
        } else {
            a.a.a.a.a.b(this, i);
        }
    }

    @Override // android.widget.TextView
    public void setLineHeight(int i) {
        a.a.a.a.a.c(this, i);
    }

    public void setPrecomputedText(b.d.i.a aVar) {
        a.a.a.a.a.a((TextView) this, aVar);
    }

    public void setSupportBackgroundTintList(ColorStateList colorStateList) {
        e eVar = this.f439b;
        if (eVar != null) {
            eVar.b(colorStateList);
        }
    }

    public void setSupportBackgroundTintMode(PorterDuff.Mode mode) {
        e eVar = this.f439b;
        if (eVar != null) {
            eVar.a(mode);
        }
    }

    @Override // b.d.l.e
    public void setSupportCompoundDrawablesTintList(ColorStateList colorStateList) {
        m mVar = this.f440c;
        if (mVar.h == null) {
            mVar.h = new h0();
        }
        h0 h0Var = mVar.h;
        h0Var.f405a = colorStateList;
        h0Var.f408d = colorStateList != null;
        h0 h0Var2 = mVar.h;
        mVar.f426b = h0Var2;
        mVar.f427c = h0Var2;
        mVar.f428d = h0Var2;
        mVar.e = h0Var2;
        mVar.f = h0Var2;
        mVar.g = h0Var2;
        this.f440c.a();
    }

    @Override // b.d.l.e
    public void setSupportCompoundDrawablesTintMode(PorterDuff.Mode mode) {
        m mVar = this.f440c;
        if (mVar.h == null) {
            mVar.h = new h0();
        }
        h0 h0Var = mVar.h;
        h0Var.f406b = mode;
        h0Var.f407c = mode != null;
        h0 h0Var2 = mVar.h;
        mVar.f426b = h0Var2;
        mVar.f427c = h0Var2;
        mVar.f428d = h0Var2;
        mVar.e = h0Var2;
        mVar.f = h0Var2;
        mVar.g = h0Var2;
        this.f440c.a();
    }

    @Override // android.widget.TextView
    public void setTextAppearance(Context context, int i) {
        super.setTextAppearance(context, i);
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a(context, i);
        }
    }

    @Override // android.widget.TextView
    public void setTextClassifier(TextClassifier textClassifier) {
        l lVar;
        if (Build.VERSION.SDK_INT < 28 && (lVar = this.f441d) != null) {
            lVar.f420b = textClassifier;
        } else {
            super.setTextClassifier(textClassifier);
        }
    }

    public void setTextFuture(Future<b.d.i.a> future) {
        this.e = future;
        if (future != null) {
            requestLayout();
        }
    }

    public void setTextMetricsParamsCompat(a.C0017a c0017a) {
        TextDirectionHeuristic textDirectionHeuristic = c0017a.f605b;
        int i = 1;
        if (textDirectionHeuristic != TextDirectionHeuristics.FIRSTSTRONG_RTL && textDirectionHeuristic != TextDirectionHeuristics.FIRSTSTRONG_LTR) {
            if (textDirectionHeuristic == TextDirectionHeuristics.ANYRTL_LTR) {
                i = 2;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LTR) {
                i = 3;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.RTL) {
                i = 4;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.LOCALE) {
                i = 5;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_LTR) {
                i = 6;
            } else if (textDirectionHeuristic == TextDirectionHeuristics.FIRSTSTRONG_RTL) {
                i = 7;
            }
        }
        setTextDirection(i);
        if (Build.VERSION.SDK_INT < 23) {
            float textScaleX = c0017a.f604a.getTextScaleX();
            getPaint().set(c0017a.f604a);
            if (textScaleX == getTextScaleX()) {
                setTextScaleX((textScaleX / 2.0f) + 1.0f);
            }
            setTextScaleX(textScaleX);
            return;
        }
        getPaint().set(c0017a.f604a);
        setBreakStrategy(c0017a.f606c);
        setHyphenationFrequency(c0017a.f607d);
    }

    @Override // android.widget.TextView
    public void setTextSize(int i, float f) {
        boolean z = b.d.l.b.f657a;
        if (z) {
            super.setTextSize(i, f);
            return;
        }
        m mVar = this.f440c;
        if (mVar == null || z || mVar.b()) {
            return;
        }
        mVar.i.a(i, f);
    }

    @Override // android.widget.TextView
    public void setTypeface(Typeface typeface, int i) {
        Typeface a2 = (typeface == null || i <= 0) ? null : b.d.f.c.a(getContext(), typeface, i);
        if (a2 != null) {
            typeface = a2;
        }
        super.setTypeface(typeface, i);
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesRelativeWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a();
        }
    }

    @Override // android.widget.TextView
    public void setCompoundDrawablesWithIntrinsicBounds(Drawable drawable, Drawable drawable2, Drawable drawable3, Drawable drawable4) {
        super.setCompoundDrawablesWithIntrinsicBounds(drawable, drawable2, drawable3, drawable4);
        m mVar = this.f440c;
        if (mVar != null) {
            mVar.a();
        }
    }
}
