package b.a.p;

import android.view.View;
import android.widget.AdapterView;

/* loaded from: classes.dex */
public class w implements AdapterView.OnItemSelectedListener {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ x f468b;

    public w(x xVar) {
        this.f468b = xVar;
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
        s sVar;
        if (i == -1 || (sVar = this.f468b.f471d) == null) {
            return;
        }
        sVar.setListSelectionHidden(false);
    }

    @Override // android.widget.AdapterView.OnItemSelectedListener
    public void onNothingSelected(AdapterView<?> adapterView) {
    }
}
