package b.a.p;

import android.content.res.Resources;

/* loaded from: classes.dex */
public class o0 extends Resources {
    public static boolean a() {
        return false;
    }
}
