package b.a.p;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;

/* loaded from: classes.dex */
public class h0 {

    /* renamed from: a, reason: collision with root package name */
    public ColorStateList f405a;

    /* renamed from: b, reason: collision with root package name */
    public PorterDuff.Mode f406b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f407c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f408d;
}
