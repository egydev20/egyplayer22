package b.a.p;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public class x implements b.a.o.d.n {
    public static Method D;
    public static Method E;
    public static Method F;
    public Rect A;
    public boolean B;
    public PopupWindow C;

    /* renamed from: b, reason: collision with root package name */
    public Context f469b;

    /* renamed from: c, reason: collision with root package name */
    public ListAdapter f470c;

    /* renamed from: d, reason: collision with root package name */
    public s f471d;
    public int g;
    public int h;
    public boolean j;
    public boolean k;
    public boolean l;
    public DataSetObserver r;
    public View s;
    public AdapterView.OnItemClickListener t;
    public final Handler y;
    public int e = -2;
    public int f = -2;
    public int i = 1002;
    public int m = 0;
    public boolean n = false;
    public boolean o = false;
    public int p = Integer.MAX_VALUE;
    public int q = 0;
    public final e u = new e();
    public final d v = new d();
    public final c w = new c();
    public final a x = new a();
    public final Rect z = new Rect();

    /* loaded from: classes.dex */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            s sVar = x.this.f471d;
            if (sVar != null) {
                sVar.setListSelectionHidden(true);
                sVar.requestLayout();
            }
        }
    }

    /* loaded from: classes.dex */
    public class b extends DataSetObserver {
        public b() {
        }

        @Override // android.database.DataSetObserver
        public void onChanged() {
            if (x.this.c()) {
                x.this.a();
            }
        }

        @Override // android.database.DataSetObserver
        public void onInvalidated() {
            x.this.dismiss();
        }
    }

    /* loaded from: classes.dex */
    public class c implements AbsListView.OnScrollListener {
        public c() {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScroll(AbsListView absListView, int i, int i2, int i3) {
        }

        @Override // android.widget.AbsListView.OnScrollListener
        public void onScrollStateChanged(AbsListView absListView, int i) {
            if (i == 1) {
                if ((x.this.C.getInputMethodMode() == 2) || x.this.C.getContentView() == null) {
                    return;
                }
                x xVar = x.this;
                xVar.y.removeCallbacks(xVar.u);
                x.this.u.run();
            }
        }
    }

    /* loaded from: classes.dex */
    public class d implements View.OnTouchListener {
        public d() {
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            PopupWindow popupWindow;
            int action = motionEvent.getAction();
            int x = (int) motionEvent.getX();
            int y = (int) motionEvent.getY();
            if (action == 0 && (popupWindow = x.this.C) != null && popupWindow.isShowing() && x >= 0 && x < x.this.C.getWidth() && y >= 0 && y < x.this.C.getHeight()) {
                x xVar = x.this;
                xVar.y.postDelayed(xVar.u, 250L);
                return false;
            }
            if (action != 1) {
                return false;
            }
            x xVar2 = x.this;
            xVar2.y.removeCallbacks(xVar2.u);
            return false;
        }
    }

    /* loaded from: classes.dex */
    public class e implements Runnable {
        public e() {
        }

        @Override // java.lang.Runnable
        public void run() {
            s sVar = x.this.f471d;
            if (sVar == null || !b.d.k.l.l(sVar) || x.this.f471d.getCount() <= x.this.f471d.getChildCount()) {
                return;
            }
            int childCount = x.this.f471d.getChildCount();
            x xVar = x.this;
            if (childCount <= xVar.p) {
                xVar.C.setInputMethodMode(2);
                x.this.a();
            }
        }
    }

    static {
        if (Build.VERSION.SDK_INT <= 28) {
            try {
                D = PopupWindow.class.getDeclaredMethod("setClipToScreenEnabled", Boolean.TYPE);
            } catch (NoSuchMethodException unused) {
                Log.i("ListPopupWindow", "Could not find method setClipToScreenEnabled() on PopupWindow. Oh well.");
            }
            try {
                F = PopupWindow.class.getDeclaredMethod("setEpicenterBounds", Rect.class);
            } catch (NoSuchMethodException unused2) {
                Log.i("ListPopupWindow", "Could not find method setEpicenterBounds(Rect) on PopupWindow. Oh well.");
            }
        }
        if (Build.VERSION.SDK_INT <= 23) {
            try {
                E = PopupWindow.class.getDeclaredMethod("getMaxAvailableHeight", View.class, Integer.TYPE, Boolean.TYPE);
            } catch (NoSuchMethodException unused3) {
                Log.i("ListPopupWindow", "Could not find method getMaxAvailableHeight(View, int, boolean) on PopupWindow. Oh well.");
            }
        }
    }

    public x(Context context, AttributeSet attributeSet, int i, int i2) {
        this.f469b = context;
        this.y = new Handler(context.getMainLooper());
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.a.j.ListPopupWindow, i, i2);
        this.g = obtainStyledAttributes.getDimensionPixelOffset(b.a.j.ListPopupWindow_android_dropDownHorizontalOffset, 0);
        int dimensionPixelOffset = obtainStyledAttributes.getDimensionPixelOffset(b.a.j.ListPopupWindow_android_dropDownVerticalOffset, 0);
        this.h = dimensionPixelOffset;
        if (dimensionPixelOffset != 0) {
            this.j = true;
        }
        obtainStyledAttributes.recycle();
        k kVar = new k(context, attributeSet, i, i2);
        this.C = kVar;
        kVar.setInputMethodMode(1);
    }

    public s a(Context context, boolean z) {
        throw null;
    }

    public void a(int i) {
        Drawable background = this.C.getBackground();
        if (background == null) {
            this.f = i;
            return;
        }
        background.getPadding(this.z);
        Rect rect = this.z;
        this.f = rect.left + rect.right + i;
    }

    public void a(ListAdapter listAdapter) {
        DataSetObserver dataSetObserver = this.r;
        if (dataSetObserver == null) {
            this.r = new b();
        } else {
            ListAdapter listAdapter2 = this.f470c;
            if (listAdapter2 != null) {
                listAdapter2.unregisterDataSetObserver(dataSetObserver);
            }
        }
        this.f470c = listAdapter;
        if (listAdapter != null) {
            listAdapter.registerDataSetObserver(this.r);
        }
        s sVar = this.f471d;
        if (sVar != null) {
            sVar.setAdapter(this.f470c);
        }
    }

    public void a(boolean z) {
        this.B = z;
        this.C.setFocusable(z);
    }

    public void b(int i) {
        this.h = i;
        this.j = true;
    }

    @Override // b.a.o.d.n
    public boolean c() {
        return this.C.isShowing();
    }

    @Override // b.a.o.d.n
    public ListView d() {
        return this.f471d;
    }

    @Override // b.a.o.d.n
    public void dismiss() {
        this.C.dismiss();
        this.C.setContentView(null);
        this.f471d = null;
        this.y.removeCallbacks(this.u);
    }

    @Override // b.a.o.d.n
    public void a() {
        int i;
        int maxAvailableHeight;
        int i2;
        s sVar;
        int i3;
        if (this.f471d == null) {
            s a2 = a(this.f469b, !this.B);
            this.f471d = a2;
            a2.setAdapter(this.f470c);
            this.f471d.setOnItemClickListener(this.t);
            this.f471d.setFocusable(true);
            this.f471d.setFocusableInTouchMode(true);
            this.f471d.setOnItemSelectedListener(new w(this));
            this.f471d.setOnScrollListener(this.w);
            this.C.setContentView(this.f471d);
        }
        Drawable background = this.C.getBackground();
        if (background != null) {
            background.getPadding(this.z);
            Rect rect = this.z;
            int i4 = rect.top;
            i = rect.bottom + i4;
            if (!this.j) {
                this.h = -i4;
            }
        } else {
            this.z.setEmpty();
            i = 0;
        }
        boolean z = this.C.getInputMethodMode() == 2;
        View view = this.s;
        int i5 = this.h;
        if (Build.VERSION.SDK_INT <= 23) {
            Method method = E;
            if (method != null) {
                try {
                    maxAvailableHeight = ((Integer) method.invoke(this.C, view, Integer.valueOf(i5), Boolean.valueOf(z))).intValue();
                } catch (Exception unused) {
                    Log.i("ListPopupWindow", "Could not call getMaxAvailableHeightMethod(View, int, boolean) on PopupWindow. Using the public version.");
                }
            }
            maxAvailableHeight = this.C.getMaxAvailableHeight(view, i5);
        } else {
            maxAvailableHeight = this.C.getMaxAvailableHeight(view, i5, z);
        }
        if (this.n || this.e == -1) {
            i2 = maxAvailableHeight + i;
        } else {
            int i6 = this.f;
            if (i6 != -2) {
                i3 = 1073741824;
                if (i6 == -1) {
                    int i7 = this.f469b.getResources().getDisplayMetrics().widthPixels;
                    Rect rect2 = this.z;
                    i6 = i7 - (rect2.left + rect2.right);
                }
            } else {
                int i8 = this.f469b.getResources().getDisplayMetrics().widthPixels;
                Rect rect3 = this.z;
                i6 = i8 - (rect3.left + rect3.right);
                i3 = Integer.MIN_VALUE;
            }
            int a3 = this.f471d.a(View.MeasureSpec.makeMeasureSpec(i6, i3), maxAvailableHeight - 0, -1);
            i2 = a3 + (a3 > 0 ? this.f471d.getPaddingBottom() + this.f471d.getPaddingTop() + i + 0 : 0);
        }
        boolean z2 = this.C.getInputMethodMode() == 2;
        a.a.a.a.a.a(this.C, this.i);
        if (this.C.isShowing()) {
            if (b.d.k.l.l(this.s)) {
                int i9 = this.f;
                if (i9 == -1) {
                    i9 = -1;
                } else if (i9 == -2) {
                    i9 = this.s.getWidth();
                }
                int i10 = this.e;
                if (i10 == -1) {
                    if (!z2) {
                        i2 = -1;
                    }
                    if (z2) {
                        this.C.setWidth(this.f == -1 ? -1 : 0);
                        this.C.setHeight(0);
                    } else {
                        this.C.setWidth(this.f == -1 ? -1 : 0);
                        this.C.setHeight(-1);
                    }
                } else if (i10 != -2) {
                    i2 = i10;
                }
                this.C.setOutsideTouchable((this.o || this.n) ? false : true);
                this.C.update(this.s, this.g, this.h, i9 < 0 ? -1 : i9, i2 < 0 ? -1 : i2);
                return;
            }
            return;
        }
        int i11 = this.f;
        if (i11 == -1) {
            i11 = -1;
        } else if (i11 == -2) {
            i11 = this.s.getWidth();
        }
        int i12 = this.e;
        if (i12 == -1) {
            i2 = -1;
        } else if (i12 != -2) {
            i2 = i12;
        }
        this.C.setWidth(i11);
        this.C.setHeight(i2);
        if (Build.VERSION.SDK_INT <= 28) {
            Method method2 = D;
            if (method2 != null) {
                try {
                    method2.invoke(this.C, true);
                } catch (Exception unused2) {
                    Log.i("ListPopupWindow", "Could not call setClipToScreenEnabled() on PopupWindow. Oh well.");
                }
            }
        } else {
            this.C.setIsClippedToScreen(true);
        }
        this.C.setOutsideTouchable((this.o || this.n) ? false : true);
        this.C.setTouchInterceptor(this.v);
        if (this.l) {
            a.a.a.a.a.a(this.C, this.k);
        }
        if (Build.VERSION.SDK_INT <= 28) {
            Method method3 = F;
            if (method3 != null) {
                try {
                    method3.invoke(this.C, this.A);
                } catch (Exception e2) {
                    Log.e("ListPopupWindow", "Could not invoke setEpicenterBounds on PopupWindow", e2);
                }
            }
        } else {
            this.C.setEpicenterBounds(this.A);
        }
        this.C.showAsDropDown(this.s, this.g, this.h, this.m);
        this.f471d.setSelection(-1);
        if ((!this.B || this.f471d.isInTouchMode()) && (sVar = this.f471d) != null) {
            sVar.setListSelectionHidden(true);
            sVar.requestLayout();
        }
        if (this.B) {
            return;
        }
        this.y.post(this.x);
    }
}
