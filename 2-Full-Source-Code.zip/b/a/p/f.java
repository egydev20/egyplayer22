package b.a.p;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import b.a.p.a0;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: b, reason: collision with root package name */
    public static final PorterDuff.Mode f388b = PorterDuff.Mode.SRC_IN;

    /* renamed from: c, reason: collision with root package name */
    public static f f389c;

    /* renamed from: a, reason: collision with root package name */
    public a0 f390a;

    /* loaded from: classes.dex */
    public static class a implements a0.e {

        /* renamed from: a, reason: collision with root package name */
        public final int[] f391a = {b.a.e.abc_textfield_search_default_mtrl_alpha, b.a.e.abc_textfield_default_mtrl_alpha, b.a.e.abc_ab_share_pack_mtrl_alpha};

        /* renamed from: b, reason: collision with root package name */
        public final int[] f392b = {b.a.e.abc_ic_commit_search_api_mtrl_alpha, b.a.e.abc_seekbar_tick_mark_material, b.a.e.abc_ic_menu_share_mtrl_alpha, b.a.e.abc_ic_menu_copy_mtrl_am_alpha, b.a.e.abc_ic_menu_cut_mtrl_alpha, b.a.e.abc_ic_menu_selectall_mtrl_alpha, b.a.e.abc_ic_menu_paste_mtrl_am_alpha};

        /* renamed from: c, reason: collision with root package name */
        public final int[] f393c = {b.a.e.abc_textfield_activated_mtrl_alpha, b.a.e.abc_textfield_search_activated_mtrl_alpha, b.a.e.abc_cab_background_top_mtrl_alpha, b.a.e.abc_text_cursor_material, b.a.e.abc_text_select_handle_left_mtrl_dark, b.a.e.abc_text_select_handle_middle_mtrl_dark, b.a.e.abc_text_select_handle_right_mtrl_dark, b.a.e.abc_text_select_handle_left_mtrl_light, b.a.e.abc_text_select_handle_middle_mtrl_light, b.a.e.abc_text_select_handle_right_mtrl_light};

        /* renamed from: d, reason: collision with root package name */
        public final int[] f394d = {b.a.e.abc_popup_background_mtrl_mult, b.a.e.abc_cab_background_internal_bg, b.a.e.abc_menu_hardkey_panel_mtrl_mult};
        public final int[] e = {b.a.e.abc_tab_indicator_material, b.a.e.abc_textfield_search_material};
        public final int[] f = {b.a.e.abc_btn_check_material, b.a.e.abc_btn_radio_material, b.a.e.abc_btn_check_material_anim, b.a.e.abc_btn_radio_material_anim};

        public final ColorStateList a(Context context, int i) {
            int b2 = f0.b(context, b.a.a.colorControlHighlight);
            return new ColorStateList(new int[][]{f0.f396b, f0.f398d, f0.f397c, f0.f}, new int[]{f0.a(context, b.a.a.colorButtonNormal), b.d.f.a.a(b2, i), b.d.f.a.a(b2, i), i});
        }

        public final void a(Drawable drawable, int i, PorterDuff.Mode mode) {
            if (r.a(drawable)) {
                drawable = drawable.mutate();
            }
            if (mode == null) {
                mode = f.f388b;
            }
            drawable.setColorFilter(f.a(i, mode));
        }

        public final boolean a(int[] iArr, int i) {
            for (int i2 : iArr) {
                if (i2 == i) {
                    return true;
                }
            }
            return false;
        }

        public ColorStateList b(Context context, int i) {
            if (i == b.a.e.abc_edit_text_material) {
                return b.a.l.a.a.b(context, b.a.c.abc_tint_edittext);
            }
            if (i == b.a.e.abc_switch_track_mtrl_alpha) {
                return b.a.l.a.a.b(context, b.a.c.abc_tint_switch_track);
            }
            if (i == b.a.e.abc_switch_thumb_material) {
                int[][] iArr = new int[3];
                int[] iArr2 = new int[3];
                ColorStateList c2 = f0.c(context, b.a.a.colorSwitchThumbNormal);
                if (c2 == null || !c2.isStateful()) {
                    iArr[0] = f0.f396b;
                    iArr2[0] = f0.a(context, b.a.a.colorSwitchThumbNormal);
                    iArr[1] = f0.e;
                    iArr2[1] = f0.b(context, b.a.a.colorControlActivated);
                    iArr[2] = f0.f;
                    iArr2[2] = f0.b(context, b.a.a.colorSwitchThumbNormal);
                } else {
                    iArr[0] = f0.f396b;
                    iArr2[0] = c2.getColorForState(iArr[0], 0);
                    iArr[1] = f0.e;
                    iArr2[1] = f0.b(context, b.a.a.colorControlActivated);
                    iArr[2] = f0.f;
                    iArr2[2] = c2.getDefaultColor();
                }
                return new ColorStateList(iArr, iArr2);
            }
            if (i == b.a.e.abc_btn_default_mtrl_shape) {
                return a(context, f0.b(context, b.a.a.colorButtonNormal));
            }
            if (i == b.a.e.abc_btn_borderless_material) {
                return a(context, 0);
            }
            if (i == b.a.e.abc_btn_colored_material) {
                return a(context, f0.b(context, b.a.a.colorAccent));
            }
            if (i == b.a.e.abc_spinner_mtrl_am_alpha || i == b.a.e.abc_spinner_textfield_background_material) {
                return b.a.l.a.a.b(context, b.a.c.abc_tint_spinner);
            }
            if (a(this.f392b, i)) {
                return f0.c(context, b.a.a.colorControlNormal);
            }
            if (a(this.e, i)) {
                return b.a.l.a.a.b(context, b.a.c.abc_tint_default);
            }
            if (a(this.f, i)) {
                return b.a.l.a.a.b(context, b.a.c.abc_tint_btn_checkable);
            }
            if (i == b.a.e.abc_seekbar_thumb_material) {
                return b.a.l.a.a.b(context, b.a.c.abc_tint_seek_thumb);
            }
            return null;
        }
    }

    public static synchronized PorterDuffColorFilter a(int i, PorterDuff.Mode mode) {
        PorterDuffColorFilter a2;
        synchronized (f.class) {
            a2 = a0.a(i, mode);
        }
        return a2;
    }

    public static synchronized f a() {
        f fVar;
        synchronized (f.class) {
            if (f389c == null) {
                b();
            }
            fVar = f389c;
        }
        return fVar;
    }

    public static void a(Drawable drawable, h0 h0Var, int[] iArr) {
        a0.a(drawable, h0Var, iArr);
    }

    public static synchronized void b() {
        synchronized (f.class) {
            if (f389c == null) {
                f fVar = new f();
                f389c = fVar;
                fVar.f390a = a0.a();
                f389c.f390a.a(new a());
            }
        }
    }

    public synchronized Drawable a(Context context, int i) {
        return this.f390a.b(context, i);
    }

    public synchronized ColorStateList b(Context context, int i) {
        return this.f390a.c(context, i);
    }
}
