package b.a.p;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.util.TypedValue;

/* loaded from: classes.dex */
public class j0 {

    /* renamed from: a, reason: collision with root package name */
    public final Context f414a;

    /* renamed from: b, reason: collision with root package name */
    public final TypedArray f415b;

    /* renamed from: c, reason: collision with root package name */
    public TypedValue f416c;

    public j0(Context context, TypedArray typedArray) {
        this.f414a = context;
        this.f415b = typedArray;
    }

    public static j0 a(Context context, AttributeSet attributeSet, int[] iArr) {
        return new j0(context, context.obtainStyledAttributes(attributeSet, iArr));
    }

    public static j0 a(Context context, AttributeSet attributeSet, int[] iArr, int i, int i2) {
        return new j0(context, context.obtainStyledAttributes(attributeSet, iArr, i, i2));
    }

    public int a(int i, int i2) {
        return this.f415b.getDimensionPixelOffset(i, i2);
    }

    public ColorStateList a(int i) {
        int resourceId;
        ColorStateList b2;
        return (!this.f415b.hasValue(i) || (resourceId = this.f415b.getResourceId(i, 0)) == 0 || (b2 = b.a.l.a.a.b(this.f414a, resourceId)) == null) ? this.f415b.getColorStateList(i) : b2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:14:0x003e, code lost:
    
        if (r15 != null) goto L42;
     */
    /* JADX WARN: Code restructure failed: missing block: B:19:0x00b2, code lost:
    
        r15.a(-3, (android.os.Handler) null);
     */
    /* JADX WARN: Code restructure failed: missing block: B:43:0x00b0, code lost:
    
        if (r15 != null) goto L42;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.graphics.Typeface a(int r13, int r14, b.d.e.b.g r15) {
        /*
            Method dump skipped, instructions count: 258
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.p.j0.a(int, int, b.d.e.b.g):android.graphics.Typeface");
    }

    public boolean a(int i, boolean z) {
        return this.f415b.getBoolean(i, z);
    }

    public int b(int i, int i2) {
        return this.f415b.getDimensionPixelSize(i, i2);
    }

    public Drawable b(int i) {
        int resourceId;
        return (!this.f415b.hasValue(i) || (resourceId = this.f415b.getResourceId(i, 0)) == 0) ? this.f415b.getDrawable(i) : b.a.l.a.a.c(this.f414a, resourceId);
    }

    public int c(int i, int i2) {
        return this.f415b.getInt(i, i2);
    }

    public String c(int i) {
        return this.f415b.getString(i);
    }

    public int d(int i, int i2) {
        return this.f415b.getLayoutDimension(i, i2);
    }

    public CharSequence d(int i) {
        return this.f415b.getText(i);
    }

    public int e(int i, int i2) {
        return this.f415b.getResourceId(i, i2);
    }

    public boolean e(int i) {
        return this.f415b.hasValue(i);
    }
}
