package b.a.p;

import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.Arrays;

/* loaded from: classes.dex */
public class m {

    /* renamed from: a, reason: collision with root package name */
    public final TextView f425a;

    /* renamed from: b, reason: collision with root package name */
    public h0 f426b;

    /* renamed from: c, reason: collision with root package name */
    public h0 f427c;

    /* renamed from: d, reason: collision with root package name */
    public h0 f428d;
    public h0 e;
    public h0 f;
    public h0 g;
    public h0 h;
    public final o i;
    public int j = 0;
    public int k = -1;
    public Typeface l;
    public boolean m;

    /* loaded from: classes.dex */
    public static class a extends b.d.e.b.g {

        /* renamed from: a, reason: collision with root package name */
        public final WeakReference<m> f429a;

        /* renamed from: b, reason: collision with root package name */
        public final int f430b;

        /* renamed from: c, reason: collision with root package name */
        public final int f431c;

        /* renamed from: b.a.p.m$a$a, reason: collision with other inner class name */
        /* loaded from: classes.dex */
        public class RunnableC0012a implements Runnable {

            /* renamed from: b, reason: collision with root package name */
            public final WeakReference<m> f432b;

            /* renamed from: c, reason: collision with root package name */
            public final Typeface f433c;

            public RunnableC0012a(a aVar, WeakReference<m> weakReference, Typeface typeface) {
                this.f432b = weakReference;
                this.f433c = typeface;
            }

            @Override // java.lang.Runnable
            public void run() {
                m mVar = this.f432b.get();
                if (mVar == null) {
                    return;
                }
                Typeface typeface = this.f433c;
                if (mVar.m) {
                    mVar.f425a.setTypeface(typeface);
                    mVar.l = typeface;
                }
            }
        }

        public a(m mVar, int i, int i2) {
            this.f429a = new WeakReference<>(mVar);
            this.f430b = i;
            this.f431c = i2;
        }

        @Override // b.d.e.b.g
        public void a(Typeface typeface) {
            int i;
            m mVar = this.f429a.get();
            if (mVar == null) {
                return;
            }
            if (Build.VERSION.SDK_INT >= 28 && (i = this.f430b) != -1) {
                typeface = Typeface.create(typeface, i, (this.f431c & 2) != 0);
            }
            mVar.f425a.post(new RunnableC0012a(this, this.f429a, typeface));
        }
    }

    public m(TextView textView) {
        this.f425a = textView;
        this.i = new o(this.f425a);
    }

    public static h0 a(Context context, f fVar, int i) {
        ColorStateList b2 = fVar.b(context, i);
        if (b2 == null) {
            return null;
        }
        h0 h0Var = new h0();
        h0Var.f408d = true;
        h0Var.f405a = b2;
        return h0Var;
    }

    public void a() {
        if (this.f426b != null || this.f427c != null || this.f428d != null || this.e != null) {
            Drawable[] compoundDrawables = this.f425a.getCompoundDrawables();
            a(compoundDrawables[0], this.f426b);
            a(compoundDrawables[1], this.f427c);
            a(compoundDrawables[2], this.f428d);
            a(compoundDrawables[3], this.e);
        }
        if (this.f == null && this.g == null) {
            return;
        }
        Drawable[] compoundDrawablesRelative = this.f425a.getCompoundDrawablesRelative();
        a(compoundDrawablesRelative[0], this.f);
        a(compoundDrawablesRelative[2], this.g);
    }

    public final void a(Context context, j0 j0Var) {
        String c2;
        Typeface create;
        Typeface typeface;
        this.j = j0Var.c(b.a.j.TextAppearance_android_textStyle, this.j);
        if (Build.VERSION.SDK_INT >= 28) {
            int c3 = j0Var.c(b.a.j.TextAppearance_android_textFontWeight, -1);
            this.k = c3;
            if (c3 != -1) {
                this.j = (this.j & 2) | 0;
            }
        }
        if (!j0Var.e(b.a.j.TextAppearance_android_fontFamily) && !j0Var.e(b.a.j.TextAppearance_fontFamily)) {
            if (j0Var.e(b.a.j.TextAppearance_android_typeface)) {
                this.m = false;
                int c4 = j0Var.c(b.a.j.TextAppearance_android_typeface, 1);
                if (c4 == 1) {
                    typeface = Typeface.SANS_SERIF;
                } else if (c4 == 2) {
                    typeface = Typeface.SERIF;
                } else if (c4 != 3) {
                    return;
                } else {
                    typeface = Typeface.MONOSPACE;
                }
                this.l = typeface;
                return;
            }
            return;
        }
        this.l = null;
        int i = j0Var.e(b.a.j.TextAppearance_fontFamily) ? b.a.j.TextAppearance_fontFamily : b.a.j.TextAppearance_android_fontFamily;
        int i2 = this.k;
        int i3 = this.j;
        if (!context.isRestricted()) {
            try {
                Typeface a2 = j0Var.a(i, this.j, new a(this, i2, i3));
                if (a2 != null) {
                    if (Build.VERSION.SDK_INT >= 28 && this.k != -1) {
                        a2 = Typeface.create(Typeface.create(a2, 0), this.k, (this.j & 2) != 0);
                    }
                    this.l = a2;
                }
                this.m = this.l == null;
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            }
        }
        if (this.l != null || (c2 = j0Var.c(i)) == null) {
            return;
        }
        if (Build.VERSION.SDK_INT < 28 || this.k == -1) {
            create = Typeface.create(c2, this.j);
        } else {
            create = Typeface.create(Typeface.create(c2, 0), this.k, (this.j & 2) != 0);
        }
        this.l = create;
    }

    public final void a(Drawable drawable, h0 h0Var) {
        if (drawable == null || h0Var == null) {
            return;
        }
        f.a(drawable, h0Var, this.f425a.getDrawableState());
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:102:0x0242  */
    /* JADX WARN: Removed duplicated region for block: B:105:0x0254  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x0265  */
    /* JADX WARN: Removed duplicated region for block: B:111:0x0276  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x02a0  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x02c3  */
    /* JADX WARN: Removed duplicated region for block: B:143:0x02fe  */
    /* JADX WARN: Removed duplicated region for block: B:153:0x034f  */
    /* JADX WARN: Removed duplicated region for block: B:156:0x035d  */
    /* JADX WARN: Removed duplicated region for block: B:159:0x036b  */
    /* JADX WARN: Removed duplicated region for block: B:162:0x0379  */
    /* JADX WARN: Removed duplicated region for block: B:165:0x0387  */
    /* JADX WARN: Removed duplicated region for block: B:168:0x0395  */
    /* JADX WARN: Removed duplicated region for block: B:178:0x0419  */
    /* JADX WARN: Removed duplicated region for block: B:191:0x0442  */
    /* JADX WARN: Removed duplicated region for block: B:203:0x0481  */
    /* JADX WARN: Removed duplicated region for block: B:205:0x0488  */
    /* JADX WARN: Removed duplicated region for block: B:207:0x048f  */
    /* JADX WARN: Removed duplicated region for block: B:209:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:233:0x03fb  */
    /* JADX WARN: Removed duplicated region for block: B:235:0x0401  */
    /* JADX WARN: Removed duplicated region for block: B:237:0x0407  */
    /* JADX WARN: Removed duplicated region for block: B:239:0x040c  */
    /* JADX WARN: Removed duplicated region for block: B:241:0x039a  */
    /* JADX WARN: Removed duplicated region for block: B:242:0x038c  */
    /* JADX WARN: Removed duplicated region for block: B:243:0x037e  */
    /* JADX WARN: Removed duplicated region for block: B:244:0x0370  */
    /* JADX WARN: Removed duplicated region for block: B:245:0x0362  */
    /* JADX WARN: Removed duplicated region for block: B:246:0x0354  */
    /* JADX WARN: Removed duplicated region for block: B:247:0x02f7  */
    /* JADX WARN: Removed duplicated region for block: B:248:0x027d  */
    /* JADX WARN: Removed duplicated region for block: B:249:0x026c  */
    /* JADX WARN: Removed duplicated region for block: B:250:0x025b  */
    @android.annotation.SuppressLint({"NewApi"})
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void a(android.util.AttributeSet r18, int r19) {
        /*
            Method dump skipped, instructions count: 1173
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.p.m.a(android.util.AttributeSet, int):void");
    }

    public boolean b() {
        o oVar = this.i;
        return oVar.d() && oVar.f446a != 0;
    }

    public void a(Context context, int i) {
        String c2;
        ColorStateList a2;
        j0 j0Var = new j0(context, context.obtainStyledAttributes(i, b.a.j.TextAppearance));
        if (j0Var.e(b.a.j.TextAppearance_textAllCaps)) {
            this.f425a.setAllCaps(j0Var.a(b.a.j.TextAppearance_textAllCaps, false));
        }
        if (Build.VERSION.SDK_INT < 23 && j0Var.e(b.a.j.TextAppearance_android_textColor) && (a2 = j0Var.a(b.a.j.TextAppearance_android_textColor)) != null) {
            this.f425a.setTextColor(a2);
        }
        if (j0Var.e(b.a.j.TextAppearance_android_textSize) && j0Var.b(b.a.j.TextAppearance_android_textSize, -1) == 0) {
            this.f425a.setTextSize(0, 0.0f);
        }
        a(context, j0Var);
        if (Build.VERSION.SDK_INT >= 26 && j0Var.e(b.a.j.TextAppearance_fontVariationSettings) && (c2 = j0Var.c(b.a.j.TextAppearance_fontVariationSettings)) != null) {
            this.f425a.setFontVariationSettings(c2);
        }
        j0Var.f415b.recycle();
        Typeface typeface = this.l;
        if (typeface != null) {
            this.f425a.setTypeface(typeface, this.j);
        }
    }

    public void a(int i, int i2, int i3, int i4) {
        o oVar = this.i;
        if (oVar.d()) {
            DisplayMetrics displayMetrics = oVar.j.getResources().getDisplayMetrics();
            oVar.a(TypedValue.applyDimension(i4, i, displayMetrics), TypedValue.applyDimension(i4, i2, displayMetrics), TypedValue.applyDimension(i4, i3, displayMetrics));
            if (oVar.b()) {
                oVar.a();
            }
        }
    }

    public void a(int[] iArr, int i) {
        o oVar = this.i;
        if (oVar.d()) {
            int length = iArr.length;
            if (length > 0) {
                int[] iArr2 = new int[length];
                if (i == 0) {
                    iArr2 = Arrays.copyOf(iArr, length);
                } else {
                    DisplayMetrics displayMetrics = oVar.j.getResources().getDisplayMetrics();
                    for (int i2 = 0; i2 < length; i2++) {
                        iArr2[i2] = Math.round(TypedValue.applyDimension(i, iArr[i2], displayMetrics));
                    }
                }
                oVar.f = oVar.a(iArr2);
                if (!oVar.c()) {
                    StringBuilder a2 = c.a.b.a.a.a("None of the preset sizes is valid: ");
                    a2.append(Arrays.toString(iArr));
                    throw new IllegalArgumentException(a2.toString());
                }
            } else {
                oVar.g = false;
            }
            if (oVar.b()) {
                oVar.a();
            }
        }
    }

    public void a(int i) {
        o oVar = this.i;
        if (oVar.d()) {
            if (i == 0) {
                oVar.f446a = 0;
                oVar.f449d = -1.0f;
                oVar.e = -1.0f;
                oVar.f448c = -1.0f;
                oVar.f = new int[0];
                oVar.f447b = false;
                return;
            }
            if (i != 1) {
                throw new IllegalArgumentException(c.a.b.a.a.a("Unknown auto-size text type: ", i));
            }
            DisplayMetrics displayMetrics = oVar.j.getResources().getDisplayMetrics();
            oVar.a(TypedValue.applyDimension(2, 12.0f, displayMetrics), TypedValue.applyDimension(2, 112.0f, displayMetrics), 1.0f);
            if (oVar.b()) {
                oVar.a();
            }
        }
    }
}
