package b.a.p;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.util.SparseBooleanArray;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import b.a.o.d.f;
import b.a.o.d.k;
import b.a.o.d.l;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class c extends b.a.o.d.b {
    public d j;
    public Drawable k;
    public boolean l;
    public boolean m;
    public boolean n;
    public int o;
    public int p;
    public int q;
    public boolean r;
    public int s;
    public final SparseBooleanArray t;
    public e u;
    public a v;
    public RunnableC0011c w;
    public b x;
    public final f y;
    public int z;

    /* loaded from: classes.dex */
    public class a extends b.a.o.d.j {
        public a(Context context, b.a.o.d.p pVar, View view) {
            super(context, pVar, view, false, b.a.a.actionOverflowMenuStyle, 0);
            if (!pVar.B.d()) {
                View view2 = c.this.j;
                this.f = view2 == null ? (View) c.this.i : view2;
            }
            a(c.this.y);
        }

        @Override // b.a.o.d.j
        public void c() {
            c cVar = c.this;
            cVar.v = null;
            cVar.z = 0;
            super.c();
        }
    }

    /* loaded from: classes.dex */
    public class b extends ActionMenuItemView.b {
        public b() {
        }
    }

    /* renamed from: b.a.p.c$c, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class RunnableC0011c implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public e f364b;

        public RunnableC0011c(e eVar) {
            this.f364b = eVar;
        }

        @Override // java.lang.Runnable
        public void run() {
            f.a aVar;
            b.a.o.d.f fVar = c.this.f305d;
            if (fVar != null && (aVar = fVar.e) != null) {
                aVar.a(fVar);
            }
            View view = (View) c.this.i;
            if (view != null && view.getWindowToken() != null && this.f364b.d()) {
                c.this.u = this.f364b;
            }
            c.this.w = null;
        }
    }

    /* loaded from: classes.dex */
    public class d extends j implements ActionMenuView.a {

        /* loaded from: classes.dex */
        public class a extends u {
            public a(View view, c cVar) {
                super(view);
            }

            @Override // b.a.p.u
            public b.a.o.d.n b() {
                e eVar = c.this.u;
                if (eVar == null) {
                    return null;
                }
                return eVar.a();
            }

            @Override // b.a.p.u
            public boolean c() {
                c.this.f();
                return true;
            }

            @Override // b.a.p.u
            public boolean d() {
                c cVar = c.this;
                if (cVar.w != null) {
                    return false;
                }
                cVar.c();
                return true;
            }
        }

        public d(Context context) {
            super(context, null, b.a.a.actionOverflowButtonStyle);
            setClickable(true);
            setFocusable(true);
            setVisibility(0);
            setEnabled(true);
            a.a.a.a.a.a(this, getContentDescription());
            setOnTouchListener(new a(this, c.this));
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean a() {
            return false;
        }

        @Override // androidx.appcompat.widget.ActionMenuView.a
        public boolean b() {
            return false;
        }

        @Override // android.view.View
        public boolean performClick() {
            if (super.performClick()) {
                return true;
            }
            playSoundEffect(0);
            c.this.f();
            return true;
        }

        @Override // android.widget.ImageView
        public boolean setFrame(int i, int i2, int i3, int i4) {
            boolean frame = super.setFrame(i, i2, i3, i4);
            Drawable drawable = getDrawable();
            Drawable background = getBackground();
            if (drawable != null && background != null) {
                int width = getWidth();
                int height = getHeight();
                int max = Math.max(width, height) / 2;
                int paddingLeft = (width + (getPaddingLeft() - getPaddingRight())) / 2;
                int paddingTop = (height + (getPaddingTop() - getPaddingBottom())) / 2;
                background.setHotspotBounds(paddingLeft - max, paddingTop - max, paddingLeft + max, paddingTop + max);
            }
            return frame;
        }
    }

    /* loaded from: classes.dex */
    public class e extends b.a.o.d.j {
        public e(Context context, b.a.o.d.f fVar, View view, boolean z) {
            super(context, fVar, view, z, b.a.a.actionOverflowMenuStyle, 0);
            this.g = 8388613;
            a(c.this.y);
        }

        @Override // b.a.o.d.j
        public void c() {
            b.a.o.d.f fVar = c.this.f305d;
            if (fVar != null) {
                fVar.a(true);
            }
            c.this.u = null;
            super.c();
        }
    }

    public c(Context context) {
        super(context, b.a.g.abc_action_menu_layout, b.a.g.abc_action_menu_item_layout);
        this.t = new SparseBooleanArray();
        this.y = new f();
    }

    @Override // b.a.o.d.b
    public View a(b.a.o.d.g gVar, View view, ViewGroup viewGroup) {
        View actionView = gVar.getActionView();
        if (actionView == null || gVar.c()) {
            actionView = super.a(gVar, view, viewGroup);
        }
        actionView.setVisibility(gVar.C ? 8 : 0);
        ActionMenuView actionMenuView = (ActionMenuView) viewGroup;
        ViewGroup.LayoutParams layoutParams = actionView.getLayoutParams();
        if (actionMenuView != null) {
            if (!(layoutParams instanceof ActionMenuView.c)) {
                actionView.setLayoutParams(actionMenuView.generateLayoutParams(layoutParams));
            }
            return actionView;
        }
        throw null;
    }

    public boolean a() {
        return c() | d();
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // b.a.o.d.k
    public boolean b() {
        ArrayList<b.a.o.d.g> arrayList;
        int i;
        int i2;
        boolean z;
        b.a.o.d.f fVar = this.f305d;
        View view = null;
        if (fVar != null) {
            arrayList = fVar.c();
            i = arrayList.size();
        } else {
            arrayList = null;
            i = 0;
        }
        int i3 = this.q;
        int i4 = this.p;
        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
        ViewGroup viewGroup = (ViewGroup) this.i;
        int i5 = 0;
        boolean z2 = false;
        int i6 = 0;
        int i7 = 0;
        while (true) {
            i2 = 2;
            z = 1;
            if (i5 >= i) {
                break;
            }
            b.a.o.d.g gVar = arrayList.get(i5);
            if ((gVar.y & 2) == 2) {
                i7++;
            } else if ((gVar.y & 1) == 1) {
                i6++;
            } else {
                z2 = true;
            }
            if (this.r && gVar.C) {
                i3 = 0;
            }
            i5++;
        }
        if (this.m && (z2 || i6 + i7 > i3)) {
            i3--;
        }
        int i8 = i3 - i7;
        SparseBooleanArray sparseBooleanArray = this.t;
        sparseBooleanArray.clear();
        int i9 = 0;
        int i10 = 0;
        while (i9 < i) {
            b.a.o.d.g gVar2 = arrayList.get(i9);
            if ((gVar2.y & i2) == i2) {
                View a2 = a(gVar2, view, viewGroup);
                a2.measure(makeMeasureSpec, makeMeasureSpec);
                int measuredWidth = a2.getMeasuredWidth();
                i4 -= measuredWidth;
                if (i10 == 0) {
                    i10 = measuredWidth;
                }
                int i11 = gVar2.f328b;
                if (i11 != 0) {
                    sparseBooleanArray.put(i11, z);
                }
                gVar2.b(z);
            } else if ((gVar2.y & z) == z) {
                int i12 = gVar2.f328b;
                boolean z3 = sparseBooleanArray.get(i12);
                boolean z4 = (i8 > 0 || z3) && i4 > 0;
                if (z4) {
                    View a3 = a(gVar2, view, viewGroup);
                    a3.measure(makeMeasureSpec, makeMeasureSpec);
                    int measuredWidth2 = a3.getMeasuredWidth();
                    i4 -= measuredWidth2;
                    if (i10 == 0) {
                        i10 = measuredWidth2;
                    }
                    z4 &= i4 + i10 > 0;
                }
                boolean z5 = z4;
                if (z5 && i12 != 0) {
                    sparseBooleanArray.put(i12, z);
                } else if (z3) {
                    sparseBooleanArray.put(i12, false);
                    for (int i13 = 0; i13 < i9; i13++) {
                        b.a.o.d.g gVar3 = arrayList.get(i13);
                        if (gVar3.f328b == i12) {
                            if (gVar3.d()) {
                                i8++;
                            }
                            gVar3.b(false);
                        }
                    }
                }
                if (z5) {
                    i8--;
                }
                gVar2.b(z5);
            } else {
                gVar2.b(false);
                i9++;
                view = null;
                i2 = 2;
                z = 1;
            }
            i9++;
            view = null;
            i2 = 2;
            z = 1;
        }
        return true;
    }

    public boolean c() {
        Object obj;
        RunnableC0011c runnableC0011c = this.w;
        if (runnableC0011c != null && (obj = this.i) != null) {
            ((View) obj).removeCallbacks(runnableC0011c);
            this.w = null;
            return true;
        }
        e eVar = this.u;
        if (eVar == null) {
            return false;
        }
        if (eVar.b()) {
            eVar.j.dismiss();
        }
        return true;
    }

    public boolean d() {
        a aVar = this.v;
        if (aVar == null) {
            return false;
        }
        if (!aVar.b()) {
            return true;
        }
        aVar.j.dismiss();
        return true;
    }

    public boolean e() {
        e eVar = this.u;
        return eVar != null && eVar.b();
    }

    public boolean f() {
        b.a.o.d.f fVar;
        if (!this.m || e() || (fVar = this.f305d) == null || this.i == null || this.w != null) {
            return false;
        }
        fVar.a();
        if (fVar.j.isEmpty()) {
            return false;
        }
        RunnableC0011c runnableC0011c = new RunnableC0011c(new e(this.f304c, this.f305d, this.j, true));
        this.w = runnableC0011c;
        ((View) this.i).post(runnableC0011c);
        super.a((b.a.o.d.p) null);
        return true;
    }

    /* loaded from: classes.dex */
    public class f implements k.a {
        public f() {
        }

        @Override // b.a.o.d.k.a
        public void a(b.a.o.d.f fVar, boolean z) {
            if (fVar instanceof b.a.o.d.p) {
                fVar.b().a(false);
            }
            k.a aVar = c.this.f;
            if (aVar != null) {
                aVar.a(fVar, z);
            }
        }

        @Override // b.a.o.d.k.a
        public boolean a(b.a.o.d.f fVar) {
            if (fVar == null) {
                return false;
            }
            c.this.z = ((b.a.o.d.p) fVar).B.getItemId();
            k.a aVar = c.this.f;
            if (aVar != null) {
                return aVar.a(fVar);
            }
            return false;
        }
    }

    @Override // b.a.o.d.k
    public void a(Context context, b.a.o.d.f fVar) {
        this.f304c = context;
        LayoutInflater.from(context);
        this.f305d = fVar;
        Resources resources = context.getResources();
        if (!this.n) {
            this.m = true;
        }
        int i = 2;
        this.o = context.getResources().getDisplayMetrics().widthPixels / 2;
        Configuration configuration = context.getResources().getConfiguration();
        int i2 = configuration.screenWidthDp;
        int i3 = configuration.screenHeightDp;
        if (configuration.smallestScreenWidthDp > 600 || i2 > 600 || ((i2 > 960 && i3 > 720) || (i2 > 720 && i3 > 960))) {
            i = 5;
        } else if (i2 >= 500 || ((i2 > 640 && i3 > 480) || (i2 > 480 && i3 > 640))) {
            i = 4;
        } else if (i2 >= 360) {
            i = 3;
        }
        this.q = i;
        int i4 = this.o;
        if (this.m) {
            if (this.j == null) {
                d dVar = new d(this.f303b);
                this.j = dVar;
                if (this.l) {
                    dVar.setImageDrawable(this.k);
                    this.k = null;
                    this.l = false;
                }
                int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                this.j.measure(makeMeasureSpec, makeMeasureSpec);
            }
            i4 -= this.j.getMeasuredWidth();
        } else {
            this.j = null;
        }
        this.p = i4;
        this.s = (int) (resources.getDisplayMetrics().density * 56.0f);
    }

    @Override // b.a.o.d.k
    public void a(b.a.o.d.f fVar, boolean z) {
        a();
        k.a aVar = this.f;
        if (aVar != null) {
            aVar.a(fVar, z);
        }
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // b.a.o.d.b, b.a.o.d.k
    public boolean a(b.a.o.d.p pVar) {
        boolean z = false;
        if (!pVar.hasVisibleItems()) {
            return false;
        }
        b.a.o.d.p pVar2 = pVar;
        while (true) {
            b.a.o.d.f fVar = pVar2.A;
            if (fVar == this.f305d) {
                break;
            }
            pVar2 = (b.a.o.d.p) fVar;
        }
        b.a.o.d.g gVar = pVar2.B;
        ViewGroup viewGroup = (ViewGroup) this.i;
        View view = null;
        if (viewGroup != null) {
            int childCount = viewGroup.getChildCount();
            int i = 0;
            while (true) {
                if (i >= childCount) {
                    break;
                }
                View childAt = viewGroup.getChildAt(i);
                if ((childAt instanceof l.a) && ((l.a) childAt).getItemData() == gVar) {
                    view = childAt;
                    break;
                }
                i++;
            }
        }
        if (view == null) {
            return false;
        }
        pVar.B.getItemId();
        int size = pVar.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            MenuItem item = pVar.getItem(i2);
            if (item.isVisible() && item.getIcon() != null) {
                z = true;
                break;
            }
            i2++;
        }
        a aVar = new a(this.f304c, pVar, view);
        this.v = aVar;
        aVar.h = z;
        b.a.o.d.i iVar = aVar.j;
        if (iVar != null) {
            iVar.b(z);
        }
        if (this.v.d()) {
            k.a aVar2 = this.f;
            if (aVar2 != null) {
                aVar2.a(pVar);
            }
            return true;
        }
        throw new IllegalStateException("MenuPopupHelper cannot be used without an anchor");
    }

    @Override // b.a.o.d.b, b.a.o.d.k
    public void a(boolean z) {
        ArrayList<b.a.o.d.g> arrayList;
        super.a(z);
        ((View) this.i).requestLayout();
        b.a.o.d.f fVar = this.f305d;
        boolean z2 = false;
        if (fVar != null) {
            fVar.a();
            ArrayList<b.a.o.d.g> arrayList2 = fVar.i;
            int size = arrayList2.size();
            for (int i = 0; i < size; i++) {
                b.d.k.b bVar = arrayList2.get(i).A;
            }
        }
        b.a.o.d.f fVar2 = this.f305d;
        if (fVar2 != null) {
            fVar2.a();
            arrayList = fVar2.j;
        } else {
            arrayList = null;
        }
        if (this.m && arrayList != null) {
            int size2 = arrayList.size();
            if (size2 == 1) {
                z2 = !arrayList.get(0).C;
            } else if (size2 > 0) {
                z2 = true;
            }
        }
        d dVar = this.j;
        if (z2) {
            if (dVar == null) {
                this.j = new d(this.f303b);
            }
            ViewGroup viewGroup = (ViewGroup) this.j.getParent();
            if (viewGroup != this.i) {
                if (viewGroup != null) {
                    viewGroup.removeView(this.j);
                }
                ActionMenuView actionMenuView = (ActionMenuView) this.i;
                d dVar2 = this.j;
                ActionMenuView.c generateDefaultLayoutParams = actionMenuView.generateDefaultLayoutParams();
                generateDefaultLayoutParams.f50c = true;
                actionMenuView.addView(dVar2, generateDefaultLayoutParams);
            }
        } else if (dVar != null) {
            Object parent = dVar.getParent();
            Object obj = this.i;
            if (parent == obj) {
                ((ViewGroup) obj).removeView(this.j);
            }
        }
        ((ActionMenuView) this.i).setOverflowReserved(this.m);
    }
}
