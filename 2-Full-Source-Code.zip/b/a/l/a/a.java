package b.a.l.a;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.Log;
import android.util.SparseArray;
import android.util.TypedValue;
import b.a.p.a0;
import java.util.WeakHashMap;

@SuppressLint({"RestrictedAPI"})
/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public static final ThreadLocal<TypedValue> f259a = new ThreadLocal<>();

    /* renamed from: b, reason: collision with root package name */
    public static final WeakHashMap<Context, SparseArray<C0005a>> f260b = new WeakHashMap<>(0);

    /* renamed from: c, reason: collision with root package name */
    public static final Object f261c = new Object();

    /* renamed from: b.a.l.a.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0005a {

        /* renamed from: a, reason: collision with root package name */
        public final ColorStateList f262a;

        /* renamed from: b, reason: collision with root package name */
        public final Configuration f263b;

        public C0005a(ColorStateList colorStateList, Configuration configuration) {
            this.f262a = colorStateList;
            this.f263b = configuration;
        }
    }

    public static ColorStateList a(Context context, int i) {
        C0005a c0005a;
        synchronized (f261c) {
            SparseArray<C0005a> sparseArray = f260b.get(context);
            if (sparseArray != null && sparseArray.size() > 0 && (c0005a = sparseArray.get(i)) != null) {
                if (c0005a.f263b.equals(context.getResources().getConfiguration())) {
                    return c0005a.f262a;
                }
                sparseArray.remove(i);
            }
            return null;
        }
    }

    public static void a(Context context, int i, ColorStateList colorStateList) {
        synchronized (f261c) {
            SparseArray<C0005a> sparseArray = f260b.get(context);
            if (sparseArray == null) {
                sparseArray = new SparseArray<>();
                f260b.put(context, sparseArray);
            }
            sparseArray.append(i, new C0005a(colorStateList, context.getResources().getConfiguration()));
        }
    }

    public static ColorStateList b(Context context, int i) {
        if (Build.VERSION.SDK_INT >= 23) {
            return context.getColorStateList(i);
        }
        ColorStateList a2 = a(context, i);
        if (a2 != null) {
            return a2;
        }
        Resources resources = context.getResources();
        TypedValue typedValue = f259a.get();
        if (typedValue == null) {
            typedValue = new TypedValue();
            f259a.set(typedValue);
        }
        resources.getValue(i, typedValue, true);
        int i2 = typedValue.type;
        boolean z = i2 >= 28 && i2 <= 31;
        ColorStateList colorStateList = null;
        if (!z) {
            Resources resources2 = context.getResources();
            try {
                colorStateList = a.a.a.a.a.a(resources2, resources2.getXml(i), context.getTheme());
            } catch (Exception e) {
                Log.e("AppCompatResources", "Failed to inflate ColorStateList, leaving it to the framework", e);
            }
        }
        if (colorStateList == null) {
            return b.d.e.a.a(context, i);
        }
        a(context, i, colorStateList);
        return colorStateList;
    }

    public static Drawable c(Context context, int i) {
        return a0.a().b(context, i);
    }
}
