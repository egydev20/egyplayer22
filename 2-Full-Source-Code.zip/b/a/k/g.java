package b.a.k;

import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import androidx.appcompat.widget.ActionBarContainer;
import androidx.appcompat.widget.ActionBarOverlayLayout;
import b.d.k.l;
import b.d.k.n;
import b.d.k.o;
import b.d.k.q;

/* loaded from: classes.dex */
public class g extends b.a.k.a implements ActionBarOverlayLayout.d {
    public static final Interpolator n = new AccelerateInterpolator();
    public static final Interpolator o = new DecelerateInterpolator();

    /* renamed from: a, reason: collision with root package name */
    public ActionBarOverlayLayout f254a;

    /* renamed from: b, reason: collision with root package name */
    public ActionBarContainer f255b;

    /* renamed from: c, reason: collision with root package name */
    public View f256c;

    /* renamed from: d, reason: collision with root package name */
    public int f257d;
    public boolean e;
    public boolean f;
    public boolean g;
    public boolean h;
    public b.a.o.c i;
    public boolean j;
    public final o k;
    public final o l;
    public final q m;

    /* loaded from: classes.dex */
    public class a implements q {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ g f258a;
    }

    public final void a(boolean z) {
        View view;
        View view2;
        View view3;
        if (!(this.g || !this.f)) {
            if (this.h) {
                this.h = false;
                b.a.o.c cVar = this.i;
                if (cVar != null) {
                    cVar.a();
                }
                if (this.f257d != 0 || (!this.j && !z)) {
                    this.k.a(null);
                    return;
                }
                this.f255b.setAlpha(1.0f);
                this.f255b.setTransitioning(true);
                b.a.o.c cVar2 = new b.a.o.c();
                float f = -this.f255b.getHeight();
                if (z) {
                    this.f255b.getLocationInWindow(new int[]{0, 0});
                    f -= r9[1];
                }
                n a2 = l.a(this.f255b);
                a2.a(f);
                a2.a(this.m);
                if (!cVar2.e) {
                    cVar2.f292a.add(a2);
                }
                if (this.e && (view = this.f256c) != null) {
                    n a3 = l.a(view);
                    a3.a(f);
                    if (!cVar2.e) {
                        cVar2.f292a.add(a3);
                    }
                }
                Interpolator interpolator = n;
                if (!cVar2.e) {
                    cVar2.f294c = interpolator;
                }
                if (!cVar2.e) {
                    cVar2.f293b = 250L;
                }
                o oVar = this.k;
                if (!cVar2.e) {
                    cVar2.f295d = oVar;
                }
                this.i = cVar2;
                cVar2.b();
                return;
            }
            return;
        }
        if (this.h) {
            return;
        }
        this.h = true;
        b.a.o.c cVar3 = this.i;
        if (cVar3 != null) {
            cVar3.a();
        }
        this.f255b.setVisibility(0);
        if (this.f257d == 0 && (this.j || z)) {
            this.f255b.setTranslationY(0.0f);
            float f2 = -this.f255b.getHeight();
            if (z) {
                this.f255b.getLocationInWindow(new int[]{0, 0});
                f2 -= r9[1];
            }
            this.f255b.setTranslationY(f2);
            b.a.o.c cVar4 = new b.a.o.c();
            n a4 = l.a(this.f255b);
            a4.a(0.0f);
            a4.a(this.m);
            if (!cVar4.e) {
                cVar4.f292a.add(a4);
            }
            if (this.e && (view3 = this.f256c) != null) {
                view3.setTranslationY(f2);
                n a5 = l.a(this.f256c);
                a5.a(0.0f);
                if (!cVar4.e) {
                    cVar4.f292a.add(a5);
                }
            }
            Interpolator interpolator2 = o;
            if (!cVar4.e) {
                cVar4.f294c = interpolator2;
            }
            if (!cVar4.e) {
                cVar4.f293b = 250L;
            }
            o oVar2 = this.l;
            if (!cVar4.e) {
                cVar4.f295d = oVar2;
            }
            this.i = cVar4;
            cVar4.b();
        } else {
            this.f255b.setAlpha(1.0f);
            this.f255b.setTranslationY(0.0f);
            if (this.e && (view2 = this.f256c) != null) {
                view2.setTranslationY(0.0f);
            }
            this.l.a(null);
        }
        ActionBarOverlayLayout actionBarOverlayLayout = this.f254a;
        if (actionBarOverlayLayout != null) {
            l.o(actionBarOverlayLayout);
        }
    }
}
