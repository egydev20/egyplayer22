package b.a.k;

import androidx.appcompat.widget.ContentFrameLayout;

/* loaded from: classes.dex */
public class f implements ContentFrameLayout.a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ d f253a;
}
