package b.a.k;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.ViewGroup;
import b.a.j;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: b.a.k.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0004a extends ViewGroup.MarginLayoutParams {

        /* renamed from: a, reason: collision with root package name */
        public int f244a;

        public C0004a(int i, int i2) {
            super(i, i2);
            this.f244a = 0;
            this.f244a = 8388627;
        }

        public C0004a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f244a = 0;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, j.ActionBarLayout);
            this.f244a = obtainStyledAttributes.getInt(j.ActionBarLayout_android_layout_gravity, 0);
            obtainStyledAttributes.recycle();
        }

        public C0004a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f244a = 0;
        }

        public C0004a(C0004a c0004a) {
            super((ViewGroup.MarginLayoutParams) c0004a);
            this.f244a = 0;
            this.f244a = c0004a.f244a;
        }
    }

    @Deprecated
    /* loaded from: classes.dex */
    public static abstract class b {
        public abstract void a();
    }
}
