package b.a.k;

import b.a.p.t;

/* loaded from: classes.dex */
public class e implements t {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ d f252a;
}
