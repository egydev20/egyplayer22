package b.a.k;

import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public abstract class c {

    /* renamed from: b, reason: collision with root package name */
    public static final b.c.c<WeakReference<c>> f247b = new b.c.c<>();

    /* renamed from: c, reason: collision with root package name */
    public static final Object f248c = new Object();
}
