package b.a.k;

import android.view.View;
import androidx.core.widget.NestedScrollView;

/* loaded from: classes.dex */
public class b implements NestedScrollView.b {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ View f245a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f246b;
}
