package b.a.k;

import android.R;
import android.content.res.Resources;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.Window;
import android.widget.PopupWindow;
import b.a.o.d.f;
import b.a.p.p;
import java.lang.Thread;
import java.util.Map;

/* loaded from: classes.dex */
public class d extends c implements f.a, LayoutInflater.Factory2 {
    public static final Map<Class<?>, Integer> h = new b.c.a();
    public static final boolean i;
    public static final int[] j;
    public static boolean k;
    public static final boolean l;

    /* renamed from: d, reason: collision with root package name */
    public Window f249d;
    public p e;
    public PopupWindow f;
    public Runnable g;

    /* loaded from: classes.dex */
    public static class a implements Thread.UncaughtExceptionHandler {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Thread.UncaughtExceptionHandler f250a;

        public a(Thread.UncaughtExceptionHandler uncaughtExceptionHandler) {
            this.f250a = uncaughtExceptionHandler;
        }

        @Override // java.lang.Thread.UncaughtExceptionHandler
        public void uncaughtException(Thread thread, Throwable th) {
            String message;
            boolean z = false;
            if ((th instanceof Resources.NotFoundException) && (message = th.getMessage()) != null && (message.contains("drawable") || message.contains("Drawable"))) {
                z = true;
            }
            if (!z) {
                this.f250a.uncaughtException(thread, th);
                return;
            }
            Resources.NotFoundException notFoundException = new Resources.NotFoundException(th.getMessage() + ". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
            notFoundException.initCause(th.getCause());
            notFoundException.setStackTrace(th.getStackTrace());
            this.f250a.uncaughtException(thread, notFoundException);
        }
    }

    /* loaded from: classes.dex */
    public static final class b {

        /* renamed from: a, reason: collision with root package name */
        public b.a.o.d.f f251a;
    }

    static {
        int i2 = Build.VERSION.SDK_INT;
        i = false;
        j = new int[]{R.attr.windowBackground};
        l = i2 <= 25;
        if (!i || k) {
            return;
        }
        Thread.setDefaultUncaughtExceptionHandler(new a(Thread.getDefaultUncaughtExceptionHandler()));
        k = true;
    }

    public b a(int i2) {
        throw null;
    }

    public void a() {
        throw null;
    }

    public int b(int i2) {
        throw null;
    }
}
