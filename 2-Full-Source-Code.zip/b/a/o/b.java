package b.a.o;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.PorterDuff;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import android.view.InflateException;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import b.a.j;
import b.a.o.d.g;
import b.a.o.d.h;
import b.a.p.j0;
import b.a.p.r;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

/* loaded from: classes.dex */
public class b extends MenuInflater {
    public static final Class<?>[] e;
    public static final Class<?>[] f;

    /* renamed from: a, reason: collision with root package name */
    public final Object[] f281a;

    /* renamed from: b, reason: collision with root package name */
    public final Object[] f282b;

    /* renamed from: c, reason: collision with root package name */
    public Context f283c;

    /* renamed from: d, reason: collision with root package name */
    public Object f284d;

    /* loaded from: classes.dex */
    public static class a implements MenuItem.OnMenuItemClickListener {

        /* renamed from: c, reason: collision with root package name */
        public static final Class<?>[] f285c = {MenuItem.class};

        /* renamed from: a, reason: collision with root package name */
        public Object f286a;

        /* renamed from: b, reason: collision with root package name */
        public Method f287b;

        public a(Object obj, String str) {
            this.f286a = obj;
            Class<?> cls = obj.getClass();
            try {
                this.f287b = cls.getMethod(str, f285c);
            } catch (Exception e) {
                InflateException inflateException = new InflateException("Couldn't resolve menu item onClick handler " + str + " in class " + cls.getName());
                inflateException.initCause(e);
                throw inflateException;
            }
        }

        @Override // android.view.MenuItem.OnMenuItemClickListener
        public boolean onMenuItemClick(MenuItem menuItem) {
            try {
                if (this.f287b.getReturnType() == Boolean.TYPE) {
                    return ((Boolean) this.f287b.invoke(this.f286a, menuItem)).booleanValue();
                }
                this.f287b.invoke(this.f286a, menuItem);
                return true;
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
        }
    }

    /* renamed from: b.a.o.b$b, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class C0008b {
        public b.d.k.b A;
        public CharSequence B;
        public CharSequence C;

        /* renamed from: a, reason: collision with root package name */
        public Menu f288a;
        public boolean h;
        public int i;
        public int j;
        public CharSequence k;
        public CharSequence l;
        public int m;
        public char n;
        public int o;
        public char p;
        public int q;
        public int r;
        public boolean s;
        public boolean t;
        public boolean u;
        public int v;
        public int w;
        public String x;
        public String y;
        public String z;
        public ColorStateList D = null;
        public PorterDuff.Mode E = null;

        /* renamed from: b, reason: collision with root package name */
        public int f289b = 0;

        /* renamed from: c, reason: collision with root package name */
        public int f290c = 0;

        /* renamed from: d, reason: collision with root package name */
        public int f291d = 0;
        public int e = 0;
        public boolean f = true;
        public boolean g = true;

        public C0008b(Menu menu) {
            this.f288a = menu;
        }

        public SubMenu a() {
            this.h = true;
            SubMenu addSubMenu = this.f288a.addSubMenu(this.f289b, this.i, this.j, this.k);
            a(addSubMenu.getItem());
            return addSubMenu;
        }

        public final <T> T a(String str, Class<?>[] clsArr, Object[] objArr) {
            try {
                Constructor<?> constructor = Class.forName(str, false, b.this.f283c.getClassLoader()).getConstructor(clsArr);
                constructor.setAccessible(true);
                return (T) constructor.newInstance(objArr);
            } catch (Exception e) {
                Log.w("SupportMenuInflater", "Cannot instantiate class: " + str, e);
                return null;
            }
        }

        public final void a(MenuItem menuItem) {
            boolean z = false;
            menuItem.setChecked(this.s).setVisible(this.t).setEnabled(this.u).setCheckable(this.r >= 1).setTitleCondensed(this.l).setIcon(this.m);
            int i = this.v;
            if (i >= 0) {
                menuItem.setShowAsAction(i);
            }
            if (this.z != null) {
                if (b.this.f283c.isRestricted()) {
                    throw new IllegalStateException("The android:onClick attribute cannot be used within a restricted context");
                }
                b bVar = b.this;
                if (bVar.f284d == null) {
                    bVar.f284d = bVar.a(bVar.f283c);
                }
                menuItem.setOnMenuItemClickListener(new a(bVar.f284d, this.z));
            }
            boolean z2 = menuItem instanceof g;
            if (z2) {
            }
            if (this.r >= 2) {
                if (z2) {
                    g gVar = (g) menuItem;
                    gVar.x = (gVar.x & (-5)) | 4;
                } else if (menuItem instanceof h) {
                    h hVar = (h) menuItem;
                    try {
                        if (hVar.e == null) {
                            hVar.e = hVar.f332d.getClass().getDeclaredMethod("setExclusiveCheckable", Boolean.TYPE);
                        }
                        hVar.e.invoke(hVar.f332d, true);
                    } catch (Exception e) {
                        Log.w("MenuItemWrapper", "Error while calling setExclusiveCheckable", e);
                    }
                }
            }
            String str = this.x;
            if (str != null) {
                menuItem.setActionView((View) a(str, b.e, b.this.f281a));
                z = true;
            }
            int i2 = this.w;
            if (i2 > 0) {
                if (z) {
                    Log.w("SupportMenuInflater", "Ignoring attribute 'itemActionViewLayout'. Action view already specified.");
                } else {
                    menuItem.setActionView(i2);
                }
            }
            b.d.k.b bVar2 = this.A;
            if (bVar2 != null) {
                if (menuItem instanceof b.d.g.a.b) {
                    ((b.d.g.a.b) menuItem).a(bVar2);
                } else {
                    Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
                }
            }
            CharSequence charSequence = this.B;
            boolean z3 = menuItem instanceof b.d.g.a.b;
            if (z3) {
                ((b.d.g.a.b) menuItem).setContentDescription(charSequence);
            } else if (Build.VERSION.SDK_INT >= 26) {
                menuItem.setContentDescription(charSequence);
            }
            CharSequence charSequence2 = this.C;
            if (z3) {
                ((b.d.g.a.b) menuItem).setTooltipText(charSequence2);
            } else if (Build.VERSION.SDK_INT >= 26) {
                menuItem.setTooltipText(charSequence2);
            }
            char c2 = this.n;
            int i3 = this.o;
            if (z3) {
                ((b.d.g.a.b) menuItem).setAlphabeticShortcut(c2, i3);
            } else if (Build.VERSION.SDK_INT >= 26) {
                menuItem.setAlphabeticShortcut(c2, i3);
            }
            char c3 = this.p;
            int i4 = this.q;
            if (z3) {
                ((b.d.g.a.b) menuItem).setNumericShortcut(c3, i4);
            } else if (Build.VERSION.SDK_INT >= 26) {
                menuItem.setNumericShortcut(c3, i4);
            }
            PorterDuff.Mode mode = this.E;
            if (mode != null) {
                if (z3) {
                    ((b.d.g.a.b) menuItem).setIconTintMode(mode);
                } else if (Build.VERSION.SDK_INT >= 26) {
                    menuItem.setIconTintMode(mode);
                }
            }
            ColorStateList colorStateList = this.D;
            if (colorStateList != null) {
                if (z3) {
                    ((b.d.g.a.b) menuItem).setIconTintList(colorStateList);
                } else if (Build.VERSION.SDK_INT >= 26) {
                    menuItem.setIconTintList(colorStateList);
                }
            }
        }
    }

    static {
        Class<?>[] clsArr = {Context.class};
        e = clsArr;
        f = clsArr;
    }

    public b(Context context) {
        super(context);
        this.f283c = context;
        Object[] objArr = {context};
        this.f281a = objArr;
        this.f282b = objArr;
    }

    public final Object a(Object obj) {
        return (!(obj instanceof Activity) && (obj instanceof ContextWrapper)) ? a(((ContextWrapper) obj).getBaseContext()) : obj;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public final void a(XmlPullParser xmlPullParser, AttributeSet attributeSet, Menu menu) {
        C0008b c0008b = new C0008b(menu);
        int eventType = xmlPullParser.getEventType();
        while (true) {
            if (eventType == 2) {
                String name = xmlPullParser.getName();
                if (!name.equals("menu")) {
                    throw new RuntimeException(c.a.b.a.a.a("Expecting menu, got ", name));
                }
                eventType = xmlPullParser.next();
            } else {
                eventType = xmlPullParser.next();
                if (eventType == 1) {
                    break;
                }
            }
        }
        boolean z = false;
        boolean z2 = false;
        String str = null;
        while (!z) {
            if (eventType == 1) {
                throw new RuntimeException("Unexpected end of document");
            }
            if (eventType != 2) {
                if (eventType == 3) {
                    String name2 = xmlPullParser.getName();
                    if (z2 && name2.equals(str)) {
                        str = null;
                        z2 = false;
                    } else if (name2.equals("group")) {
                        c0008b.f289b = 0;
                        c0008b.f290c = 0;
                        c0008b.f291d = 0;
                        c0008b.e = 0;
                        c0008b.f = true;
                        c0008b.g = true;
                    } else if (name2.equals("item")) {
                        if (!c0008b.h) {
                            b.d.k.b bVar = c0008b.A;
                            if (bVar != null && ((h.a) bVar).f333b.hasSubMenu()) {
                                c0008b.a();
                            } else {
                                c0008b.h = true;
                                c0008b.a(c0008b.f288a.add(c0008b.f289b, c0008b.i, c0008b.j, c0008b.k));
                            }
                        }
                    } else if (name2.equals("menu")) {
                        z = true;
                    }
                }
            } else if (!z2) {
                String name3 = xmlPullParser.getName();
                if (name3.equals("group")) {
                    TypedArray obtainStyledAttributes = b.this.f283c.obtainStyledAttributes(attributeSet, j.MenuGroup);
                    c0008b.f289b = obtainStyledAttributes.getResourceId(j.MenuGroup_android_id, 0);
                    c0008b.f290c = obtainStyledAttributes.getInt(j.MenuGroup_android_menuCategory, 0);
                    c0008b.f291d = obtainStyledAttributes.getInt(j.MenuGroup_android_orderInCategory, 0);
                    c0008b.e = obtainStyledAttributes.getInt(j.MenuGroup_android_checkableBehavior, 0);
                    c0008b.f = obtainStyledAttributes.getBoolean(j.MenuGroup_android_visible, true);
                    c0008b.g = obtainStyledAttributes.getBoolean(j.MenuGroup_android_enabled, true);
                    obtainStyledAttributes.recycle();
                } else if (name3.equals("item")) {
                    j0 a2 = j0.a(b.this.f283c, attributeSet, j.MenuItem);
                    c0008b.i = a2.e(j.MenuItem_android_id, 0);
                    c0008b.j = (a2.c(j.MenuItem_android_menuCategory, c0008b.f290c) & (-65536)) | (a2.c(j.MenuItem_android_orderInCategory, c0008b.f291d) & 65535);
                    c0008b.k = a2.d(j.MenuItem_android_title);
                    c0008b.l = a2.d(j.MenuItem_android_titleCondensed);
                    c0008b.m = a2.e(j.MenuItem_android_icon, 0);
                    String c2 = a2.c(j.MenuItem_android_alphabeticShortcut);
                    c0008b.n = c2 == null ? (char) 0 : c2.charAt(0);
                    c0008b.o = a2.c(j.MenuItem_alphabeticModifiers, 4096);
                    String c3 = a2.c(j.MenuItem_android_numericShortcut);
                    c0008b.p = c3 == null ? (char) 0 : c3.charAt(0);
                    c0008b.q = a2.c(j.MenuItem_numericModifiers, 4096);
                    c0008b.r = a2.e(j.MenuItem_android_checkable) ? a2.a(j.MenuItem_android_checkable, false) : c0008b.e;
                    c0008b.s = a2.a(j.MenuItem_android_checked, false);
                    c0008b.t = a2.a(j.MenuItem_android_visible, c0008b.f);
                    c0008b.u = a2.a(j.MenuItem_android_enabled, c0008b.g);
                    c0008b.v = a2.c(j.MenuItem_showAsAction, -1);
                    c0008b.z = a2.c(j.MenuItem_android_onClick);
                    c0008b.w = a2.e(j.MenuItem_actionLayout, 0);
                    c0008b.x = a2.c(j.MenuItem_actionViewClass);
                    String c4 = a2.c(j.MenuItem_actionProviderClass);
                    c0008b.y = c4;
                    boolean z3 = c4 != null;
                    if (z3 && c0008b.w == 0 && c0008b.x == null) {
                        c0008b.A = (b.d.k.b) c0008b.a(c0008b.y, f, b.this.f282b);
                    } else {
                        if (z3) {
                            Log.w("SupportMenuInflater", "Ignoring attribute 'actionProviderClass'. Action view already specified.");
                        }
                        c0008b.A = null;
                    }
                    c0008b.B = a2.d(j.MenuItem_contentDescription);
                    c0008b.C = a2.d(j.MenuItem_tooltipText);
                    if (a2.e(j.MenuItem_iconTintMode)) {
                        c0008b.E = r.a(a2.c(j.MenuItem_iconTintMode, -1), c0008b.E);
                    } else {
                        c0008b.E = null;
                    }
                    if (a2.e(j.MenuItem_iconTint)) {
                        c0008b.D = a2.a(j.MenuItem_iconTint);
                    } else {
                        c0008b.D = null;
                    }
                    a2.f415b.recycle();
                    c0008b.h = false;
                } else if (name3.equals("menu")) {
                    a(xmlPullParser, attributeSet, c0008b.a());
                } else {
                    z2 = true;
                    str = name3;
                }
            }
            eventType = xmlPullParser.next();
        }
    }

    @Override // android.view.MenuInflater
    public void inflate(int i, Menu menu) {
        if (!(menu instanceof b.d.g.a.a)) {
            super.inflate(i, menu);
            return;
        }
        XmlResourceParser xmlResourceParser = null;
        try {
            try {
                try {
                    xmlResourceParser = this.f283c.getResources().getLayout(i);
                    a(xmlResourceParser, Xml.asAttributeSet(xmlResourceParser), menu);
                    xmlResourceParser.close();
                } catch (XmlPullParserException e2) {
                    throw new InflateException("Error inflating menu XML", e2);
                }
            } catch (IOException e3) {
                throw new InflateException("Error inflating menu XML", e3);
            }
        } catch (Throwable th) {
            if (xmlResourceParser != null) {
                xmlResourceParser.close();
            }
            throw th;
        }
    }
}
