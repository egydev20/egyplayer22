package b.a.o;

import android.view.View;
import android.view.animation.Interpolator;
import b.d.k.n;
import b.d.k.o;
import b.d.k.p;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class c {

    /* renamed from: c, reason: collision with root package name */
    public Interpolator f294c;

    /* renamed from: d, reason: collision with root package name */
    public o f295d;
    public boolean e;

    /* renamed from: b, reason: collision with root package name */
    public long f293b = -1;
    public final p f = new a();

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList<n> f292a = new ArrayList<>();

    /* loaded from: classes.dex */
    public class a extends p {

        /* renamed from: a, reason: collision with root package name */
        public boolean f296a = false;

        /* renamed from: b, reason: collision with root package name */
        public int f297b = 0;

        public a() {
        }

        @Override // b.d.k.o
        public void a(View view) {
            int i = this.f297b + 1;
            this.f297b = i;
            if (i == c.this.f292a.size()) {
                o oVar = c.this.f295d;
                if (oVar != null) {
                    oVar.a(null);
                }
                this.f297b = 0;
                this.f296a = false;
                c.this.e = false;
            }
        }

        @Override // b.d.k.o
        public void b(View view) {
            if (this.f296a) {
                return;
            }
            this.f296a = true;
            o oVar = c.this.f295d;
            if (oVar != null) {
                oVar.b(null);
            }
        }
    }

    public void a() {
        if (this.e) {
            Iterator<n> it = this.f292a.iterator();
            while (it.hasNext()) {
                it.next().a();
            }
            this.e = false;
        }
    }

    public void b() {
        View view;
        if (this.e) {
            return;
        }
        Iterator<n> it = this.f292a.iterator();
        while (it.hasNext()) {
            n next = it.next();
            long j = this.f293b;
            if (j >= 0) {
                next.a(j);
            }
            Interpolator interpolator = this.f294c;
            if (interpolator != null && (view = next.f628a.get()) != null) {
                view.animate().setInterpolator(interpolator);
            }
            if (this.f295d != null) {
                next.a(this.f);
            }
            View view2 = next.f628a.get();
            if (view2 != null) {
                view2.animate().start();
            }
        }
        this.e = true;
    }
}
