package b.a.o.d;

/* loaded from: classes.dex */
public interface l {

    /* loaded from: classes.dex */
    public interface a {
        void a(g gVar, int i);

        boolean c();

        g getItemData();
    }
}
