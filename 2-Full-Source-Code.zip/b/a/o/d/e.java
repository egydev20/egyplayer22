package b.a.o.d;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import androidx.appcompat.view.menu.ListMenuItemView;
import b.a.o.d.l;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class e extends BaseAdapter {

    /* renamed from: b, reason: collision with root package name */
    public f f320b;

    /* renamed from: c, reason: collision with root package name */
    public int f321c = -1;

    /* renamed from: d, reason: collision with root package name */
    public boolean f322d;
    public final boolean e;
    public final LayoutInflater f;
    public final int g;

    public e(f fVar, LayoutInflater layoutInflater, boolean z, int i) {
        this.e = z;
        this.f = layoutInflater;
        this.f320b = fVar;
        this.g = i;
        a();
    }

    public void a() {
        f fVar = this.f320b;
        g gVar = fVar.w;
        if (gVar != null) {
            fVar.a();
            ArrayList<g> arrayList = fVar.j;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                if (arrayList.get(i) == gVar) {
                    this.f321c = i;
                    return;
                }
            }
        }
        this.f321c = -1;
    }

    @Override // android.widget.Adapter
    public int getCount() {
        ArrayList<g> c2;
        if (this.e) {
            f fVar = this.f320b;
            fVar.a();
            c2 = fVar.j;
        } else {
            c2 = this.f320b.c();
        }
        int i = this.f321c;
        int size = c2.size();
        return i < 0 ? size : size - 1;
    }

    @Override // android.widget.Adapter
    public g getItem(int i) {
        ArrayList<g> c2;
        if (this.e) {
            f fVar = this.f320b;
            fVar.a();
            c2 = fVar.j;
        } else {
            c2 = this.f320b.c();
        }
        int i2 = this.f321c;
        if (i2 >= 0 && i >= i2) {
            i++;
        }
        return c2.get(i);
    }

    @Override // android.widget.Adapter
    public long getItemId(int i) {
        return i;
    }

    @Override // android.widget.Adapter
    public View getView(int i, View view, ViewGroup viewGroup) {
        if (view == null) {
            view = this.f.inflate(this.g, viewGroup, false);
        }
        int i2 = getItem(i).f328b;
        int i3 = i - 1;
        ListMenuItemView listMenuItemView = (ListMenuItemView) view;
        listMenuItemView.setGroupDividerEnabled(this.f320b.d() && i2 != (i3 >= 0 ? getItem(i3).f328b : i2));
        l.a aVar = (l.a) view;
        if (this.f322d) {
            listMenuItemView.setForceShowIcon(true);
        }
        aVar.a(getItem(i), 0);
        return view;
    }

    @Override // android.widget.BaseAdapter
    public void notifyDataSetChanged() {
        a();
        super.notifyDataSetChanged();
    }
}
