package b.a.o.d;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.appcompat.view.menu.ActionMenuItemView;
import androidx.appcompat.widget.ActionMenuView;
import b.a.o.d.k;
import b.a.o.d.l;
import b.a.p.c;
import java.util.ArrayList;

/* loaded from: classes.dex */
public abstract class b implements k {

    /* renamed from: b, reason: collision with root package name */
    public Context f303b;

    /* renamed from: c, reason: collision with root package name */
    public Context f304c;

    /* renamed from: d, reason: collision with root package name */
    public f f305d;
    public LayoutInflater e;
    public k.a f;
    public int g;
    public int h;
    public l i;

    public b(Context context, int i, int i2) {
        this.f303b = context;
        this.e = LayoutInflater.from(context);
        this.g = i;
        this.h = i2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r4v0, types: [android.view.View] */
    /* JADX WARN: Type inference failed for: r4v4, types: [b.a.o.d.l$a] */
    /* JADX WARN: Type inference failed for: r4v7 */
    /* JADX WARN: Type inference failed for: r4v8 */
    public View a(g gVar, View view, ViewGroup viewGroup) {
        ActionMenuItemView actionMenuItemView = view instanceof l.a ? (l.a) view : (l.a) this.e.inflate(this.h, viewGroup, false);
        b.a.p.c cVar = (b.a.p.c) this;
        actionMenuItemView.a(gVar, 0);
        ActionMenuItemView actionMenuItemView2 = actionMenuItemView;
        actionMenuItemView2.setItemInvoker((ActionMenuView) cVar.i);
        if (cVar.x == null) {
            cVar.x = new c.b();
        }
        actionMenuItemView2.setPopupCallback(cVar.x);
        return actionMenuItemView;
    }

    @Override // b.a.o.d.k
    public void a(k.a aVar) {
        this.f = aVar;
    }

    @Override // b.a.o.d.k
    public boolean a(f fVar, g gVar) {
        return false;
    }

    @Override // b.a.o.d.k
    public boolean a(p pVar) {
        k.a aVar = this.f;
        if (aVar != null) {
            return aVar.a(pVar);
        }
        return false;
    }

    @Override // b.a.o.d.k
    public boolean b(f fVar, g gVar) {
        return false;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // b.a.o.d.k
    public void a(boolean z) {
        int i;
        boolean z2;
        ViewGroup viewGroup = (ViewGroup) this.i;
        if (viewGroup == null) {
            return;
        }
        f fVar = this.f305d;
        if (fVar != null) {
            fVar.a();
            ArrayList<g> c2 = this.f305d.c();
            int size = c2.size();
            i = 0;
            for (int i2 = 0; i2 < size; i2++) {
                g gVar = c2.get(i2);
                if (gVar.d()) {
                    View childAt = viewGroup.getChildAt(i);
                    g itemData = childAt instanceof l.a ? ((l.a) childAt).getItemData() : null;
                    View a2 = a(gVar, childAt, viewGroup);
                    if (gVar != itemData) {
                        a2.setPressed(false);
                        a2.jumpDrawablesToCurrentState();
                    }
                    if (a2 != childAt) {
                        ViewGroup viewGroup2 = (ViewGroup) a2.getParent();
                        if (viewGroup2 != null) {
                            viewGroup2.removeView(a2);
                        }
                        ((ViewGroup) this.i).addView(a2, i);
                    }
                    i++;
                }
            }
        } else {
            i = 0;
        }
        while (i < viewGroup.getChildCount()) {
            if (viewGroup.getChildAt(i) == ((b.a.p.c) this).j) {
                z2 = false;
            } else {
                viewGroup.removeViewAt(i);
                z2 = true;
            }
            if (!z2) {
                i++;
            }
        }
    }
}
