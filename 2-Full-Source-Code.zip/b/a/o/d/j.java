package b.a.o.d;

import android.content.Context;
import android.graphics.Point;
import android.graphics.Rect;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.PopupWindow;
import b.a.o.d.k;

/* loaded from: classes.dex */
public class j {

    /* renamed from: a, reason: collision with root package name */
    public final Context f342a;

    /* renamed from: b, reason: collision with root package name */
    public final f f343b;

    /* renamed from: c, reason: collision with root package name */
    public final boolean f344c;

    /* renamed from: d, reason: collision with root package name */
    public final int f345d;
    public final int e;
    public View f;
    public boolean h;
    public k.a i;
    public i j;
    public PopupWindow.OnDismissListener k;
    public int g = 8388611;
    public final PopupWindow.OnDismissListener l = new a();

    /* loaded from: classes.dex */
    public class a implements PopupWindow.OnDismissListener {
        public a() {
        }

        @Override // android.widget.PopupWindow.OnDismissListener
        public void onDismiss() {
            j.this.c();
        }
    }

    public j(Context context, f fVar, View view, boolean z, int i, int i2) {
        this.f342a = context;
        this.f343b = fVar;
        this.f = view;
        this.f344c = z;
        this.f345d = i;
        this.e = i2;
    }

    public i a() {
        if (this.j == null) {
            Display defaultDisplay = ((WindowManager) this.f342a.getSystemService("window")).getDefaultDisplay();
            Point point = new Point();
            defaultDisplay.getRealSize(point);
            i dVar = Math.min(point.x, point.y) >= this.f342a.getResources().getDimensionPixelSize(b.a.d.abc_cascading_menus_min_smallest_width) ? new d(this.f342a, this.f, this.f345d, this.e, this.f344c) : new o(this.f342a, this.f343b, this.f, this.f345d, this.e, this.f344c);
            dVar.a(this.f343b);
            dVar.a(this.l);
            dVar.a(this.f);
            dVar.a(this.i);
            dVar.b(this.h);
            dVar.a(this.g);
            this.j = dVar;
        }
        return this.j;
    }

    public void a(k.a aVar) {
        this.i = aVar;
        i iVar = this.j;
        if (iVar != null) {
            iVar.a(aVar);
        }
    }

    public boolean b() {
        i iVar = this.j;
        return iVar != null && iVar.c();
    }

    public void c() {
        this.j = null;
        PopupWindow.OnDismissListener onDismissListener = this.k;
        if (onDismissListener != null) {
            onDismissListener.onDismiss();
        }
    }

    public boolean d() {
        if (b()) {
            return true;
        }
        if (this.f == null) {
            return false;
        }
        a(0, 0, false, false);
        return true;
    }

    public final void a(int i, int i2, boolean z, boolean z2) {
        i a2 = a();
        a2.c(z2);
        if (z) {
            if ((Gravity.getAbsoluteGravity(this.g, b.d.k.l.g(this.f)) & 7) == 5) {
                i -= this.f.getWidth();
            }
            a2.b(i);
            a2.c(i2);
            int i3 = (int) ((this.f342a.getResources().getDisplayMetrics().density * 48.0f) / 2.0f);
            a2.f341b = new Rect(i - i3, i2 - i3, i + i3, i2 + i3);
        }
        a2.a();
    }
}
