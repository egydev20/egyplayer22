package b.a.o.d;

import android.content.Context;
import android.view.MenuItem;
import android.view.SubMenu;
import java.util.Map;

/* loaded from: classes.dex */
public abstract class c {

    /* renamed from: a, reason: collision with root package name */
    public final Context f306a;

    /* renamed from: b, reason: collision with root package name */
    public Map<b.d.g.a.b, MenuItem> f307b;

    /* renamed from: c, reason: collision with root package name */
    public Map<b.d.g.a.c, SubMenu> f308c;

    public c(Context context) {
        this.f306a = context;
    }

    public final MenuItem a(MenuItem menuItem) {
        if (!(menuItem instanceof b.d.g.a.b)) {
            return menuItem;
        }
        b.d.g.a.b bVar = (b.d.g.a.b) menuItem;
        if (this.f307b == null) {
            this.f307b = new b.c.a();
        }
        MenuItem menuItem2 = this.f307b.get(menuItem);
        if (menuItem2 != null) {
            return menuItem2;
        }
        h hVar = new h(this.f306a, bVar);
        this.f307b.put(bVar, hVar);
        return hVar;
    }

    public final SubMenu a(SubMenu subMenu) {
        if (!(subMenu instanceof b.d.g.a.c)) {
            return subMenu;
        }
        b.d.g.a.c cVar = (b.d.g.a.c) subMenu;
        if (this.f308c == null) {
            this.f308c = new b.c.a();
        }
        SubMenu subMenu2 = this.f308c.get(cVar);
        if (subMenu2 != null) {
            return subMenu2;
        }
        q qVar = new q(this.f306a, cVar);
        this.f308c.put(cVar, qVar);
        return qVar;
    }
}
