package b.a.o.d;

import android.widget.ListView;

/* loaded from: classes.dex */
public interface n {
    void a();

    boolean c();

    ListView d();

    void dismiss();
}
