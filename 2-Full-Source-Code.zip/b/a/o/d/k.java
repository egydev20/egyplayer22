package b.a.o.d;

import android.content.Context;

/* loaded from: classes.dex */
public interface k {

    /* loaded from: classes.dex */
    public interface a {
        void a(f fVar, boolean z);

        boolean a(f fVar);
    }

    void a(Context context, f fVar);

    void a(f fVar, boolean z);

    void a(a aVar);

    void a(boolean z);

    boolean a(f fVar, g gVar);

    boolean a(p pVar);

    boolean b();

    boolean b(f fVar, g gVar);
}
