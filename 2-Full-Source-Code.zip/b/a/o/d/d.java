package b.a.o.d;

import android.content.Context;
import android.content.res.Resources;
import android.os.Build;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewTreeObserver;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import b.a.o.d.k;
import b.a.p.y;
import b.a.p.z;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public final class d extends i implements k, View.OnKeyListener, PopupWindow.OnDismissListener {
    public static final int C = b.a.g.abc_cascading_menu_item_layout;
    public PopupWindow.OnDismissListener A;
    public boolean B;

    /* renamed from: c, reason: collision with root package name */
    public final Context f309c;

    /* renamed from: d, reason: collision with root package name */
    public final int f310d;
    public final int e;
    public final int f;
    public final boolean g;
    public final Handler h;
    public View p;
    public View q;
    public int r;
    public boolean s;
    public boolean t;
    public int u;
    public int v;
    public boolean x;
    public k.a y;
    public ViewTreeObserver z;
    public final List<f> i = new ArrayList();
    public final List<C0009d> j = new ArrayList();
    public final ViewTreeObserver.OnGlobalLayoutListener k = new a();
    public final View.OnAttachStateChangeListener l = new b();
    public final y m = new c();
    public int n = 0;
    public int o = 0;
    public boolean w = false;

    /* loaded from: classes.dex */
    public class a implements ViewTreeObserver.OnGlobalLayoutListener {
        public a() {
        }

        @Override // android.view.ViewTreeObserver.OnGlobalLayoutListener
        public void onGlobalLayout() {
            if (!d.this.c() || d.this.j.size() <= 0 || d.this.j.get(0).f317a.B) {
                return;
            }
            View view = d.this.q;
            if (view == null || !view.isShown()) {
                d.this.dismiss();
                return;
            }
            Iterator<C0009d> it = d.this.j.iterator();
            while (it.hasNext()) {
                it.next().f317a.a();
            }
        }
    }

    /* loaded from: classes.dex */
    public class b implements View.OnAttachStateChangeListener {
        public b() {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewAttachedToWindow(View view) {
        }

        @Override // android.view.View.OnAttachStateChangeListener
        public void onViewDetachedFromWindow(View view) {
            ViewTreeObserver viewTreeObserver = d.this.z;
            if (viewTreeObserver != null) {
                if (!viewTreeObserver.isAlive()) {
                    d.this.z = view.getViewTreeObserver();
                }
                d dVar = d.this;
                dVar.z.removeGlobalOnLayoutListener(dVar.k);
            }
            view.removeOnAttachStateChangeListener(this);
        }
    }

    /* loaded from: classes.dex */
    public class c implements y {

        /* loaded from: classes.dex */
        public class a implements Runnable {

            /* renamed from: b, reason: collision with root package name */
            public final /* synthetic */ C0009d f314b;

            /* renamed from: c, reason: collision with root package name */
            public final /* synthetic */ MenuItem f315c;

            /* renamed from: d, reason: collision with root package name */
            public final /* synthetic */ f f316d;

            public a(C0009d c0009d, MenuItem menuItem, f fVar) {
                this.f314b = c0009d;
                this.f315c = menuItem;
                this.f316d = fVar;
            }

            @Override // java.lang.Runnable
            public void run() {
                C0009d c0009d = this.f314b;
                if (c0009d != null) {
                    d.this.B = true;
                    c0009d.f318b.a(false);
                    d.this.B = false;
                }
                if (this.f315c.isEnabled() && this.f315c.hasSubMenu()) {
                    this.f316d.a(this.f315c, 4);
                }
            }
        }

        public c() {
        }

        @Override // b.a.p.y
        public void a(f fVar, MenuItem menuItem) {
            d.this.h.removeCallbacksAndMessages(null);
            int size = d.this.j.size();
            int i = 0;
            while (true) {
                if (i >= size) {
                    i = -1;
                    break;
                } else if (fVar == d.this.j.get(i).f318b) {
                    break;
                } else {
                    i++;
                }
            }
            if (i == -1) {
                return;
            }
            int i2 = i + 1;
            d.this.h.postAtTime(new a(i2 < d.this.j.size() ? d.this.j.get(i2) : null, menuItem, fVar), fVar, SystemClock.uptimeMillis() + 200);
        }

        @Override // b.a.p.y
        public void b(f fVar, MenuItem menuItem) {
            d.this.h.removeCallbacksAndMessages(fVar);
        }
    }

    /* renamed from: b.a.o.d.d$d, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0009d {

        /* renamed from: a, reason: collision with root package name */
        public final z f317a;

        /* renamed from: b, reason: collision with root package name */
        public final f f318b;

        /* renamed from: c, reason: collision with root package name */
        public final int f319c;

        public C0009d(z zVar, f fVar, int i) {
            this.f317a = zVar;
            this.f318b = fVar;
            this.f319c = i;
        }
    }

    public d(Context context, View view, int i, int i2, boolean z) {
        this.f309c = context;
        this.p = view;
        this.e = i;
        this.f = i2;
        this.g = z;
        this.r = b.d.k.l.g(view) != 1 ? 1 : 0;
        Resources resources = context.getResources();
        this.f310d = Math.max(resources.getDisplayMetrics().widthPixels / 2, resources.getDimensionPixelSize(b.a.d.abc_config_prefDialogWidth));
        this.h = new Handler();
    }

    @Override // b.a.o.d.n
    public void a() {
        if (c()) {
            return;
        }
        Iterator<f> it = this.i.iterator();
        while (it.hasNext()) {
            c(it.next());
        }
        this.i.clear();
        View view = this.p;
        this.q = view;
        if (view != null) {
            boolean z = this.z == null;
            ViewTreeObserver viewTreeObserver = this.q.getViewTreeObserver();
            this.z = viewTreeObserver;
            if (z) {
                viewTreeObserver.addOnGlobalLayoutListener(this.k);
            }
            this.q.addOnAttachStateChangeListener(this.l);
        }
    }

    @Override // b.a.o.d.i
    public void a(PopupWindow.OnDismissListener onDismissListener) {
        this.A = onDismissListener;
    }

    @Override // b.a.o.d.i
    public void a(f fVar) {
        fVar.a(this, this.f309c);
        if (c()) {
            c(fVar);
        } else {
            this.i.add(fVar);
        }
    }

    @Override // b.a.o.d.k
    public void a(f fVar, boolean z) {
        int i;
        int size = this.j.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (fVar == this.j.get(i2).f318b) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 < 0) {
            return;
        }
        int i3 = i2 + 1;
        if (i3 < this.j.size()) {
            this.j.get(i3).f318b.a(false);
        }
        C0009d remove = this.j.remove(i2);
        remove.f318b.a(this);
        if (this.B) {
            z zVar = remove.f317a;
            if (zVar != null) {
                if (Build.VERSION.SDK_INT >= 23) {
                    zVar.C.setExitTransition(null);
                }
                remove.f317a.C.setAnimationStyle(0);
            } else {
                throw null;
            }
        }
        remove.f317a.dismiss();
        int size2 = this.j.size();
        if (size2 > 0) {
            i = this.j.get(size2 - 1).f319c;
        } else {
            i = b.d.k.l.g(this.p) == 1 ? 0 : 1;
        }
        this.r = i;
        if (size2 != 0) {
            if (z) {
                this.j.get(0).f318b.a(false);
                return;
            }
            return;
        }
        dismiss();
        k.a aVar = this.y;
        if (aVar != null) {
            aVar.a(fVar, true);
        }
        ViewTreeObserver viewTreeObserver = this.z;
        if (viewTreeObserver != null) {
            if (viewTreeObserver.isAlive()) {
                this.z.removeGlobalOnLayoutListener(this.k);
            }
            this.z = null;
        }
        this.q.removeOnAttachStateChangeListener(this.l);
        this.A.onDismiss();
    }

    @Override // b.a.o.d.k
    public void a(k.a aVar) {
        this.y = aVar;
    }

    @Override // b.a.o.d.i
    public void b(int i) {
        this.s = true;
        this.u = i;
    }

    @Override // b.a.o.d.i
    public void b(boolean z) {
        this.w = z;
    }

    @Override // b.a.o.d.k
    public boolean b() {
        return false;
    }

    @Override // b.a.o.d.i
    public void c(int i) {
        this.t = true;
        this.v = i;
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x00e9  */
    /* JADX WARN: Removed duplicated region for block: B:88:0x01b8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void c(b.a.o.d.f r17) {
        /*
            Method dump skipped, instructions count: 533
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.o.d.d.c(b.a.o.d.f):void");
    }

    @Override // b.a.o.d.i
    public void c(boolean z) {
        this.x = z;
    }

    @Override // b.a.o.d.n
    public boolean c() {
        return this.j.size() > 0 && this.j.get(0).f317a.c();
    }

    @Override // b.a.o.d.n
    public ListView d() {
        if (this.j.isEmpty()) {
            return null;
        }
        return this.j.get(r0.size() - 1).f317a.f471d;
    }

    @Override // b.a.o.d.n
    public void dismiss() {
        int size = this.j.size();
        if (size > 0) {
            C0009d[] c0009dArr = (C0009d[]) this.j.toArray(new C0009d[size]);
            for (int i = size - 1; i >= 0; i--) {
                C0009d c0009d = c0009dArr[i];
                if (c0009d.f317a.c()) {
                    c0009d.f317a.dismiss();
                }
            }
        }
    }

    @Override // b.a.o.d.i
    public boolean e() {
        return false;
    }

    @Override // android.widget.PopupWindow.OnDismissListener
    public void onDismiss() {
        C0009d c0009d;
        int size = this.j.size();
        int i = 0;
        while (true) {
            if (i >= size) {
                c0009d = null;
                break;
            }
            c0009d = this.j.get(i);
            if (!c0009d.f317a.c()) {
                break;
            } else {
                i++;
            }
        }
        if (c0009d != null) {
            c0009d.f318b.a(false);
        }
    }

    @Override // android.view.View.OnKeyListener
    public boolean onKey(View view, int i, KeyEvent keyEvent) {
        if (keyEvent.getAction() != 1 || i != 82) {
            return false;
        }
        dismiss();
        return true;
    }

    @Override // b.a.o.d.k
    public boolean a(p pVar) {
        for (C0009d c0009d : this.j) {
            if (pVar == c0009d.f318b) {
                c0009d.f317a.f471d.requestFocus();
                return true;
            }
        }
        if (!pVar.hasVisibleItems()) {
            return false;
        }
        pVar.a(this, this.f309c);
        if (c()) {
            c(pVar);
        } else {
            this.i.add(pVar);
        }
        k.a aVar = this.y;
        if (aVar != null) {
            aVar.a(pVar);
        }
        return true;
    }

    @Override // b.a.o.d.i
    public void a(View view) {
        if (this.p != view) {
            this.p = view;
            this.o = Gravity.getAbsoluteGravity(this.n, b.d.k.l.g(view));
        }
    }

    @Override // b.a.o.d.i
    public void a(int i) {
        if (this.n != i) {
            this.n = i;
            this.o = Gravity.getAbsoluteGravity(i, b.d.k.l.g(this.p));
        }
    }

    @Override // b.a.o.d.k
    public void a(boolean z) {
        Iterator<C0009d> it = this.j.iterator();
        while (it.hasNext()) {
            ListAdapter adapter = it.next().f317a.f471d.getAdapter();
            if (adapter instanceof HeaderViewListAdapter) {
                adapter = ((HeaderViewListAdapter) adapter).getWrappedAdapter();
            }
            ((e) adapter).notifyDataSetChanged();
        }
    }
}
