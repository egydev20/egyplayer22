package b.a.o.d;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.view.ViewConfiguration;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/* loaded from: classes.dex */
public class f implements b.d.g.a.a {
    public static final int[] z = {1, 4, 5, 3, 2, 0};

    /* renamed from: a, reason: collision with root package name */
    public final Context f323a;

    /* renamed from: b, reason: collision with root package name */
    public final Resources f324b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f325c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f326d;
    public a e;
    public CharSequence m;
    public Drawable n;
    public View o;
    public g w;
    public boolean y;
    public int l = 0;
    public boolean p = false;
    public boolean q = false;
    public boolean r = false;
    public boolean s = false;
    public boolean t = false;
    public ArrayList<g> u = new ArrayList<>();
    public CopyOnWriteArrayList<WeakReference<k>> v = new CopyOnWriteArrayList<>();
    public boolean x = false;
    public ArrayList<g> f = new ArrayList<>();
    public ArrayList<g> g = new ArrayList<>();
    public boolean h = true;
    public ArrayList<g> i = new ArrayList<>();
    public ArrayList<g> j = new ArrayList<>();
    public boolean k = true;

    /* loaded from: classes.dex */
    public interface a {
        void a(f fVar);

        boolean a(f fVar, MenuItem menuItem);
    }

    /* loaded from: classes.dex */
    public interface b {
        boolean a(g gVar);
    }

    public f(Context context) {
        boolean z2 = false;
        this.f323a = context;
        this.f324b = context.getResources();
        if (this.f324b.getConfiguration().keyboard != 1 && b.d.k.m.c(ViewConfiguration.get(this.f323a), this.f323a)) {
            z2 = true;
        }
        this.f326d = z2;
    }

    public MenuItem a(int i, int i2, int i3, CharSequence charSequence) {
        int i4;
        int i5 = ((-65536) & i3) >> 16;
        if (i5 >= 0) {
            int[] iArr = z;
            if (i5 < iArr.length) {
                int i6 = (iArr[i5] << 16) | (65535 & i3);
                g gVar = new g(this, i, i2, i3, i6, charSequence, this.l);
                ArrayList<g> arrayList = this.f;
                int size = arrayList.size();
                while (true) {
                    size--;
                    if (size < 0) {
                        i4 = 0;
                        break;
                    }
                    if (arrayList.get(size).f330d <= i6) {
                        i4 = size + 1;
                        break;
                    }
                }
                arrayList.add(i4, gVar);
                b(true);
                return gVar;
            }
        }
        throw new IllegalArgumentException("order does not contain a valid category.");
    }

    public void a() {
        ArrayList<g> c2 = c();
        if (this.k) {
            Iterator<WeakReference<k>> it = this.v.iterator();
            boolean z2 = false;
            while (it.hasNext()) {
                WeakReference<k> next = it.next();
                k kVar = next.get();
                if (kVar == null) {
                    this.v.remove(next);
                } else {
                    z2 |= kVar.b();
                }
            }
            if (z2) {
                this.i.clear();
                this.j.clear();
                int size = c2.size();
                for (int i = 0; i < size; i++) {
                    g gVar = c2.get(i);
                    (gVar.d() ? this.i : this.j).add(gVar);
                }
            } else {
                this.i.clear();
                this.j.clear();
                this.j.addAll(c());
            }
            this.k = false;
        }
    }

    public final void a(int i, boolean z2) {
        if (i < 0 || i >= this.f.size()) {
            return;
        }
        this.f.remove(i);
        if (z2) {
            b(true);
        }
    }

    public void a(k kVar) {
        Iterator<WeakReference<k>> it = this.v.iterator();
        while (it.hasNext()) {
            WeakReference<k> next = it.next();
            k kVar2 = next.get();
            if (kVar2 == null || kVar2 == kVar) {
                this.v.remove(next);
            }
        }
    }

    public void a(k kVar, Context context) {
        this.v.add(new WeakReference<>(kVar));
        kVar.a(context, this);
        this.k = true;
    }

    public final void a(boolean z2) {
        if (this.t) {
            return;
        }
        this.t = true;
        Iterator<WeakReference<k>> it = this.v.iterator();
        while (it.hasNext()) {
            WeakReference<k> next = it.next();
            k kVar = next.get();
            if (kVar == null) {
                this.v.remove(next);
            } else {
                kVar.a(this, z2);
            }
        }
        this.t = false;
    }

    public boolean a(MenuItem menuItem, int i) {
        return a(menuItem, (k) null, i);
    }

    public boolean a(f fVar, MenuItem menuItem) {
        a aVar = this.e;
        return aVar != null && aVar.a(fVar, menuItem);
    }

    public boolean a(g gVar) {
        boolean z2 = false;
        if (!this.v.isEmpty() && this.w == gVar) {
            i();
            Iterator<WeakReference<k>> it = this.v.iterator();
            while (it.hasNext()) {
                WeakReference<k> next = it.next();
                k kVar = next.get();
                if (kVar == null) {
                    this.v.remove(next);
                } else {
                    z2 = kVar.a(this, gVar);
                    if (z2) {
                        break;
                    }
                }
            }
            h();
            if (z2) {
                this.w = null;
            }
        }
        return z2;
    }

    @Override // android.view.Menu
    public MenuItem add(int i) {
        return a(0, 0, 0, this.f324b.getString(i));
    }

    @Override // android.view.Menu
    public MenuItem add(int i, int i2, int i3, int i4) {
        return a(i, i2, i3, this.f324b.getString(i4));
    }

    @Override // android.view.Menu
    public MenuItem add(int i, int i2, int i3, CharSequence charSequence) {
        return a(i, i2, i3, charSequence);
    }

    @Override // android.view.Menu
    public MenuItem add(CharSequence charSequence) {
        return a(0, 0, 0, charSequence);
    }

    @Override // android.view.Menu
    public int addIntentOptions(int i, int i2, int i3, ComponentName componentName, Intent[] intentArr, Intent intent, int i4, MenuItem[] menuItemArr) {
        int i5;
        PackageManager packageManager = this.f323a.getPackageManager();
        List<ResolveInfo> queryIntentActivityOptions = packageManager.queryIntentActivityOptions(componentName, intentArr, intent, 0);
        int size = queryIntentActivityOptions != null ? queryIntentActivityOptions.size() : 0;
        if ((i4 & 1) == 0) {
            removeGroup(i);
        }
        for (int i6 = 0; i6 < size; i6++) {
            ResolveInfo resolveInfo = queryIntentActivityOptions.get(i6);
            int i7 = resolveInfo.specificIndex;
            Intent intent2 = new Intent(i7 < 0 ? intent : intentArr[i7]);
            ActivityInfo activityInfo = resolveInfo.activityInfo;
            intent2.setComponent(new ComponentName(activityInfo.applicationInfo.packageName, activityInfo.name));
            MenuItem intent3 = a(i, i2, i3, resolveInfo.loadLabel(packageManager)).setIcon(resolveInfo.loadIcon(packageManager)).setIntent(intent2);
            if (menuItemArr != null && (i5 = resolveInfo.specificIndex) >= 0) {
                menuItemArr[i5] = intent3;
            }
        }
        return size;
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(int i) {
        return addSubMenu(0, 0, 0, this.f324b.getString(i));
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(int i, int i2, int i3, int i4) {
        return addSubMenu(i, i2, i3, this.f324b.getString(i4));
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(int i, int i2, int i3, CharSequence charSequence) {
        g gVar = (g) a(i, i2, i3, charSequence);
        p pVar = new p(this.f323a, this, gVar);
        gVar.o = pVar;
        pVar.setHeaderTitle(gVar.e);
        return pVar;
    }

    @Override // android.view.Menu
    public SubMenu addSubMenu(CharSequence charSequence) {
        return addSubMenu(0, 0, 0, charSequence);
    }

    public f b() {
        return this;
    }

    public void b(boolean z2) {
        if (!this.p) {
            if (z2) {
                this.h = true;
                this.k = true;
            }
            if (this.v.isEmpty()) {
                return;
            }
            i();
            Iterator<WeakReference<k>> it = this.v.iterator();
            while (it.hasNext()) {
                WeakReference<k> next = it.next();
                k kVar = next.get();
                if (kVar == null) {
                    this.v.remove(next);
                } else {
                    kVar.a(z2);
                }
            }
            h();
            return;
        }
        this.q = true;
        if (z2) {
            this.r = true;
        }
    }

    public boolean b(g gVar) {
        boolean z2 = false;
        if (this.v.isEmpty()) {
            return false;
        }
        i();
        Iterator<WeakReference<k>> it = this.v.iterator();
        while (it.hasNext()) {
            WeakReference<k> next = it.next();
            k kVar = next.get();
            if (kVar == null) {
                this.v.remove(next);
            } else {
                z2 = kVar.b(this, gVar);
                if (z2) {
                    break;
                }
            }
        }
        h();
        if (z2) {
            this.w = gVar;
        }
        return z2;
    }

    public ArrayList<g> c() {
        if (!this.h) {
            return this.g;
        }
        this.g.clear();
        int size = this.f.size();
        for (int i = 0; i < size; i++) {
            g gVar = this.f.get(i);
            if (gVar.isVisible()) {
                this.g.add(gVar);
            }
        }
        this.h = false;
        this.k = true;
        return this.g;
    }

    @Override // android.view.Menu
    public void clear() {
        g gVar = this.w;
        if (gVar != null) {
            a(gVar);
        }
        this.f.clear();
        b(true);
    }

    public void clearHeader() {
        this.n = null;
        this.m = null;
        this.o = null;
        b(false);
    }

    @Override // android.view.Menu
    public void close() {
        a(true);
    }

    public boolean d() {
        return this.x;
    }

    public boolean e() {
        return this.f325c;
    }

    public boolean f() {
        return this.f326d;
    }

    @Override // android.view.Menu
    public MenuItem findItem(int i) {
        MenuItem findItem;
        int size = size();
        for (int i2 = 0; i2 < size; i2++) {
            g gVar = this.f.get(i2);
            if (gVar.f327a == i) {
                return gVar;
            }
            if (gVar.hasSubMenu() && (findItem = gVar.o.findItem(i)) != null) {
                return findItem;
            }
        }
        return null;
    }

    public void g() {
        this.k = true;
        b(true);
    }

    @Override // android.view.Menu
    public MenuItem getItem(int i) {
        return this.f.get(i);
    }

    public void h() {
        this.p = false;
        if (this.q) {
            this.q = false;
            b(this.r);
        }
    }

    @Override // android.view.Menu
    public boolean hasVisibleItems() {
        if (this.y) {
            return true;
        }
        int size = size();
        for (int i = 0; i < size; i++) {
            if (this.f.get(i).isVisible()) {
                return true;
            }
        }
        return false;
    }

    public void i() {
        if (this.p) {
            return;
        }
        this.p = true;
        this.q = false;
        this.r = false;
    }

    @Override // android.view.Menu
    public boolean isShortcutKey(int i, KeyEvent keyEvent) {
        return a(i, keyEvent) != null;
    }

    @Override // android.view.Menu
    public boolean performIdentifierAction(int i, int i2) {
        return a(findItem(i), i2);
    }

    @Override // android.view.Menu
    public boolean performShortcut(int i, KeyEvent keyEvent, int i2) {
        g a2 = a(i, keyEvent);
        boolean a3 = a2 != null ? a(a2, (k) null, i2) : false;
        if ((i2 & 2) != 0) {
            a(true);
        }
        return a3;
    }

    @Override // android.view.Menu
    public void removeGroup(int i) {
        int size = size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (this.f.get(i2).f328b == i) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 >= 0) {
            int size2 = this.f.size() - i2;
            int i3 = 0;
            while (true) {
                int i4 = i3 + 1;
                if (i3 >= size2 || this.f.get(i2).f328b != i) {
                    break;
                }
                a(i2, false);
                i3 = i4;
            }
            b(true);
        }
    }

    @Override // android.view.Menu
    public void removeItem(int i) {
        int size = size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                i2 = -1;
                break;
            } else if (this.f.get(i2).f327a == i) {
                break;
            } else {
                i2++;
            }
        }
        a(i2, true);
    }

    @Override // android.view.Menu
    public void setGroupCheckable(int i, boolean z2, boolean z3) {
        int size = this.f.size();
        for (int i2 = 0; i2 < size; i2++) {
            g gVar = this.f.get(i2);
            if (gVar.f328b == i) {
                gVar.x = (gVar.x & (-5)) | (z3 ? 4 : 0);
                gVar.setCheckable(z2);
            }
        }
    }

    @Override // android.view.Menu
    public void setGroupDividerEnabled(boolean z2) {
        this.x = z2;
    }

    @Override // android.view.Menu
    public void setGroupEnabled(int i, boolean z2) {
        int size = this.f.size();
        for (int i2 = 0; i2 < size; i2++) {
            g gVar = this.f.get(i2);
            if (gVar.f328b == i) {
                gVar.setEnabled(z2);
            }
        }
    }

    @Override // android.view.Menu
    public void setGroupVisible(int i, boolean z2) {
        int size = this.f.size();
        boolean z3 = false;
        for (int i2 = 0; i2 < size; i2++) {
            g gVar = this.f.get(i2);
            if (gVar.f328b == i && gVar.c(z2)) {
                z3 = true;
            }
        }
        if (z3) {
            b(true);
        }
    }

    @Override // android.view.Menu
    public void setQwertyMode(boolean z2) {
        this.f325c = z2;
        b(false);
    }

    @Override // android.view.Menu
    public int size() {
        return this.f.size();
    }

    public g a(int i, KeyEvent keyEvent) {
        char c2;
        ArrayList<g> arrayList = this.u;
        arrayList.clear();
        a(arrayList, i, keyEvent);
        if (arrayList.isEmpty()) {
            return null;
        }
        int metaState = keyEvent.getMetaState();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        keyEvent.getKeyData(keyData);
        int size = arrayList.size();
        if (size == 1) {
            return arrayList.get(0);
        }
        boolean e = e();
        for (int i2 = 0; i2 < size; i2++) {
            g gVar = arrayList.get(i2);
            if (e) {
                c2 = gVar.j;
            } else {
                c2 = gVar.h;
            }
            if ((c2 == keyData.meta[0] && (metaState & 2) == 0) || ((c2 == keyData.meta[2] && (metaState & 2) != 0) || (e && c2 == '\b' && i == 67))) {
                return gVar;
            }
        }
        return null;
    }

    public void a(List<g> list, int i, KeyEvent keyEvent) {
        char c2;
        int i2;
        boolean e = e();
        int modifiers = keyEvent.getModifiers();
        KeyCharacterMap.KeyData keyData = new KeyCharacterMap.KeyData();
        if (keyEvent.getKeyData(keyData) || i == 67) {
            int size = this.f.size();
            for (int i3 = 0; i3 < size; i3++) {
                g gVar = this.f.get(i3);
                if (gVar.hasSubMenu()) {
                    gVar.o.a(list, i, keyEvent);
                }
                if (e) {
                    c2 = gVar.j;
                } else {
                    c2 = gVar.h;
                }
                if (e) {
                    i2 = gVar.k;
                } else {
                    i2 = gVar.i;
                }
                if (((modifiers & 69647) == (i2 & 69647)) && c2 != 0) {
                    char[] cArr = keyData.meta;
                    if ((c2 == cArr[0] || c2 == cArr[2] || (e && c2 == '\b' && i == 67)) && gVar.isEnabled()) {
                        list.add(gVar);
                    }
                }
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:18:0x0064, code lost:
    
        if (r1 != false) goto L69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x00db, code lost:
    
        a(true);
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x0073, code lost:
    
        if ((r9 & 1) == 0) goto L69;
     */
    /* JADX WARN: Code restructure failed: missing block: B:57:0x00d9, code lost:
    
        if (r1 == false) goto L69;
     */
    /* JADX WARN: Removed duplicated region for block: B:17:0x005f  */
    /* JADX WARN: Removed duplicated region for block: B:22:0x0068  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean a(android.view.MenuItem r7, b.a.o.d.k r8, int r9) {
        /*
            Method dump skipped, instructions count: 224
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.a.o.d.f.a(android.view.MenuItem, b.a.o.d.k, int):boolean");
    }

    public final void a(int i, CharSequence charSequence, int i2, Drawable drawable, View view) {
        Resources resources = this.f324b;
        if (view != null) {
            this.o = view;
            this.m = null;
            this.n = null;
        } else {
            if (i > 0) {
                this.m = resources.getText(i);
            } else if (charSequence != null) {
                this.m = charSequence;
            }
            if (i2 > 0) {
                this.n = b.d.e.a.b(this.f323a, i2);
            } else if (drawable != null) {
                this.n = drawable;
            }
            this.o = null;
        }
        b(false);
    }
}
