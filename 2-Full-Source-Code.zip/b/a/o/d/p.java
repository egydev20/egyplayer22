package b.a.o.d;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;

/* loaded from: classes.dex */
public class p extends f implements SubMenu {
    public f A;
    public g B;

    public p(Context context, f fVar, g gVar) {
        super(context);
        this.A = fVar;
        this.B = gVar;
    }

    @Override // b.a.o.d.f
    public boolean a(f fVar, MenuItem menuItem) {
        return super.a(fVar, menuItem) || this.A.a(fVar, menuItem);
    }

    @Override // b.a.o.d.f
    public boolean a(g gVar) {
        return this.A.a(gVar);
    }

    @Override // b.a.o.d.f
    public f b() {
        return this.A.b();
    }

    @Override // b.a.o.d.f
    public boolean b(g gVar) {
        return this.A.b(gVar);
    }

    @Override // b.a.o.d.f
    public boolean d() {
        return this.A.d();
    }

    @Override // b.a.o.d.f
    public boolean e() {
        return this.A.e();
    }

    @Override // b.a.o.d.f
    public boolean f() {
        return this.A.f();
    }

    @Override // android.view.SubMenu
    public MenuItem getItem() {
        return this.B;
    }

    @Override // b.a.o.d.f, android.view.Menu
    public void setGroupDividerEnabled(boolean z) {
        this.A.setGroupDividerEnabled(z);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(int i) {
        a(0, null, i, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(int i) {
        a(i, null, 0, null, null);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderView(View view) {
        a(0, null, 0, null, view);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(int i) {
        this.B.setIcon(i);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setIcon(Drawable drawable) {
        this.B.setIcon(drawable);
        return this;
    }

    @Override // b.a.o.d.f, android.view.Menu
    public void setQwertyMode(boolean z) {
        this.A.setQwertyMode(z);
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderIcon(Drawable drawable) {
        a(0, null, 0, drawable, null);
        return this;
    }

    @Override // android.view.SubMenu
    public SubMenu setHeaderTitle(CharSequence charSequence) {
        a(0, charSequence, 0, null, null);
        return this;
    }
}
