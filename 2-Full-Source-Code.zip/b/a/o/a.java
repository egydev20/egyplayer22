package b.a.o;

/* loaded from: classes.dex */
public interface a {
    void a();

    void b();
}
