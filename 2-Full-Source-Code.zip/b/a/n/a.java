package b.a.n;

/* loaded from: classes.dex */
public final class a {
    public static final int abc_vector_test = 2131165269;
    public static final int notification_action_background = 2131165387;
    public static final int notification_bg = 2131165388;
    public static final int notification_bg_low = 2131165389;
    public static final int notification_bg_low_normal = 2131165390;
    public static final int notification_bg_low_pressed = 2131165391;
    public static final int notification_bg_normal = 2131165392;
    public static final int notification_bg_normal_pressed = 2131165393;
    public static final int notification_icon_background = 2131165394;
    public static final int notification_template_icon_bg = 2131165395;
    public static final int notification_template_icon_low_bg = 2131165396;
    public static final int notification_tile_bg = 2131165397;
    public static final int notify_panel_notification_icon_bg = 2131165398;
}
