package b.c;

import java.util.ConcurrentModificationException;
import java.util.Map;

/* loaded from: classes.dex */
public class j<K, V> {
    public static Object[] e;
    public static int f;
    public static Object[] g;
    public static int h;

    /* renamed from: b, reason: collision with root package name */
    public int[] f518b;

    /* renamed from: c, reason: collision with root package name */
    public Object[] f519c;

    /* renamed from: d, reason: collision with root package name */
    public int f520d;

    public j() {
        this.f518b = f.f496a;
        this.f519c = f.f498c;
        this.f520d = 0;
    }

    public j(int i) {
        if (i == 0) {
            this.f518b = f.f496a;
            this.f519c = f.f498c;
        } else {
            a(i);
        }
        this.f520d = 0;
    }

    public static void a(int[] iArr, Object[] objArr, int i) {
        if (iArr.length == 8) {
            synchronized (j.class) {
                if (h < 10) {
                    objArr[0] = g;
                    objArr[1] = iArr;
                    for (int i2 = (i << 1) - 1; i2 >= 2; i2--) {
                        objArr[i2] = null;
                    }
                    g = objArr;
                    h++;
                }
            }
            return;
        }
        if (iArr.length == 4) {
            synchronized (j.class) {
                if (f < 10) {
                    objArr[0] = e;
                    objArr[1] = iArr;
                    for (int i3 = (i << 1) - 1; i3 >= 2; i3--) {
                        objArr[i3] = null;
                    }
                    e = objArr;
                    f++;
                }
            }
        }
    }

    public int a(Object obj) {
        return obj == null ? a() : a(obj, obj.hashCode());
    }

    public int a(Object obj, int i) {
        int i2 = this.f520d;
        if (i2 == 0) {
            return -1;
        }
        try {
            int a2 = f.a(this.f518b, i2, i);
            if (a2 < 0 || obj.equals(this.f519c[a2 << 1])) {
                return a2;
            }
            int i3 = a2 + 1;
            while (i3 < i2 && this.f518b[i3] == i) {
                if (obj.equals(this.f519c[i3 << 1])) {
                    return i3;
                }
                i3++;
            }
            for (int i4 = a2 - 1; i4 >= 0 && this.f518b[i4] == i; i4--) {
                if (obj.equals(this.f519c[i4 << 1])) {
                    return i4;
                }
            }
            return ~i3;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }

    public V a(int i, V v) {
        int i2 = (i << 1) + 1;
        Object[] objArr = this.f519c;
        V v2 = (V) objArr[i2];
        objArr[i2] = v;
        return v2;
    }

    public final void a(int i) {
        if (i == 8) {
            synchronized (j.class) {
                if (g != null) {
                    Object[] objArr = g;
                    this.f519c = objArr;
                    g = (Object[]) objArr[0];
                    this.f518b = (int[]) objArr[1];
                    objArr[1] = null;
                    objArr[0] = null;
                    h--;
                    return;
                }
            }
        } else if (i == 4) {
            synchronized (j.class) {
                if (e != null) {
                    Object[] objArr2 = e;
                    this.f519c = objArr2;
                    e = (Object[]) objArr2[0];
                    this.f518b = (int[]) objArr2[1];
                    objArr2[1] = null;
                    objArr2[0] = null;
                    f--;
                    return;
                }
            }
        }
        this.f518b = new int[i];
        this.f519c = new Object[i << 1];
    }

    public int b(Object obj) {
        int i = this.f520d * 2;
        Object[] objArr = this.f519c;
        if (obj == null) {
            for (int i2 = 1; i2 < i; i2 += 2) {
                if (objArr[i2] == null) {
                    return i2 >> 1;
                }
            }
            return -1;
        }
        for (int i3 = 1; i3 < i; i3 += 2) {
            if (obj.equals(objArr[i3])) {
                return i3 >> 1;
            }
        }
        return -1;
    }

    public K b(int i) {
        return (K) this.f519c[i << 1];
    }

    public V c(int i) {
        Object[] objArr = this.f519c;
        int i2 = i << 1;
        V v = (V) objArr[i2 + 1];
        int i3 = this.f520d;
        int i4 = 0;
        if (i3 <= 1) {
            a(this.f518b, objArr, i3);
            this.f518b = f.f496a;
            this.f519c = f.f498c;
        } else {
            int i5 = i3 - 1;
            int[] iArr = this.f518b;
            if (iArr.length <= 8 || i3 >= iArr.length / 3) {
                if (i < i5) {
                    int[] iArr2 = this.f518b;
                    int i6 = i + 1;
                    int i7 = i5 - i;
                    System.arraycopy(iArr2, i6, iArr2, i, i7);
                    Object[] objArr2 = this.f519c;
                    System.arraycopy(objArr2, i6 << 1, objArr2, i2, i7 << 1);
                }
                Object[] objArr3 = this.f519c;
                int i8 = i5 << 1;
                objArr3[i8] = null;
                objArr3[i8 + 1] = null;
            } else {
                int i9 = i3 > 8 ? i3 + (i3 >> 1) : 8;
                int[] iArr3 = this.f518b;
                Object[] objArr4 = this.f519c;
                a(i9);
                if (i3 != this.f520d) {
                    throw new ConcurrentModificationException();
                }
                if (i > 0) {
                    System.arraycopy(iArr3, 0, this.f518b, 0, i);
                    System.arraycopy(objArr4, 0, this.f519c, 0, i2);
                }
                if (i < i5) {
                    int i10 = i + 1;
                    int i11 = i5 - i;
                    System.arraycopy(iArr3, i10, this.f518b, i, i11);
                    System.arraycopy(objArr4, i10 << 1, this.f519c, i2, i11 << 1);
                }
            }
            i4 = i5;
        }
        if (i3 != this.f520d) {
            throw new ConcurrentModificationException();
        }
        this.f520d = i4;
        return v;
    }

    public void clear() {
        int i = this.f520d;
        if (i > 0) {
            int[] iArr = this.f518b;
            Object[] objArr = this.f519c;
            this.f518b = f.f496a;
            this.f519c = f.f498c;
            this.f520d = 0;
            a(iArr, objArr, i);
        }
        if (this.f520d > 0) {
            throw new ConcurrentModificationException();
        }
    }

    public boolean containsKey(Object obj) {
        return a(obj) >= 0;
    }

    public boolean containsValue(Object obj) {
        return b(obj) >= 0;
    }

    public V d(int i) {
        return (V) this.f519c[(i << 1) + 1];
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj instanceof j) {
            j jVar = (j) obj;
            if (this.f520d != jVar.f520d) {
                return false;
            }
            for (int i = 0; i < this.f520d; i++) {
                try {
                    K b2 = b(i);
                    V d2 = d(i);
                    Object obj2 = jVar.get(b2);
                    if (d2 == null) {
                        if (obj2 != null || !jVar.containsKey(b2)) {
                            return false;
                        }
                    } else if (!d2.equals(obj2)) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused) {
                    return false;
                }
            }
            return true;
        }
        if (obj instanceof Map) {
            Map map = (Map) obj;
            if (this.f520d != map.size()) {
                return false;
            }
            for (int i2 = 0; i2 < this.f520d; i2++) {
                try {
                    K b3 = b(i2);
                    V d3 = d(i2);
                    Object obj3 = map.get(b3);
                    if (d3 == null) {
                        if (obj3 != null || !map.containsKey(b3)) {
                            return false;
                        }
                    } else if (!d3.equals(obj3)) {
                        return false;
                    }
                } catch (ClassCastException | NullPointerException unused2) {
                }
            }
            return true;
        }
        return false;
    }

    public V get(Object obj) {
        return getOrDefault(obj, null);
    }

    public V getOrDefault(Object obj, V v) {
        int a2 = a(obj);
        return a2 >= 0 ? (V) this.f519c[(a2 << 1) + 1] : v;
    }

    public int hashCode() {
        int[] iArr = this.f518b;
        Object[] objArr = this.f519c;
        int i = this.f520d;
        int i2 = 1;
        int i3 = 0;
        int i4 = 0;
        while (i3 < i) {
            Object obj = objArr[i2];
            i4 += (obj == null ? 0 : obj.hashCode()) ^ iArr[i3];
            i3++;
            i2 += 2;
        }
        return i4;
    }

    public boolean isEmpty() {
        return this.f520d <= 0;
    }

    public V put(K k, V v) {
        int i;
        int a2;
        int i2 = this.f520d;
        if (k == null) {
            a2 = a();
            i = 0;
        } else {
            int hashCode = k.hashCode();
            i = hashCode;
            a2 = a(k, hashCode);
        }
        if (a2 >= 0) {
            int i3 = (a2 << 1) + 1;
            Object[] objArr = this.f519c;
            V v2 = (V) objArr[i3];
            objArr[i3] = v;
            return v2;
        }
        int i4 = ~a2;
        if (i2 >= this.f518b.length) {
            int i5 = 4;
            if (i2 >= 8) {
                i5 = (i2 >> 1) + i2;
            } else if (i2 >= 4) {
                i5 = 8;
            }
            int[] iArr = this.f518b;
            Object[] objArr2 = this.f519c;
            a(i5);
            if (i2 != this.f520d) {
                throw new ConcurrentModificationException();
            }
            int[] iArr2 = this.f518b;
            if (iArr2.length > 0) {
                System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
                System.arraycopy(objArr2, 0, this.f519c, 0, objArr2.length);
            }
            a(iArr, objArr2, i2);
        }
        if (i4 < i2) {
            int[] iArr3 = this.f518b;
            int i6 = i4 + 1;
            System.arraycopy(iArr3, i4, iArr3, i6, i2 - i4);
            Object[] objArr3 = this.f519c;
            System.arraycopy(objArr3, i4 << 1, objArr3, i6 << 1, (this.f520d - i4) << 1);
        }
        int i7 = this.f520d;
        if (i2 == i7) {
            int[] iArr4 = this.f518b;
            if (i4 < iArr4.length) {
                iArr4[i4] = i;
                Object[] objArr4 = this.f519c;
                int i8 = i4 << 1;
                objArr4[i8] = k;
                objArr4[i8 + 1] = v;
                this.f520d = i7 + 1;
                return null;
            }
        }
        throw new ConcurrentModificationException();
    }

    public V putIfAbsent(K k, V v) {
        V orDefault = getOrDefault(k, null);
        return orDefault == null ? put(k, v) : orDefault;
    }

    public V remove(Object obj) {
        int a2 = a(obj);
        if (a2 >= 0) {
            return c(a2);
        }
        return null;
    }

    public boolean remove(Object obj, Object obj2) {
        int a2 = a(obj);
        if (a2 < 0) {
            return false;
        }
        V d2 = d(a2);
        if (obj2 != d2 && (obj2 == null || !obj2.equals(d2))) {
            return false;
        }
        c(a2);
        return true;
    }

    public V replace(K k, V v) {
        int a2 = a(k);
        if (a2 >= 0) {
            return a(a2, (int) v);
        }
        return null;
    }

    public boolean replace(K k, V v, V v2) {
        int a2 = a(k);
        if (a2 < 0) {
            return false;
        }
        V d2 = d(a2);
        if (d2 != v && (v == null || !v.equals(d2))) {
            return false;
        }
        a(a2, (int) v2);
        return true;
    }

    public int size() {
        return this.f520d;
    }

    public String toString() {
        if (isEmpty()) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.f520d * 28);
        sb.append('{');
        for (int i = 0; i < this.f520d; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            K b2 = b(i);
            if (b2 != this) {
                sb.append(b2);
            } else {
                sb.append("(this Map)");
            }
            sb.append('=');
            V d2 = d(i);
            if (d2 != this) {
                sb.append(d2);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }

    public int a() {
        int i = this.f520d;
        if (i == 0) {
            return -1;
        }
        try {
            int a2 = f.a(this.f518b, i, 0);
            if (a2 < 0 || this.f519c[a2 << 1] == null) {
                return a2;
            }
            int i2 = a2 + 1;
            while (i2 < i && this.f518b[i2] == 0) {
                if (this.f519c[i2 << 1] == null) {
                    return i2;
                }
                i2++;
            }
            for (int i3 = a2 - 1; i3 >= 0 && this.f518b[i3] == 0; i3--) {
                if (this.f519c[i3 << 1] == null) {
                    return i3;
                }
            }
            return ~i2;
        } catch (ArrayIndexOutOfBoundsException unused) {
            throw new ConcurrentModificationException();
        }
    }
}
