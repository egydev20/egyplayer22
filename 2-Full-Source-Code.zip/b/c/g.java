package b.c;

/* loaded from: classes.dex */
public class g<E> implements Cloneable {
    public static final Object f = new Object();

    /* renamed from: b, reason: collision with root package name */
    public boolean f499b = false;

    /* renamed from: c, reason: collision with root package name */
    public long[] f500c;

    /* renamed from: d, reason: collision with root package name */
    public Object[] f501d;
    public int e;

    public g() {
        int c2 = f.c(10);
        this.f500c = new long[c2];
        this.f501d = new Object[c2];
    }

    public void a() {
        int i = this.e;
        Object[] objArr = this.f501d;
        for (int i2 = 0; i2 < i; i2++) {
            objArr[i2] = null;
        }
        this.e = 0;
        this.f499b = false;
    }

    public void a(long j) {
        int a2 = f.a(this.f500c, this.e, j);
        if (a2 >= 0) {
            Object[] objArr = this.f501d;
            Object obj = objArr[a2];
            Object obj2 = f;
            if (obj != obj2) {
                objArr[a2] = obj2;
                this.f499b = true;
            }
        }
    }

    public void a(long j, E e) {
        int i = this.e;
        if (i != 0 && j <= this.f500c[i - 1]) {
            c(j, e);
            return;
        }
        if (this.f499b && this.e >= this.f500c.length) {
            b();
        }
        int i2 = this.e;
        if (i2 >= this.f500c.length) {
            int c2 = f.c(i2 + 1);
            long[] jArr = new long[c2];
            Object[] objArr = new Object[c2];
            long[] jArr2 = this.f500c;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr2 = this.f501d;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.f500c = jArr;
            this.f501d = objArr;
        }
        this.f500c[i2] = j;
        this.f501d[i2] = e;
        this.e = i2 + 1;
    }

    public E b(long j, E e) {
        int a2 = f.a(this.f500c, this.e, j);
        if (a2 >= 0) {
            Object[] objArr = this.f501d;
            if (objArr[a2] != f) {
                return (E) objArr[a2];
            }
        }
        return e;
    }

    public final void b() {
        int i = this.e;
        long[] jArr = this.f500c;
        Object[] objArr = this.f501d;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != f) {
                if (i3 != i2) {
                    jArr[i2] = jArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.f499b = false;
        this.e = i2;
    }

    public void c(long j, E e) {
        int a2 = f.a(this.f500c, this.e, j);
        if (a2 >= 0) {
            this.f501d[a2] = e;
            return;
        }
        int i = ~a2;
        if (i < this.e) {
            Object[] objArr = this.f501d;
            if (objArr[i] == f) {
                this.f500c[i] = j;
                objArr[i] = e;
                return;
            }
        }
        if (this.f499b && this.e >= this.f500c.length) {
            b();
            i = ~f.a(this.f500c, this.e, j);
        }
        int i2 = this.e;
        if (i2 >= this.f500c.length) {
            int c2 = f.c(i2 + 1);
            long[] jArr = new long[c2];
            Object[] objArr2 = new Object[c2];
            long[] jArr2 = this.f500c;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = this.f501d;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.f500c = jArr;
            this.f501d = objArr2;
        }
        int i3 = this.e;
        if (i3 - i != 0) {
            long[] jArr3 = this.f500c;
            int i4 = i + 1;
            System.arraycopy(jArr3, i, jArr3, i4, i3 - i);
            Object[] objArr4 = this.f501d;
            System.arraycopy(objArr4, i, objArr4, i4, this.e - i);
        }
        this.f500c[i] = j;
        this.f501d[i] = e;
        this.e++;
    }

    /* renamed from: clone, reason: merged with bridge method [inline-methods] */
    public g<E> m0clone() {
        try {
            g<E> gVar = (g) super.clone();
            gVar.f500c = (long[]) this.f500c.clone();
            gVar.f501d = (Object[]) this.f501d.clone();
            return gVar;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public String toString() {
        if (this.f499b) {
            b();
        }
        int i = this.e;
        if (i <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(i * 28);
        sb.append('{');
        for (int i2 = 0; i2 < this.e; i2++) {
            if (i2 > 0) {
                sb.append(", ");
            }
            if (this.f499b) {
                b();
            }
            sb.append(this.f500c[i2]);
            sb.append('=');
            if (this.f499b) {
                b();
            }
            Object obj = this.f501d[i2];
            if (obj != this) {
                sb.append(obj);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
