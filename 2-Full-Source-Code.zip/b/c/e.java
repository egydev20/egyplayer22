package b.c;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public int[] f492a;

    /* renamed from: b, reason: collision with root package name */
    public int f493b;

    /* renamed from: c, reason: collision with root package name */
    public int f494c;

    /* renamed from: d, reason: collision with root package name */
    public int f495d;

    public e() {
        int highestOneBit = Integer.bitCount(8) != 1 ? Integer.highestOneBit(7) << 1 : 8;
        this.f495d = highestOneBit - 1;
        this.f492a = new int[highestOneBit];
    }

    public int a() {
        return (this.f494c - this.f493b) & this.f495d;
    }

    public void a(int i) {
        int[] iArr = this.f492a;
        int i2 = this.f494c;
        iArr[i2] = i;
        int i3 = this.f495d & (i2 + 1);
        this.f494c = i3;
        int i4 = this.f493b;
        if (i3 == i4) {
            int length = iArr.length;
            int i5 = length - i4;
            int i6 = length << 1;
            if (i6 < 0) {
                throw new RuntimeException("Max array capacity exceeded");
            }
            int[] iArr2 = new int[i6];
            System.arraycopy(iArr, i4, iArr2, 0, i5);
            System.arraycopy(this.f492a, 0, iArr2, i5, this.f493b);
            this.f492a = iArr2;
            this.f493b = 0;
            this.f494c = length;
            this.f495d = i6 - 1;
        }
    }

    public int b(int i) {
        if (i < 0 || i >= a()) {
            throw new ArrayIndexOutOfBoundsException();
        }
        return this.f492a[this.f495d & (this.f493b + i)];
    }
}
