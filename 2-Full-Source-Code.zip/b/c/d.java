package b.c;

/* loaded from: classes.dex */
public final class d<E> {

    /* renamed from: a, reason: collision with root package name */
    public E[] f488a;

    /* renamed from: b, reason: collision with root package name */
    public int f489b;

    /* renamed from: c, reason: collision with root package name */
    public int f490c;

    /* renamed from: d, reason: collision with root package name */
    public int f491d;

    public d(int i) {
        if (i < 1) {
            throw new IllegalArgumentException("capacity must be >= 1");
        }
        if (i > 1073741824) {
            throw new IllegalArgumentException("capacity must be <= 2^30");
        }
        i = Integer.bitCount(i) != 1 ? Integer.highestOneBit(i - 1) << 1 : i;
        this.f491d = i - 1;
        this.f488a = (E[]) new Object[i];
    }

    public final void a() {
        E[] eArr = this.f488a;
        int length = eArr.length;
        int i = this.f489b;
        int i2 = length - i;
        int i3 = length << 1;
        if (i3 < 0) {
            throw new RuntimeException("Max array capacity exceeded");
        }
        E[] eArr2 = (E[]) new Object[i3];
        System.arraycopy(eArr, i, eArr2, 0, i2);
        System.arraycopy(this.f488a, 0, eArr2, i2, this.f489b);
        this.f488a = eArr2;
        this.f489b = 0;
        this.f490c = length;
        this.f491d = i3 - 1;
    }

    public void a(int i) {
        int i2;
        if (i <= 0) {
            return;
        }
        if (i > b()) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int i3 = this.f490c;
        int i4 = i < i3 ? i3 - i : 0;
        int i5 = i4;
        while (true) {
            i2 = this.f490c;
            if (i5 >= i2) {
                break;
            }
            this.f488a[i5] = null;
            i5++;
        }
        int i6 = i2 - i4;
        int i7 = i - i6;
        this.f490c = i2 - i6;
        if (i7 > 0) {
            int length = this.f488a.length;
            this.f490c = length;
            int i8 = length - i7;
            for (int i9 = i8; i9 < this.f490c; i9++) {
                this.f488a[i9] = null;
            }
            this.f490c = i8;
        }
    }

    public int b() {
        return (this.f490c - this.f489b) & this.f491d;
    }

    public void b(int i) {
        if (i <= 0) {
            return;
        }
        if (i > b()) {
            throw new ArrayIndexOutOfBoundsException();
        }
        int length = this.f488a.length;
        int i2 = this.f489b;
        if (i < length - i2) {
            length = i2 + i;
        }
        for (int i3 = this.f489b; i3 < length; i3++) {
            this.f488a[i3] = null;
        }
        int i4 = this.f489b;
        int i5 = length - i4;
        int i6 = i - i5;
        this.f489b = this.f491d & (i4 + i5);
        if (i6 > 0) {
            for (int i7 = 0; i7 < i6; i7++) {
                this.f488a[i7] = null;
            }
            this.f489b = i6;
        }
    }
}
