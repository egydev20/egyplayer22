package b.c;

import java.util.Map;

/* JADX INFO: Add missing generic type declarations: [E] */
/* loaded from: classes.dex */
public class b<E> extends i<E, E> {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ c f484d;

    public b(c cVar) {
        this.f484d = cVar;
    }

    @Override // b.c.i
    public int a(Object obj) {
        return this.f484d.a(obj);
    }

    @Override // b.c.i
    public Object a(int i, int i2) {
        return this.f484d.f486c[i];
    }

    @Override // b.c.i
    public E a(int i, E e) {
        throw new UnsupportedOperationException("not a map");
    }

    @Override // b.c.i
    public void a() {
        this.f484d.clear();
    }

    @Override // b.c.i
    public void a(int i) {
        this.f484d.b(i);
    }

    @Override // b.c.i
    public void a(E e, E e2) {
        this.f484d.add(e);
    }

    @Override // b.c.i
    public int b(Object obj) {
        return this.f484d.a(obj);
    }

    @Override // b.c.i
    public Map<E, E> b() {
        throw new UnsupportedOperationException("not a map");
    }

    @Override // b.c.i
    public int c() {
        return this.f484d.f487d;
    }
}
