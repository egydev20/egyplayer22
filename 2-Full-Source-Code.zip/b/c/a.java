package b.c;

import b.c.i;
import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public class a<K, V> extends j<K, V> implements Map<K, V> {
    public i<K, V> i;

    /* renamed from: b.c.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class C0013a extends i<K, V> {
        public C0013a() {
        }

        @Override // b.c.i
        public int a(Object obj) {
            return a.this.a(obj);
        }

        @Override // b.c.i
        public Object a(int i, int i2) {
            return a.this.f519c[(i << 1) + i2];
        }

        @Override // b.c.i
        public V a(int i, V v) {
            int i2 = (i << 1) + 1;
            Object[] objArr = a.this.f519c;
            V v2 = (V) objArr[i2];
            objArr[i2] = v;
            return v2;
        }

        @Override // b.c.i
        public void a() {
            a.this.clear();
        }

        @Override // b.c.i
        public void a(int i) {
            a.this.c(i);
        }

        @Override // b.c.i
        public void a(K k, V v) {
            a.this.put(k, v);
        }

        @Override // b.c.i
        public int b(Object obj) {
            return a.this.b(obj);
        }

        @Override // b.c.i
        public Map<K, V> b() {
            return a.this;
        }

        @Override // b.c.i
        public int c() {
            return a.this.f520d;
        }
    }

    public a() {
    }

    public a(int i) {
        super(i);
    }

    public final i<K, V> b() {
        if (this.i == null) {
            this.i = new C0013a();
        }
        return this.i;
    }

    @Override // java.util.Map
    public Set<Map.Entry<K, V>> entrySet() {
        i<K, V> b2 = b();
        if (b2.f506a == null) {
            b2.f506a = new i.b();
        }
        return b2.f506a;
    }

    @Override // java.util.Map
    public Set<K> keySet() {
        i<K, V> b2 = b();
        if (b2.f507b == null) {
            b2.f507b = new i.c();
        }
        return b2.f507b;
    }

    @Override // java.util.Map
    public void putAll(Map<? extends K, ? extends V> map) {
        int size = map.size() + this.f520d;
        int i = this.f520d;
        int[] iArr = this.f518b;
        if (iArr.length < size) {
            Object[] objArr = this.f519c;
            a(size);
            if (this.f520d > 0) {
                System.arraycopy(iArr, 0, this.f518b, 0, i);
                System.arraycopy(objArr, 0, this.f519c, 0, i << 1);
            }
            j.a(iArr, objArr, i);
        }
        if (this.f520d == i) {
            for (Map.Entry<? extends K, ? extends V> entry : map.entrySet()) {
                put(entry.getKey(), entry.getValue());
            }
            return;
        }
        throw new ConcurrentModificationException();
    }

    @Override // java.util.Map
    public Collection<V> values() {
        i<K, V> b2 = b();
        if (b2.f508c == null) {
            b2.f508c = new i.e();
        }
        return b2.f508c;
    }
}
