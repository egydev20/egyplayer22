package b.c;

/* loaded from: classes.dex */
public class k<E> implements Cloneable {
    public static final Object f = new Object();

    /* renamed from: b, reason: collision with root package name */
    public boolean f521b;

    /* renamed from: c, reason: collision with root package name */
    public int[] f522c;

    /* renamed from: d, reason: collision with root package name */
    public Object[] f523d;
    public int e;

    public k() {
        this(10);
    }

    public k(int i) {
        this.f521b = false;
        if (i == 0) {
            this.f522c = f.f496a;
            this.f523d = f.f498c;
        } else {
            int b2 = f.b(i);
            this.f522c = new int[b2];
            this.f523d = new Object[b2];
        }
    }

    public int a(int i) {
        if (this.f521b) {
            a();
        }
        return this.f522c[i];
    }

    public final void a() {
        int i = this.e;
        int[] iArr = this.f522c;
        Object[] objArr = this.f523d;
        int i2 = 0;
        for (int i3 = 0; i3 < i; i3++) {
            Object obj = objArr[i3];
            if (obj != f) {
                if (i3 != i2) {
                    iArr[i2] = iArr[i3];
                    objArr[i2] = obj;
                    objArr[i3] = null;
                }
                i2++;
            }
        }
        this.f521b = false;
        this.e = i2;
    }

    public void a(int i, E e) {
        int i2 = this.e;
        if (i2 != 0 && i <= this.f522c[i2 - 1]) {
            c(i, e);
            return;
        }
        if (this.f521b && this.e >= this.f522c.length) {
            a();
        }
        int i3 = this.e;
        if (i3 >= this.f522c.length) {
            int b2 = f.b(i3 + 1);
            int[] iArr = new int[b2];
            Object[] objArr = new Object[b2];
            int[] iArr2 = this.f522c;
            System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
            Object[] objArr2 = this.f523d;
            System.arraycopy(objArr2, 0, objArr, 0, objArr2.length);
            this.f522c = iArr;
            this.f523d = objArr;
        }
        this.f522c[i3] = i;
        this.f523d[i3] = e;
        this.e = i3 + 1;
    }

    public int b() {
        if (this.f521b) {
            a();
        }
        return this.e;
    }

    public E b(int i) {
        if (this.f521b) {
            a();
        }
        return (E) this.f523d[i];
    }

    public E b(int i, E e) {
        int a2 = f.a(this.f522c, this.e, i);
        if (a2 >= 0) {
            Object[] objArr = this.f523d;
            if (objArr[a2] != f) {
                return (E) objArr[a2];
            }
        }
        return e;
    }

    public void c(int i, E e) {
        int a2 = f.a(this.f522c, this.e, i);
        if (a2 >= 0) {
            this.f523d[a2] = e;
            return;
        }
        int i2 = ~a2;
        if (i2 < this.e) {
            Object[] objArr = this.f523d;
            if (objArr[i2] == f) {
                this.f522c[i2] = i;
                objArr[i2] = e;
                return;
            }
        }
        if (this.f521b && this.e >= this.f522c.length) {
            a();
            i2 = ~f.a(this.f522c, this.e, i);
        }
        int i3 = this.e;
        if (i3 >= this.f522c.length) {
            int b2 = f.b(i3 + 1);
            int[] iArr = new int[b2];
            Object[] objArr2 = new Object[b2];
            int[] iArr2 = this.f522c;
            System.arraycopy(iArr2, 0, iArr, 0, iArr2.length);
            Object[] objArr3 = this.f523d;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            this.f522c = iArr;
            this.f523d = objArr2;
        }
        int i4 = this.e;
        if (i4 - i2 != 0) {
            int[] iArr3 = this.f522c;
            int i5 = i2 + 1;
            System.arraycopy(iArr3, i2, iArr3, i5, i4 - i2);
            Object[] objArr4 = this.f523d;
            System.arraycopy(objArr4, i2, objArr4, i5, this.e - i2);
        }
        this.f522c[i2] = i;
        this.f523d[i2] = e;
        this.e++;
    }

    /* renamed from: clone, reason: merged with bridge method [inline-methods] */
    public k<E> m1clone() {
        try {
            k<E> kVar = (k) super.clone();
            kVar.f522c = (int[]) this.f522c.clone();
            kVar.f523d = (Object[]) this.f523d.clone();
            return kVar;
        } catch (CloneNotSupportedException e) {
            throw new AssertionError(e);
        }
    }

    public String toString() {
        if (b() <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(this.e * 28);
        sb.append('{');
        for (int i = 0; i < this.e; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(a(i));
            sb.append('=');
            E b2 = b(i);
            if (b2 != this) {
                sb.append(b2);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
