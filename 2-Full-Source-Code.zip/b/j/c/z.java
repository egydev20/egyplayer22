package b.j.c;

import b.j.c.t;

/* loaded from: classes.dex */
public class z {

    /* renamed from: a, reason: collision with root package name */
    public final b.c.a<t.z, a> f879a = new b.c.a<>();

    /* renamed from: b, reason: collision with root package name */
    public final b.c.g<t.z> f880b = new b.c.g<>();

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: d, reason: collision with root package name */
        public static b.d.j.a<a> f881d = new b.d.j.a<>(20);

        /* renamed from: a, reason: collision with root package name */
        public int f882a;

        /* renamed from: b, reason: collision with root package name */
        public t.i.c f883b;

        /* renamed from: c, reason: collision with root package name */
        public t.i.c f884c;

        public static a a() {
            a a2 = f881d.a();
            return a2 == null ? new a() : a2;
        }

        public static void a(a aVar) {
            aVar.f882a = 0;
            aVar.f883b = null;
            aVar.f884c = null;
            f881d.a(aVar);
        }
    }

    /* loaded from: classes.dex */
    public interface b {
    }

    public final t.i.c a(t.z zVar, int i) {
        a d2;
        t.i.c cVar;
        int a2 = this.f879a.a(zVar);
        if (a2 >= 0 && (d2 = this.f879a.d(a2)) != null) {
            int i2 = d2.f882a;
            if ((i2 & i) != 0) {
                d2.f882a = (~i) & i2;
                if (i == 4) {
                    cVar = d2.f883b;
                } else {
                    if (i != 8) {
                        throw new IllegalArgumentException("Must provide flag PRE or POST");
                    }
                    cVar = d2.f884c;
                }
                if ((d2.f882a & 12) == 0) {
                    this.f879a.c(a2);
                    a.a(d2);
                }
                return cVar;
            }
        }
        return null;
    }

    public void a(t.z zVar) {
        a orDefault = this.f879a.getOrDefault(zVar, null);
        if (orDefault == null) {
            orDefault = a.a();
            this.f879a.put(zVar, orDefault);
        }
        orDefault.f882a |= 1;
    }

    public void b(t.z zVar, t.i.c cVar) {
        a orDefault = this.f879a.getOrDefault(zVar, null);
        if (orDefault == null) {
            orDefault = a.a();
            this.f879a.put(zVar, orDefault);
        }
        orDefault.f883b = cVar;
        orDefault.f882a |= 4;
    }

    public void c(t.z zVar) {
        a orDefault = this.f879a.getOrDefault(zVar, null);
        if (orDefault == null) {
            return;
        }
        orDefault.f882a &= -2;
    }

    public void d(t.z zVar) {
        b.c.g<t.z> gVar = this.f880b;
        if (gVar.f499b) {
            gVar.b();
        }
        int i = gVar.e - 1;
        while (true) {
            if (i < 0) {
                break;
            }
            b.c.g<t.z> gVar2 = this.f880b;
            if (gVar2.f499b) {
                gVar2.b();
            }
            if (zVar == gVar2.f501d[i]) {
                b.c.g<t.z> gVar3 = this.f880b;
                Object[] objArr = gVar3.f501d;
                Object obj = objArr[i];
                Object obj2 = b.c.g.f;
                if (obj != obj2) {
                    objArr[i] = obj2;
                    gVar3.f499b = true;
                }
            } else {
                i--;
            }
        }
        a remove = this.f879a.remove(zVar);
        if (remove != null) {
            a.a(remove);
        }
    }

    public void a(t.z zVar, t.i.c cVar) {
        a orDefault = this.f879a.getOrDefault(zVar, null);
        if (orDefault == null) {
            orDefault = a.a();
            this.f879a.put(zVar, orDefault);
        }
        orDefault.f884c = cVar;
        orDefault.f882a |= 8;
    }

    public boolean b(t.z zVar) {
        a orDefault = this.f879a.getOrDefault(zVar, null);
        return (orDefault == null || (orDefault.f882a & 1) == 0) ? false : true;
    }
}
