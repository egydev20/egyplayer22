package b.j.c;

import android.graphics.Rect;
import android.view.View;
import b.j.c.t;

/* loaded from: classes.dex */
public abstract class s {

    /* renamed from: a, reason: collision with root package name */
    public final t.l f807a;

    /* renamed from: b, reason: collision with root package name */
    public int f808b = Integer.MIN_VALUE;

    /* renamed from: c, reason: collision with root package name */
    public final Rect f809c = new Rect();

    public /* synthetic */ s(t.l lVar, q qVar) {
        this.f807a = lVar;
    }

    public static s a(t.l lVar, int i) {
        if (i == 0) {
            return new q(lVar);
        }
        if (i == 1) {
            return new r(lVar);
        }
        throw new IllegalArgumentException("invalid orientation");
    }

    public abstract int a();

    public abstract int a(View view);

    public abstract void a(int i);

    public abstract int b();

    public abstract int b(View view);

    public abstract int c();

    public abstract int c(View view);

    public abstract int d();

    public abstract int d(View view);

    public abstract int e();

    public abstract int e(View view);

    public abstract int f();

    public abstract int f(View view);

    public abstract int g();

    public int h() {
        if (Integer.MIN_VALUE == this.f808b) {
            return 0;
        }
        return g() - this.f808b;
    }
}
