package b.j.c;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.database.Observable;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.PointF;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.os.Trace;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.Display;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewPropertyAnimator;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import b.d.k.r.b;
import b.g.n.a;
import b.j.c.a;
import b.j.c.b;
import b.j.c.k;
import b.j.c.m;
import b.j.c.y;
import b.j.c.z;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.videolan.libvlc.interfaces.IMediaList;

/* loaded from: classes.dex */
public class t extends ViewGroup implements b.d.k.c {
    public static final boolean A0 = false;
    public static final boolean B0;
    public static final boolean C0;
    public static final boolean D0;
    public static final boolean E0;
    public static final Class<?>[] F0;
    public static final Interpolator G0;
    public static final int[] y0 = {R.attr.nestedScrollingEnabled};
    public static final int[] z0 = {R.attr.clipToPadding};
    public boolean A;
    public final AccessibilityManager B;
    public boolean C;
    public boolean D;
    public int E;
    public int F;
    public h G;
    public EdgeEffect H;
    public EdgeEffect I;
    public EdgeEffect J;
    public EdgeEffect K;
    public i L;
    public int M;
    public int N;
    public VelocityTracker O;
    public int P;
    public int Q;
    public int R;
    public int S;
    public int T;
    public n U;
    public final int V;
    public final int W;
    public float a0;

    /* renamed from: b, reason: collision with root package name */
    public final C0029t f810b;
    public float b0;

    /* renamed from: c, reason: collision with root package name */
    public final r f811c;
    public boolean c0;

    /* renamed from: d, reason: collision with root package name */
    public u f812d;
    public final y d0;
    public b.j.c.a e;
    public b.j.c.m e0;
    public b.j.c.b f;
    public m.b f0;
    public final b.j.c.z g;
    public final w g0;
    public boolean h;
    public p h0;
    public final Rect i;
    public List<p> i0;
    public final Rect j;
    public boolean j0;
    public final RectF k;
    public boolean k0;
    public d l;
    public i.b l0;
    public l m;
    public boolean m0;
    public s n;
    public b.j.c.w n0;
    public final ArrayList<k> o;
    public g o0;
    public final ArrayList<o> p;
    public final int[] p0;
    public o q;
    public b.d.k.e q0;
    public boolean r;
    public final int[] r0;
    public boolean s;
    public final int[] s0;
    public boolean t;
    public final int[] t0;
    public boolean u;
    public final int[] u0;
    public int v;
    public final List<z> v0;
    public boolean w;
    public Runnable w0;
    public boolean x;
    public final z.b x0;
    public boolean y;
    public int z;

    /* loaded from: classes.dex */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            i iVar = t.this.L;
            if (iVar != null) {
                b.j.c.k kVar = (b.j.c.k) iVar;
                boolean z = !kVar.h.isEmpty();
                boolean z2 = !kVar.j.isEmpty();
                boolean z3 = !kVar.k.isEmpty();
                boolean z4 = !kVar.i.isEmpty();
                if (z || z2 || z4 || z3) {
                    Iterator<z> it = kVar.h.iterator();
                    while (it.hasNext()) {
                        z next = it.next();
                        View view = next.f865a;
                        ViewPropertyAnimator animate = view.animate();
                        kVar.q.add(next);
                        animate.setDuration(kVar.f820d).alpha(0.0f).setListener(new b.j.c.f(kVar, next, animate, view)).start();
                    }
                    kVar.h.clear();
                    if (z2) {
                        ArrayList<k.b> arrayList = new ArrayList<>();
                        arrayList.addAll(kVar.j);
                        kVar.m.add(arrayList);
                        kVar.j.clear();
                        b.j.c.c cVar = new b.j.c.c(kVar, arrayList);
                        if (z) {
                            b.d.k.l.a(arrayList.get(0).f778a.f865a, cVar, kVar.f820d);
                        } else {
                            cVar.run();
                        }
                    }
                    if (z3) {
                        ArrayList<k.a> arrayList2 = new ArrayList<>();
                        arrayList2.addAll(kVar.k);
                        kVar.n.add(arrayList2);
                        kVar.k.clear();
                        b.j.c.d dVar = new b.j.c.d(kVar, arrayList2);
                        if (z) {
                            b.d.k.l.a(arrayList2.get(0).f774a.f865a, dVar, kVar.f820d);
                        } else {
                            dVar.run();
                        }
                    }
                    if (z4) {
                        ArrayList<z> arrayList3 = new ArrayList<>();
                        arrayList3.addAll(kVar.i);
                        kVar.l.add(arrayList3);
                        kVar.i.clear();
                        b.j.c.e eVar = new b.j.c.e(kVar, arrayList3);
                        if (z || z2 || z3) {
                            b.d.k.l.a(arrayList3.get(0).f865a, eVar, Math.max(z2 ? kVar.e : 0L, z3 ? kVar.f : 0L) + (z ? kVar.f820d : 0L));
                        } else {
                            eVar.run();
                        }
                    }
                }
            }
            t.this.m0 = false;
        }
    }

    /* loaded from: classes.dex */
    public static class b implements Interpolator {
        @Override // android.animation.TimeInterpolator
        public float getInterpolation(float f) {
            float f2 = f - 1.0f;
            return (f2 * f2 * f2 * f2 * f2) + 1.0f;
        }
    }

    /* loaded from: classes.dex */
    public class c implements z.b {
        public c() {
        }

        public void a(z zVar, i.c cVar, i.c cVar2) {
            boolean z;
            t tVar = t.this;
            if (tVar != null) {
                zVar.a(false);
                b.j.c.x xVar = (b.j.c.x) tVar.L;
                if (xVar != null) {
                    if (cVar == null || (cVar.f821a == cVar2.f821a && cVar.f822b == cVar2.f822b)) {
                        b.j.c.k kVar = (b.j.c.k) xVar;
                        kVar.e(zVar);
                        zVar.f865a.setAlpha(0.0f);
                        kVar.i.add(zVar);
                        z = true;
                    } else {
                        z = xVar.a(zVar, cVar.f821a, cVar.f822b, cVar2.f821a, cVar2.f822b);
                    }
                    if (z) {
                        tVar.q();
                        return;
                    }
                    return;
                }
                throw null;
            }
            throw null;
        }

        public void b(z zVar, i.c cVar, i.c cVar2) {
            boolean z;
            t.this.f811c.b(zVar);
            t tVar = t.this;
            tVar.a(zVar);
            zVar.a(false);
            b.j.c.x xVar = (b.j.c.x) tVar.L;
            if (xVar != null) {
                int i = cVar.f821a;
                int i2 = cVar.f822b;
                View view = zVar.f865a;
                int left = cVar2 == null ? view.getLeft() : cVar2.f821a;
                int top = cVar2 == null ? view.getTop() : cVar2.f822b;
                if (zVar.i() || (i == left && i2 == top)) {
                    b.j.c.k kVar = (b.j.c.k) xVar;
                    kVar.e(zVar);
                    kVar.h.add(zVar);
                    z = true;
                } else {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                    z = xVar.a(zVar, i, i2, left, top);
                }
                if (z) {
                    tVar.q();
                    return;
                }
                return;
            }
            throw null;
        }
    }

    /* loaded from: classes.dex */
    public static abstract class d<VH extends z> {

        /* renamed from: a, reason: collision with root package name */
        public final e f815a = new e();

        /* renamed from: b, reason: collision with root package name */
        public boolean f816b = false;

        public abstract int a();
    }

    /* loaded from: classes.dex */
    public static class e extends Observable<f> {
        public void a() {
            for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
                C0029t c0029t = (C0029t) ((f) ((Observable) this).mObservers.get(size));
                t.this.a((String) null);
                t tVar = t.this;
                tVar.g0.f = true;
                tVar.b(true);
                if (!t.this.e.c()) {
                    t.this.requestLayout();
                }
            }
        }
    }

    /* loaded from: classes.dex */
    public static abstract class f {
    }

    /* loaded from: classes.dex */
    public interface g {
        int a(int i, int i2);
    }

    /* loaded from: classes.dex */
    public static class h {
        public EdgeEffect a(t tVar) {
            return new EdgeEffect(tVar.getContext());
        }
    }

    /* loaded from: classes.dex */
    public static abstract class i {

        /* renamed from: a, reason: collision with root package name */
        public b f817a = null;

        /* renamed from: b, reason: collision with root package name */
        public ArrayList<a> f818b = new ArrayList<>();

        /* renamed from: c, reason: collision with root package name */
        public long f819c = 120;

        /* renamed from: d, reason: collision with root package name */
        public long f820d = 120;
        public long e = 250;
        public long f = 250;

        /* loaded from: classes.dex */
        public interface a {
            void a();
        }

        /* loaded from: classes.dex */
        public interface b {
        }

        /* loaded from: classes.dex */
        public static class c {

            /* renamed from: a, reason: collision with root package name */
            public int f821a;

            /* renamed from: b, reason: collision with root package name */
            public int f822b;
        }

        public static int d(z zVar) {
            int i = zVar.j & 14;
            if (zVar.g()) {
                return 4;
            }
            if ((i & 4) != 0) {
                return i;
            }
            int i2 = zVar.f868d;
            int c2 = zVar.c();
            return (i2 == -1 || c2 == -1 || i2 == c2) ? i : i | 2048;
        }

        public final void a() {
            int size = this.f818b.size();
            for (int i = 0; i < size; i++) {
                this.f818b.get(i).a();
            }
            this.f818b.clear();
        }

        public abstract boolean a(z zVar, z zVar2, c cVar, c cVar2);

        public boolean a(z zVar, List<Object> list) {
            return !((b.j.c.x) this).g || zVar.g();
        }

        public abstract void b();

        public abstract void b(z zVar);

        public c c(z zVar) {
            c cVar = new c();
            View view = zVar.f865a;
            cVar.f821a = view.getLeft();
            cVar.f822b = view.getTop();
            view.getRight();
            view.getBottom();
            return cVar;
        }

        public abstract boolean c();

        public final void a(z zVar) {
            b bVar = this.f817a;
            if (bVar != null) {
                j jVar = (j) bVar;
                if (jVar == null) {
                    throw null;
                }
                boolean z = true;
                zVar.a(true);
                if (zVar.h != null && zVar.i == null) {
                    zVar.h = null;
                }
                zVar.i = null;
                if ((zVar.j & 16) != 0) {
                    return;
                }
                t tVar = t.this;
                View view = zVar.f865a;
                tVar.u();
                b.j.c.b bVar2 = tVar.f;
                int indexOfChild = ((b.j.c.u) bVar2.f743a).f869a.indexOfChild(view);
                if (indexOfChild == -1) {
                    bVar2.d(view);
                } else if (bVar2.f744b.c(indexOfChild)) {
                    bVar2.f744b.d(indexOfChild);
                    bVar2.d(view);
                    ((b.j.c.u) bVar2.f743a).b(indexOfChild);
                } else {
                    z = false;
                }
                if (z) {
                    z f = t.f(view);
                    tVar.f811c.b(f);
                    tVar.f811c.a(f);
                }
                tVar.c(!z);
                if (z || !zVar.k()) {
                    return;
                }
                t.this.removeDetachedView(zVar.f865a, false);
            }
        }
    }

    /* loaded from: classes.dex */
    public class j implements i.b {
        public j() {
        }
    }

    /* loaded from: classes.dex */
    public static abstract class k {
    }

    /* loaded from: classes.dex */
    public static abstract class l {

        /* renamed from: a, reason: collision with root package name */
        public b.j.c.b f824a;

        /* renamed from: b, reason: collision with root package name */
        public t f825b;
        public v g;
        public int m;
        public boolean n;
        public int o;
        public int p;
        public int q;
        public int r;

        /* renamed from: c, reason: collision with root package name */
        public final y.b f826c = new a();

        /* renamed from: d, reason: collision with root package name */
        public final y.b f827d = new b();
        public b.j.c.y e = new b.j.c.y(this.f826c);
        public b.j.c.y f = new b.j.c.y(this.f827d);
        public boolean h = false;
        public boolean i = false;
        public boolean j = false;
        public boolean k = true;
        public boolean l = true;

        /* loaded from: classes.dex */
        public class a implements y.b {
            public a() {
            }

            @Override // b.j.c.y.b
            public int a() {
                l lVar = l.this;
                return lVar.q - lVar.l();
            }

            @Override // b.j.c.y.b
            public int a(View view) {
                return l.this.h(view) + ((ViewGroup.MarginLayoutParams) ((m) view.getLayoutParams())).rightMargin;
            }

            @Override // b.j.c.y.b
            public View a(int i) {
                return l.this.c(i);
            }

            @Override // b.j.c.y.b
            public int b() {
                return l.this.k();
            }

            @Override // b.j.c.y.b
            public int b(View view) {
                return l.this.e(view) - ((ViewGroup.MarginLayoutParams) ((m) view.getLayoutParams())).leftMargin;
            }
        }

        /* loaded from: classes.dex */
        public class b implements y.b {
            public b() {
            }

            @Override // b.j.c.y.b
            public int a() {
                l lVar = l.this;
                return lVar.r - lVar.j();
            }

            @Override // b.j.c.y.b
            public int a(View view) {
                return l.this.d(view) + ((ViewGroup.MarginLayoutParams) ((m) view.getLayoutParams())).bottomMargin;
            }

            @Override // b.j.c.y.b
            public View a(int i) {
                return l.this.c(i);
            }

            @Override // b.j.c.y.b
            public int b() {
                return l.this.m();
            }

            @Override // b.j.c.y.b
            public int b(View view) {
                return l.this.i(view) - ((ViewGroup.MarginLayoutParams) ((m) view.getLayoutParams())).topMargin;
            }
        }

        /* loaded from: classes.dex */
        public interface c {
        }

        /* loaded from: classes.dex */
        public static class d {

            /* renamed from: a, reason: collision with root package name */
            public int f830a;

            /* renamed from: b, reason: collision with root package name */
            public int f831b;

            /* renamed from: c, reason: collision with root package name */
            public boolean f832c;

            /* renamed from: d, reason: collision with root package name */
            public boolean f833d;
        }

        public static int a(int i, int i2, int i3) {
            int mode = View.MeasureSpec.getMode(i);
            int size = View.MeasureSpec.getSize(i);
            return mode != Integer.MIN_VALUE ? mode != 1073741824 ? Math.max(i2, i3) : size : Math.min(size, Math.max(i2, i3));
        }

        /* JADX WARN: Code restructure failed: missing block: B:7:0x0017, code lost:
        
            if (r5 == 1073741824) goto L14;
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public static int a(int r4, int r5, int r6, int r7, boolean r8) {
            /*
                int r4 = r4 - r6
                r6 = 0
                int r4 = java.lang.Math.max(r6, r4)
                r0 = -2
                r1 = -1
                r2 = -2147483648(0xffffffff80000000, float:-0.0)
                r3 = 1073741824(0x40000000, float:2.0)
                if (r8 == 0) goto L1a
                if (r7 < 0) goto L11
                goto L1c
            L11:
                if (r7 != r1) goto L2f
                if (r5 == r2) goto L21
                if (r5 == 0) goto L2f
                if (r5 == r3) goto L21
                goto L2f
            L1a:
                if (r7 < 0) goto L1f
            L1c:
                r5 = 1073741824(0x40000000, float:2.0)
                goto L31
            L1f:
                if (r7 != r1) goto L23
            L21:
                r7 = r4
                goto L31
            L23:
                if (r7 != r0) goto L2f
                if (r5 == r2) goto L2c
                if (r5 != r3) goto L2a
                goto L2c
            L2a:
                r5 = 0
                goto L21
            L2c:
                r5 = -2147483648(0xffffffff80000000, float:-0.0)
                goto L21
            L2f:
                r5 = 0
                r7 = 0
            L31:
                int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r5)
                return r4
            */
            throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.l.a(int, int, int, int, boolean):int");
        }

        public static d a(Context context, AttributeSet attributeSet, int i, int i2) {
            d dVar = new d();
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.j.b.RecyclerView, i, i2);
            dVar.f830a = obtainStyledAttributes.getInt(b.j.b.RecyclerView_android_orientation, 1);
            dVar.f831b = obtainStyledAttributes.getInt(b.j.b.RecyclerView_spanCount, 1);
            dVar.f832c = obtainStyledAttributes.getBoolean(b.j.b.RecyclerView_reverseLayout, false);
            dVar.f833d = obtainStyledAttributes.getBoolean(b.j.b.RecyclerView_stackFromEnd, false);
            obtainStyledAttributes.recycle();
            return dVar;
        }

        public static boolean b(int i, int i2, int i3) {
            int mode = View.MeasureSpec.getMode(i2);
            int size = View.MeasureSpec.getSize(i2);
            if (i3 > 0 && i != i3) {
                return false;
            }
            if (mode == Integer.MIN_VALUE) {
                return size >= i;
            }
            if (mode != 0) {
                return mode == 1073741824 && size == i;
            }
            return true;
        }

        public int a(int i, r rVar, w wVar) {
            return 0;
        }

        public int a(r rVar, w wVar) {
            t tVar = this.f825b;
            if (tVar == null || tVar.l == null || !a()) {
                return 1;
            }
            return this.f825b.l.a();
        }

        public int a(w wVar) {
            return 0;
        }

        public View a(View view, int i) {
            return null;
        }

        public View a(View view, int i, r rVar, w wVar) {
            return null;
        }

        public m a(Context context, AttributeSet attributeSet) {
            return new m(context, attributeSet);
        }

        public m a(ViewGroup.LayoutParams layoutParams) {
            return layoutParams instanceof m ? new m((m) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new m((ViewGroup.MarginLayoutParams) layoutParams) : new m(layoutParams);
        }

        public void a(int i, int i2) {
            this.q = View.MeasureSpec.getSize(i);
            int mode = View.MeasureSpec.getMode(i);
            this.o = mode;
            if (mode == 0 && !t.B0) {
                this.q = 0;
            }
            this.r = View.MeasureSpec.getSize(i2);
            int mode2 = View.MeasureSpec.getMode(i2);
            this.p = mode2;
            if (mode2 != 0 || t.B0) {
                return;
            }
            this.r = 0;
        }

        public void a(int i, int i2, w wVar, c cVar) {
        }

        public void a(int i, c cVar) {
        }

        public void a(int i, r rVar) {
            View c2 = c(i);
            g(i);
            rVar.a(c2);
        }

        public void a(Parcelable parcelable) {
        }

        public void a(View view) {
            a(view, -1, true);
        }

        public void a(View view, int i, int i2, int i3, int i4) {
            m mVar = (m) view.getLayoutParams();
            Rect rect = mVar.f835b;
            view.layout(i + rect.left + ((ViewGroup.MarginLayoutParams) mVar).leftMargin, i2 + rect.top + ((ViewGroup.MarginLayoutParams) mVar).topMargin, (i3 - rect.right) - ((ViewGroup.MarginLayoutParams) mVar).rightMargin, (i4 - rect.bottom) - ((ViewGroup.MarginLayoutParams) mVar).bottomMargin);
        }

        public void a(View view, Rect rect) {
            t tVar = this.f825b;
            if (tVar == null) {
                rect.set(0, 0, 0, 0);
            } else {
                rect.set(tVar.d(view));
            }
        }

        public void a(View view, b.d.k.r.b bVar) {
            z f = t.f(view);
            if (f == null || f.i() || this.f824a.c(f.f865a)) {
                return;
            }
            t tVar = this.f825b;
            a(tVar.f811c, tVar.g0, view, bVar);
        }

        public void a(View view, r rVar) {
            a(rVar, this.f824a.b(view), view);
        }

        public void a(View view, boolean z, Rect rect) {
            Matrix matrix;
            if (z) {
                Rect rect2 = ((m) view.getLayoutParams()).f835b;
                rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
            } else {
                rect.set(0, 0, view.getWidth(), view.getHeight());
            }
            if (this.f825b != null && (matrix = view.getMatrix()) != null && !matrix.isIdentity()) {
                RectF rectF = this.f825b.k;
                rectF.set(rect);
                matrix.mapRect(rectF);
                rect.set((int) Math.floor(rectF.left), (int) Math.floor(rectF.top), (int) Math.ceil(rectF.right), (int) Math.ceil(rectF.bottom));
            }
            rect.offset(view.getLeft(), view.getTop());
        }

        public void a(d dVar, d dVar2) {
        }

        public void a(r rVar) {
            for (int d2 = d() - 1; d2 >= 0; d2--) {
                a(rVar, d2, c(d2));
            }
        }

        public void a(r rVar, w wVar, int i, int i2) {
            this.f825b.b(i, i2);
        }

        public void a(r rVar, w wVar, View view, b.d.k.r.b bVar) {
            bVar.a(b.C0019b.a(b() ? j(view) : 0, 1, a() ? j(view) : 0, 1, false, false));
        }

        public void a(t tVar) {
        }

        public void a(t tVar, int i, int i2) {
        }

        public void a(t tVar, int i, int i2, int i3) {
        }

        public void a(t tVar, int i, int i2, Object obj) {
            c(tVar, i, i2);
        }

        public void a(t tVar, r rVar) {
        }

        public void a(String str) {
            t tVar = this.f825b;
            if (tVar != null) {
                tVar.a(str);
            }
        }

        public boolean a() {
            return false;
        }

        public boolean a(View view, int i, int i2, m mVar) {
            return (!view.isLayoutRequested() && this.k && b(view.getWidth(), i, ((ViewGroup.MarginLayoutParams) mVar).width) && b(view.getHeight(), i2, ((ViewGroup.MarginLayoutParams) mVar).height)) ? false : true;
        }

        public boolean a(m mVar) {
            return mVar != null;
        }

        public boolean a(t tVar, View view, Rect rect, boolean z) {
            return a(tVar, view, rect, z, false);
        }

        @Deprecated
        public boolean a(t tVar, View view, View view2) {
            return p() || tVar.n();
        }

        public boolean a(t tVar, ArrayList<View> arrayList, int i, int i2) {
            return false;
        }

        public int b(int i, r rVar, w wVar) {
            return 0;
        }

        public int b(r rVar, w wVar) {
            t tVar = this.f825b;
            if (tVar == null || tVar.l == null || !b()) {
                return 1;
            }
            return this.f825b.l.a();
        }

        public int b(w wVar) {
            return 0;
        }

        public void b(int i, int i2) {
            int d2 = d();
            if (d2 == 0) {
                this.f825b.b(i, i2);
                return;
            }
            int i3 = Integer.MIN_VALUE;
            int i4 = Integer.MIN_VALUE;
            int i5 = Integer.MAX_VALUE;
            int i6 = Integer.MAX_VALUE;
            for (int i7 = 0; i7 < d2; i7++) {
                View c2 = c(i7);
                Rect rect = this.f825b.i;
                b(c2, rect);
                int i8 = rect.left;
                if (i8 < i5) {
                    i5 = i8;
                }
                int i9 = rect.right;
                if (i9 > i3) {
                    i3 = i9;
                }
                int i10 = rect.top;
                if (i10 < i6) {
                    i6 = i10;
                }
                int i11 = rect.bottom;
                if (i11 > i4) {
                    i4 = i11;
                }
            }
            this.f825b.i.set(i5, i6, i3, i4);
            a(this.f825b.i, i, i2);
        }

        public void b(View view) {
            a(view, -1, false);
        }

        public void b(View view, Rect rect) {
            t.a(view, rect);
        }

        public void b(r rVar) {
            for (int d2 = d() - 1; d2 >= 0; d2--) {
                if (!t.f(c(d2)).o()) {
                    a(d2, rVar);
                }
            }
        }

        public void b(t tVar) {
            a(View.MeasureSpec.makeMeasureSpec(tVar.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(tVar.getHeight(), 1073741824));
        }

        public void b(t tVar, int i, int i2) {
        }

        public boolean b() {
            return false;
        }

        public boolean b(View view, int i, int i2, m mVar) {
            return (this.k && b(view.getMeasuredWidth(), i, ((ViewGroup.MarginLayoutParams) mVar).width) && b(view.getMeasuredHeight(), i2, ((ViewGroup.MarginLayoutParams) mVar).height)) ? false : true;
        }

        public int c(w wVar) {
            return 0;
        }

        public View c(View view) {
            View b2;
            t tVar = this.f825b;
            if (tVar == null || (b2 = tVar.b(view)) == null || this.f824a.f745c.contains(b2)) {
                return null;
            }
            return b2;
        }

        public abstract m c();

        public void c(r rVar, w wVar) {
            Log.e("RecyclerView", "You must override onLayoutChildren(Recycler recycler, State state) ");
        }

        public void c(t tVar) {
            int height;
            if (tVar == null) {
                this.f825b = null;
                this.f824a = null;
                height = 0;
                this.q = 0;
            } else {
                this.f825b = tVar;
                this.f824a = tVar.f;
                this.q = tVar.getWidth();
                height = tVar.getHeight();
            }
            this.r = height;
            this.o = 1073741824;
            this.p = 1073741824;
        }

        public void c(t tVar, int i, int i2) {
        }

        public int d() {
            b.j.c.b bVar = this.f824a;
            if (bVar != null) {
                return bVar.a();
            }
            return 0;
        }

        public int d(View view) {
            return view.getBottom() + ((m) view.getLayoutParams()).f835b.bottom;
        }

        public int d(w wVar) {
            return 0;
        }

        public int e(View view) {
            return view.getLeft() - ((m) view.getLayoutParams()).f835b.left;
        }

        public int e(w wVar) {
            return 0;
        }

        public int f() {
            t tVar = this.f825b;
            d adapter = tVar != null ? tVar.getAdapter() : null;
            if (adapter != null) {
                return adapter.a();
            }
            return 0;
        }

        public int f(View view) {
            Rect rect = ((m) view.getLayoutParams()).f835b;
            return view.getMeasuredHeight() + rect.top + rect.bottom;
        }

        public int f(w wVar) {
            return 0;
        }

        public void f(int i) {
        }

        public int g() {
            return b.d.k.l.g(this.f825b);
        }

        public int g(View view) {
            Rect rect = ((m) view.getLayoutParams()).f835b;
            return view.getMeasuredWidth() + rect.left + rect.right;
        }

        public void g(int i) {
            b.j.c.b bVar;
            int c2;
            View a2;
            if (c(i) == null || (a2 = ((b.j.c.u) bVar.f743a).a((c2 = (bVar = this.f824a).c(i)))) == null) {
                return;
            }
            if (bVar.f744b.d(c2)) {
                bVar.d(a2);
            }
            ((b.j.c.u) bVar.f743a).b(c2);
        }

        public void g(w wVar) {
        }

        public int h() {
            return b.d.k.l.h(this.f825b);
        }

        public int h(View view) {
            return view.getRight() + ((m) view.getLayoutParams()).f835b.right;
        }

        public void h(int i) {
        }

        public int i() {
            return b.d.k.l.i(this.f825b);
        }

        public int i(View view) {
            return view.getTop() - ((m) view.getLayoutParams()).f835b.top;
        }

        public int j() {
            t tVar = this.f825b;
            if (tVar != null) {
                return tVar.getPaddingBottom();
            }
            return 0;
        }

        public int j(View view) {
            return ((m) view.getLayoutParams()).b();
        }

        public int k() {
            t tVar = this.f825b;
            if (tVar != null) {
                return tVar.getPaddingLeft();
            }
            return 0;
        }

        public int l() {
            t tVar = this.f825b;
            if (tVar != null) {
                return tVar.getPaddingRight();
            }
            return 0;
        }

        public int m() {
            t tVar = this.f825b;
            if (tVar != null) {
                return tVar.getPaddingTop();
            }
            return 0;
        }

        public boolean n() {
            t tVar = this.f825b;
            return tVar != null && tVar.hasFocus();
        }

        public boolean o() {
            return this.j;
        }

        public boolean p() {
            v vVar = this.g;
            return vVar != null && vVar.e;
        }

        public Parcelable q() {
            return null;
        }

        public void r() {
            t tVar = this.f825b;
            if (tVar != null) {
                tVar.requestLayout();
            }
        }

        public boolean s() {
            return false;
        }

        public boolean t() {
            return false;
        }

        public final void a(View view, int i, boolean z) {
            z f = t.f(view);
            if (z || f.i()) {
                this.f825b.g.a(f);
            } else {
                this.f825b.g.c(f);
            }
            m mVar = (m) view.getLayoutParams();
            if (f.p() || f.j()) {
                if (f.j()) {
                    f.n.b(f);
                } else {
                    f.b();
                }
                this.f824a.a(view, i, view.getLayoutParams(), false);
            } else if (view.getParent() == this.f825b) {
                int b2 = this.f824a.b(view);
                if (i == -1) {
                    i = this.f824a.a();
                }
                if (b2 == -1) {
                    StringBuilder a2 = c.a.b.a.a.a("Added View has RecyclerView as parent but view is not a real child. Unfiltered index:");
                    a2.append(this.f825b.indexOfChild(view));
                    throw new IllegalStateException(c.a.b.a.a.a(this.f825b, a2));
                }
                if (b2 != i) {
                    l lVar = this.f825b.m;
                    View c2 = lVar.c(b2);
                    if (c2 != null) {
                        lVar.c(b2);
                        lVar.f824a.a(b2);
                        m mVar2 = (m) c2.getLayoutParams();
                        z f2 = t.f(c2);
                        if (f2.i()) {
                            lVar.f825b.g.a(f2);
                        } else {
                            lVar.f825b.g.c(f2);
                        }
                        lVar.f824a.a(c2, i, mVar2, f2.i());
                    } else {
                        throw new IllegalArgumentException("Cannot move a child from non-existing index:" + b2 + lVar.f825b.toString());
                    }
                }
            } else {
                this.f824a.a(view, i, false);
                mVar.f836c = true;
                v vVar = this.g;
                if (vVar != null && vVar.e && vVar.a(view) == vVar.f850a) {
                    vVar.f = view;
                }
            }
            if (mVar.f837d) {
                f.f865a.invalidate();
                mVar.f837d = false;
            }
        }

        public View b(int i) {
            int d2 = d();
            for (int i2 = 0; i2 < d2; i2++) {
                View c2 = c(i2);
                z f = t.f(c2);
                if (f != null && f.d() == i && !f.o() && (this.f825b.g0.g || !f.i())) {
                    return c2;
                }
            }
            return null;
        }

        public View c(int i) {
            b.j.c.b bVar = this.f824a;
            if (bVar == null) {
                return null;
            }
            return ((b.j.c.u) bVar.f743a).a(bVar.c(i));
        }

        public void d(int i) {
            t tVar = this.f825b;
            if (tVar != null) {
                int a2 = tVar.f.a();
                for (int i2 = 0; i2 < a2; i2++) {
                    tVar.f.b(i2).offsetLeftAndRight(i);
                }
            }
        }

        public View e() {
            View focusedChild;
            t tVar = this.f825b;
            if (tVar == null || (focusedChild = tVar.getFocusedChild()) == null || this.f824a.f745c.contains(focusedChild)) {
                return null;
            }
            return focusedChild;
        }

        public void c(r rVar) {
            int size = rVar.f844a.size();
            for (int i = size - 1; i >= 0; i--) {
                View view = rVar.f844a.get(i).f865a;
                z f = t.f(view);
                if (!f.o()) {
                    f.a(false);
                    if (f.k()) {
                        this.f825b.removeDetachedView(view, false);
                    }
                    i iVar = this.f825b.L;
                    if (iVar != null) {
                        iVar.b(f);
                    }
                    f.a(true);
                    z f2 = t.f(view);
                    f2.n = null;
                    f2.o = false;
                    f2.b();
                    rVar.a(f2);
                }
            }
            rVar.f844a.clear();
            ArrayList<z> arrayList = rVar.f845b;
            if (arrayList != null) {
                arrayList.clear();
            }
            if (size > 0) {
                this.f825b.invalidate();
            }
        }

        public void e(int i) {
            t tVar = this.f825b;
            if (tVar != null) {
                int a2 = tVar.f.a();
                for (int i2 = 0; i2 < a2; i2++) {
                    tVar.f.b(i2).offsetTopAndBottom(i);
                }
            }
        }

        public void b(View view, r rVar) {
            b.j.c.b bVar = this.f824a;
            int indexOfChild = ((b.j.c.u) bVar.f743a).f869a.indexOfChild(view);
            if (indexOfChild >= 0) {
                if (bVar.f744b.d(indexOfChild)) {
                    bVar.d(view);
                }
                ((b.j.c.u) bVar.f743a).b(indexOfChild);
            }
            rVar.a(view);
        }

        public void a(AccessibilityEvent accessibilityEvent) {
            t tVar = this.f825b;
            r rVar = tVar.f811c;
            w wVar = tVar.g0;
            if (tVar == null || accessibilityEvent == null) {
                return;
            }
            boolean z = true;
            if (!tVar.canScrollVertically(1) && !this.f825b.canScrollVertically(-1) && !this.f825b.canScrollHorizontally(-1) && !this.f825b.canScrollHorizontally(1)) {
                z = false;
            }
            accessibilityEvent.setScrollable(z);
            d dVar = this.f825b.l;
            if (dVar != null) {
                accessibilityEvent.setItemCount(dVar.a());
            }
        }

        public void a(r rVar, w wVar, b.d.k.r.b bVar) {
            if (this.f825b.canScrollVertically(-1) || this.f825b.canScrollHorizontally(-1)) {
                bVar.f640a.addAction(8192);
                bVar.f640a.setScrollable(true);
            }
            if (this.f825b.canScrollVertically(1) || this.f825b.canScrollHorizontally(1)) {
                bVar.f640a.addAction(4096);
                bVar.f640a.setScrollable(true);
            }
            bVar.f640a.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(b(rVar, wVar), a(rVar, wVar), false, 0));
        }

        /* JADX WARN: Removed duplicated region for block: B:12:0x0068 A[ADDED_TO_REGION] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public boolean a(b.j.c.t.r r2, b.j.c.t.w r3, int r4, android.os.Bundle r5) {
            /*
                r1 = this;
                b.j.c.t r2 = r1.f825b
                r3 = 0
                if (r2 != 0) goto L6
                return r3
            L6:
                r5 = 4096(0x1000, float:5.74E-42)
                r0 = 1
                if (r4 == r5) goto L3e
                r5 = 8192(0x2000, float:1.14794E-41)
                if (r4 == r5) goto L12
                r2 = 0
            L10:
                r4 = 0
                goto L66
            L12:
                r4 = -1
                boolean r2 = r2.canScrollVertically(r4)
                if (r2 == 0) goto L27
                int r2 = r1.r
                int r5 = r1.m()
                int r2 = r2 - r5
                int r5 = r1.j()
                int r2 = r2 - r5
                int r2 = -r2
                goto L28
            L27:
                r2 = 0
            L28:
                b.j.c.t r5 = r1.f825b
                boolean r4 = r5.canScrollHorizontally(r4)
                if (r4 == 0) goto L10
                int r4 = r1.q
                int r5 = r1.k()
                int r4 = r4 - r5
                int r5 = r1.l()
                int r4 = r4 - r5
                int r4 = -r4
                goto L66
            L3e:
                boolean r2 = r2.canScrollVertically(r0)
                if (r2 == 0) goto L51
                int r2 = r1.r
                int r4 = r1.m()
                int r2 = r2 - r4
                int r4 = r1.j()
                int r2 = r2 - r4
                goto L52
            L51:
                r2 = 0
            L52:
                b.j.c.t r4 = r1.f825b
                boolean r4 = r4.canScrollHorizontally(r0)
                if (r4 == 0) goto L10
                int r4 = r1.q
                int r5 = r1.k()
                int r4 = r4 - r5
                int r5 = r1.l()
                int r4 = r4 - r5
            L66:
                if (r2 != 0) goto L6b
                if (r4 != 0) goto L6b
                return r3
            L6b:
                b.j.c.t r3 = r1.f825b
                r3.d(r4, r2)
                return r0
            */
            throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.l.a(b.j.c.t$r, b.j.c.t$w, int, android.os.Bundle):boolean");
        }

        /* JADX WARN: Code restructure failed: missing block: B:12:0x00b3, code lost:
        
            if (r14 == false) goto L33;
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public boolean a(b.j.c.t r10, android.view.View r11, android.graphics.Rect r12, boolean r13, boolean r14) {
            /*
                r9 = this;
                r0 = 2
                int[] r0 = new int[r0]
                int r1 = r9.k()
                int r2 = r9.m()
                int r3 = r9.q
                int r4 = r9.l()
                int r3 = r3 - r4
                int r4 = r9.r
                int r5 = r9.j()
                int r4 = r4 - r5
                int r5 = r11.getLeft()
                int r6 = r12.left
                int r5 = r5 + r6
                int r6 = r11.getScrollX()
                int r5 = r5 - r6
                int r6 = r11.getTop()
                int r7 = r12.top
                int r6 = r6 + r7
                int r11 = r11.getScrollY()
                int r6 = r6 - r11
                int r11 = r12.width()
                int r11 = r11 + r5
                int r12 = r12.height()
                int r12 = r12 + r6
                int r5 = r5 - r1
                r1 = 0
                int r7 = java.lang.Math.min(r1, r5)
                int r6 = r6 - r2
                int r2 = java.lang.Math.min(r1, r6)
                int r11 = r11 - r3
                int r3 = java.lang.Math.max(r1, r11)
                int r12 = r12 - r4
                int r12 = java.lang.Math.max(r1, r12)
                int r4 = r9.g()
                r8 = 1
                if (r4 != r8) goto L5f
                if (r3 == 0) goto L5a
                goto L67
            L5a:
                int r3 = java.lang.Math.max(r7, r11)
                goto L67
            L5f:
                if (r7 == 0) goto L62
                goto L66
            L62:
                int r7 = java.lang.Math.min(r5, r3)
            L66:
                r3 = r7
            L67:
                if (r2 == 0) goto L6a
                goto L6e
            L6a:
                int r2 = java.lang.Math.min(r6, r12)
            L6e:
                r0[r1] = r3
                r0[r8] = r2
                r11 = r0[r1]
                r12 = r0[r8]
                if (r14 == 0) goto Lb5
                android.view.View r14 = r10.getFocusedChild()
                if (r14 != 0) goto L80
            L7e:
                r14 = 0
                goto Lb3
            L80:
                int r0 = r9.k()
                int r2 = r9.m()
                int r3 = r9.q
                int r4 = r9.l()
                int r3 = r3 - r4
                int r4 = r9.r
                int r5 = r9.j()
                int r4 = r4 - r5
                b.j.c.t r5 = r9.f825b
                android.graphics.Rect r5 = r5.i
                r9.b(r14, r5)
                int r14 = r5.left
                int r14 = r14 - r11
                if (r14 >= r3) goto L7e
                int r14 = r5.right
                int r14 = r14 - r11
                if (r14 <= r0) goto L7e
                int r14 = r5.top
                int r14 = r14 - r12
                if (r14 >= r4) goto L7e
                int r14 = r5.bottom
                int r14 = r14 - r12
                if (r14 > r2) goto Lb2
                goto L7e
            Lb2:
                r14 = 1
            Lb3:
                if (r14 == 0) goto Lba
            Lb5:
                if (r11 != 0) goto Lbb
                if (r12 == 0) goto Lba
                goto Lbb
            Lba:
                return r1
            Lbb:
                if (r13 == 0) goto Lc1
                r10.scrollBy(r11, r12)
                goto Lc4
            Lc1:
                r10.d(r11, r12)
            Lc4:
                return r8
            */
            throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.l.a(b.j.c.t, android.view.View, android.graphics.Rect, boolean, boolean):boolean");
        }

        public final void a(r rVar, int i, View view) {
            z f = t.f(view);
            if (f.o()) {
                return;
            }
            if (f.g() && !f.i() && !this.f825b.l.f816b) {
                g(i);
                rVar.a(f);
            } else {
                c(i);
                this.f824a.a(i);
                rVar.b(view);
                this.f825b.g.c(f);
            }
        }

        public void a(Rect rect, int i, int i2) {
            int l = l() + k() + rect.width();
            int j = j() + m() + rect.height();
            this.f825b.setMeasuredDimension(a(i, l, i()), a(i2, j, h()));
        }
    }

    /* loaded from: classes.dex */
    public static class m extends ViewGroup.MarginLayoutParams {

        /* renamed from: a, reason: collision with root package name */
        public z f834a;

        /* renamed from: b, reason: collision with root package name */
        public final Rect f835b;

        /* renamed from: c, reason: collision with root package name */
        public boolean f836c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f837d;

        public m(int i, int i2) {
            super(i, i2);
            this.f835b = new Rect();
            this.f836c = true;
            this.f837d = false;
        }

        public m(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f835b = new Rect();
            this.f836c = true;
            this.f837d = false;
        }

        public m(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
            this.f835b = new Rect();
            this.f836c = true;
            this.f837d = false;
        }

        public m(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
            this.f835b = new Rect();
            this.f836c = true;
            this.f837d = false;
        }

        public m(m mVar) {
            super((ViewGroup.LayoutParams) mVar);
            this.f835b = new Rect();
            this.f836c = true;
            this.f837d = false;
        }

        public int a() {
            return this.f834a.c();
        }

        public int b() {
            return this.f834a.d();
        }

        public boolean c() {
            return this.f834a.l();
        }

        public boolean d() {
            return this.f834a.i();
        }
    }

    /* loaded from: classes.dex */
    public static abstract class n {
    }

    /* loaded from: classes.dex */
    public interface o {
        void a(boolean z);

        boolean a(t tVar, MotionEvent motionEvent);

        void b(t tVar, MotionEvent motionEvent);
    }

    /* loaded from: classes.dex */
    public static abstract class p {
        public void a(t tVar, int i, int i2) {
        }
    }

    /* loaded from: classes.dex */
    public static class q {

        /* renamed from: a, reason: collision with root package name */
        public SparseArray<a> f838a = new SparseArray<>();

        /* renamed from: b, reason: collision with root package name */
        public int f839b = 0;

        /* loaded from: classes.dex */
        public static class a {

            /* renamed from: a, reason: collision with root package name */
            public final ArrayList<z> f840a = new ArrayList<>();

            /* renamed from: b, reason: collision with root package name */
            public int f841b = 5;

            /* renamed from: c, reason: collision with root package name */
            public long f842c = 0;

            /* renamed from: d, reason: collision with root package name */
            public long f843d = 0;
        }

        public long a(long j, long j2) {
            if (j == 0) {
                return j2;
            }
            return (j2 / 4) + ((j / 4) * 3);
        }

        public final a a(int i) {
            a aVar = this.f838a.get(i);
            if (aVar != null) {
                return aVar;
            }
            a aVar2 = new a();
            this.f838a.put(i, aVar2);
            return aVar2;
        }
    }

    /* loaded from: classes.dex */
    public final class r {

        /* renamed from: a, reason: collision with root package name */
        public final ArrayList<z> f844a = new ArrayList<>();

        /* renamed from: b, reason: collision with root package name */
        public ArrayList<z> f845b = null;

        /* renamed from: c, reason: collision with root package name */
        public final ArrayList<z> f846c = new ArrayList<>();

        /* renamed from: d, reason: collision with root package name */
        public final List<z> f847d = Collections.unmodifiableList(this.f844a);
        public int e = 2;
        public int f = 2;
        public q g;

        public r() {
        }

        public void a() {
            this.f844a.clear();
            c();
        }

        public final void a(ViewGroup viewGroup, boolean z) {
            for (int childCount = viewGroup.getChildCount() - 1; childCount >= 0; childCount--) {
                View childAt = viewGroup.getChildAt(childCount);
                if (childAt instanceof ViewGroup) {
                    a((ViewGroup) childAt, true);
                }
            }
            if (z) {
                if (viewGroup.getVisibility() == 4) {
                    viewGroup.setVisibility(0);
                    viewGroup.setVisibility(4);
                } else {
                    int visibility = viewGroup.getVisibility();
                    viewGroup.setVisibility(4);
                    viewGroup.setVisibility(visibility);
                }
            }
        }

        public void a(z zVar, boolean z) {
            t.d(zVar);
            if (zVar.b(16384)) {
                zVar.a(0, 16384);
                b.d.k.l.a(zVar.f865a, (b.d.k.a) null);
            }
            if (z) {
                s sVar = t.this.n;
                if (sVar != null) {
                    ((a.C0024a) sVar).a(zVar);
                }
                d dVar = t.this.l;
                t tVar = t.this;
                if (tVar.g0 != null) {
                    tVar.g.d(zVar);
                }
            }
            zVar.r = null;
            q b2 = b();
            if (b2 != null) {
                int i = zVar.f;
                ArrayList<z> arrayList = b2.a(i).f840a;
                if (b2.f838a.get(i).f841b <= arrayList.size()) {
                    return;
                }
                zVar.n();
                arrayList.add(zVar);
                return;
            }
            throw null;
        }

        public View b(int i) {
            return a(i, false, Long.MAX_VALUE).f865a;
        }

        public q b() {
            if (this.g == null) {
                this.g = new q();
            }
            return this.g;
        }

        public void b(z zVar) {
            (zVar.o ? this.f845b : this.f844a).remove(zVar);
            zVar.n = null;
            zVar.o = false;
            zVar.b();
        }

        public void c() {
            for (int size = this.f846c.size() - 1; size >= 0; size--) {
                c(size);
            }
            this.f846c.clear();
            if (t.C0) {
                m.b bVar = t.this.f0;
                int[] iArr = bVar.f796c;
                if (iArr != null) {
                    Arrays.fill(iArr, -1);
                }
                bVar.f797d = 0;
            }
        }

        public void c(int i) {
            a(this.f846c.get(i), true);
            this.f846c.remove(i);
        }

        public void d() {
            l lVar = t.this.m;
            this.f = this.e + (lVar != null ? lVar.m : 0);
            for (int size = this.f846c.size() - 1; size >= 0 && this.f846c.size() > this.f; size--) {
                c(size);
            }
        }

        public void b(View view) {
            ArrayList<z> arrayList;
            z f = t.f(view);
            if (!f.b(12) && f.l()) {
                i iVar = t.this.L;
                if (!(iVar == null || iVar.a(f, f.e()))) {
                    if (this.f845b == null) {
                        this.f845b = new ArrayList<>();
                    }
                    f.n = this;
                    f.o = true;
                    arrayList = this.f845b;
                    arrayList.add(f);
                }
            }
            if (f.g() && !f.i() && !t.this.l.f816b) {
                throw new IllegalArgumentException(c.a.b.a.a.a(t.this, c.a.b.a.a.a("Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool.")));
            }
            f.n = this;
            f.o = false;
            arrayList = this.f844a;
            arrayList.add(f);
        }

        public int a(int i) {
            if (i >= 0 && i < t.this.g0.a()) {
                t tVar = t.this;
                return !tVar.g0.g ? i : tVar.e.a(i, 0);
            }
            StringBuilder sb = new StringBuilder();
            sb.append("invalid position ");
            sb.append(i);
            sb.append(". State ");
            sb.append("item count is ");
            sb.append(t.this.g0.a());
            throw new IndexOutOfBoundsException(c.a.b.a.a.a(t.this, sb));
        }

        public void a(View view) {
            z f = t.f(view);
            if (f.k()) {
                t.this.removeDetachedView(view, false);
            }
            if (f.j()) {
                f.n.b(f);
            } else if (f.p()) {
                f.b();
            }
            a(f);
        }

        /* JADX WARN: Code restructure failed: missing block: B:34:0x006f, code lost:
        
            if (r6.h.f0.a(r7.f867c) == false) goto L38;
         */
        /* JADX WARN: Code restructure failed: missing block: B:35:0x0071, code lost:
        
            r3 = r3 - 1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:36:0x0073, code lost:
        
            if (r3 < 0) goto L63;
         */
        /* JADX WARN: Code restructure failed: missing block: B:38:0x0087, code lost:
        
            if (r6.h.f0.a(r6.f846c.get(r3).f867c) != false) goto L65;
         */
        /* JADX WARN: Code restructure failed: missing block: B:40:0x0089, code lost:
        
            r3 = r3 + 1;
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void a(b.j.c.t.z r7) {
            /*
                Method dump skipped, instructions count: 254
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.r.a(b.j.c.t$z):void");
        }

        /*  JADX ERROR: NullPointerException in pass: LoopRegionVisitor
            java.lang.NullPointerException: Cannot invoke "jadx.core.dex.instructions.args.SSAVar.use(jadx.core.dex.instructions.args.RegisterArg)" because "ssaVar" is null
            	at jadx.core.dex.nodes.InsnNode.rebindArgs(InsnNode.java:489)
            	at jadx.core.dex.nodes.InsnNode.rebindArgs(InsnNode.java:492)
            */
        /* JADX WARN: Code restructure failed: missing block: B:172:0x02e2, code lost:
        
            r9 = null;
         */
        /* JADX WARN: Code restructure failed: missing block: B:271:0x0474, code lost:
        
            if ((r5 == 0 || r5 + r12 < r20) == false) goto L255;
         */
        /* JADX WARN: Code restructure failed: missing block: B:62:0x01dc, code lost:
        
            if (r9.f != 0) goto L120;
         */
        /* JADX WARN: Removed duplicated region for block: B:130:0x023d  */
        /* JADX WARN: Removed duplicated region for block: B:20:0x0086  */
        /* JADX WARN: Removed duplicated region for block: B:237:0x0411  */
        /* JADX WARN: Removed duplicated region for block: B:23:0x008d  */
        /* JADX WARN: Removed duplicated region for block: B:246:0x055b  */
        /* JADX WARN: Removed duplicated region for block: B:250:0x057e A[ADDED_TO_REGION] */
        /* JADX WARN: Removed duplicated region for block: B:254:0x0562  */
        /* JADX WARN: Removed duplicated region for block: B:266:0x045d  */
        /* JADX WARN: Removed duplicated region for block: B:275:0x047f  */
        /* JADX WARN: Removed duplicated region for block: B:317:0x0584  */
        /* JADX WARN: Removed duplicated region for block: B:39:0x01b3  */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public b.j.c.t.z a(int r18, boolean r19, long r20) {
            /*
                Method dump skipped, instructions count: 1462
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.r.a(int, boolean, long):b.j.c.t$z");
        }
    }

    /* loaded from: classes.dex */
    public interface s {
    }

    /* renamed from: b.j.c.t$t, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class C0029t extends f {
        public C0029t() {
        }
    }

    /* loaded from: classes.dex */
    public static class u extends b.f.a.a {
        public static final Parcelable.Creator<u> CREATOR = new a();

        /* renamed from: d, reason: collision with root package name */
        public Parcelable f849d;

        /* loaded from: classes.dex */
        public static class a implements Parcelable.ClassLoaderCreator<u> {
            @Override // android.os.Parcelable.Creator
            public Object createFromParcel(Parcel parcel) {
                return new u(parcel, null);
            }

            @Override // android.os.Parcelable.Creator
            public Object[] newArray(int i) {
                return new u[i];
            }

            @Override // android.os.Parcelable.ClassLoaderCreator
            public u createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return new u(parcel, classLoader);
            }
        }

        public u(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f849d = parcel.readParcelable(classLoader == null ? l.class.getClassLoader() : classLoader);
        }

        public u(Parcelable parcelable) {
            super(parcelable);
        }

        @Override // b.f.a.a, android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeParcelable(this.f669b, i);
            parcel.writeParcelable(this.f849d, 0);
        }
    }

    /* loaded from: classes.dex */
    public static class w {

        /* renamed from: a, reason: collision with root package name */
        public int f858a = -1;

        /* renamed from: b, reason: collision with root package name */
        public int f859b = 0;

        /* renamed from: c, reason: collision with root package name */
        public int f860c = 0;

        /* renamed from: d, reason: collision with root package name */
        public int f861d = 1;
        public int e = 0;
        public boolean f = false;
        public boolean g = false;
        public boolean h = false;
        public boolean i = false;
        public boolean j = false;
        public boolean k = false;
        public int l;
        public long m;
        public int n;
        public int o;
        public int p;

        public int a() {
            return this.g ? this.f859b - this.f860c : this.e;
        }

        public void a(int i) {
            if ((this.f861d & i) != 0) {
                return;
            }
            StringBuilder a2 = c.a.b.a.a.a("Layout state should be one of ");
            a2.append(Integer.toBinaryString(i));
            a2.append(" but it is ");
            a2.append(Integer.toBinaryString(this.f861d));
            throw new IllegalStateException(a2.toString());
        }

        public String toString() {
            StringBuilder a2 = c.a.b.a.a.a("State{mTargetPosition=");
            a2.append(this.f858a);
            a2.append(", mData=");
            a2.append((Object) null);
            a2.append(", mItemCount=");
            a2.append(this.e);
            a2.append(", mIsMeasuring=");
            a2.append(this.i);
            a2.append(", mPreviousLayoutItemCount=");
            a2.append(this.f859b);
            a2.append(", mDeletedInvisibleItemCountSincePreviousLayout=");
            a2.append(this.f860c);
            a2.append(", mStructureChanged=");
            a2.append(this.f);
            a2.append(", mInPreLayout=");
            a2.append(this.g);
            a2.append(", mRunSimpleAnimations=");
            a2.append(this.j);
            a2.append(", mRunPredictiveAnimations=");
            a2.append(this.k);
            a2.append('}');
            return a2.toString();
        }
    }

    /* loaded from: classes.dex */
    public static abstract class x {
    }

    /* loaded from: classes.dex */
    public class y implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public int f862b;

        /* renamed from: c, reason: collision with root package name */
        public int f863c;

        /* renamed from: d, reason: collision with root package name */
        public OverScroller f864d;
        public Interpolator e = t.G0;
        public boolean f = false;
        public boolean g = false;

        public y() {
            this.f864d = new OverScroller(t.this.getContext(), t.G0);
        }

        public final int a(int i, int i2, int i3, int i4) {
            int i5;
            int abs = Math.abs(i);
            int abs2 = Math.abs(i2);
            boolean z = abs > abs2;
            int sqrt = (int) Math.sqrt((i4 * i4) + (i3 * i3));
            int sqrt2 = (int) Math.sqrt((i2 * i2) + (i * i));
            t tVar = t.this;
            int width = z ? tVar.getWidth() : tVar.getHeight();
            int i6 = width / 2;
            float f = width;
            float f2 = i6;
            float sin = (((float) Math.sin((Math.min(1.0f, (sqrt2 * 1.0f) / f) - 0.5f) * 0.47123894f)) * f2) + f2;
            if (sqrt > 0) {
                i5 = Math.round(Math.abs(sin / sqrt) * 1000.0f) * 4;
            } else {
                if (!z) {
                    abs = abs2;
                }
                i5 = (int) (((abs / f) + 1.0f) * 300.0f);
            }
            return Math.min(i5, 2000);
        }

        public void a() {
            if (this.f) {
                this.g = true;
            } else {
                t.this.removeCallbacks(this);
                b.d.k.l.a(t.this, this);
            }
        }

        public void a(int i, int i2, int i3, Interpolator interpolator) {
            if (this.e != interpolator) {
                this.e = interpolator;
                this.f864d = new OverScroller(t.this.getContext(), interpolator);
            }
            t.this.setScrollState(2);
            this.f863c = 0;
            this.f862b = 0;
            this.f864d.startScroll(0, 0, i, i2, i3);
            if (Build.VERSION.SDK_INT < 23) {
                this.f864d.computeScrollOffset();
            }
            a();
        }

        /* JADX WARN: Code restructure failed: missing block: B:69:0x00e0, code lost:
        
            if (r9 > 0) goto L50;
         */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:41:0x00dc  */
        /* JADX WARN: Removed duplicated region for block: B:45:0x00ec  */
        /* JADX WARN: Removed duplicated region for block: B:61:0x0128 A[ADDED_TO_REGION] */
        /* JADX WARN: Type inference failed for: r2v1 */
        /* JADX WARN: Type inference failed for: r2v10 */
        /* JADX WARN: Type inference failed for: r2v12 */
        /* JADX WARN: Type inference failed for: r2v2, types: [int, boolean] */
        @Override // java.lang.Runnable
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public void run() {
            /*
                Method dump skipped, instructions count: 473
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.y.run():void");
        }
    }

    /* loaded from: classes.dex */
    public static abstract class z {
        public static final List<Object> s = Collections.emptyList();

        /* renamed from: a, reason: collision with root package name */
        public final View f865a;

        /* renamed from: b, reason: collision with root package name */
        public WeakReference<t> f866b;
        public int j;
        public t r;

        /* renamed from: c, reason: collision with root package name */
        public int f867c = -1;

        /* renamed from: d, reason: collision with root package name */
        public int f868d = -1;
        public long e = -1;
        public int f = -1;
        public int g = -1;
        public z h = null;
        public z i = null;
        public List<Object> k = null;
        public List<Object> l = null;
        public int m = 0;
        public r n = null;
        public boolean o = false;
        public int p = 0;
        public int q = -1;

        public z(View view) {
            if (view == null) {
                throw new IllegalArgumentException("itemView may not be null");
            }
            this.f865a = view;
        }

        public void a() {
            this.f868d = -1;
            this.g = -1;
        }

        public void a(int i) {
            this.j = i | this.j;
        }

        public void a(int i, int i2) {
            this.j = (i & i2) | (this.j & (~i2));
        }

        public void a(int i, boolean z) {
            if (this.f868d == -1) {
                this.f868d = this.f867c;
            }
            if (this.g == -1) {
                this.g = this.f867c;
            }
            if (z) {
                this.g += i;
            }
            this.f867c += i;
            if (this.f865a.getLayoutParams() != null) {
                ((m) this.f865a.getLayoutParams()).f836c = true;
            }
        }

        public void a(Object obj) {
            if (obj == null) {
                a(1024);
                return;
            }
            if ((1024 & this.j) == 0) {
                if (this.k == null) {
                    ArrayList arrayList = new ArrayList();
                    this.k = arrayList;
                    this.l = Collections.unmodifiableList(arrayList);
                }
                this.k.add(obj);
            }
        }

        public final void a(boolean z) {
            int i;
            int i2 = this.m;
            int i3 = z ? i2 - 1 : i2 + 1;
            this.m = i3;
            if (i3 < 0) {
                this.m = 0;
                Log.e("View", "isRecyclable decremented below 0: unmatched pair of setIsRecyable() calls for " + this);
                return;
            }
            if (!z && i3 == 1) {
                i = this.j | 16;
            } else if (!z || this.m != 0) {
                return;
            } else {
                i = this.j & (-17);
            }
            this.j = i;
        }

        public void b() {
            this.j &= -33;
        }

        public boolean b(int i) {
            return (i & this.j) != 0;
        }

        public final int c() {
            t tVar = this.r;
            if (tVar == null) {
                return -1;
            }
            return tVar.b(this);
        }

        public final int d() {
            int i = this.g;
            return i == -1 ? this.f867c : i;
        }

        public List<Object> e() {
            if ((this.j & 1024) != 0) {
                return s;
            }
            List<Object> list = this.k;
            return (list == null || list.size() == 0) ? s : this.l;
        }

        public boolean f() {
            return (this.j & 1) != 0;
        }

        public boolean g() {
            return (this.j & 4) != 0;
        }

        public final boolean h() {
            return (this.j & 16) == 0 && !b.d.k.l.k(this.f865a);
        }

        public boolean i() {
            return (this.j & 8) != 0;
        }

        public boolean j() {
            return this.n != null;
        }

        public boolean k() {
            return (this.j & 256) != 0;
        }

        public boolean l() {
            return (this.j & 2) != 0;
        }

        public boolean m() {
            return (this.j & 2) != 0;
        }

        public void n() {
            this.j = 0;
            this.f867c = -1;
            this.f868d = -1;
            this.e = -1L;
            this.g = -1;
            this.m = 0;
            this.h = null;
            this.i = null;
            List<Object> list = this.k;
            if (list != null) {
                list.clear();
            }
            this.j &= -1025;
            this.p = 0;
            this.q = -1;
            t.d(this);
        }

        public boolean o() {
            return (this.j & 128) != 0;
        }

        public boolean p() {
            return (this.j & 32) != 0;
        }

        public String toString() {
            StringBuilder a2 = c.a.b.a.a.a("ViewHolder{");
            a2.append(Integer.toHexString(hashCode()));
            a2.append(" position=");
            a2.append(this.f867c);
            a2.append(" id=");
            a2.append(this.e);
            a2.append(", oldPos=");
            a2.append(this.f868d);
            a2.append(", pLpos:");
            a2.append(this.g);
            StringBuilder sb = new StringBuilder(a2.toString());
            if (j()) {
                sb.append(" scrap ");
                sb.append(this.o ? "[changeScrap]" : "[attachedScrap]");
            }
            if (g()) {
                sb.append(" invalid");
            }
            if (!f()) {
                sb.append(" unbound");
            }
            if (m()) {
                sb.append(" update");
            }
            if (i()) {
                sb.append(" removed");
            }
            if (o()) {
                sb.append(" ignored");
            }
            if (k()) {
                sb.append(" tmpDetached");
            }
            if (!h()) {
                StringBuilder a3 = c.a.b.a.a.a(" not recyclable(");
                a3.append(this.m);
                a3.append(")");
                sb.append(a3.toString());
            }
            if ((this.j & IMediaList.Event.ItemAdded) != 0 || g()) {
                sb.append(" undefined adapter position");
            }
            if (this.f865a.getParent() == null) {
                sb.append(" no parent");
            }
            sb.append("}");
            return sb.toString();
        }
    }

    static {
        B0 = Build.VERSION.SDK_INT >= 23;
        C0 = true;
        D0 = false;
        E0 = false;
        Class<?> cls = Integer.TYPE;
        F0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        G0 = new b();
    }

    public t(Context context) {
        this(context, null);
    }

    public t(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    /* JADX WARN: Can't wrap try/catch for region: R(8:(1:40)(10:78|(1:80)|42|43|44|(1:46)(1:62)|47|48|49|50)|43|44|(0)(0)|47|48|49|50) */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x0268, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:55:0x026a, code lost:
    
        r0 = r3.getConstructor(new java.lang.Class[0]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x0270, code lost:
    
        r4 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:58:0x0280, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x0281, code lost:
    
        r0.initCause(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x02a1, code lost:
    
        throw new java.lang.IllegalStateException(r22.getPositionDescription() + ": Error creating LayoutManager " + r2, r0);
     */
    /* JADX WARN: Removed duplicated region for block: B:46:0x0236 A[Catch: ClassCastException -> 0x02a2, IllegalAccessException -> 0x02c1, InstantiationException -> 0x02e0, InvocationTargetException -> 0x02fd, ClassNotFoundException -> 0x031a, TryCatch #4 {ClassCastException -> 0x02a2, ClassNotFoundException -> 0x031a, IllegalAccessException -> 0x02c1, InstantiationException -> 0x02e0, InvocationTargetException -> 0x02fd, blocks: (B:44:0x0230, B:46:0x0236, B:47:0x0243, B:49:0x024d, B:50:0x0272, B:55:0x026a, B:59:0x0281, B:60:0x02a1, B:62:0x023f), top: B:43:0x0230 }] */
    /* JADX WARN: Removed duplicated region for block: B:62:0x023f A[Catch: ClassCastException -> 0x02a2, IllegalAccessException -> 0x02c1, InstantiationException -> 0x02e0, InvocationTargetException -> 0x02fd, ClassNotFoundException -> 0x031a, TryCatch #4 {ClassCastException -> 0x02a2, ClassNotFoundException -> 0x031a, IllegalAccessException -> 0x02c1, InstantiationException -> 0x02e0, InvocationTargetException -> 0x02fd, blocks: (B:44:0x0230, B:46:0x0236, B:47:0x0243, B:49:0x024d, B:50:0x0272, B:55:0x026a, B:59:0x0281, B:60:0x02a1, B:62:0x023f), top: B:43:0x0230 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public t(android.content.Context r21, android.util.AttributeSet r22, int r23) {
        /*
            Method dump skipped, instructions count: 846
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.<init>(android.content.Context, android.util.AttributeSet, int):void");
    }

    public static void a(View view, Rect rect) {
        m mVar = (m) view.getLayoutParams();
        Rect rect2 = mVar.f835b;
        rect.set((view.getLeft() - rect2.left) - ((ViewGroup.MarginLayoutParams) mVar).leftMargin, (view.getTop() - rect2.top) - ((ViewGroup.MarginLayoutParams) mVar).topMargin, view.getRight() + rect2.right + ((ViewGroup.MarginLayoutParams) mVar).rightMargin, view.getBottom() + rect2.bottom + ((ViewGroup.MarginLayoutParams) mVar).bottomMargin);
    }

    public static void d(z zVar) {
        WeakReference<t> weakReference = zVar.f866b;
        if (weakReference != null) {
            Object obj = weakReference.get();
            while (true) {
                for (View view = (View) obj; view != null; view = null) {
                    if (view == zVar.f865a) {
                        return;
                    }
                    obj = view.getParent();
                    if (obj instanceof View) {
                        break;
                    }
                }
                zVar.f866b = null;
                return;
            }
        }
    }

    public static t e(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof t) {
            return (t) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            t e2 = e(viewGroup.getChildAt(i2));
            if (e2 != null) {
                return e2;
            }
        }
        return null;
    }

    public static z f(View view) {
        if (view == null) {
            return null;
        }
        return ((m) view.getLayoutParams()).f834a;
    }

    private b.d.k.e getScrollingChildHelper() {
        if (this.q0 == null) {
            this.q0 = new b.d.k.e(this);
        }
        return this.q0;
    }

    public z a(int i2) {
        z zVar = null;
        if (this.C) {
            return null;
        }
        int b2 = this.f.b();
        for (int i3 = 0; i3 < b2; i3++) {
            z f2 = f(this.f.d(i3));
            if (f2 != null && !f2.i() && b(f2) == i2) {
                if (!this.f.c(f2.f865a)) {
                    return f2;
                }
                zVar = f2;
            }
        }
        return zVar;
    }

    public final void a() {
        t();
        setScrollState(0);
    }

    public void a(int i2, int i3) {
        boolean z2;
        EdgeEffect edgeEffect = this.H;
        if (edgeEffect == null || edgeEffect.isFinished() || i2 <= 0) {
            z2 = false;
        } else {
            this.H.onRelease();
            z2 = this.H.isFinished();
        }
        EdgeEffect edgeEffect2 = this.J;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i2 < 0) {
            this.J.onRelease();
            z2 |= this.J.isFinished();
        }
        EdgeEffect edgeEffect3 = this.I;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i3 > 0) {
            this.I.onRelease();
            z2 |= this.I.isFinished();
        }
        EdgeEffect edgeEffect4 = this.K;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i3 < 0) {
            this.K.onRelease();
            z2 |= this.K.isFinished();
        }
        if (z2) {
            b.d.k.l.n(this);
        }
    }

    public final void a(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.N) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.N = motionEvent.getPointerId(i2);
            int x2 = (int) (motionEvent.getX(i2) + 0.5f);
            this.R = x2;
            this.P = x2;
            int y2 = (int) (motionEvent.getY(i2) + 0.5f);
            this.S = y2;
            this.Q = y2;
        }
    }

    public final void a(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        this.i.set(0, 0, view3.getWidth(), view3.getHeight());
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof m) {
            m mVar = (m) layoutParams;
            if (!mVar.f836c) {
                Rect rect = mVar.f835b;
                Rect rect2 = this.i;
                rect2.left -= rect.left;
                rect2.right += rect.right;
                rect2.top -= rect.top;
                rect2.bottom += rect.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, this.i);
            offsetRectIntoDescendantCoords(view, this.i);
        }
        this.m.a(this, view, this.i, !this.u, view2 == null);
    }

    public final void a(w wVar) {
        if (getScrollState() != 2) {
            wVar.o = 0;
            wVar.p = 0;
        } else {
            OverScroller overScroller = this.d0.f864d;
            wVar.o = overScroller.getFinalX() - overScroller.getCurrX();
            wVar.p = overScroller.getFinalY() - overScroller.getCurrY();
        }
    }

    public final void a(z zVar) {
        View view = zVar.f865a;
        boolean z2 = view.getParent() == this;
        this.f811c.b(c(view));
        if (zVar.k()) {
            this.f.a(view, -1, view.getLayoutParams(), true);
            return;
        }
        b.j.c.b bVar = this.f;
        if (!z2) {
            bVar.a(view, -1, true);
            return;
        }
        int indexOfChild = ((b.j.c.u) bVar.f743a).f869a.indexOfChild(view);
        if (indexOfChild >= 0) {
            bVar.f744b.e(indexOfChild);
            bVar.a(view);
        } else {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        }
    }

    public void a(String str) {
        if (n()) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException(c.a.b.a.a.a(this, c.a.b.a.a.a("Cannot call this method while RecyclerView is computing a layout or scrolling")));
        }
        if (this.F > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(c.a.b.a.a.a(this, c.a.b.a.a.a(""))));
        }
    }

    public final void a(int[] iArr) {
        int a2 = this.f.a();
        if (a2 == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i2 = Integer.MAX_VALUE;
        int i3 = Integer.MIN_VALUE;
        for (int i4 = 0; i4 < a2; i4++) {
            z f2 = f(this.f.b(i4));
            if (!f2.o()) {
                int d2 = f2.d();
                if (d2 < i2) {
                    i2 = d2;
                }
                if (d2 > i3) {
                    i3 = d2;
                }
            }
        }
        iArr[0] = i2;
        iArr[1] = i3;
    }

    public boolean a(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return getScrollingChildHelper().a(i2, i3, iArr, iArr2, i4);
    }

    public boolean a(z zVar, int i2) {
        if (!n()) {
            b.d.k.l.a(zVar.f865a, i2);
            return true;
        }
        zVar.q = i2;
        this.v0.add(zVar);
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void addFocusables(ArrayList<View> arrayList, int i2, int i3) {
        l lVar = this.m;
        if (lVar == null || !lVar.a(this, arrayList, i2, i3)) {
            super.addFocusables(arrayList, i2, i3);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:?, code lost:
    
        return r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.view.View b(android.view.View r3) {
        /*
            r2 = this;
        L0:
            android.view.ViewParent r0 = r3.getParent()
            if (r0 == 0) goto L10
            if (r0 == r2) goto L10
            boolean r1 = r0 instanceof android.view.View
            if (r1 == 0) goto L10
            r3 = r0
            android.view.View r3 = (android.view.View) r3
            goto L0
        L10:
            if (r0 != r2) goto L13
            goto L14
        L13:
            r3 = 0
        L14:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.b(android.view.View):android.view.View");
    }

    public void b() {
        int b2 = this.f.b();
        for (int i2 = 0; i2 < b2; i2++) {
            z f2 = f(this.f.d(i2));
            if (!f2.o()) {
                f2.a();
            }
        }
        r rVar = this.f811c;
        int size = rVar.f846c.size();
        for (int i3 = 0; i3 < size; i3++) {
            rVar.f846c.get(i3).a();
        }
        int size2 = rVar.f844a.size();
        for (int i4 = 0; i4 < size2; i4++) {
            rVar.f844a.get(i4).a();
        }
        ArrayList<z> arrayList = rVar.f845b;
        if (arrayList != null) {
            int size3 = arrayList.size();
            for (int i5 = 0; i5 < size3; i5++) {
                rVar.f845b.get(i5).a();
            }
        }
    }

    public z c(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return f(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public void c() {
        if (!this.u || this.C) {
            Trace.beginSection("RV FullInvalidate");
            d();
            Trace.endSection();
            return;
        }
        if (this.e.c()) {
            boolean z2 = false;
            if ((this.e.g & 4) != 0) {
                if (!((this.e.g & 11) != 0)) {
                    Trace.beginSection("RV PartialInvalidate");
                    u();
                    p();
                    this.e.d();
                    if (!this.w) {
                        int a2 = this.f.a();
                        int i2 = 0;
                        while (true) {
                            if (i2 < a2) {
                                z f2 = f(this.f.b(i2));
                                if (f2 != null && !f2.o() && f2.l()) {
                                    z2 = true;
                                    break;
                                }
                                i2++;
                            } else {
                                break;
                            }
                        }
                        if (z2) {
                            d();
                        } else {
                            this.e.a();
                        }
                    }
                    c(true);
                    a(true);
                    Trace.endSection();
                }
            }
            if (this.e.c()) {
                Trace.beginSection("RV FullInvalidate");
                d();
                Trace.endSection();
            }
        }
    }

    public void c(int i2) {
        l lVar = this.m;
        if (lVar == null) {
            return;
        }
        lVar.h(i2);
        awakenScrollBars();
    }

    public void c(int i2, int i3) {
        this.F++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX, scrollY);
        p pVar = this.h0;
        if (pVar != null) {
            pVar.a(this, i2, i3);
        }
        List<p> list = this.i0;
        if (list != null) {
            for (int size = list.size() - 1; size >= 0; size--) {
                this.i0.get(size).a(this, i2, i3);
            }
        }
        this.F--;
    }

    public void c(boolean z2) {
        if (this.v < 1) {
            this.v = 1;
        }
        if (!z2 && !this.x) {
            this.w = false;
        }
        if (this.v == 1) {
            if (z2 && this.w && !this.x && this.m != null && this.l != null) {
                d();
            }
            if (!this.x) {
                this.w = false;
            }
        }
        this.v--;
    }

    @Override // android.view.ViewGroup
    public boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof m) && this.m.a((m) layoutParams);
    }

    @Override // android.view.View
    public int computeHorizontalScrollExtent() {
        l lVar = this.m;
        if (lVar != null && lVar.a()) {
            return this.m.a(this.g0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeHorizontalScrollOffset() {
        l lVar = this.m;
        if (lVar != null && lVar.a()) {
            return this.m.b(this.g0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeHorizontalScrollRange() {
        l lVar = this.m;
        if (lVar != null && lVar.a()) {
            return this.m.c(this.g0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollExtent() {
        l lVar = this.m;
        if (lVar != null && lVar.b()) {
            return this.m.d(this.g0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollOffset() {
        l lVar = this.m;
        if (lVar != null && lVar.b()) {
            return this.m.e(this.g0);
        }
        return 0;
    }

    @Override // android.view.View
    public int computeVerticalScrollRange() {
        l lVar = this.m;
        if (lVar != null && lVar.b()) {
            return this.m.f(this.g0);
        }
        return 0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:158:0x0327, code lost:
    
        if (r18.f.c(r1) == false) goto L220;
     */
    /* JADX WARN: Removed duplicated region for block: B:123:0x028d  */
    /* JADX WARN: Removed duplicated region for block: B:126:0x0296  */
    /* JADX WARN: Removed duplicated region for block: B:133:0x02cf  */
    /* JADX WARN: Removed duplicated region for block: B:148:0x0300  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x0073  */
    /* JADX WARN: Removed duplicated region for block: B:173:0x03d4  */
    /* JADX WARN: Removed duplicated region for block: B:183:0x0390  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void d() {
        /*
            Method dump skipped, instructions count: 1014
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.d():void");
    }

    public void d(int i2) {
        getScrollingChildHelper().c(i2);
    }

    @Override // android.view.View
    public boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        return getScrollingChildHelper().a(f2, f3, z2);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreFling(float f2, float f3) {
        return getScrollingChildHelper().a(f2, f3);
    }

    @Override // android.view.View
    public boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().a(i2, i3, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return getScrollingChildHelper().a(i2, i3, i4, i5, iArr);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchRestoreInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public void dispatchSaveInstanceState(SparseArray<Parcelable> sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        boolean z2;
        float f2;
        float f3;
        super.draw(canvas);
        int size = this.o.size();
        boolean z3 = false;
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                break;
            }
            b.j.c.l lVar = (b.j.c.l) this.o.get(i2);
            if (lVar.q != lVar.s.getWidth() || lVar.r != lVar.s.getHeight()) {
                lVar.q = lVar.s.getWidth();
                lVar.r = lVar.s.getHeight();
                lVar.a(0);
            } else if (lVar.A != 0) {
                if (lVar.t) {
                    int i3 = lVar.q;
                    int i4 = lVar.e;
                    int i5 = i3 - i4;
                    int i6 = lVar.l;
                    int i7 = lVar.k;
                    int i8 = i6 - (i7 / 2);
                    lVar.f784c.setBounds(0, 0, i4, i7);
                    lVar.f785d.setBounds(0, 0, lVar.f, lVar.r);
                    if (b.d.k.l.g(lVar.s) == 1) {
                        lVar.f785d.draw(canvas);
                        canvas.translate(lVar.e, i8);
                        canvas.scale(-1.0f, 1.0f);
                        lVar.f784c.draw(canvas);
                        canvas.scale(1.0f, 1.0f);
                        i5 = lVar.e;
                    } else {
                        canvas.translate(i5, 0.0f);
                        lVar.f785d.draw(canvas);
                        canvas.translate(0.0f, i8);
                        lVar.f784c.draw(canvas);
                    }
                    canvas.translate(-i5, -i8);
                }
                if (lVar.u) {
                    int i9 = lVar.r;
                    int i10 = lVar.i;
                    int i11 = lVar.o;
                    int i12 = lVar.n;
                    lVar.g.setBounds(0, 0, i12, i10);
                    lVar.h.setBounds(0, 0, lVar.q, lVar.j);
                    canvas.translate(0.0f, i9 - i10);
                    lVar.h.draw(canvas);
                    canvas.translate(i11 - (i12 / 2), 0.0f);
                    lVar.g.draw(canvas);
                    canvas.translate(-r7, -r4);
                }
            }
            i2++;
        }
        EdgeEffect edgeEffect = this.H;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z2 = false;
        } else {
            int save = canvas.save();
            int paddingBottom = this.h ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, 0.0f);
            EdgeEffect edgeEffect2 = this.H;
            z2 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect3 = this.I;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.h) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.I;
            z2 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.J;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.h ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(-paddingTop, -width);
            EdgeEffect edgeEffect6 = this.J;
            z2 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.K;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.h) {
                f2 = getPaddingRight() + (-getWidth());
                f3 = getPaddingBottom() + (-getHeight());
            } else {
                f2 = -getWidth();
                f3 = -getHeight();
            }
            canvas.translate(f2, f3);
            EdgeEffect edgeEffect8 = this.K;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 |= z3;
            canvas.restoreToCount(save4);
        }
        if ((z2 || this.L == null || this.o.size() <= 0 || !this.L.c()) ? z2 : true) {
            b.d.k.l.n(this);
        }
    }

    @Override // android.view.ViewGroup
    public boolean drawChild(Canvas canvas, View view, long j2) {
        return super.drawChild(canvas, view, j2);
    }

    public final void e() {
        int id;
        View b2;
        this.g0.a(1);
        a(this.g0);
        this.g0.i = false;
        u();
        b.j.c.z zVar = this.g;
        zVar.f879a.clear();
        zVar.f880b.a();
        p();
        r();
        View focusedChild = (this.c0 && hasFocus() && this.l != null) ? getFocusedChild() : null;
        z c2 = (focusedChild == null || (b2 = b(focusedChild)) == null) ? null : c(b2);
        if (c2 == null) {
            w wVar = this.g0;
            wVar.m = -1L;
            wVar.l = -1;
            wVar.n = -1;
        } else {
            this.g0.m = this.l.f816b ? c2.e : -1L;
            this.g0.l = this.C ? -1 : c2.i() ? c2.f868d : c2.c();
            w wVar2 = this.g0;
            View view = c2.f865a;
            loop3: while (true) {
                id = view.getId();
                while (!view.isFocused() && (view instanceof ViewGroup) && view.hasFocus()) {
                    view = ((ViewGroup) view).getFocusedChild();
                    if (view.getId() != -1) {
                        break;
                    }
                }
            }
            wVar2.n = id;
        }
        w wVar3 = this.g0;
        wVar3.h = wVar3.j && this.k0;
        this.k0 = false;
        this.j0 = false;
        w wVar4 = this.g0;
        wVar4.g = wVar4.k;
        wVar4.e = this.l.a();
        a(this.p0);
        if (this.g0.j) {
            int a2 = this.f.a();
            for (int i2 = 0; i2 < a2; i2++) {
                z f2 = f(this.f.b(i2));
                if (!f2.o() && (!f2.g() || this.l.f816b)) {
                    i iVar = this.L;
                    i.d(f2);
                    f2.e();
                    this.g.b(f2, iVar.c(f2));
                    if (this.g0.h && f2.l() && !f2.i() && !f2.o() && !f2.g()) {
                        this.g.f880b.c(c(f2), f2);
                    }
                }
            }
        }
        if (this.g0.k) {
            int b3 = this.f.b();
            for (int i3 = 0; i3 < b3; i3++) {
                z f3 = f(this.f.d(i3));
                if (!f3.o() && f3.f868d == -1) {
                    f3.f868d = f3.f867c;
                }
            }
            w wVar5 = this.g0;
            boolean z2 = wVar5.f;
            wVar5.f = false;
            this.m.c(this.f811c, wVar5);
            this.g0.f = z2;
            for (int i4 = 0; i4 < this.f.a(); i4++) {
                z f4 = f(this.f.b(i4));
                if (!f4.o()) {
                    z.a orDefault = this.g.f879a.getOrDefault(f4, null);
                    if (!((orDefault == null || (orDefault.f882a & 4) == 0) ? false : true)) {
                        i.d(f4);
                        boolean b4 = f4.b(8192);
                        i iVar2 = this.L;
                        f4.e();
                        i.c c3 = iVar2.c(f4);
                        if (b4) {
                            a(f4, c3);
                        } else {
                            b.j.c.z zVar2 = this.g;
                            z.a orDefault2 = zVar2.f879a.getOrDefault(f4, null);
                            if (orDefault2 == null) {
                                orDefault2 = z.a.a();
                                zVar2.f879a.put(f4, orDefault2);
                            }
                            orDefault2.f882a |= 2;
                            orDefault2.f883b = c3;
                        }
                    }
                }
            }
        }
        b();
        a(true);
        c(false);
        this.g0.f861d = 2;
    }

    public boolean e(int i2, int i3) {
        return getScrollingChildHelper().a(i2, i3);
    }

    public final void f() {
        u();
        p();
        this.g0.a(6);
        this.e.b();
        this.g0.e = this.l.a();
        w wVar = this.g0;
        wVar.f860c = 0;
        wVar.g = false;
        this.m.c(this.f811c, wVar);
        w wVar2 = this.g0;
        wVar2.f = false;
        this.f812d = null;
        wVar2.j = wVar2.j && this.L != null;
        this.g0.f861d = 4;
        a(true);
        c(false);
    }

    /* JADX WARN: Code restructure failed: missing block: B:101:0x01b7, code lost:
    
        if (r8 > 0) goto L146;
     */
    /* JADX WARN: Code restructure failed: missing block: B:102:0x01ba, code lost:
    
        if (r3 < 0) goto L146;
     */
    /* JADX WARN: Code restructure failed: missing block: B:103:0x01bd, code lost:
    
        if (r8 < 0) goto L146;
     */
    /* JADX WARN: Code restructure failed: missing block: B:107:0x01c6, code lost:
    
        if ((r8 * r1) < 0) goto L147;
     */
    /* JADX WARN: Code restructure failed: missing block: B:111:0x01cf, code lost:
    
        if ((r8 * r1) > 0) goto L147;
     */
    /* JADX WARN: Code restructure failed: missing block: B:98:0x019d, code lost:
    
        if (r3 > 0) goto L146;
     */
    /* JADX WARN: Removed duplicated region for block: B:126:0x01d7  */
    /* JADX WARN: Removed duplicated region for block: B:128:? A[RETURN, SYNTHETIC] */
    @Override // android.view.ViewGroup, android.view.ViewParent
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.view.View focusSearch(android.view.View r14, int r15) {
        /*
            Method dump skipped, instructions count: 476
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.focusSearch(android.view.View, int):android.view.View");
    }

    public void g() {
        int measuredWidth;
        int measuredHeight;
        if (this.K != null) {
            return;
        }
        EdgeEffect a2 = this.G.a(this);
        this.K = a2;
        if (this.h) {
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        } else {
            measuredWidth = getMeasuredWidth();
            measuredHeight = getMeasuredHeight();
        }
        a2.setSize(measuredWidth, measuredHeight);
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateDefaultLayoutParams() {
        l lVar = this.m;
        if (lVar != null) {
            return lVar.c();
        }
        throw new IllegalStateException(c.a.b.a.a.a(this, c.a.b.a.a.a("RecyclerView has no LayoutManager")));
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        l lVar = this.m;
        if (lVar != null) {
            return lVar.a(getContext(), attributeSet);
        }
        throw new IllegalStateException(c.a.b.a.a.a(this, c.a.b.a.a.a("RecyclerView has no LayoutManager")));
    }

    @Override // android.view.ViewGroup
    public ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        l lVar = this.m;
        if (lVar != null) {
            return lVar.a(layoutParams);
        }
        throw new IllegalStateException(c.a.b.a.a.a(this, c.a.b.a.a.a("RecyclerView has no LayoutManager")));
    }

    public d getAdapter() {
        return this.l;
    }

    @Override // android.view.View
    public int getBaseline() {
        l lVar = this.m;
        if (lVar == null) {
            return super.getBaseline();
        }
        if (lVar != null) {
            return -1;
        }
        throw null;
    }

    @Override // android.view.ViewGroup
    public int getChildDrawingOrder(int i2, int i3) {
        g gVar = this.o0;
        return gVar == null ? super.getChildDrawingOrder(i2, i3) : gVar.a(i2, i3);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.h;
    }

    public b.j.c.w getCompatAccessibilityDelegate() {
        return this.n0;
    }

    public h getEdgeEffectFactory() {
        return this.G;
    }

    public i getItemAnimator() {
        return this.L;
    }

    public int getItemDecorationCount() {
        return this.o.size();
    }

    public l getLayoutManager() {
        return this.m;
    }

    public int getMaxFlingVelocity() {
        return this.W;
    }

    public int getMinFlingVelocity() {
        return this.V;
    }

    public long getNanoTime() {
        if (C0) {
            return System.nanoTime();
        }
        return 0L;
    }

    public n getOnFlingListener() {
        return null;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.c0;
    }

    public q getRecycledViewPool() {
        return this.f811c.b();
    }

    public int getScrollState() {
        return this.M;
    }

    public void h() {
        int measuredHeight;
        int measuredWidth;
        if (this.H != null) {
            return;
        }
        EdgeEffect a2 = this.G.a(this);
        this.H = a2;
        if (this.h) {
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
        } else {
            measuredHeight = getMeasuredHeight();
            measuredWidth = getMeasuredWidth();
        }
        a2.setSize(measuredHeight, measuredWidth);
    }

    @Override // android.view.View
    public boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().b(0);
    }

    public void i() {
        int measuredHeight;
        int measuredWidth;
        if (this.J != null) {
            return;
        }
        EdgeEffect a2 = this.G.a(this);
        this.J = a2;
        if (this.h) {
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
        } else {
            measuredHeight = getMeasuredHeight();
            measuredWidth = getMeasuredWidth();
        }
        a2.setSize(measuredHeight, measuredWidth);
    }

    @Override // android.view.View
    public boolean isAttachedToWindow() {
        return this.r;
    }

    @Override // android.view.View
    public boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().f618d;
    }

    public void j() {
        int measuredWidth;
        int measuredHeight;
        if (this.I != null) {
            return;
        }
        EdgeEffect a2 = this.G.a(this);
        this.I = a2;
        if (this.h) {
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        } else {
            measuredWidth = getMeasuredWidth();
            measuredHeight = getMeasuredHeight();
        }
        a2.setSize(measuredWidth, measuredHeight);
    }

    public String k() {
        StringBuilder a2 = c.a.b.a.a.a(" ");
        a2.append(super.toString());
        a2.append(", adapter:");
        a2.append(this.l);
        a2.append(", layout:");
        a2.append(this.m);
        a2.append(", context:");
        a2.append(getContext());
        return a2.toString();
    }

    public boolean l() {
        return !this.u || this.C || this.e.c();
    }

    public void m() {
        this.K = null;
        this.I = null;
        this.J = null;
        this.H = null;
    }

    public boolean n() {
        return this.E > 0;
    }

    public void o() {
        int b2 = this.f.b();
        for (int i2 = 0; i2 < b2; i2++) {
            ((m) this.f.d(i2).getLayoutParams()).f836c = true;
        }
        r rVar = this.f811c;
        int size = rVar.f846c.size();
        for (int i3 = 0; i3 < size; i3++) {
            m mVar = (m) rVar.f846c.get(i3).f865a.getLayoutParams();
            if (mVar != null) {
                mVar.f836c = true;
            }
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.E = 0;
        this.r = true;
        this.u = this.u && !isLayoutRequested();
        l lVar = this.m;
        if (lVar != null) {
            lVar.i = true;
        }
        this.m0 = false;
        if (C0) {
            b.j.c.m mVar = b.j.c.m.f.get();
            this.e0 = mVar;
            if (mVar == null) {
                this.e0 = new b.j.c.m();
                Display d2 = b.d.k.l.d(this);
                float f2 = 60.0f;
                if (!isInEditMode() && d2 != null) {
                    float refreshRate = d2.getRefreshRate();
                    if (refreshRate >= 30.0f) {
                        f2 = refreshRate;
                    }
                }
                b.j.c.m mVar2 = this.e0;
                mVar2.f793d = 1.0E9f / f2;
                b.j.c.m.f.set(mVar2);
            }
            this.e0.f791b.add(this);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onDetachedFromWindow() {
        b.j.c.m mVar;
        super.onDetachedFromWindow();
        i iVar = this.L;
        if (iVar != null) {
            iVar.b();
        }
        v();
        this.r = false;
        l lVar = this.m;
        if (lVar != null) {
            r rVar = this.f811c;
            lVar.i = false;
            lVar.a(this, rVar);
        }
        this.v0.clear();
        removeCallbacks(this.w0);
        if (this.g == null) {
            throw null;
        }
        do {
        } while (z.a.f881d.a() != null);
        if (!C0 || (mVar = this.e0) == null) {
            return;
        }
        mVar.f791b.remove(this);
        this.e0 = null;
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        int size = this.o.size();
        for (int i2 = 0; i2 < size; i2++) {
            if (this.o.get(i2) == null) {
                throw null;
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0066  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onGenericMotionEvent(android.view.MotionEvent r6) {
        /*
            r5 = this;
            b.j.c.t$l r0 = r5.m
            r1 = 0
            if (r0 != 0) goto L6
            return r1
        L6:
            boolean r0 = r5.x
            if (r0 == 0) goto Lb
            return r1
        Lb:
            int r0 = r6.getAction()
            r2 = 8
            if (r0 != r2) goto L77
            int r0 = r6.getSource()
            r0 = r0 & 2
            r2 = 0
            if (r0 == 0) goto L3c
            b.j.c.t$l r0 = r5.m
            boolean r0 = r0.b()
            if (r0 == 0) goto L2c
            r0 = 9
            float r0 = r6.getAxisValue(r0)
            float r0 = -r0
            goto L2d
        L2c:
            r0 = 0
        L2d:
            b.j.c.t$l r3 = r5.m
            boolean r3 = r3.a()
            if (r3 == 0) goto L61
            r3 = 10
            float r3 = r6.getAxisValue(r3)
            goto L62
        L3c:
            int r0 = r6.getSource()
            r3 = 4194304(0x400000, float:5.877472E-39)
            r0 = r0 & r3
            if (r0 == 0) goto L60
            r0 = 26
            float r0 = r6.getAxisValue(r0)
            b.j.c.t$l r3 = r5.m
            boolean r3 = r3.b()
            if (r3 == 0) goto L55
            float r0 = -r0
            goto L61
        L55:
            b.j.c.t$l r3 = r5.m
            boolean r3 = r3.a()
            if (r3 == 0) goto L60
            r3 = r0
            r0 = 0
            goto L62
        L60:
            r0 = 0
        L61:
            r3 = 0
        L62:
            int r4 = (r0 > r2 ? 1 : (r0 == r2 ? 0 : -1))
            if (r4 != 0) goto L6a
            int r2 = (r3 > r2 ? 1 : (r3 == r2 ? 0 : -1))
            if (r2 == 0) goto L77
        L6a:
            float r2 = r5.a0
            float r3 = r3 * r2
            int r2 = (int) r3
            float r3 = r5.b0
            float r0 = r0 * r3
            int r0 = (int) r0
            r5.a(r2, r0, r6)
        L77:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.onGenericMotionEvent(android.view.MotionEvent):boolean");
    }

    @Override // android.view.ViewGroup
    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        boolean z3;
        if (this.x) {
            return false;
        }
        int action = motionEvent.getAction();
        if (action == 3 || action == 0) {
            this.q = null;
        }
        int size = this.p.size();
        int i2 = 0;
        while (true) {
            if (i2 >= size) {
                z2 = false;
                break;
            }
            o oVar = this.p.get(i2);
            if (oVar.a(this, motionEvent) && action != 3) {
                this.q = oVar;
                z2 = true;
                break;
            }
            i2++;
        }
        if (z2) {
            a();
            return true;
        }
        l lVar = this.m;
        if (lVar == null) {
            return false;
        }
        boolean a2 = lVar.a();
        boolean b2 = this.m.b();
        if (this.O == null) {
            this.O = VelocityTracker.obtain();
        }
        this.O.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.y) {
                this.y = false;
            }
            this.N = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            this.R = x2;
            this.P = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            this.S = y2;
            this.Q = y2;
            if (this.M == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
            }
            int[] iArr = this.t0;
            iArr[1] = 0;
            iArr[0] = 0;
            int i3 = a2 ? 1 : 0;
            if (b2) {
                i3 |= 2;
            }
            e(i3, 0);
        } else if (actionMasked == 1) {
            this.O.clear();
            d(0);
        } else if (actionMasked == 2) {
            int findPointerIndex = motionEvent.findPointerIndex(this.N);
            if (findPointerIndex < 0) {
                StringBuilder a3 = c.a.b.a.a.a("Error processing scroll; pointer index for id ");
                a3.append(this.N);
                a3.append(" not found. Did any MotionEvents get skipped?");
                Log.e("RecyclerView", a3.toString());
                return false;
            }
            int x3 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
            int y3 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
            if (this.M != 1) {
                int i4 = x3 - this.P;
                int i5 = y3 - this.Q;
                if (!a2 || Math.abs(i4) <= this.T) {
                    z3 = false;
                } else {
                    this.R = x3;
                    z3 = true;
                }
                if (b2 && Math.abs(i5) > this.T) {
                    this.S = y3;
                    z3 = true;
                }
                if (z3) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            a();
        } else if (actionMasked == 5) {
            this.N = motionEvent.getPointerId(actionIndex);
            int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.R = x4;
            this.P = x4;
            int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.S = y4;
            this.Q = y4;
        } else if (actionMasked == 6) {
            a(motionEvent);
        }
        return this.M == 1;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        Trace.beginSection("RV OnLayout");
        d();
        Trace.endSection();
        this.u = true;
    }

    @Override // android.view.View
    public void onMeasure(int i2, int i3) {
        l lVar = this.m;
        if (lVar == null) {
            b(i2, i3);
            return;
        }
        boolean z2 = false;
        if (lVar.o()) {
            int mode = View.MeasureSpec.getMode(i2);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.m.a(this.f811c, this.g0, i2, i3);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z2 = true;
            }
            if (z2 || this.l == null) {
                return;
            }
            if (this.g0.f861d == 1) {
                e();
            }
            this.m.a(i2, i3);
            this.g0.i = true;
            f();
            this.m.b(i2, i3);
            if (this.m.s()) {
                this.m.a(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                this.g0.i = true;
                f();
                this.m.b(i2, i3);
                return;
            }
            return;
        }
        if (this.s) {
            this.m.a(this.f811c, this.g0, i2, i3);
            return;
        }
        if (this.A) {
            u();
            p();
            r();
            a(true);
            w wVar = this.g0;
            if (wVar.k) {
                wVar.g = true;
            } else {
                this.e.b();
                this.g0.g = false;
            }
            this.A = false;
            c(false);
        } else if (this.g0.k) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        d dVar = this.l;
        if (dVar != null) {
            this.g0.e = dVar.a();
        } else {
            this.g0.e = 0;
        }
        u();
        this.m.a(this.f811c, this.g0, i2, i3);
        c(false);
        this.g0.g = false;
    }

    @Override // android.view.ViewGroup
    public boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (n()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i2, rect);
    }

    @Override // android.view.View
    public void onRestoreInstanceState(Parcelable parcelable) {
        Parcelable parcelable2;
        if (!(parcelable instanceof u)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        u uVar = (u) parcelable;
        this.f812d = uVar;
        super.onRestoreInstanceState(uVar.f669b);
        l lVar = this.m;
        if (lVar == null || (parcelable2 = this.f812d.f849d) == null) {
            return;
        }
        lVar.a(parcelable2);
    }

    @Override // android.view.View
    public Parcelable onSaveInstanceState() {
        u uVar = new u(super.onSaveInstanceState());
        u uVar2 = this.f812d;
        if (uVar2 != null) {
            uVar.f849d = uVar2.f849d;
        } else {
            l lVar = this.m;
            uVar.f849d = lVar != null ? lVar.q() : null;
        }
        return uVar;
    }

    @Override // android.view.View
    public void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        m();
    }

    /* JADX WARN: Code restructure failed: missing block: B:102:0x0249, code lost:
    
        if (r1 != false) goto L138;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:0x0024, code lost:
    
        if (r2 != 1) goto L22;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:15:0x004a  */
    /* JADX WARN: Removed duplicated region for block: B:18:0x004e  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0142  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0152  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean onTouchEvent(android.view.MotionEvent r23) {
        /*
            Method dump skipped, instructions count: 645
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public void p() {
        this.E++;
    }

    public void q() {
        if (this.m0 || !this.r) {
            return;
        }
        b.d.k.l.a(this, this.w0);
        this.m0 = true;
    }

    public final void r() {
        boolean z2 = false;
        if (this.C) {
            b.j.c.a aVar = this.e;
            aVar.a(aVar.f736b);
            aVar.a(aVar.f737c);
            aVar.g = 0;
            if (this.D) {
                this.m.a(this);
            }
        }
        if (this.L != null && this.m.t()) {
            this.e.d();
        } else {
            this.e.b();
        }
        boolean z3 = this.j0 || this.k0;
        this.g0.j = this.u && this.L != null && (this.C || z3 || this.m.h) && (!this.C || this.l.f816b);
        w wVar = this.g0;
        if (wVar.j && z3 && !this.C) {
            if (this.L != null && this.m.t()) {
                z2 = true;
            }
        }
        wVar.k = z2;
    }

    @Override // android.view.ViewGroup
    public void removeDetachedView(View view, boolean z2) {
        z f2 = f(view);
        if (f2 != null) {
            if (f2.k()) {
                f2.j &= -257;
            } else if (!f2.o()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Called removeDetachedView with a view which is not flagged as tmp detached.");
                sb.append(f2);
                throw new IllegalArgumentException(c.a.b.a.a.a(this, sb));
            }
        }
        view.clearAnimation();
        a(view);
        super.removeDetachedView(view, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View view, View view2) {
        if (!this.m.a(this, view, view2) && view2 != null) {
            a(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        return this.m.a(this, view, rect, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestDisallowInterceptTouchEvent(boolean z2) {
        int size = this.p.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.p.get(i2).a(z2);
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public void requestLayout() {
        if (this.v != 0 || this.x) {
            this.w = true;
        } else {
            super.requestLayout();
        }
    }

    public void s() {
        i iVar = this.L;
        if (iVar != null) {
            iVar.b();
        }
        l lVar = this.m;
        if (lVar != null) {
            lVar.b(this.f811c);
            this.m.c(this.f811c);
        }
        this.f811c.a();
    }

    @Override // android.view.View
    public void scrollBy(int i2, int i3) {
        l lVar = this.m;
        if (lVar == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.x) {
            return;
        }
        boolean a2 = lVar.a();
        boolean b2 = this.m.b();
        if (a2 || b2) {
            if (!a2) {
                i2 = 0;
            }
            if (!b2) {
                i3 = 0;
            }
            a(i2, i3, (MotionEvent) null);
        }
    }

    @Override // android.view.View
    public void scrollTo(int i2, int i3) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (n()) {
            int contentChangeTypes = accessibilityEvent != null ? accessibilityEvent.getContentChangeTypes() : 0;
            this.z |= contentChangeTypes != 0 ? contentChangeTypes : 0;
            r1 = 1;
        }
        if (r1 != 0) {
            return;
        }
        super.sendAccessibilityEventUnchecked(accessibilityEvent);
    }

    public void setAccessibilityDelegateCompat(b.j.c.w wVar) {
        this.n0 = wVar;
        b.d.k.l.a(this, wVar);
    }

    public void setAdapter(d dVar) {
        setLayoutFrozen(false);
        d dVar2 = this.l;
        if (dVar2 != null) {
            dVar2.f815a.unregisterObserver(this.f810b);
            if (this.l == null) {
                throw null;
            }
        }
        s();
        b.j.c.a aVar = this.e;
        aVar.a(aVar.f736b);
        aVar.a(aVar.f737c);
        aVar.g = 0;
        d dVar3 = this.l;
        this.l = dVar;
        if (dVar != null) {
            dVar.f815a.registerObserver(this.f810b);
        }
        l lVar = this.m;
        if (lVar != null) {
            lVar.a(dVar3, this.l);
        }
        r rVar = this.f811c;
        d dVar4 = this.l;
        rVar.a();
        q b2 = rVar.b();
        if (b2 != null) {
            if (dVar3 != null) {
                b2.f839b--;
            }
            if (b2.f839b == 0) {
                for (int i2 = 0; i2 < b2.f838a.size(); i2++) {
                    b2.f838a.valueAt(i2).f840a.clear();
                }
            }
            if (dVar4 != null) {
                b2.f839b++;
            }
            this.g0.f = true;
            b(false);
            requestLayout();
            return;
        }
        throw null;
    }

    public void setChildDrawingOrderCallback(g gVar) {
        if (gVar == this.o0) {
            return;
        }
        this.o0 = gVar;
        setChildrenDrawingOrderEnabled(gVar != null);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z2) {
        if (z2 != this.h) {
            m();
        }
        this.h = z2;
        super.setClipToPadding(z2);
        if (this.u) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(h hVar) {
        if (hVar == null) {
            throw null;
        }
        this.G = hVar;
        m();
    }

    public void setHasFixedSize(boolean z2) {
        this.s = z2;
    }

    public void setItemAnimator(i iVar) {
        i iVar2 = this.L;
        if (iVar2 != null) {
            iVar2.b();
            this.L.f817a = null;
        }
        this.L = iVar;
        if (iVar != null) {
            iVar.f817a = this.l0;
        }
    }

    public void setItemViewCacheSize(int i2) {
        r rVar = this.f811c;
        rVar.e = i2;
        rVar.d();
    }

    public void setLayoutFrozen(boolean z2) {
        if (z2 != this.x) {
            a("Do not setLayoutFrozen in layout or scroll");
            if (z2) {
                long uptimeMillis = SystemClock.uptimeMillis();
                onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0));
                this.x = true;
                this.y = true;
                v();
                return;
            }
            this.x = false;
            if (this.w && this.m != null && this.l != null) {
                requestLayout();
            }
            this.w = false;
        }
    }

    public void setLayoutManager(l lVar) {
        if (lVar == this.m) {
            return;
        }
        v();
        if (this.m != null) {
            i iVar = this.L;
            if (iVar != null) {
                iVar.b();
            }
            this.m.b(this.f811c);
            this.m.c(this.f811c);
            this.f811c.a();
            if (this.r) {
                l lVar2 = this.m;
                r rVar = this.f811c;
                lVar2.i = false;
                lVar2.a(this, rVar);
            }
            this.m.c((t) null);
            this.m = null;
        } else {
            this.f811c.a();
        }
        b.j.c.b bVar = this.f;
        b.a aVar = bVar.f744b;
        aVar.f746a = 0L;
        b.a aVar2 = aVar.f747b;
        if (aVar2 != null) {
            aVar2.b();
        }
        int size = bVar.f745c.size();
        while (true) {
            size--;
            if (size < 0) {
                b.j.c.u uVar = (b.j.c.u) bVar.f743a;
                int a2 = uVar.a();
                for (int i2 = 0; i2 < a2; i2++) {
                    View a3 = uVar.a(i2);
                    uVar.f869a.a(a3);
                    a3.clearAnimation();
                }
                uVar.f869a.removeAllViews();
                this.m = lVar;
                if (lVar != null) {
                    if (lVar.f825b != null) {
                        StringBuilder sb = new StringBuilder();
                        sb.append("LayoutManager ");
                        sb.append(lVar);
                        sb.append(" is already attached to a RecyclerView:");
                        throw new IllegalArgumentException(c.a.b.a.a.a(lVar.f825b, sb));
                    }
                    lVar.c(this);
                    if (this.r) {
                        this.m.i = true;
                    }
                }
                this.f811c.d();
                requestLayout();
                return;
            }
            b.InterfaceC0028b interfaceC0028b = bVar.f743a;
            View view = bVar.f745c.get(size);
            b.j.c.u uVar2 = (b.j.c.u) interfaceC0028b;
            if (uVar2 != null) {
                z f2 = f(view);
                if (f2 != null) {
                    uVar2.f869a.a(f2, f2.p);
                    f2.p = 0;
                }
                bVar.f745c.remove(size);
            } else {
                throw null;
            }
        }
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        b.d.k.e scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.f618d) {
            b.d.k.l.p(scrollingChildHelper.f617c);
        }
        scrollingChildHelper.f618d = z2;
    }

    public void setOnFlingListener(n nVar) {
        this.U = nVar;
    }

    @Deprecated
    public void setOnScrollListener(p pVar) {
        this.h0 = pVar;
    }

    public void setPreserveFocusAfterLayout(boolean z2) {
        this.c0 = z2;
    }

    public void setRecycledViewPool(q qVar) {
        r rVar = this.f811c;
        if (rVar.g != null) {
            r1.f839b--;
        }
        rVar.g = qVar;
        if (qVar == null || t.this.getAdapter() == null) {
            return;
        }
        rVar.g.f839b++;
    }

    public void setRecyclerListener(s sVar) {
        this.n = sVar;
    }

    public void setScrollState(int i2) {
        if (i2 == this.M) {
            return;
        }
        this.M = i2;
        if (i2 != 2) {
            w();
        }
        l lVar = this.m;
        if (lVar != null) {
            lVar.f(i2);
        }
        p pVar = this.h0;
        List<p> list = this.i0;
        if (list != null) {
            int size = list.size();
            do {
                size--;
                if (size < 0) {
                    return;
                }
            } while (this.i0.get(size) != null);
            throw null;
        }
    }

    public void setScrollingTouchSlop(int i2) {
        int scaledTouchSlop;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i2 != 0) {
            if (i2 == 1) {
                scaledTouchSlop = viewConfiguration.getScaledPagingTouchSlop();
                this.T = scaledTouchSlop;
            } else {
                Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i2 + "; using default value");
            }
        }
        scaledTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.T = scaledTouchSlop;
    }

    public void setViewCacheExtension(x xVar) {
    }

    @Override // android.view.View
    public boolean startNestedScroll(int i2) {
        return getScrollingChildHelper().a(i2, 0);
    }

    @Override // android.view.View
    public void stopNestedScroll() {
        getScrollingChildHelper().c(0);
    }

    public final void t() {
        VelocityTracker velocityTracker = this.O;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        boolean z2 = false;
        d(0);
        EdgeEffect edgeEffect = this.H;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z2 = this.H.isFinished();
        }
        EdgeEffect edgeEffect2 = this.I;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z2 |= this.I.isFinished();
        }
        EdgeEffect edgeEffect3 = this.J;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z2 |= this.J.isFinished();
        }
        EdgeEffect edgeEffect4 = this.K;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z2 |= this.K.isFinished();
        }
        if (z2) {
            b.d.k.l.n(this);
        }
    }

    public void u() {
        int i2 = this.v + 1;
        this.v = i2;
        if (i2 != 1 || this.x) {
            return;
        }
        this.w = false;
    }

    public void v() {
        setScrollState(0);
        w();
    }

    public final void w() {
        v vVar;
        y yVar = this.d0;
        t.this.removeCallbacks(yVar);
        yVar.f864d.abortAnimation();
        l lVar = this.m;
        if (lVar == null || (vVar = lVar.g) == null) {
            return;
        }
        vVar.b();
    }

    /* loaded from: classes.dex */
    public static abstract class v {

        /* renamed from: b, reason: collision with root package name */
        public t f851b;

        /* renamed from: c, reason: collision with root package name */
        public l f852c;

        /* renamed from: d, reason: collision with root package name */
        public boolean f853d;
        public boolean e;
        public View f;
        public boolean h;

        /* renamed from: a, reason: collision with root package name */
        public int f850a = -1;
        public final a g = new a(0, 0);

        /* loaded from: classes.dex */
        public static class a {

            /* renamed from: a, reason: collision with root package name */
            public int f854a;

            /* renamed from: b, reason: collision with root package name */
            public int f855b;

            /* renamed from: d, reason: collision with root package name */
            public int f857d = -1;
            public boolean f = false;
            public int g = 0;

            /* renamed from: c, reason: collision with root package name */
            public int f856c = Integer.MIN_VALUE;
            public Interpolator e = null;

            public a(int i, int i2) {
                this.f854a = i;
                this.f855b = i2;
            }

            public void a(t tVar) {
                int i = this.f857d;
                if (i >= 0) {
                    this.f857d = -1;
                    tVar.c(i);
                    this.f = false;
                    return;
                }
                if (this.f) {
                    if (this.e != null && this.f856c < 1) {
                        throw new IllegalStateException("If you provide an interpolator, you must set a positive duration");
                    }
                    int i2 = this.f856c;
                    if (i2 >= 1) {
                        Interpolator interpolator = this.e;
                        if (interpolator == null) {
                            y yVar = tVar.d0;
                            if (i2 == Integer.MIN_VALUE) {
                                int i3 = this.f854a;
                                int i4 = this.f855b;
                                yVar.a(i3, i4, yVar.a(i3, i4, 0, 0), t.G0);
                            } else {
                                int i5 = this.f854a;
                                int i6 = this.f855b;
                                if (yVar == null) {
                                    throw null;
                                }
                                yVar.a(i5, i6, i2, t.G0);
                            }
                        } else {
                            tVar.d0.a(this.f854a, this.f855b, i2, interpolator);
                        }
                        int i7 = this.g + 1;
                        this.g = i7;
                        if (i7 > 10) {
                            Log.e("RecyclerView", "Smooth Scroll action is being updated too frequently. Make sure you are not changing it unless necessary");
                        }
                        this.f = false;
                        return;
                    }
                    throw new IllegalStateException("Scroll duration must be a positive number");
                }
                this.g = 0;
            }
        }

        /* loaded from: classes.dex */
        public interface b {
            PointF a(int i);
        }

        public PointF a(int i) {
            Object obj = this.f852c;
            if (obj instanceof b) {
                return ((b) obj).a(i);
            }
            StringBuilder a2 = c.a.b.a.a.a("You should override computeScrollVectorForPosition when the LayoutManager does not implement ");
            a2.append(b.class.getCanonicalName());
            Log.w("RecyclerView", a2.toString());
            return null;
        }

        public abstract void a();

        public abstract void a(View view, w wVar, a aVar);

        public View b(int i) {
            return this.f851b.m.b(i);
        }

        public final void b() {
            if (this.e) {
                this.e = false;
                a();
                this.f851b.g0.f858a = -1;
                this.f = null;
                this.f850a = -1;
                this.f853d = false;
                l lVar = this.f852c;
                if (lVar.g == this) {
                    lVar.g = null;
                }
                this.f852c = null;
                this.f851b = null;
            }
        }

        public int a(View view) {
            if (this.f851b == null) {
                throw null;
            }
            z f = t.f(view);
            if (f != null) {
                return f.d();
            }
            return -1;
        }

        public void a(int i, int i2) {
            PointF a2;
            t tVar = this.f851b;
            if (!this.e || this.f850a == -1 || tVar == null) {
                b();
            }
            if (this.f853d && this.f == null && this.f852c != null && (a2 = a(this.f850a)) != null && (a2.x != 0.0f || a2.y != 0.0f)) {
                tVar.a((int) Math.signum(a2.x), (int) Math.signum(a2.y), (int[]) null);
            }
            this.f853d = false;
            View view = this.f;
            if (view != null) {
                if (a(view) == this.f850a) {
                    a(this.f, tVar.g0, this.g);
                    this.g.a(tVar);
                    b();
                } else {
                    Log.e("RecyclerView", "Passed over target position while smooth scrolling.");
                    this.f = null;
                }
            }
            if (this.e) {
                w wVar = tVar.g0;
                a aVar = this.g;
                b.j.c.o oVar = (b.j.c.o) this;
                if (oVar.f851b.m.d() == 0) {
                    oVar.b();
                } else {
                    int i3 = oVar.l;
                    int i4 = i3 - i;
                    if (i3 * i4 <= 0) {
                        i4 = 0;
                    }
                    oVar.l = i4;
                    int i5 = oVar.m;
                    int i6 = i5 - i2;
                    if (i5 * i6 <= 0) {
                        i6 = 0;
                    }
                    oVar.m = i6;
                    if (oVar.l == 0 && i6 == 0) {
                        oVar.a(aVar);
                    }
                }
                boolean z = this.g.f857d >= 0;
                this.g.a(tVar);
                if (z) {
                    if (!this.e) {
                        b();
                    } else {
                        this.f853d = true;
                        tVar.d0.a();
                    }
                }
            }
        }
    }

    public void b(int i2, int i3) {
        setMeasuredDimension(l.a(i2, getPaddingRight() + getPaddingLeft(), b.d.k.l.i(this)), l.a(i3, getPaddingBottom() + getPaddingTop(), getMinimumHeight()));
    }

    public int b(z zVar) {
        if (zVar.b(524) || !zVar.f()) {
            return -1;
        }
        b.j.c.a aVar = this.e;
        int i2 = zVar.f867c;
        int size = aVar.f736b.size();
        for (int i3 = 0; i3 < size; i3++) {
            a.b bVar = aVar.f736b.get(i3);
            int i4 = bVar.f739a;
            if (i4 != 1) {
                if (i4 == 2) {
                    int i5 = bVar.f740b;
                    if (i5 <= i2) {
                        int i6 = bVar.f742d;
                        if (i5 + i6 > i2) {
                            return -1;
                        }
                        i2 -= i6;
                    } else {
                        continue;
                    }
                } else if (i4 == 8) {
                    int i7 = bVar.f740b;
                    if (i7 == i2) {
                        i2 = bVar.f742d;
                    } else {
                        if (i7 < i2) {
                            i2--;
                        }
                        if (bVar.f742d <= i2) {
                            i2++;
                        }
                    }
                }
            } else if (bVar.f740b <= i2) {
                i2 += bVar.f742d;
            }
        }
        return i2;
    }

    public void a(View view) {
        z f2 = f(view);
        d dVar = this.l;
        if (dVar != null && f2 != null && dVar == null) {
            throw null;
        }
    }

    public boolean b(int i2) {
        return getScrollingChildHelper().a(i2) != null;
    }

    public boolean a(int i2, int i3, int i4, int i5, int[] iArr, int i6) {
        return getScrollingChildHelper().a(i2, i3, i4, i5, iArr, i6, null);
    }

    public void b(boolean z2) {
        this.D = z2 | this.D;
        this.C = true;
        int b2 = this.f.b();
        for (int i2 = 0; i2 < b2; i2++) {
            z f2 = f(this.f.d(i2));
            if (f2 != null && !f2.o()) {
                f2.a(6);
            }
        }
        o();
        r rVar = this.f811c;
        int size = rVar.f846c.size();
        for (int i3 = 0; i3 < size; i3++) {
            z zVar = rVar.f846c.get(i3);
            if (zVar != null) {
                zVar.a(6);
                zVar.a((Object) null);
            }
        }
        d dVar = t.this.l;
        if (dVar == null || !dVar.f816b) {
            rVar.c();
        }
    }

    public void a(int i2, int i3, boolean z2) {
        int i4 = i2 + i3;
        int b2 = this.f.b();
        for (int i5 = 0; i5 < b2; i5++) {
            z f2 = f(this.f.d(i5));
            if (f2 != null && !f2.o()) {
                int i6 = f2.f867c;
                if (i6 >= i4) {
                    f2.a(-i3, z2);
                } else if (i6 >= i2) {
                    f2.a(8);
                    f2.a(-i3, z2);
                    f2.f867c = i2 - 1;
                }
                this.g0.f = true;
            }
        }
        r rVar = this.f811c;
        int size = rVar.f846c.size();
        while (true) {
            size--;
            if (size < 0) {
                requestLayout();
                return;
            }
            z zVar = rVar.f846c.get(size);
            if (zVar != null) {
                int i7 = zVar.f867c;
                if (i7 >= i4) {
                    zVar.a(-i3, z2);
                } else if (i7 >= i2) {
                    zVar.a(8);
                    rVar.c(size);
                }
            }
        }
    }

    public void a(boolean z2) {
        int i2;
        int i3 = this.E - 1;
        this.E = i3;
        if (i3 < 1) {
            this.E = 0;
            if (z2) {
                int i4 = this.z;
                this.z = 0;
                if (i4 != 0) {
                    AccessibilityManager accessibilityManager = this.B;
                    if (accessibilityManager != null && accessibilityManager.isEnabled()) {
                        AccessibilityEvent obtain = AccessibilityEvent.obtain();
                        obtain.setEventType(2048);
                        obtain.setContentChangeTypes(i4);
                        sendAccessibilityEventUnchecked(obtain);
                    }
                }
                for (int size = this.v0.size() - 1; size >= 0; size--) {
                    z zVar = this.v0.get(size);
                    if (zVar.f865a.getParent() == this && !zVar.o() && (i2 = zVar.q) != -1) {
                        b.d.k.l.a(zVar.f865a, i2);
                        zVar.q = -1;
                    }
                }
                this.v0.clear();
            }
        }
    }

    public long c(z zVar) {
        if (this.l.f816b) {
            return zVar.e;
        }
        return zVar.f867c;
    }

    public void a(z zVar, i.c cVar) {
        zVar.a(0, 8192);
        if (this.g0.h && zVar.l() && !zVar.i() && !zVar.o()) {
            this.g.f880b.c(c(zVar), zVar);
        }
        this.g.b(zVar, cVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x00d6  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0109  */
    /* JADX WARN: Removed duplicated region for block: B:46:0x00ec  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean a(int r19, int r20, android.view.MotionEvent r21) {
        /*
            Method dump skipped, instructions count: 302
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.c.t.a(int, int, android.view.MotionEvent):boolean");
    }

    public void a(int i2, int i3, int[] iArr) {
        z zVar;
        u();
        p();
        Trace.beginSection("RV Scroll");
        a(this.g0);
        int a2 = i2 != 0 ? this.m.a(i2, this.f811c, this.g0) : 0;
        int b2 = i3 != 0 ? this.m.b(i3, this.f811c, this.g0) : 0;
        Trace.endSection();
        int a3 = this.f.a();
        for (int i4 = 0; i4 < a3; i4++) {
            View b3 = this.f.b(i4);
            z c2 = c(b3);
            if (c2 != null && (zVar = c2.i) != null) {
                View view = zVar.f865a;
                int left = b3.getLeft();
                int top = b3.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
        a(true);
        c(false);
        if (iArr != null) {
            iArr[0] = a2;
            iArr[1] = b2;
        }
    }

    public Rect d(View view) {
        m mVar = (m) view.getLayoutParams();
        if (!mVar.f836c) {
            return mVar.f835b;
        }
        if (this.g0.g && (mVar.c() || mVar.f834a.g())) {
            return mVar.f835b;
        }
        Rect rect = mVar.f835b;
        rect.set(0, 0, 0, 0);
        int size = this.o.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.i.set(0, 0, 0, 0);
            k kVar = this.o.get(i2);
            Rect rect2 = this.i;
            if (kVar != null) {
                ((m) view.getLayoutParams()).b();
                rect2.set(0, 0, 0, 0);
                int i3 = rect.left;
                Rect rect3 = this.i;
                rect.left = i3 + rect3.left;
                rect.top += rect3.top;
                rect.right += rect3.right;
                rect.bottom += rect3.bottom;
            } else {
                throw null;
            }
        }
        mVar.f836c = false;
        return rect;
    }

    public void d(int i2, int i3) {
        l lVar = this.m;
        if (lVar == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.x) {
            return;
        }
        if (!lVar.a()) {
            i2 = 0;
        }
        if (!this.m.b()) {
            i3 = 0;
        }
        if (i2 == 0 && i3 == 0) {
            return;
        }
        y yVar = this.d0;
        yVar.a(i2, i3, yVar.a(i2, i3, 0, 0), G0);
    }
}
