package b.j.c;

import android.view.View;
import android.view.ViewPropertyAnimator;
import b.j.c.t;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class e implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ArrayList f752b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ k f753c;

    public e(k kVar, ArrayList arrayList) {
        this.f753c = kVar;
        this.f752b = arrayList;
    }

    @Override // java.lang.Runnable
    public void run() {
        Iterator it = this.f752b.iterator();
        while (it.hasNext()) {
            t.z zVar = (t.z) it.next();
            k kVar = this.f753c;
            if (kVar == null) {
                throw null;
            }
            View view = zVar.f865a;
            ViewPropertyAnimator animate = view.animate();
            kVar.o.add(zVar);
            animate.alpha(1.0f).setDuration(kVar.f819c).setListener(new g(kVar, zVar, view, animate)).start();
        }
        this.f752b.clear();
        this.f753c.l.remove(this.f752b);
    }
}
