package b.j.c;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import b.j.c.t;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class k extends x {
    public static TimeInterpolator s;
    public ArrayList<t.z> h = new ArrayList<>();
    public ArrayList<t.z> i = new ArrayList<>();
    public ArrayList<b> j = new ArrayList<>();
    public ArrayList<a> k = new ArrayList<>();
    public ArrayList<ArrayList<t.z>> l = new ArrayList<>();
    public ArrayList<ArrayList<b>> m = new ArrayList<>();
    public ArrayList<ArrayList<a>> n = new ArrayList<>();
    public ArrayList<t.z> o = new ArrayList<>();
    public ArrayList<t.z> p = new ArrayList<>();
    public ArrayList<t.z> q = new ArrayList<>();
    public ArrayList<t.z> r = new ArrayList<>();

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public t.z f774a;

        /* renamed from: b, reason: collision with root package name */
        public t.z f775b;

        /* renamed from: c, reason: collision with root package name */
        public int f776c;

        /* renamed from: d, reason: collision with root package name */
        public int f777d;
        public int e;
        public int f;

        public a(t.z zVar, t.z zVar2, int i, int i2, int i3, int i4) {
            this.f774a = zVar;
            this.f775b = zVar2;
            this.f776c = i;
            this.f777d = i2;
            this.e = i3;
            this.f = i4;
        }

        public String toString() {
            StringBuilder a2 = c.a.b.a.a.a("ChangeInfo{oldHolder=");
            a2.append(this.f774a);
            a2.append(", newHolder=");
            a2.append(this.f775b);
            a2.append(", fromX=");
            a2.append(this.f776c);
            a2.append(", fromY=");
            a2.append(this.f777d);
            a2.append(", toX=");
            a2.append(this.e);
            a2.append(", toY=");
            a2.append(this.f);
            a2.append('}');
            return a2.toString();
        }
    }

    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public t.z f778a;

        /* renamed from: b, reason: collision with root package name */
        public int f779b;

        /* renamed from: c, reason: collision with root package name */
        public int f780c;

        /* renamed from: d, reason: collision with root package name */
        public int f781d;
        public int e;

        public b(t.z zVar, int i, int i2, int i3, int i4) {
            this.f778a = zVar;
            this.f779b = i;
            this.f780c = i2;
            this.f781d = i3;
            this.e = i4;
        }
    }

    public void a(List<t.z> list) {
        for (int size = list.size() - 1; size >= 0; size--) {
            list.get(size).f865a.animate().cancel();
        }
    }

    public final void a(List<a> list, t.z zVar) {
        for (int size = list.size() - 1; size >= 0; size--) {
            a aVar = list.get(size);
            if (a(aVar, zVar) && aVar.f774a == null && aVar.f775b == null) {
                list.remove(aVar);
            }
        }
    }

    @Override // b.j.c.x
    public boolean a(t.z zVar, int i, int i2, int i3, int i4) {
        View view = zVar.f865a;
        int translationX = i + ((int) view.getTranslationX());
        int translationY = i2 + ((int) zVar.f865a.getTranslationY());
        e(zVar);
        int i5 = i3 - translationX;
        int i6 = i4 - translationY;
        if (i5 == 0 && i6 == 0) {
            a(zVar);
            return false;
        }
        if (i5 != 0) {
            view.setTranslationX(-i5);
        }
        if (i6 != 0) {
            view.setTranslationY(-i6);
        }
        this.j.add(new b(zVar, translationX, translationY, i3, i4));
        return true;
    }

    @Override // b.j.c.t.i
    public boolean a(t.z zVar, List<Object> list) {
        return !list.isEmpty() || super.a(zVar, list);
    }

    @Override // b.j.c.t.i
    public void b(t.z zVar) {
        View view = zVar.f865a;
        view.animate().cancel();
        int size = this.j.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            if (this.j.get(size).f778a == zVar) {
                view.setTranslationY(0.0f);
                view.setTranslationX(0.0f);
                a(zVar);
                this.j.remove(size);
            }
        }
        a(this.k, zVar);
        if (this.h.remove(zVar)) {
            view.setAlpha(1.0f);
            a(zVar);
        }
        if (this.i.remove(zVar)) {
            view.setAlpha(1.0f);
            a(zVar);
        }
        for (int size2 = this.n.size() - 1; size2 >= 0; size2--) {
            ArrayList<a> arrayList = this.n.get(size2);
            a(arrayList, zVar);
            if (arrayList.isEmpty()) {
                this.n.remove(size2);
            }
        }
        for (int size3 = this.m.size() - 1; size3 >= 0; size3--) {
            ArrayList<b> arrayList2 = this.m.get(size3);
            int size4 = arrayList2.size() - 1;
            while (true) {
                if (size4 < 0) {
                    break;
                }
                if (arrayList2.get(size4).f778a == zVar) {
                    view.setTranslationY(0.0f);
                    view.setTranslationX(0.0f);
                    a(zVar);
                    arrayList2.remove(size4);
                    if (arrayList2.isEmpty()) {
                        this.m.remove(size3);
                    }
                } else {
                    size4--;
                }
            }
        }
        for (int size5 = this.l.size() - 1; size5 >= 0; size5--) {
            ArrayList<t.z> arrayList3 = this.l.get(size5);
            if (arrayList3.remove(zVar)) {
                view.setAlpha(1.0f);
                a(zVar);
                if (arrayList3.isEmpty()) {
                    this.l.remove(size5);
                }
            }
        }
        this.q.remove(zVar);
        this.o.remove(zVar);
        this.r.remove(zVar);
        this.p.remove(zVar);
        d();
    }

    @Override // b.j.c.t.i
    public boolean c() {
        return (this.i.isEmpty() && this.k.isEmpty() && this.j.isEmpty() && this.h.isEmpty() && this.p.isEmpty() && this.q.isEmpty() && this.o.isEmpty() && this.r.isEmpty() && this.m.isEmpty() && this.l.isEmpty() && this.n.isEmpty()) ? false : true;
    }

    public void d() {
        if (c()) {
            return;
        }
        a();
    }

    public final void e(t.z zVar) {
        if (s == null) {
            s = new ValueAnimator().getInterpolator();
        }
        zVar.f865a.animate().setInterpolator(s);
        b(zVar);
    }

    public final boolean a(a aVar, t.z zVar) {
        if (aVar.f775b == zVar) {
            aVar.f775b = null;
        } else {
            if (aVar.f774a != zVar) {
                return false;
            }
            aVar.f774a = null;
        }
        zVar.f865a.setAlpha(1.0f);
        zVar.f865a.setTranslationX(0.0f);
        zVar.f865a.setTranslationY(0.0f);
        a(zVar);
        return true;
    }

    @Override // b.j.c.t.i
    public void b() {
        int size = this.j.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            b bVar = this.j.get(size);
            View view = bVar.f778a.f865a;
            view.setTranslationY(0.0f);
            view.setTranslationX(0.0f);
            a(bVar.f778a);
            this.j.remove(size);
        }
        int size2 = this.h.size();
        while (true) {
            size2--;
            if (size2 < 0) {
                break;
            }
            a(this.h.get(size2));
            this.h.remove(size2);
        }
        int size3 = this.i.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            t.z zVar = this.i.get(size3);
            zVar.f865a.setAlpha(1.0f);
            a(zVar);
            this.i.remove(size3);
        }
        int size4 = this.k.size();
        while (true) {
            size4--;
            if (size4 < 0) {
                break;
            }
            a aVar = this.k.get(size4);
            t.z zVar2 = aVar.f774a;
            if (zVar2 != null) {
                a(aVar, zVar2);
            }
            t.z zVar3 = aVar.f775b;
            if (zVar3 != null) {
                a(aVar, zVar3);
            }
        }
        this.k.clear();
        if (!c()) {
            return;
        }
        int size5 = this.m.size();
        while (true) {
            size5--;
            if (size5 < 0) {
                break;
            }
            ArrayList<b> arrayList = this.m.get(size5);
            int size6 = arrayList.size();
            while (true) {
                size6--;
                if (size6 >= 0) {
                    b bVar2 = arrayList.get(size6);
                    View view2 = bVar2.f778a.f865a;
                    view2.setTranslationY(0.0f);
                    view2.setTranslationX(0.0f);
                    a(bVar2.f778a);
                    arrayList.remove(size6);
                    if (arrayList.isEmpty()) {
                        this.m.remove(arrayList);
                    }
                }
            }
        }
        int size7 = this.l.size();
        while (true) {
            size7--;
            if (size7 < 0) {
                break;
            }
            ArrayList<t.z> arrayList2 = this.l.get(size7);
            int size8 = arrayList2.size();
            while (true) {
                size8--;
                if (size8 >= 0) {
                    t.z zVar4 = arrayList2.get(size8);
                    zVar4.f865a.setAlpha(1.0f);
                    a(zVar4);
                    arrayList2.remove(size8);
                    if (arrayList2.isEmpty()) {
                        this.l.remove(arrayList2);
                    }
                }
            }
        }
        int size9 = this.n.size();
        while (true) {
            size9--;
            if (size9 < 0) {
                a(this.q);
                a(this.p);
                a(this.o);
                a(this.r);
                a();
                return;
            }
            ArrayList<a> arrayList3 = this.n.get(size9);
            int size10 = arrayList3.size();
            while (true) {
                size10--;
                if (size10 >= 0) {
                    a aVar2 = arrayList3.get(size10);
                    t.z zVar5 = aVar2.f774a;
                    if (zVar5 != null) {
                        a(aVar2, zVar5);
                    }
                    t.z zVar6 = aVar2.f775b;
                    if (zVar6 != null) {
                        a(aVar2, zVar6);
                    }
                    if (arrayList3.isEmpty()) {
                        this.n.remove(arrayList3);
                    }
                }
            }
        }
    }
}
