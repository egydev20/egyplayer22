package b.j.c;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;
import b.j.c.t;

/* loaded from: classes.dex */
public class f extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ t.z f754a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f755b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f756c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ k f757d;

    public f(k kVar, t.z zVar, ViewPropertyAnimator viewPropertyAnimator, View view) {
        this.f757d = kVar;
        this.f754a = zVar;
        this.f755b = viewPropertyAnimator;
        this.f756c = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        this.f755b.setListener(null);
        this.f756c.setAlpha(1.0f);
        this.f757d.a(this.f754a);
        this.f757d.q.remove(this.f754a);
        this.f757d.d();
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        if (this.f757d == null) {
            throw null;
        }
    }
}
