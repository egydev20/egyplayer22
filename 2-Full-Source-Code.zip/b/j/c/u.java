package b.j.c;

import android.view.View;
import b.j.c.b;

/* loaded from: classes.dex */
public class u implements b.InterfaceC0028b {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ t f869a;

    public u(t tVar) {
        this.f869a = tVar;
    }

    public int a() {
        return this.f869a.getChildCount();
    }

    public View a(int i) {
        return this.f869a.getChildAt(i);
    }

    public void b(int i) {
        View childAt = this.f869a.getChildAt(i);
        if (childAt != null) {
            this.f869a.a(childAt);
            childAt.clearAnimation();
        }
        this.f869a.removeViewAt(i);
    }
}
