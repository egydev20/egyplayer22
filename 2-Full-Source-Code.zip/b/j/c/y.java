package b.j.c;

import android.view.View;

/* loaded from: classes.dex */
public class y {

    /* renamed from: a, reason: collision with root package name */
    public final b f873a;

    /* renamed from: b, reason: collision with root package name */
    public a f874b = new a();

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public int f875a = 0;

        /* renamed from: b, reason: collision with root package name */
        public int f876b;

        /* renamed from: c, reason: collision with root package name */
        public int f877c;

        /* renamed from: d, reason: collision with root package name */
        public int f878d;
        public int e;

        public int a(int i, int i2) {
            if (i > i2) {
                return 1;
            }
            return i == i2 ? 2 : 4;
        }

        public boolean a() {
            int i = this.f875a;
            if ((i & 7) != 0 && (i & (a(this.f878d, this.f876b) << 0)) == 0) {
                return false;
            }
            int i2 = this.f875a;
            if ((i2 & b.a.j.AppCompatTheme_tooltipForegroundColor) != 0 && (i2 & (a(this.f878d, this.f877c) << 4)) == 0) {
                return false;
            }
            int i3 = this.f875a;
            if ((i3 & 1792) != 0 && (i3 & (a(this.e, this.f876b) << 8)) == 0) {
                return false;
            }
            int i4 = this.f875a;
            return (i4 & 28672) == 0 || (i4 & (a(this.e, this.f877c) << 12)) != 0;
        }
    }

    /* loaded from: classes.dex */
    public interface b {
        int a();

        int a(View view);

        View a(int i);

        int b();

        int b(View view);
    }

    public y(b bVar) {
        this.f873a = bVar;
    }

    public View a(int i, int i2, int i3, int i4) {
        int b2 = this.f873a.b();
        int a2 = this.f873a.a();
        int i5 = i2 > i ? 1 : -1;
        View view = null;
        while (i != i2) {
            View a3 = this.f873a.a(i);
            int b3 = this.f873a.b(a3);
            int a4 = this.f873a.a(a3);
            a aVar = this.f874b;
            aVar.f876b = b2;
            aVar.f877c = a2;
            aVar.f878d = b3;
            aVar.e = a4;
            if (i3 != 0) {
                aVar.f875a = 0;
                aVar.f875a = i3 | 0;
                if (aVar.a()) {
                    return a3;
                }
            }
            if (i4 != 0) {
                a aVar2 = this.f874b;
                aVar2.f875a = 0;
                aVar2.f875a = i4 | 0;
                if (aVar2.a()) {
                    view = a3;
                }
            }
            i += i5;
        }
        return view;
    }

    public boolean a(View view, int i) {
        a aVar = this.f874b;
        int b2 = this.f873a.b();
        int a2 = this.f873a.a();
        int b3 = this.f873a.b(view);
        int a3 = this.f873a.a(view);
        aVar.f876b = b2;
        aVar.f877c = a2;
        aVar.f878d = b3;
        aVar.e = a3;
        if (i == 0) {
            return false;
        }
        a aVar2 = this.f874b;
        aVar2.f875a = 0;
        aVar2.f875a = 0 | i;
        return aVar2.a();
    }
}
