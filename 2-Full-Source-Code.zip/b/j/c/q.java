package b.j.c;

import android.view.View;
import android.view.ViewGroup;
import b.j.c.t;

/* loaded from: classes.dex */
public final class q extends s {
    public q(t.l lVar) {
        super(lVar, null);
    }

    @Override // b.j.c.s
    public int a() {
        return this.f807a.q;
    }

    @Override // b.j.c.s
    public int a(View view) {
        return this.f807a.h(view) + ((ViewGroup.MarginLayoutParams) ((t.m) view.getLayoutParams())).rightMargin;
    }

    @Override // b.j.c.s
    public void a(int i) {
        this.f807a.d(i);
    }

    @Override // b.j.c.s
    public int b() {
        t.l lVar = this.f807a;
        return lVar.q - lVar.l();
    }

    @Override // b.j.c.s
    public int b(View view) {
        t.m mVar = (t.m) view.getLayoutParams();
        return this.f807a.g(view) + ((ViewGroup.MarginLayoutParams) mVar).leftMargin + ((ViewGroup.MarginLayoutParams) mVar).rightMargin;
    }

    @Override // b.j.c.s
    public int c() {
        return this.f807a.l();
    }

    @Override // b.j.c.s
    public int c(View view) {
        t.m mVar = (t.m) view.getLayoutParams();
        return this.f807a.f(view) + ((ViewGroup.MarginLayoutParams) mVar).topMargin + ((ViewGroup.MarginLayoutParams) mVar).bottomMargin;
    }

    @Override // b.j.c.s
    public int d() {
        return this.f807a.o;
    }

    @Override // b.j.c.s
    public int d(View view) {
        return this.f807a.e(view) - ((ViewGroup.MarginLayoutParams) ((t.m) view.getLayoutParams())).leftMargin;
    }

    @Override // b.j.c.s
    public int e() {
        return this.f807a.p;
    }

    @Override // b.j.c.s
    public int e(View view) {
        this.f807a.a(view, true, this.f809c);
        return this.f809c.right;
    }

    @Override // b.j.c.s
    public int f() {
        return this.f807a.k();
    }

    @Override // b.j.c.s
    public int f(View view) {
        this.f807a.a(view, true, this.f809c);
        return this.f809c.left;
    }

    @Override // b.j.c.s
    public int g() {
        t.l lVar = this.f807a;
        return (lVar.q - lVar.k()) - this.f807a.l();
    }
}
