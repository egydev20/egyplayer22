package b.j.c;

import b.j.c.p;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class a implements p.a {

    /* renamed from: d, reason: collision with root package name */
    public final InterfaceC0027a f738d;

    /* renamed from: a, reason: collision with root package name */
    public b.d.j.a<b> f735a = new b.d.j.a<>(30);

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList<b> f736b = new ArrayList<>();

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList<b> f737c = new ArrayList<>();
    public int g = 0;
    public final boolean e = false;
    public final p f = new p(this);

    /* renamed from: b.j.c.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface InterfaceC0027a {
    }

    /* loaded from: classes.dex */
    public static class b {

        /* renamed from: a, reason: collision with root package name */
        public int f739a;

        /* renamed from: b, reason: collision with root package name */
        public int f740b;

        /* renamed from: c, reason: collision with root package name */
        public Object f741c;

        /* renamed from: d, reason: collision with root package name */
        public int f742d;

        public b(int i, int i2, int i3, Object obj) {
            this.f739a = i;
            this.f740b = i2;
            this.f742d = i3;
            this.f741c = obj;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || b.class != obj.getClass()) {
                return false;
            }
            b bVar = (b) obj;
            int i = this.f739a;
            if (i != bVar.f739a) {
                return false;
            }
            if (i == 8 && Math.abs(this.f742d - this.f740b) == 1 && this.f742d == bVar.f740b && this.f740b == bVar.f742d) {
                return true;
            }
            if (this.f742d != bVar.f742d || this.f740b != bVar.f740b) {
                return false;
            }
            Object obj2 = this.f741c;
            Object obj3 = bVar.f741c;
            if (obj2 != null) {
                if (!obj2.equals(obj3)) {
                    return false;
                }
            } else if (obj3 != null) {
                return false;
            }
            return true;
        }

        public int hashCode() {
            return (((this.f739a * 31) + this.f740b) * 31) + this.f742d;
        }

        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append(Integer.toHexString(System.identityHashCode(this)));
            sb.append("[");
            int i = this.f739a;
            sb.append(i != 1 ? i != 2 ? i != 4 ? i != 8 ? "??" : "mv" : "up" : "rm" : "add");
            sb.append(",s:");
            sb.append(this.f740b);
            sb.append("c:");
            sb.append(this.f742d);
            sb.append(",p:");
            sb.append(this.f741c);
            sb.append("]");
            return sb.toString();
        }
    }

    public a(InterfaceC0027a interfaceC0027a) {
        this.f738d = interfaceC0027a;
    }

    public int a(int i, int i2) {
        int size = this.f737c.size();
        while (i2 < size) {
            b bVar = this.f737c.get(i2);
            int i3 = bVar.f739a;
            if (i3 == 8) {
                int i4 = bVar.f740b;
                if (i4 == i) {
                    i = bVar.f742d;
                } else {
                    if (i4 < i) {
                        i--;
                    }
                    if (bVar.f742d <= i) {
                        i++;
                    }
                }
            } else {
                int i5 = bVar.f740b;
                if (i5 > i) {
                    continue;
                } else if (i3 == 2) {
                    int i6 = bVar.f742d;
                    if (i < i5 + i6) {
                        return -1;
                    }
                    i -= i6;
                } else if (i3 == 1) {
                    i += bVar.f742d;
                }
            }
            i2++;
        }
        return i;
    }

    public b a(int i, int i2, int i3, Object obj) {
        b a2 = this.f735a.a();
        if (a2 == null) {
            return new b(i, i2, i3, obj);
        }
        a2.f739a = i;
        a2.f740b = i2;
        a2.f742d = i3;
        a2.f741c = obj;
        return a2;
    }

    public void a() {
        int size = this.f737c.size();
        for (int i = 0; i < size; i++) {
            ((v) this.f738d).a(this.f737c.get(i));
        }
        a(this.f737c);
        this.g = 0;
    }

    public void a(List<b> list) {
        int size = list.size();
        for (int i = 0; i < size; i++) {
            c(list.get(i));
        }
        list.clear();
    }

    public final boolean a(int i) {
        int size = this.f737c.size();
        for (int i2 = 0; i2 < size; i2++) {
            b bVar = this.f737c.get(i2);
            int i3 = bVar.f739a;
            if (i3 == 8) {
                if (a(bVar.f742d, i2 + 1) == i) {
                    return true;
                }
            } else if (i3 == 1) {
                int i4 = bVar.f740b;
                int i5 = bVar.f742d + i4;
                while (i4 < i5) {
                    if (a(i4, i2 + 1) == i) {
                        return true;
                    }
                    i4++;
                }
            } else {
                continue;
            }
        }
        return false;
    }

    public void b() {
        a();
        int size = this.f736b.size();
        for (int i = 0; i < size; i++) {
            b bVar = this.f736b.get(i);
            int i2 = bVar.f739a;
            if (i2 == 1) {
                ((v) this.f738d).a(bVar);
                ((v) this.f738d).a(bVar.f740b, bVar.f742d);
            } else if (i2 == 2) {
                ((v) this.f738d).a(bVar);
                InterfaceC0027a interfaceC0027a = this.f738d;
                int i3 = bVar.f740b;
                int i4 = bVar.f742d;
                v vVar = (v) interfaceC0027a;
                vVar.f870a.a(i3, i4, true);
                t tVar = vVar.f870a;
                tVar.j0 = true;
                tVar.g0.f860c += i4;
            } else if (i2 == 4) {
                ((v) this.f738d).a(bVar);
                ((v) this.f738d).a(bVar.f740b, bVar.f742d, bVar.f741c);
            } else if (i2 == 8) {
                ((v) this.f738d).a(bVar);
                ((v) this.f738d).b(bVar.f740b, bVar.f742d);
            }
        }
        a(this.f736b);
        this.g = 0;
    }

    public void c(b bVar) {
        if (this.e) {
            return;
        }
        bVar.f741c = null;
        this.f735a.a(bVar);
    }

    public boolean c() {
        return this.f736b.size() > 0;
    }

    /* JADX WARN: Code restructure failed: missing block: B:75:0x016a, code lost:
    
        if (r6 > r12.f740b) goto L106;
     */
    /* JADX WARN: Code restructure failed: missing block: B:76:0x019b, code lost:
    
        r2.set(r4, r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x01a2, code lost:
    
        if (r11.f740b == r11.f742d) goto L110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x01a4, code lost:
    
        r2.set(r8, r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:79:0x01ab, code lost:
    
        if (r5 == null) goto L213;
     */
    /* JADX WARN: Code restructure failed: missing block: B:81:0x01ad, code lost:
    
        r2.add(r4, r5);
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x01a8, code lost:
    
        r2.remove(r8);
     */
    /* JADX WARN: Code restructure failed: missing block: B:85:0x0196, code lost:
    
        r11.f742d = r6 - r12.f742d;
     */
    /* JADX WARN: Code restructure failed: missing block: B:97:0x0194, code lost:
    
        if (r6 >= r12.f740b) goto L106;
     */
    /* JADX WARN: Removed duplicated region for block: B:105:0x010f  */
    /* JADX WARN: Removed duplicated region for block: B:108:0x00da A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:126:0x006a  */
    /* JADX WARN: Removed duplicated region for block: B:130:0x008f  */
    /* JADX WARN: Removed duplicated region for block: B:132:0x00a7  */
    /* JADX WARN: Removed duplicated region for block: B:134:0x00ac A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:137:0x0009 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:138:0x0093  */
    /* JADX WARN: Removed duplicated region for block: B:141:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:43:0x00df  */
    /* JADX WARN: Removed duplicated region for block: B:59:0x010a  */
    /* JADX WARN: Removed duplicated region for block: B:62:0x0141 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:98:0x012a A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void d() {
        /*
            Method dump skipped, instructions count: 721
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.j.c.a.d():void");
    }

    public final void a(b bVar) {
        int i;
        int i2 = bVar.f739a;
        if (i2 != 1 && i2 != 8) {
            int b2 = b(bVar.f740b, i2);
            int i3 = bVar.f740b;
            int i4 = bVar.f739a;
            if (i4 == 2) {
                i = 0;
            } else {
                if (i4 != 4) {
                    throw new IllegalArgumentException("op should be remove or update." + bVar);
                }
                i = 1;
            }
            int i5 = 1;
            for (int i6 = 1; i6 < bVar.f742d; i6++) {
                int b3 = b((i * i6) + bVar.f740b, bVar.f739a);
                int i7 = bVar.f739a;
                if (i7 == 2 ? b3 == b2 : i7 == 4 && b3 == b2 + 1) {
                    i5++;
                } else {
                    b a2 = a(bVar.f739a, b2, i5, bVar.f741c);
                    a(a2, i3);
                    if (!this.e) {
                        a2.f741c = null;
                        this.f735a.a(a2);
                    }
                    if (bVar.f739a == 4) {
                        i3 += i5;
                    }
                    b2 = b3;
                    i5 = 1;
                }
            }
            Object obj = bVar.f741c;
            if (!this.e) {
                bVar.f741c = null;
                this.f735a.a(bVar);
            }
            if (i5 > 0) {
                b a3 = a(bVar.f739a, b2, i5, obj);
                a(a3, i3);
                if (this.e) {
                    return;
                }
                a3.f741c = null;
                this.f735a.a(a3);
                return;
            }
            return;
        }
        throw new IllegalArgumentException("should not dispatch add or move for pre layout");
    }

    public void a(b bVar, int i) {
        ((v) this.f738d).a(bVar);
        int i2 = bVar.f739a;
        if (i2 != 2) {
            if (i2 != 4) {
                throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
            }
            ((v) this.f738d).a(i, bVar.f742d, bVar.f741c);
            return;
        }
        InterfaceC0027a interfaceC0027a = this.f738d;
        int i3 = bVar.f742d;
        v vVar = (v) interfaceC0027a;
        vVar.f870a.a(i, i3, true);
        t tVar = vVar.f870a;
        tVar.j0 = true;
        tVar.g0.f860c += i3;
    }

    public final void b(b bVar) {
        this.f737c.add(bVar);
        int i = bVar.f739a;
        if (i == 1) {
            ((v) this.f738d).a(bVar.f740b, bVar.f742d);
            return;
        }
        if (i == 2) {
            v vVar = (v) this.f738d;
            vVar.f870a.a(bVar.f740b, bVar.f742d, false);
            vVar.f870a.j0 = true;
            return;
        }
        if (i == 4) {
            ((v) this.f738d).a(bVar.f740b, bVar.f742d, bVar.f741c);
        } else if (i == 8) {
            ((v) this.f738d).b(bVar.f740b, bVar.f742d);
        } else {
            throw new IllegalArgumentException("Unknown update op type for " + bVar);
        }
    }

    public final int b(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        for (int size = this.f737c.size() - 1; size >= 0; size--) {
            b bVar = this.f737c.get(size);
            int i7 = bVar.f739a;
            if (i7 == 8) {
                int i8 = bVar.f740b;
                int i9 = bVar.f742d;
                if (i8 >= i9) {
                    i9 = i8;
                    i8 = i9;
                }
                if (i < i8 || i > i9) {
                    int i10 = bVar.f740b;
                    if (i < i10) {
                        if (i2 == 1) {
                            bVar.f740b = i10 + 1;
                            i4 = bVar.f742d + 1;
                        } else if (i2 == 2) {
                            bVar.f740b = i10 - 1;
                            i4 = bVar.f742d - 1;
                        }
                        bVar.f742d = i4;
                    }
                } else {
                    int i11 = bVar.f740b;
                    if (i8 == i11) {
                        if (i2 == 1) {
                            i6 = bVar.f742d + 1;
                        } else {
                            if (i2 == 2) {
                                i6 = bVar.f742d - 1;
                            }
                            i++;
                        }
                        bVar.f742d = i6;
                        i++;
                    } else {
                        if (i2 == 1) {
                            i5 = i11 + 1;
                        } else {
                            if (i2 == 2) {
                                i5 = i11 - 1;
                            }
                            i--;
                        }
                        bVar.f740b = i5;
                        i--;
                    }
                }
            } else {
                int i12 = bVar.f740b;
                if (i12 > i) {
                    if (i2 == 1) {
                        i3 = i12 + 1;
                    } else if (i2 == 2) {
                        i3 = i12 - 1;
                    }
                    bVar.f740b = i3;
                } else if (i7 == 1) {
                    i -= bVar.f742d;
                } else if (i7 == 2) {
                    i += bVar.f742d;
                }
            }
        }
        for (int size2 = this.f737c.size() - 1; size2 >= 0; size2--) {
            b bVar2 = this.f737c.get(size2);
            if (bVar2.f739a == 8) {
                int i13 = bVar2.f742d;
                if (i13 == bVar2.f740b || i13 < 0) {
                    this.f737c.remove(size2);
                    if (this.e) {
                    }
                    bVar2.f741c = null;
                    this.f735a.a(bVar2);
                }
            } else if (bVar2.f742d <= 0) {
                this.f737c.remove(size2);
                if (this.e) {
                }
                bVar2.f741c = null;
                this.f735a.a(bVar2);
            }
        }
        return i;
    }
}
