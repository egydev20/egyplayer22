package b.j.c;

import b.j.c.k;
import b.j.c.t;

/* loaded from: classes.dex */
public abstract class x extends t.i {
    public boolean g = true;

    public abstract boolean a(t.z zVar, int i, int i2, int i3, int i4);

    @Override // b.j.c.t.i
    public boolean a(t.z zVar, t.z zVar2, t.i.c cVar, t.i.c cVar2) {
        int i;
        int i2;
        int i3 = cVar.f821a;
        int i4 = cVar.f822b;
        if (zVar2.o()) {
            int i5 = cVar.f821a;
            i2 = cVar.f822b;
            i = i5;
        } else {
            i = cVar2.f821a;
            i2 = cVar2.f822b;
        }
        k kVar = (k) this;
        if (zVar == zVar2) {
            return kVar.a(zVar, i3, i4, i, i2);
        }
        float translationX = zVar.f865a.getTranslationX();
        float translationY = zVar.f865a.getTranslationY();
        float alpha = zVar.f865a.getAlpha();
        kVar.e(zVar);
        zVar.f865a.setTranslationX(translationX);
        zVar.f865a.setTranslationY(translationY);
        zVar.f865a.setAlpha(alpha);
        kVar.e(zVar2);
        zVar2.f865a.setTranslationX(-((int) ((i - i3) - translationX)));
        zVar2.f865a.setTranslationY(-((int) ((i2 - i4) - translationY)));
        zVar2.f865a.setAlpha(0.0f);
        kVar.k.add(new k.a(zVar, zVar2, i3, i4, i, i2));
        return true;
    }
}
