package b.j.c;

import android.view.View;
import android.view.ViewPropertyAnimator;
import b.j.c.k;
import b.j.c.t;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class d implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ArrayList f750b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ k f751c;

    public d(k kVar, ArrayList arrayList) {
        this.f751c = kVar;
        this.f750b = arrayList;
    }

    @Override // java.lang.Runnable
    public void run() {
        Iterator it = this.f750b.iterator();
        while (it.hasNext()) {
            k.a aVar = (k.a) it.next();
            k kVar = this.f751c;
            if (kVar == null) {
                throw null;
            }
            t.z zVar = aVar.f774a;
            View view = zVar == null ? null : zVar.f865a;
            t.z zVar2 = aVar.f775b;
            View view2 = zVar2 != null ? zVar2.f865a : null;
            if (view != null) {
                ViewPropertyAnimator duration = view.animate().setDuration(kVar.f);
                kVar.r.add(aVar.f774a);
                duration.translationX(aVar.e - aVar.f776c);
                duration.translationY(aVar.f - aVar.f777d);
                duration.alpha(0.0f).setListener(new i(kVar, aVar, duration, view)).start();
            }
            if (view2 != null) {
                ViewPropertyAnimator animate = view2.animate();
                kVar.r.add(aVar.f775b);
                animate.translationX(0.0f).translationY(0.0f).setDuration(kVar.f).alpha(1.0f).setListener(new j(kVar, aVar, animate, view2)).start();
            }
        }
        this.f750b.clear();
        this.f751c.n.remove(this.f750b);
    }
}
