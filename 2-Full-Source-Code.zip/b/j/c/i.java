package b.j.c;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;
import b.j.c.k;
import b.j.c.t;

/* loaded from: classes.dex */
public class i extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ k.a f766a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f767b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f768c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ k f769d;

    public i(k kVar, k.a aVar, ViewPropertyAnimator viewPropertyAnimator, View view) {
        this.f769d = kVar;
        this.f766a = aVar;
        this.f767b = viewPropertyAnimator;
        this.f768c = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        this.f767b.setListener(null);
        this.f768c.setAlpha(1.0f);
        this.f768c.setTranslationX(0.0f);
        this.f768c.setTranslationY(0.0f);
        this.f769d.a(this.f766a.f774a);
        this.f769d.r.remove(this.f766a.f774a);
        this.f769d.d();
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        k kVar = this.f769d;
        t.z zVar = this.f766a.f774a;
        if (kVar == null) {
            throw null;
        }
    }
}
