package b.j.c;

import android.view.View;
import android.view.ViewPropertyAnimator;
import b.j.c.k;
import b.j.c.t;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class c implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ArrayList f748b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ k f749c;

    public c(k kVar, ArrayList arrayList) {
        this.f749c = kVar;
        this.f748b = arrayList;
    }

    @Override // java.lang.Runnable
    public void run() {
        Iterator it = this.f748b.iterator();
        while (it.hasNext()) {
            k.b bVar = (k.b) it.next();
            k kVar = this.f749c;
            t.z zVar = bVar.f778a;
            int i = bVar.f779b;
            int i2 = bVar.f780c;
            int i3 = bVar.f781d;
            int i4 = bVar.e;
            if (kVar == null) {
                throw null;
            }
            View view = zVar.f865a;
            int i5 = i3 - i;
            int i6 = i4 - i2;
            if (i5 != 0) {
                view.animate().translationX(0.0f);
            }
            if (i6 != 0) {
                view.animate().translationY(0.0f);
            }
            ViewPropertyAnimator animate = view.animate();
            kVar.p.add(zVar);
            animate.setDuration(kVar.e).setListener(new h(kVar, zVar, i5, view, i6, animate)).start();
        }
        this.f748b.clear();
        this.f749c.m.remove(this.f748b);
    }
}
