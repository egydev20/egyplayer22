package b.j.c;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;
import b.j.c.k;
import b.j.c.t;

/* loaded from: classes.dex */
public class j extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ k.a f770a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f771b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f772c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ k f773d;

    public j(k kVar, k.a aVar, ViewPropertyAnimator viewPropertyAnimator, View view) {
        this.f773d = kVar;
        this.f770a = aVar;
        this.f771b = viewPropertyAnimator;
        this.f772c = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        this.f771b.setListener(null);
        this.f772c.setAlpha(1.0f);
        this.f772c.setTranslationX(0.0f);
        this.f772c.setTranslationY(0.0f);
        this.f773d.a(this.f770a.f775b);
        this.f773d.r.remove(this.f770a.f775b);
        this.f773d.d();
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        k kVar = this.f773d;
        t.z zVar = this.f770a.f775b;
        if (kVar == null) {
            throw null;
        }
    }
}
