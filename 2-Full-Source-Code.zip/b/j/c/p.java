package b.j.c;

/* loaded from: classes.dex */
public class p {

    /* renamed from: a, reason: collision with root package name */
    public final a f806a;

    /* loaded from: classes.dex */
    public interface a {
    }

    public p(a aVar) {
        this.f806a = aVar;
    }
}
