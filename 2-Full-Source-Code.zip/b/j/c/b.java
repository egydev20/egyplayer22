package b.j.c;

import android.view.View;
import android.view.ViewGroup;
import b.g.n.b0.a;
import b.j.c.t;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public final InterfaceC0028b f743a;

    /* renamed from: b, reason: collision with root package name */
    public final a f744b = new a();

    /* renamed from: c, reason: collision with root package name */
    public final List<View> f745c = new ArrayList();

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public long f746a = 0;

        /* renamed from: b, reason: collision with root package name */
        public a f747b;

        public final void a() {
            if (this.f747b == null) {
                this.f747b = new a();
            }
        }

        public void a(int i) {
            if (i < 64) {
                this.f746a &= ~(1 << i);
                return;
            }
            a aVar = this.f747b;
            if (aVar != null) {
                aVar.a(i - 64);
            }
        }

        public void a(int i, boolean z) {
            if (i >= 64) {
                a();
                this.f747b.a(i - 64, z);
                return;
            }
            boolean z2 = (this.f746a & Long.MIN_VALUE) != 0;
            long j = (1 << i) - 1;
            long j2 = this.f746a;
            this.f746a = ((j2 & (~j)) << 1) | (j2 & j);
            if (z) {
                e(i);
            } else {
                a(i);
            }
            if (z2 || this.f747b != null) {
                a();
                this.f747b.a(0, z2);
            }
        }

        public int b(int i) {
            long j;
            a aVar = this.f747b;
            if (aVar == null) {
                if (i >= 64) {
                    j = this.f746a;
                    return Long.bitCount(j);
                }
            } else if (i >= 64) {
                return Long.bitCount(this.f746a) + aVar.b(i - 64);
            }
            j = this.f746a & ((1 << i) - 1);
            return Long.bitCount(j);
        }

        public void b() {
            this.f746a = 0L;
            a aVar = this.f747b;
            if (aVar != null) {
                aVar.b();
            }
        }

        public boolean c(int i) {
            if (i < 64) {
                return (this.f746a & (1 << i)) != 0;
            }
            a();
            return this.f747b.c(i - 64);
        }

        public boolean d(int i) {
            if (i >= 64) {
                a();
                return this.f747b.d(i - 64);
            }
            long j = 1 << i;
            boolean z = (this.f746a & j) != 0;
            long j2 = this.f746a & (~j);
            this.f746a = j2;
            long j3 = j - 1;
            this.f746a = (j2 & j3) | Long.rotateRight((~j3) & j2, 1);
            a aVar = this.f747b;
            if (aVar != null) {
                if (aVar.c(0)) {
                    e(63);
                }
                this.f747b.d(0);
            }
            return z;
        }

        public void e(int i) {
            if (i < 64) {
                this.f746a |= 1 << i;
            } else {
                a();
                this.f747b.e(i - 64);
            }
        }

        public String toString() {
            if (this.f747b == null) {
                return Long.toBinaryString(this.f746a);
            }
            return this.f747b.toString() + "xx" + Long.toBinaryString(this.f746a);
        }
    }

    /* renamed from: b.j.c.b$b, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface InterfaceC0028b {
    }

    public b(InterfaceC0028b interfaceC0028b) {
        this.f743a = interfaceC0028b;
    }

    public int a() {
        return ((u) this.f743a).a() - this.f745c.size();
    }

    public void a(View view, int i, boolean z) {
        int a2 = i < 0 ? ((u) this.f743a).a() : c(i);
        this.f744b.a(a2, z);
        if (z) {
            a(view);
        }
        u uVar = (u) this.f743a;
        uVar.f869a.addView(view, a2);
        t tVar = uVar.f869a;
        if (tVar != null) {
            t.z f = t.f(view);
            t.d dVar = tVar.l;
            if (dVar == null || f == null) {
                return;
            }
            ((a.c) f).f865a.setFocusable(b.g.n.b0.a.this.isActivated());
            return;
        }
        throw null;
    }

    public int b() {
        return ((u) this.f743a).a();
    }

    public int b(View view) {
        int indexOfChild = ((u) this.f743a).f869a.indexOfChild(view);
        if (indexOfChild == -1 || this.f744b.c(indexOfChild)) {
            return -1;
        }
        return indexOfChild - this.f744b.b(indexOfChild);
    }

    public View b(int i) {
        return ((u) this.f743a).a(c(i));
    }

    public final int c(int i) {
        if (i < 0) {
            return -1;
        }
        int a2 = ((u) this.f743a).a();
        int i2 = i;
        while (i2 < a2) {
            int b2 = i - (i2 - this.f744b.b(i2));
            if (b2 == 0) {
                while (this.f744b.c(i2)) {
                    i2++;
                }
                return i2;
            }
            i2 += b2;
        }
        return -1;
    }

    public boolean c(View view) {
        return this.f745c.contains(view);
    }

    public View d(int i) {
        return ((u) this.f743a).f869a.getChildAt(i);
    }

    public String toString() {
        return this.f744b.toString() + ", hidden list:" + this.f745c.size();
    }

    public final boolean d(View view) {
        if (!this.f745c.remove(view)) {
            return false;
        }
        u uVar = (u) this.f743a;
        if (uVar != null) {
            t.z f = t.f(view);
            if (f == null) {
                return true;
            }
            uVar.f869a.a(f, f.p);
            f.p = 0;
            return true;
        }
        throw null;
    }

    public void a(View view, int i, ViewGroup.LayoutParams layoutParams, boolean z) {
        int a2 = i < 0 ? ((u) this.f743a).a() : c(i);
        this.f744b.a(a2, z);
        if (z) {
            a(view);
        }
        u uVar = (u) this.f743a;
        if (uVar == null) {
            throw null;
        }
        t.z f = t.f(view);
        if (f != null) {
            if (!f.k() && !f.o()) {
                StringBuilder sb = new StringBuilder();
                sb.append("Called attach on a child which is not detached: ");
                sb.append(f);
                throw new IllegalArgumentException(c.a.b.a.a.a(uVar.f869a, sb));
            }
            f.j &= -257;
        }
        uVar.f869a.attachViewToParent(view, a2, layoutParams);
    }

    public void a(int i) {
        t.z f;
        int c2 = c(i);
        this.f744b.d(c2);
        u uVar = (u) this.f743a;
        View childAt = uVar.f869a.getChildAt(c2);
        if (childAt != null && (f = t.f(childAt)) != null) {
            if (f.k() && !f.o()) {
                StringBuilder sb = new StringBuilder();
                sb.append("called detach on an already detached child ");
                sb.append(f);
                throw new IllegalArgumentException(c.a.b.a.a.a(uVar.f869a, sb));
            }
            f.a(256);
        }
        uVar.f869a.detachViewFromParent(c2);
    }

    public final void a(View view) {
        this.f745c.add(view);
        u uVar = (u) this.f743a;
        if (uVar != null) {
            t.z f = t.f(view);
            if (f != null) {
                t tVar = uVar.f869a;
                int i = f.q;
                if (i == -1) {
                    i = b.d.k.l.e(f.f865a);
                }
                f.p = i;
                tVar.a(f, 4);
                return;
            }
            return;
        }
        throw null;
    }
}
