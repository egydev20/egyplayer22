package b.j.c;

import android.view.View;
import android.view.ViewGroup;
import b.j.c.t;

/* loaded from: classes.dex */
public final class r extends s {
    public r(t.l lVar) {
        super(lVar, null);
    }

    @Override // b.j.c.s
    public int a() {
        return this.f807a.r;
    }

    @Override // b.j.c.s
    public int a(View view) {
        return this.f807a.d(view) + ((ViewGroup.MarginLayoutParams) ((t.m) view.getLayoutParams())).bottomMargin;
    }

    @Override // b.j.c.s
    public void a(int i) {
        this.f807a.e(i);
    }

    @Override // b.j.c.s
    public int b() {
        t.l lVar = this.f807a;
        return lVar.r - lVar.j();
    }

    @Override // b.j.c.s
    public int b(View view) {
        t.m mVar = (t.m) view.getLayoutParams();
        return this.f807a.f(view) + ((ViewGroup.MarginLayoutParams) mVar).topMargin + ((ViewGroup.MarginLayoutParams) mVar).bottomMargin;
    }

    @Override // b.j.c.s
    public int c() {
        return this.f807a.j();
    }

    @Override // b.j.c.s
    public int c(View view) {
        t.m mVar = (t.m) view.getLayoutParams();
        return this.f807a.g(view) + ((ViewGroup.MarginLayoutParams) mVar).leftMargin + ((ViewGroup.MarginLayoutParams) mVar).rightMargin;
    }

    @Override // b.j.c.s
    public int d() {
        return this.f807a.p;
    }

    @Override // b.j.c.s
    public int d(View view) {
        return this.f807a.i(view) - ((ViewGroup.MarginLayoutParams) ((t.m) view.getLayoutParams())).topMargin;
    }

    @Override // b.j.c.s
    public int e() {
        return this.f807a.o;
    }

    @Override // b.j.c.s
    public int e(View view) {
        this.f807a.a(view, true, this.f809c);
        return this.f809c.bottom;
    }

    @Override // b.j.c.s
    public int f() {
        return this.f807a.m();
    }

    @Override // b.j.c.s
    public int f(View view) {
        this.f807a.a(view, true, this.f809c);
        return this.f809c.top;
    }

    @Override // b.j.c.s
    public int g() {
        t.l lVar = this.f807a;
        return (lVar.r - lVar.m()) - this.f807a.j();
    }
}
