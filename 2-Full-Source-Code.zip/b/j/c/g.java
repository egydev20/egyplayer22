package b.j.c;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;
import b.j.c.t;

/* loaded from: classes.dex */
public class g extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ t.z f758a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f759b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f760c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ k f761d;

    public g(k kVar, t.z zVar, View view, ViewPropertyAnimator viewPropertyAnimator) {
        this.f761d = kVar;
        this.f758a = zVar;
        this.f759b = view;
        this.f760c = viewPropertyAnimator;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
        this.f759b.setAlpha(1.0f);
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        this.f760c.setListener(null);
        this.f761d.a(this.f758a);
        this.f761d.o.remove(this.f758a);
        this.f761d.d();
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        if (this.f761d == null) {
            throw null;
        }
    }
}
