package b.j.c;

import android.os.Bundle;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import b.j.c.t;

/* loaded from: classes.dex */
public class w extends b.d.k.a {

    /* renamed from: d, reason: collision with root package name */
    public final t f871d;
    public final b.d.k.a e = new a(this);

    public w(t tVar) {
        this.f871d = tVar;
    }

    @Override // b.d.k.a
    public void a(View view, AccessibilityEvent accessibilityEvent) {
        this.f611a.onInitializeAccessibilityEvent(view, accessibilityEvent);
        accessibilityEvent.setClassName(t.class.getName());
        if (!(view instanceof t) || a()) {
            return;
        }
        t tVar = (t) view;
        if (tVar.getLayoutManager() != null) {
            tVar.getLayoutManager().a(accessibilityEvent);
        }
    }

    public boolean a() {
        return this.f871d.l();
    }

    @Override // b.d.k.a
    public void a(View view, b.d.k.r.b bVar) {
        this.f611a.onInitializeAccessibilityNodeInfo(view, bVar.f640a);
        bVar.f640a.setClassName(t.class.getName());
        if (a() || this.f871d.getLayoutManager() == null) {
            return;
        }
        t.l layoutManager = this.f871d.getLayoutManager();
        t tVar = layoutManager.f825b;
        layoutManager.a(tVar.f811c, tVar.g0, bVar);
    }

    /* loaded from: classes.dex */
    public static class a extends b.d.k.a {

        /* renamed from: d, reason: collision with root package name */
        public final w f872d;

        public a(w wVar) {
            this.f872d = wVar;
        }

        @Override // b.d.k.a
        public void a(View view, b.d.k.r.b bVar) {
            this.f611a.onInitializeAccessibilityNodeInfo(view, bVar.f640a);
            if (this.f872d.a() || this.f872d.f871d.getLayoutManager() == null) {
                return;
            }
            this.f872d.f871d.getLayoutManager().a(view, bVar);
        }

        @Override // b.d.k.a
        public boolean a(View view, int i, Bundle bundle) {
            if (super.a(view, i, bundle)) {
                return true;
            }
            if (!this.f872d.a() && this.f872d.f871d.getLayoutManager() != null) {
                t.r rVar = this.f872d.f871d.getLayoutManager().f825b.f811c;
            }
            return false;
        }
    }

    @Override // b.d.k.a
    public boolean a(View view, int i, Bundle bundle) {
        if (super.a(view, i, bundle)) {
            return true;
        }
        if (a() || this.f871d.getLayoutManager() == null) {
            return false;
        }
        t.l layoutManager = this.f871d.getLayoutManager();
        t tVar = layoutManager.f825b;
        return layoutManager.a(tVar.f811c, tVar.g0, i, bundle);
    }
}
