package b.j.c;

import android.R;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.view.MotionEvent;
import b.j.c.t;
import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public class l extends t.k implements t.o {
    public static final int[] D = {R.attr.state_pressed};
    public static final int[] E = new int[0];

    /* renamed from: a, reason: collision with root package name */
    public final int f782a;

    /* renamed from: b, reason: collision with root package name */
    public final int f783b;

    /* renamed from: c, reason: collision with root package name */
    public final StateListDrawable f784c;

    /* renamed from: d, reason: collision with root package name */
    public final Drawable f785d;
    public final int e;
    public final int f;
    public final StateListDrawable g;
    public final Drawable h;
    public final int i;
    public final int j;
    public int k;
    public int l;
    public float m;
    public int n;
    public int o;
    public float p;
    public t s;
    public int q = 0;
    public int r = 0;
    public boolean t = false;
    public boolean u = false;
    public int v = 0;
    public int w = 0;
    public final int[] x = new int[2];
    public final int[] y = new int[2];
    public final ValueAnimator z = ValueAnimator.ofFloat(0.0f, 1.0f);
    public int A = 0;
    public final Runnable B = new a();
    public final t.p C = new b();

    /* loaded from: classes.dex */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            l lVar = l.this;
            int i = lVar.A;
            if (i == 1) {
                lVar.z.cancel();
            } else if (i != 2) {
                return;
            }
            lVar.A = 3;
            ValueAnimator valueAnimator = lVar.z;
            valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 0.0f);
            lVar.z.setDuration(500);
            lVar.z.start();
        }
    }

    /* loaded from: classes.dex */
    public class b extends t.p {
        public b() {
        }

        @Override // b.j.c.t.p
        public void a(t tVar, int i, int i2) {
            l lVar = l.this;
            int computeHorizontalScrollOffset = tVar.computeHorizontalScrollOffset();
            int computeVerticalScrollOffset = tVar.computeVerticalScrollOffset();
            int computeVerticalScrollRange = lVar.s.computeVerticalScrollRange();
            int i3 = lVar.r;
            lVar.t = computeVerticalScrollRange - i3 > 0 && i3 >= lVar.f782a;
            int computeHorizontalScrollRange = lVar.s.computeHorizontalScrollRange();
            int i4 = lVar.q;
            boolean z = computeHorizontalScrollRange - i4 > 0 && i4 >= lVar.f782a;
            lVar.u = z;
            if (!lVar.t && !z) {
                if (lVar.v != 0) {
                    lVar.a(0);
                    return;
                }
                return;
            }
            if (lVar.t) {
                float f = i3;
                lVar.l = (int) ((((f / 2.0f) + computeVerticalScrollOffset) * f) / computeVerticalScrollRange);
                lVar.k = Math.min(i3, (i3 * i3) / computeVerticalScrollRange);
            }
            if (lVar.u) {
                float f2 = computeHorizontalScrollOffset;
                float f3 = i4;
                lVar.o = (int) ((((f3 / 2.0f) + f2) * f3) / computeHorizontalScrollRange);
                lVar.n = Math.min(i4, (i4 * i4) / computeHorizontalScrollRange);
            }
            int i5 = lVar.v;
            if (i5 == 0 || i5 == 1) {
                lVar.a(1);
            }
        }
    }

    /* loaded from: classes.dex */
    public class c extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        public boolean f788a = false;

        public c() {
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f788a = true;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            if (this.f788a) {
                this.f788a = false;
                return;
            }
            if (((Float) l.this.z.getAnimatedValue()).floatValue() == 0.0f) {
                l lVar = l.this;
                lVar.A = 0;
                lVar.a(0);
            } else {
                l lVar2 = l.this;
                lVar2.A = 2;
                lVar2.s.invalidate();
            }
        }
    }

    /* loaded from: classes.dex */
    public class d implements ValueAnimator.AnimatorUpdateListener {
        public d() {
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            int floatValue = (int) (((Float) valueAnimator.getAnimatedValue()).floatValue() * 255.0f);
            l.this.f784c.setAlpha(floatValue);
            l.this.f785d.setAlpha(floatValue);
            l.this.s.invalidate();
        }
    }

    public l(t tVar, StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2, int i, int i2, int i3) {
        this.f784c = stateListDrawable;
        this.f785d = drawable;
        this.g = stateListDrawable2;
        this.h = drawable2;
        this.e = Math.max(i, stateListDrawable.getIntrinsicWidth());
        this.f = Math.max(i, drawable.getIntrinsicWidth());
        this.i = Math.max(i, stateListDrawable2.getIntrinsicWidth());
        this.j = Math.max(i, drawable2.getIntrinsicWidth());
        this.f782a = i2;
        this.f783b = i3;
        this.f784c.setAlpha(255);
        this.f785d.setAlpha(255);
        this.z.addListener(new c());
        this.z.addUpdateListener(new d());
        t tVar2 = this.s;
        if (tVar2 == tVar) {
            return;
        }
        if (tVar2 != null) {
            t.l lVar = tVar2.m;
            if (lVar != null) {
                lVar.a("Cannot remove item decoration during a scroll  or layout");
            }
            tVar2.o.remove(this);
            if (tVar2.o.isEmpty()) {
                tVar2.setWillNotDraw(tVar2.getOverScrollMode() == 2);
            }
            tVar2.o();
            tVar2.requestLayout();
            t tVar3 = this.s;
            tVar3.p.remove(this);
            if (tVar3.q == this) {
                tVar3.q = null;
            }
            t tVar4 = this.s;
            t.p pVar = this.C;
            List<t.p> list = tVar4.i0;
            if (list != null) {
                list.remove(pVar);
            }
            a();
        }
        this.s = tVar;
        if (tVar != null) {
            t.l lVar2 = tVar.m;
            if (lVar2 != null) {
                lVar2.a("Cannot add item decoration during a scroll  or layout");
            }
            if (tVar.o.isEmpty()) {
                tVar.setWillNotDraw(false);
            }
            tVar.o.add(this);
            tVar.o();
            tVar.requestLayout();
            this.s.p.add(this);
            t tVar5 = this.s;
            t.p pVar2 = this.C;
            if (tVar5.i0 == null) {
                tVar5.i0 = new ArrayList();
            }
            tVar5.i0.add(pVar2);
        }
    }

    public final int a(float f, float f2, int[] iArr, int i, int i2, int i3) {
        int i4 = iArr[1] - iArr[0];
        if (i4 == 0) {
            return 0;
        }
        int i5 = i - i3;
        int i6 = (int) (((f2 - f) / i4) * i5);
        int i7 = i2 + i6;
        if (i7 >= i5 || i7 < 0) {
            return 0;
        }
        return i6;
    }

    public final void a() {
        this.s.removeCallbacks(this.B);
    }

    public void a(int i) {
        int i2;
        if (i == 2 && this.v != 2) {
            this.f784c.setState(D);
            a();
        }
        if (i == 0) {
            this.s.invalidate();
        } else {
            b();
        }
        if (this.v != 2 || i == 2) {
            i2 = i == 1 ? 1500 : 1200;
            this.v = i;
        }
        this.f784c.setState(E);
        a();
        this.s.postDelayed(this.B, i2);
        this.v = i;
    }

    @Override // b.j.c.t.o
    public void a(boolean z) {
    }

    public boolean a(float f, float f2) {
        if (f2 >= this.r - this.i) {
            int i = this.o;
            int i2 = this.n;
            if (f >= i - (i2 / 2) && f <= (i2 / 2) + i) {
                return true;
            }
        }
        return false;
    }

    @Override // b.j.c.t.o
    public boolean a(t tVar, MotionEvent motionEvent) {
        int i = this.v;
        if (i == 1) {
            boolean b2 = b(motionEvent.getX(), motionEvent.getY());
            boolean a2 = a(motionEvent.getX(), motionEvent.getY());
            if (motionEvent.getAction() != 0) {
                return false;
            }
            if (!b2 && !a2) {
                return false;
            }
            if (a2) {
                this.w = 1;
                this.p = (int) motionEvent.getX();
            } else if (b2) {
                this.w = 2;
                this.m = (int) motionEvent.getY();
            }
            a(2);
        } else if (i != 2) {
            return false;
        }
        return true;
    }

    public void b() {
        int i = this.A;
        if (i != 0) {
            if (i != 3) {
                return;
            } else {
                this.z.cancel();
            }
        }
        this.A = 1;
        ValueAnimator valueAnimator = this.z;
        valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 1.0f);
        this.z.setDuration(500L);
        this.z.setStartDelay(0L);
        this.z.start();
    }

    public boolean b(float f, float f2) {
        if (b.d.k.l.g(this.s) == 1) {
            if (f > this.e / 2) {
                return false;
            }
        } else if (f < this.q - this.e) {
            return false;
        }
        int i = this.l;
        int i2 = this.k / 2;
        return f2 >= ((float) (i - i2)) && f2 <= ((float) (i2 + i));
    }

    @Override // b.j.c.t.o
    public void b(t tVar, MotionEvent motionEvent) {
        if (this.v == 0) {
            return;
        }
        if (motionEvent.getAction() == 0) {
            boolean b2 = b(motionEvent.getX(), motionEvent.getY());
            boolean a2 = a(motionEvent.getX(), motionEvent.getY());
            if (b2 || a2) {
                if (a2) {
                    this.w = 1;
                    this.p = (int) motionEvent.getX();
                } else if (b2) {
                    this.w = 2;
                    this.m = (int) motionEvent.getY();
                }
                a(2);
                return;
            }
            return;
        }
        if (motionEvent.getAction() == 1 && this.v == 2) {
            this.m = 0.0f;
            this.p = 0.0f;
            a(1);
            this.w = 0;
            return;
        }
        if (motionEvent.getAction() == 2 && this.v == 2) {
            b();
            if (this.w == 1) {
                float x = motionEvent.getX();
                int[] iArr = this.y;
                int i = this.f783b;
                iArr[0] = i;
                iArr[1] = this.q - i;
                float max = Math.max(iArr[0], Math.min(iArr[1], x));
                if (Math.abs(this.o - max) >= 2.0f) {
                    int a3 = a(this.p, max, iArr, this.s.computeHorizontalScrollRange(), this.s.computeHorizontalScrollOffset(), this.q);
                    if (a3 != 0) {
                        this.s.scrollBy(a3, 0);
                    }
                    this.p = max;
                }
            }
            if (this.w == 2) {
                float y = motionEvent.getY();
                int[] iArr2 = this.x;
                int i2 = this.f783b;
                iArr2[0] = i2;
                iArr2[1] = this.r - i2;
                float max2 = Math.max(iArr2[0], Math.min(iArr2[1], y));
                if (Math.abs(this.l - max2) < 2.0f) {
                    return;
                }
                int a4 = a(this.m, max2, iArr2, this.s.computeVerticalScrollRange(), this.s.computeVerticalScrollOffset(), this.r);
                if (a4 != 0) {
                    this.s.scrollBy(0, a4);
                }
                this.m = max2;
            }
        }
    }
}
