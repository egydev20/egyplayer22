package b.j.c;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;
import b.j.c.t;

/* loaded from: classes.dex */
public class h extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ t.z f762a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f763b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f764c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f765d;
    public final /* synthetic */ ViewPropertyAnimator e;
    public final /* synthetic */ k f;

    public h(k kVar, t.z zVar, int i, View view, int i2, ViewPropertyAnimator viewPropertyAnimator) {
        this.f = kVar;
        this.f762a = zVar;
        this.f763b = i;
        this.f764c = view;
        this.f765d = i2;
        this.e = viewPropertyAnimator;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
        if (this.f763b != 0) {
            this.f764c.setTranslationX(0.0f);
        }
        if (this.f765d != 0) {
            this.f764c.setTranslationY(0.0f);
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
        this.e.setListener(null);
        this.f.a(this.f762a);
        this.f.p.remove(this.f762a);
        this.f.d();
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationStart(Animator animator) {
        if (this.f == null) {
            throw null;
        }
    }
}
