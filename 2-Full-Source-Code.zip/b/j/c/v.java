package b.j.c;

import android.view.View;
import b.j.c.a;
import b.j.c.t;

/* loaded from: classes.dex */
public class v implements a.InterfaceC0027a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ t f870a;

    public v(t tVar) {
        this.f870a = tVar;
    }

    public t.z a(int i) {
        t tVar = this.f870a;
        int b2 = tVar.f.b();
        int i2 = 0;
        t.z zVar = null;
        while (true) {
            if (i2 >= b2) {
                break;
            }
            t.z f = t.f(tVar.f.d(i2));
            if (f != null && !f.i() && f.f867c == i) {
                if (!tVar.f.c(f.f865a)) {
                    zVar = f;
                    break;
                }
                zVar = f;
            }
            i2++;
        }
        if (zVar == null || this.f870a.f.c(zVar.f865a)) {
            return null;
        }
        return zVar;
    }

    public void a(a.b bVar) {
        int i = bVar.f739a;
        if (i == 1) {
            t tVar = this.f870a;
            tVar.m.a(tVar, bVar.f740b, bVar.f742d);
            return;
        }
        if (i == 2) {
            t tVar2 = this.f870a;
            tVar2.m.b(tVar2, bVar.f740b, bVar.f742d);
        } else if (i == 4) {
            t tVar3 = this.f870a;
            tVar3.m.a(tVar3, bVar.f740b, bVar.f742d, bVar.f741c);
        } else {
            if (i != 8) {
                return;
            }
            t tVar4 = this.f870a;
            tVar4.m.a(tVar4, bVar.f740b, bVar.f742d, 1);
        }
    }

    public void b(int i, int i2) {
        int i3;
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        t tVar = this.f870a;
        int b2 = tVar.f.b();
        int i10 = -1;
        if (i < i2) {
            i4 = i;
            i3 = i2;
            i5 = -1;
        } else {
            i3 = i;
            i4 = i2;
            i5 = 1;
        }
        for (int i11 = 0; i11 < b2; i11++) {
            t.z f = t.f(tVar.f.d(i11));
            if (f != null && (i9 = f.f867c) >= i4 && i9 <= i3) {
                if (i9 == i) {
                    f.a(i2 - i, false);
                } else {
                    f.a(i5, false);
                }
                tVar.g0.f = true;
            }
        }
        t.r rVar = tVar.f811c;
        if (i < i2) {
            i7 = i;
            i6 = i2;
        } else {
            i6 = i;
            i7 = i2;
            i10 = 1;
        }
        int size = rVar.f846c.size();
        for (int i12 = 0; i12 < size; i12++) {
            t.z zVar = rVar.f846c.get(i12);
            if (zVar != null && (i8 = zVar.f867c) >= i7 && i8 <= i6) {
                if (i8 == i) {
                    zVar.a(i2 - i, false);
                } else {
                    zVar.a(i10, false);
                }
            }
        }
        tVar.requestLayout();
        this.f870a.j0 = true;
    }

    public void a(int i, int i2, Object obj) {
        int i3;
        int i4;
        t tVar = this.f870a;
        int b2 = tVar.f.b();
        int i5 = i2 + i;
        for (int i6 = 0; i6 < b2; i6++) {
            View d2 = tVar.f.d(i6);
            t.z f = t.f(d2);
            if (f != null && !f.o() && (i4 = f.f867c) >= i && i4 < i5) {
                f.a(2);
                f.a(obj);
                ((t.m) d2.getLayoutParams()).f836c = true;
            }
        }
        t.r rVar = tVar.f811c;
        int size = rVar.f846c.size();
        while (true) {
            size--;
            if (size < 0) {
                this.f870a.k0 = true;
                return;
            }
            t.z zVar = rVar.f846c.get(size);
            if (zVar != null && (i3 = zVar.f867c) >= i && i3 < i5) {
                zVar.a(2);
                rVar.c(size);
            }
        }
    }

    public void a(int i, int i2) {
        t tVar = this.f870a;
        int b2 = tVar.f.b();
        for (int i3 = 0; i3 < b2; i3++) {
            t.z f = t.f(tVar.f.d(i3));
            if (f != null && !f.o() && f.f867c >= i) {
                f.a(i2, false);
                tVar.g0.f = true;
            }
        }
        t.r rVar = tVar.f811c;
        int size = rVar.f846c.size();
        for (int i4 = 0; i4 < size; i4++) {
            t.z zVar = rVar.f846c.get(i4);
            if (zVar != null && zVar.f867c >= i) {
                zVar.a(i2, true);
            }
        }
        tVar.requestLayout();
        this.f870a.j0 = true;
    }
}
