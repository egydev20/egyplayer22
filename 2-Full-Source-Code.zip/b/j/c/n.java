package b.j.c;

/* loaded from: classes.dex */
public class n {

    /* renamed from: b, reason: collision with root package name */
    public int f803b;

    /* renamed from: c, reason: collision with root package name */
    public int f804c;

    /* renamed from: d, reason: collision with root package name */
    public int f805d;
    public int e;
    public boolean h;
    public boolean i;

    /* renamed from: a, reason: collision with root package name */
    public boolean f802a = true;
    public int f = 0;
    public int g = 0;

    public String toString() {
        StringBuilder a2 = c.a.b.a.a.a("LayoutState{mAvailable=");
        a2.append(this.f803b);
        a2.append(", mCurrentPosition=");
        a2.append(this.f804c);
        a2.append(", mItemDirection=");
        a2.append(this.f805d);
        a2.append(", mLayoutDirection=");
        a2.append(this.e);
        a2.append(", mStartLine=");
        a2.append(this.f);
        a2.append(", mEndLine=");
        a2.append(this.g);
        a2.append('}');
        return a2.toString();
    }
}
