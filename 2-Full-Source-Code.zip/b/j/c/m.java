package b.j.c;

import android.os.Trace;
import b.j.c.t;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
public final class m implements Runnable {
    public static final ThreadLocal<m> f = new ThreadLocal<>();
    public static Comparator<c> g = new a();

    /* renamed from: c, reason: collision with root package name */
    public long f792c;

    /* renamed from: d, reason: collision with root package name */
    public long f793d;

    /* renamed from: b, reason: collision with root package name */
    public ArrayList<t> f791b = new ArrayList<>();
    public ArrayList<c> e = new ArrayList<>();

    /* loaded from: classes.dex */
    public static class a implements Comparator<c> {
        /* JADX WARN: Code restructure failed: missing block: B:10:0x0019, code lost:
        
            if (r6.f801d == null) goto L19;
         */
        /* JADX WARN: Code restructure failed: missing block: B:11:0x0024, code lost:
        
            r1 = -1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:13:?, code lost:
        
            return r1;
         */
        /* JADX WARN: Code restructure failed: missing block: B:17:0x0022, code lost:
        
            if (r0 != false) goto L18;
         */
        @Override // java.util.Comparator
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public int compare(b.j.c.m.c r6, b.j.c.m.c r7) {
            /*
                r5 = this;
                b.j.c.m$c r6 = (b.j.c.m.c) r6
                b.j.c.m$c r7 = (b.j.c.m.c) r7
                b.j.c.t r0 = r6.f801d
                r1 = 1
                r2 = 0
                if (r0 != 0) goto Lc
                r0 = 1
                goto Ld
            Lc:
                r0 = 0
            Ld:
                b.j.c.t r3 = r7.f801d
                if (r3 != 0) goto L13
                r3 = 1
                goto L14
            L13:
                r3 = 0
            L14:
                r4 = -1
                if (r0 == r3) goto L1c
                b.j.c.t r6 = r6.f801d
                if (r6 != 0) goto L24
                goto L25
            L1c:
                boolean r0 = r6.f798a
                boolean r3 = r7.f798a
                if (r0 == r3) goto L27
                if (r0 == 0) goto L25
            L24:
                r1 = -1
            L25:
                r2 = r1
                goto L38
            L27:
                int r0 = r7.f799b
                int r1 = r6.f799b
                int r0 = r0 - r1
                if (r0 == 0) goto L30
                r2 = r0
                goto L38
            L30:
                int r6 = r6.f800c
                int r7 = r7.f800c
                int r6 = r6 - r7
                if (r6 == 0) goto L38
                r2 = r6
            L38:
                return r2
            */
            throw new UnsupportedOperationException("Method not decompiled: b.j.c.m.a.compare(java.lang.Object, java.lang.Object):int");
        }
    }

    /* loaded from: classes.dex */
    public static class b implements t.l.c {

        /* renamed from: a, reason: collision with root package name */
        public int f794a;

        /* renamed from: b, reason: collision with root package name */
        public int f795b;

        /* renamed from: c, reason: collision with root package name */
        public int[] f796c;

        /* renamed from: d, reason: collision with root package name */
        public int f797d;

        public void a(int i, int i2) {
            if (i < 0) {
                throw new IllegalArgumentException("Layout positions must be non-negative");
            }
            if (i2 < 0) {
                throw new IllegalArgumentException("Pixel distance must be non-negative");
            }
            int i3 = this.f797d * 2;
            int[] iArr = this.f796c;
            if (iArr == null) {
                int[] iArr2 = new int[4];
                this.f796c = iArr2;
                Arrays.fill(iArr2, -1);
            } else if (i3 >= iArr.length) {
                int[] iArr3 = new int[i3 * 2];
                this.f796c = iArr3;
                System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
            }
            int[] iArr4 = this.f796c;
            iArr4[i3] = i;
            iArr4[i3 + 1] = i2;
            this.f797d++;
        }

        public void a(t tVar, boolean z) {
            this.f797d = 0;
            int[] iArr = this.f796c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            t.l lVar = tVar.m;
            if (tVar.l == null || lVar == null || !lVar.l) {
                return;
            }
            if (z) {
                if (!tVar.e.c()) {
                    lVar.a(tVar.l.a(), this);
                }
            } else if (!tVar.l()) {
                lVar.a(this.f794a, this.f795b, tVar.g0, this);
            }
            int i = this.f797d;
            if (i > lVar.m) {
                lVar.m = i;
                lVar.n = z;
                tVar.f811c.d();
            }
        }

        public boolean a(int i) {
            if (this.f796c != null) {
                int i2 = this.f797d * 2;
                for (int i3 = 0; i3 < i2; i3 += 2) {
                    if (this.f796c[i3] == i) {
                        return true;
                    }
                }
            }
            return false;
        }
    }

    /* loaded from: classes.dex */
    public static class c {

        /* renamed from: a, reason: collision with root package name */
        public boolean f798a;

        /* renamed from: b, reason: collision with root package name */
        public int f799b;

        /* renamed from: c, reason: collision with root package name */
        public int f800c;

        /* renamed from: d, reason: collision with root package name */
        public t f801d;
        public int e;
    }

    public void a(t tVar, int i, int i2) {
        if (tVar.r && this.f792c == 0) {
            this.f792c = tVar.getNanoTime();
            tVar.post(this);
        }
        b bVar = tVar.f0;
        bVar.f794a = i;
        bVar.f795b = i2;
    }

    @Override // java.lang.Runnable
    public void run() {
        try {
            Trace.beginSection("RV Prefetch");
            if (this.f791b.isEmpty()) {
                return;
            }
            int size = this.f791b.size();
            long j = 0;
            for (int i = 0; i < size; i++) {
                t tVar = this.f791b.get(i);
                if (tVar.getWindowVisibility() == 0) {
                    j = Math.max(tVar.getDrawingTime(), j);
                }
            }
            if (j == 0) {
                return;
            }
            a(TimeUnit.MILLISECONDS.toNanos(j) + this.f793d);
        } finally {
            this.f792c = 0L;
            Trace.endSection();
        }
    }

    public void a(long j) {
        t tVar;
        c cVar;
        int size = this.f791b.size();
        int i = 0;
        for (int i2 = 0; i2 < size; i2++) {
            t tVar2 = this.f791b.get(i2);
            if (tVar2.getWindowVisibility() == 0) {
                tVar2.f0.a(tVar2, false);
                i += tVar2.f0.f797d;
            }
        }
        this.e.ensureCapacity(i);
        int i3 = 0;
        for (int i4 = 0; i4 < size; i4++) {
            t tVar3 = this.f791b.get(i4);
            if (tVar3.getWindowVisibility() == 0) {
                b bVar = tVar3.f0;
                int abs = Math.abs(bVar.f795b) + Math.abs(bVar.f794a);
                for (int i5 = 0; i5 < bVar.f797d * 2; i5 += 2) {
                    if (i3 >= this.e.size()) {
                        cVar = new c();
                        this.e.add(cVar);
                    } else {
                        cVar = this.e.get(i3);
                    }
                    int i6 = bVar.f796c[i5 + 1];
                    cVar.f798a = i6 <= abs;
                    cVar.f799b = abs;
                    cVar.f800c = i6;
                    cVar.f801d = tVar3;
                    cVar.e = bVar.f796c[i5];
                    i3++;
                }
            }
        }
        Collections.sort(this.e, g);
        for (int i7 = 0; i7 < this.e.size(); i7++) {
            c cVar2 = this.e.get(i7);
            if (cVar2.f801d == null) {
                return;
            }
            t.z a2 = a(cVar2.f801d, cVar2.e, cVar2.f798a ? Long.MAX_VALUE : j);
            if (a2 != null && a2.f866b != null && a2.f() && !a2.g() && (tVar = a2.f866b.get()) != null) {
                if (tVar.C && tVar.f.b() != 0) {
                    tVar.s();
                }
                b bVar2 = tVar.f0;
                bVar2.a(tVar, true);
                if (bVar2.f797d != 0) {
                    try {
                        Trace.beginSection("RV Nested Prefetch");
                        t.w wVar = tVar.g0;
                        t.d dVar = tVar.l;
                        wVar.f861d = 1;
                        wVar.e = dVar.a();
                        wVar.g = false;
                        wVar.h = false;
                        wVar.i = false;
                        for (int i8 = 0; i8 < bVar2.f797d * 2; i8 += 2) {
                            a(tVar, bVar2.f796c[i8], j);
                        }
                    } finally {
                        Trace.endSection();
                    }
                } else {
                    continue;
                }
            }
            cVar2.f798a = false;
            cVar2.f799b = 0;
            cVar2.f800c = 0;
            cVar2.f801d = null;
            cVar2.e = 0;
        }
    }

    public final t.z a(t tVar, int i, long j) {
        boolean z;
        int b2 = tVar.f.b();
        int i2 = 0;
        while (true) {
            if (i2 >= b2) {
                z = false;
                break;
            }
            t.z f2 = t.f(tVar.f.d(i2));
            if (f2.f867c == i && !f2.g()) {
                z = true;
                break;
            }
            i2++;
        }
        if (z) {
            return null;
        }
        t.r rVar = tVar.f811c;
        try {
            tVar.p();
            t.z a2 = rVar.a(i, false, j);
            if (a2 != null) {
                if (!a2.f() || a2.g()) {
                    rVar.a(a2, false);
                } else {
                    rVar.a(a2.f865a);
                }
            }
            return a2;
        } finally {
            tVar.a(false);
        }
    }
}
