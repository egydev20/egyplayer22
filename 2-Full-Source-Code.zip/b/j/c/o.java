package b.j.c;

import android.content.Context;
import android.graphics.PointF;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import b.j.c.t;

/* loaded from: classes.dex */
public class o extends t.v {
    public final float k;
    public final LinearInterpolator i = new LinearInterpolator();
    public final DecelerateInterpolator j = new DecelerateInterpolator();
    public int l = 0;
    public int m = 0;

    public o(Context context) {
        this.k = 25.0f / context.getResources().getDisplayMetrics().densityDpi;
    }

    @Override // b.j.c.t.v
    public void a() {
        this.m = 0;
        this.l = 0;
    }

    public void a(t.v.a aVar) {
        PointF a2 = a(this.f850a);
        if (a2 != null && (a2.x != 0.0f || a2.y != 0.0f)) {
            float f = a2.x;
            float f2 = a2.y;
            float sqrt = (float) Math.sqrt((f2 * f2) + (f * f));
            float f3 = a2.x / sqrt;
            a2.x = f3;
            float f4 = a2.y / sqrt;
            a2.y = f4;
            this.l = (int) (f3 * 10000.0f);
            this.m = (int) (f4 * 10000.0f);
            int c2 = c(10000);
            LinearInterpolator linearInterpolator = this.i;
            aVar.f854a = (int) (this.l * 1.2f);
            aVar.f855b = (int) (this.m * 1.2f);
            aVar.f856c = (int) (c2 * 1.2f);
            aVar.e = linearInterpolator;
            aVar.f = true;
            return;
        }
        aVar.f857d = this.f850a;
        b();
    }

    public int c(int i) {
        return (int) Math.ceil(Math.abs(i) * this.k);
    }
}
