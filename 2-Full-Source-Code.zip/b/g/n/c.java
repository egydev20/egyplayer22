package b.g.n;

/* loaded from: classes.dex */
public interface c {
    b a(int i);
}
