package b.g.n;

import android.os.SystemClock;
import android.view.MotionEvent;
import androidx.leanback.widget.SearchBar;

/* loaded from: classes.dex */
public class s implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ SearchBar f723b;

    public s(SearchBar searchBar) {
        this.f723b = searchBar;
    }

    @Override // java.lang.Runnable
    public void run() {
        this.f723b.f159c.requestFocusFromTouch();
        this.f723b.f159c.dispatchTouchEvent(MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 0, this.f723b.f159c.getWidth(), this.f723b.f159c.getHeight(), 0));
        this.f723b.f159c.dispatchTouchEvent(MotionEvent.obtain(SystemClock.uptimeMillis(), SystemClock.uptimeMillis(), 1, this.f723b.f159c.getWidth(), this.f723b.f159c.getHeight(), 0));
    }
}
