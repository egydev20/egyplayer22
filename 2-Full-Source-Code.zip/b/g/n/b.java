package b.g.n;

/* loaded from: classes.dex */
public interface b {
    Object a(Class<?> cls);
}
