package b.g.n;

import android.view.View;
import android.view.ViewGroup;

@Deprecated
/* loaded from: classes.dex */
public interface n {
    void a(ViewGroup viewGroup, View view, int i, long j);
}
