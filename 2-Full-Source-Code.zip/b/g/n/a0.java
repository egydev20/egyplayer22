package b.g.n;

/* loaded from: classes.dex */
public class a0 {

    /* renamed from: a, reason: collision with root package name */
    public int f675a = 0;

    /* renamed from: b, reason: collision with root package name */
    public final a f676b = new a("vertical");

    /* renamed from: c, reason: collision with root package name */
    public final a f677c;

    /* renamed from: d, reason: collision with root package name */
    public a f678d;
    public a e;

    public a0() {
        a aVar = new a("horizontal");
        this.f677c = aVar;
        this.f678d = aVar;
        this.e = this.f676b;
    }

    public String toString() {
        StringBuilder a2 = c.a.b.a.a.a("horizontal=");
        a2.append(this.f677c);
        a2.append("; vertical=");
        a2.append(this.f676b);
        return a2.toString();
    }

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: c, reason: collision with root package name */
        public int f681c;

        /* renamed from: d, reason: collision with root package name */
        public int f682d;
        public int i;
        public int j;
        public int k;
        public boolean l;
        public int e = 2;
        public int f = 3;
        public int g = 0;
        public float h = 50.0f;

        /* renamed from: b, reason: collision with root package name */
        public int f680b = Integer.MIN_VALUE;

        /* renamed from: a, reason: collision with root package name */
        public int f679a = Integer.MAX_VALUE;

        public a(String str) {
        }

        public final int a() {
            if (this.l) {
                int i = this.g;
                int i2 = i >= 0 ? this.i - i : -i;
                float f = this.h;
                return f != -1.0f ? i2 - ((int) ((this.i * f) / 100.0f)) : i2;
            }
            int i3 = this.g;
            if (i3 < 0) {
                i3 += this.i;
            }
            float f2 = this.h;
            return f2 != -1.0f ? i3 + ((int) ((this.i * f2) / 100.0f)) : i3;
        }

        public final int a(int i) {
            int i2;
            int i3;
            int i4 = this.i;
            int a2 = a();
            boolean d2 = d();
            boolean c2 = c();
            if (!d2) {
                int i5 = a2 - this.j;
                if (this.l ? (this.f & 2) != 0 : (this.f & 1) != 0) {
                    int i6 = this.f680b;
                    if (i - i6 <= i5) {
                        int i7 = i6 - this.j;
                        return (c2 || i7 <= (i3 = this.f681c)) ? i7 : i3;
                    }
                }
            }
            if (!c2) {
                int i8 = (i4 - a2) - this.k;
                if (this.l ? (this.f & 1) != 0 : (this.f & 2) != 0) {
                    int i9 = this.f679a;
                    if (i9 - i <= i8) {
                        int i10 = i9 - (i4 - this.k);
                        return (d2 || i10 >= (i2 = this.f682d)) ? i10 : i2;
                    }
                }
            }
            return i - a2;
        }

        public final int b() {
            return (this.i - this.j) - this.k;
        }

        public final boolean c() {
            return this.f679a == Integer.MAX_VALUE;
        }

        public final boolean d() {
            return this.f680b == Integer.MIN_VALUE;
        }

        public String toString() {
            StringBuilder a2 = c.a.b.a.a.a(" min:");
            a2.append(this.f680b);
            a2.append(" ");
            a2.append(this.f682d);
            a2.append(" max:");
            a2.append(this.f679a);
            a2.append(" ");
            a2.append(this.f681c);
            return a2.toString();
        }

        /* JADX WARN: Code restructure failed: missing block: B:18:0x0043, code lost:
        
            r5.f681c = (r5.f679a - r5.j) - r6;
         */
        /* JADX WARN: Code restructure failed: missing block: B:30:0x0066, code lost:
        
            if (((r5.e & 1) != 0) != false) goto L35;
         */
        /* JADX WARN: Code restructure failed: missing block: B:32:0x00ad, code lost:
        
            r5.f682d = java.lang.Math.min(r5.f682d, r9 - r7);
         */
        /* JADX WARN: Code restructure failed: missing block: B:33:0x00b3, code lost:
        
            r5.f681c = java.lang.Math.max(r5.f682d, r5.f681c);
         */
        /* JADX WARN: Code restructure failed: missing block: B:34:0x00bd, code lost:
        
            return;
         */
        /* JADX WARN: Code restructure failed: missing block: B:41:0x0078, code lost:
        
            if (((r5.e & 2) != 0) != false) goto L51;
         */
        /* JADX WARN: Code restructure failed: missing block: B:44:0x008a, code lost:
        
            r5.f681c = java.lang.Math.max(r5.f681c, r8 - r7);
         */
        /* JADX WARN: Code restructure failed: missing block: B:51:0x0088, code lost:
        
            if (((r5.e & 1) != 0) != false) goto L51;
         */
        /* JADX WARN: Code restructure failed: missing block: B:57:0x00aa, code lost:
        
            if (((r5.e & 2) != 0) != false) goto L35;
         */
        /* JADX WARN: Code restructure failed: missing block: B:9:0x0027, code lost:
        
            r3 = r5.f680b - r5.j;
         */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public final void a(int r6, int r7, int r8, int r9) {
            /*
                Method dump skipped, instructions count: 190
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: b.g.n.a0.a.a(int, int, int, int):void");
        }
    }
}
