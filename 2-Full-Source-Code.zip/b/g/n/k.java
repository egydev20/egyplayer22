package b.g.n;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;
import b.g.n.e;
import b.g.n.j;

/* loaded from: classes.dex */
public class k {

    /* renamed from: a, reason: collision with root package name */
    public static Rect f713a = new Rect();

    public static int a(View view, j.a aVar, int i) {
        View view2;
        int height;
        e.d dVar = (e.d) view.getLayoutParams();
        int i2 = aVar.f709a;
        if (i2 == 0 || (view2 = view.findViewById(i2)) == null) {
            view2 = view;
        }
        int i3 = aVar.f711c;
        if (i != 0) {
            if (aVar.e) {
                float f = aVar.f712d;
                if (f == 0.0f) {
                    i3 += view2.getPaddingTop();
                } else if (f == 100.0f) {
                    i3 -= view2.getPaddingBottom();
                }
            }
            if (aVar.f712d != -1.0f) {
                if (view2 != view) {
                    height = view2.getHeight();
                } else {
                    if (dVar == null) {
                        throw null;
                    }
                    height = (view2.getHeight() - dVar.f) - dVar.h;
                }
                i3 += (int) ((height * aVar.f712d) / 100.0f);
            }
            if (view == view2) {
                return i3;
            }
            Rect rect = f713a;
            rect.top = i3;
            ((ViewGroup) view).offsetDescendantRectToMyCoords(view2, rect);
            return f713a.top - dVar.f;
        }
        if (view.getLayoutDirection() == 1) {
            int a2 = (view2 == view ? dVar.a(view2) : view2.getWidth()) - i3;
            if (aVar.e) {
                float f2 = aVar.f712d;
                if (f2 == 0.0f) {
                    a2 -= view2.getPaddingRight();
                } else if (f2 == 100.0f) {
                    a2 += view2.getPaddingLeft();
                }
            }
            if (aVar.f712d != -1.0f) {
                a2 -= (int) (((view2 == view ? dVar.a(view2) : view2.getWidth()) * aVar.f712d) / 100.0f);
            }
            if (view == view2) {
                return a2;
            }
            Rect rect2 = f713a;
            rect2.right = a2;
            ((ViewGroup) view).offsetDescendantRectToMyCoords(view2, rect2);
            return f713a.right + dVar.g;
        }
        if (aVar.e) {
            float f3 = aVar.f712d;
            if (f3 == 0.0f) {
                i3 += view2.getPaddingLeft();
            } else if (f3 == 100.0f) {
                i3 -= view2.getPaddingRight();
            }
        }
        if (aVar.f712d != -1.0f) {
            i3 += (int) (((view2 == view ? dVar.a(view2) : view2.getWidth()) * aVar.f712d) / 100.0f);
        }
        int i4 = i3;
        if (view == view2) {
            return i4;
        }
        Rect rect3 = f713a;
        rect3.left = i4;
        ((ViewGroup) view).offsetDescendantRectToMyCoords(view2, rect3);
        return f713a.left - dVar.e;
    }
}
