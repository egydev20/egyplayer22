package b.g.n;

import android.content.Context;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.animation.DecelerateInterpolator;
import b.d.k.r.b;
import b.g.n.a0;
import b.g.n.b0.a;
import b.g.n.d;
import b.g.n.i;
import b.g.n.j;
import b.j.c.m;
import b.j.c.t;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import org.videolan.libvlc.interfaces.IMediaList;

/* loaded from: classes.dex */
public final class e extends t.l {
    public static final Rect k0 = new Rect();
    public static int[] l0 = new int[2];
    public int[] A;
    public t.r B;
    public c I;
    public C0026e J;
    public int L;
    public int N;
    public int O;
    public int P;
    public int[] Q;
    public int R;
    public int S;
    public int T;
    public int U;
    public int V;
    public int X;
    public b.g.n.d Z;
    public int d0;
    public int e0;
    public b.g.n.c h0;
    public final b.g.n.a t;
    public t.w w;
    public int x;
    public int y;
    public int s = 10;
    public int u = 0;
    public b.j.c.s v = new b.j.c.q(this);
    public final SparseIntArray z = new SparseIntArray();
    public int C = 221696;
    public n D = null;
    public ArrayList<o> E = null;
    public m F = null;
    public int G = -1;
    public int H = 0;
    public int K = 0;
    public int W = 8388659;
    public int Y = 1;
    public int a0 = 0;
    public final a0 b0 = new a0();
    public final i c0 = new i();
    public int[] f0 = new int[2];
    public final z g0 = new z();
    public final Runnable i0 = new a();
    public d.b j0 = new b();
    public int M = -1;

    /* loaded from: classes.dex */
    public class a implements Runnable {
        public a() {
        }

        @Override // java.lang.Runnable
        public void run() {
            e.this.r();
        }
    }

    /* loaded from: classes.dex */
    public static final class d extends t.m {
        public int e;
        public int f;
        public int g;
        public int h;
        public int i;
        public int j;
        public int[] k;
        public j l;

        public d(int i, int i2) {
            super(i, i2);
        }

        public d(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public d(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public d(ViewGroup.MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public d(d dVar) {
            super((t.m) dVar);
        }

        public d(t.m mVar) {
            super(mVar);
        }

        public int a(View view) {
            return (view.getWidth() - this.e) - this.g;
        }
    }

    /* renamed from: b.g.n.e$e, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public final class C0026e extends c {
        public final boolean p;
        public int q;

        public C0026e(int i, boolean z) {
            super();
            this.q = i;
            this.p = z;
            this.f850a = -2;
        }

        @Override // b.j.c.t.v
        public PointF a(int i) {
            int i2 = this.q;
            if (i2 == 0) {
                return null;
            }
            int i3 = ((e.this.C & 262144) == 0 ? i2 >= 0 : i2 <= 0) ? 1 : -1;
            return e.this.u == 0 ? new PointF(i3, 0.0f) : new PointF(0.0f, i3);
        }

        @Override // b.j.c.o
        public void a(t.v.a aVar) {
            if (this.q == 0) {
                return;
            }
            super.a(aVar);
        }

        @Override // b.g.n.e.c
        public void c() {
            super.c();
            this.q = 0;
            View b2 = b(this.f850a);
            if (b2 != null) {
                e.this.a(b2, true);
            }
        }
    }

    /* loaded from: classes.dex */
    public static final class f implements Parcelable {
        public static final Parcelable.Creator<f> CREATOR = new a();

        /* renamed from: b, reason: collision with root package name */
        public int f702b;

        /* renamed from: c, reason: collision with root package name */
        public Bundle f703c;

        /* loaded from: classes.dex */
        public static class a implements Parcelable.Creator<f> {
            @Override // android.os.Parcelable.Creator
            public f createFromParcel(Parcel parcel) {
                return new f(parcel);
            }

            @Override // android.os.Parcelable.Creator
            public f[] newArray(int i) {
                return new f[i];
            }
        }

        public f() {
            this.f703c = Bundle.EMPTY;
        }

        public f(Parcel parcel) {
            this.f703c = Bundle.EMPTY;
            this.f702b = parcel.readInt();
            this.f703c = parcel.readBundle(e.class.getClassLoader());
        }

        @Override // android.os.Parcelable
        public int describeContents() {
            return 0;
        }

        @Override // android.os.Parcelable
        public void writeToParcel(Parcel parcel, int i) {
            parcel.writeInt(this.f702b);
            parcel.writeBundle(this.f703c);
        }
    }

    public e(b.g.n.a aVar) {
        this.t = aVar;
        if (this.l) {
            this.l = false;
            this.m = 0;
            b.j.c.t tVar = this.f825b;
            if (tVar != null) {
                tVar.f811c.d();
            }
        }
    }

    public boolean A() {
        return this.Z != null;
    }

    public final void B() {
        this.B = null;
        this.w = null;
        this.x = 0;
        this.y = 0;
    }

    public final void C() {
        this.Z.b((this.C & 262144) != 0 ? this.d0 + this.e0 + this.y : (-this.e0) - this.y, false);
    }

    public final void D() {
        int i = this.C;
        if ((65600 & i) == 65536) {
            b.g.n.d dVar = this.Z;
            int i2 = this.G;
            int i3 = (i & 262144) != 0 ? -this.e0 : this.d0 + this.e0;
            while (true) {
                int i4 = dVar.g;
                if (i4 < dVar.f || i4 <= i2) {
                    break;
                }
                boolean z = false;
                if (dVar.f697c ? ((b) dVar.f696b).a(i4) <= i3 : ((b) dVar.f696b).a(i4) >= i3) {
                    z = true;
                }
                if (!z) {
                    break;
                }
                ((b) dVar.f696b).c(dVar.g);
                dVar.g--;
            }
            dVar.b();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:13:0x003d, code lost:
    
        if ((((b.g.n.e.b) r1.f696b).a(r1.f) + r3) <= r0) goto L18;
     */
    /* JADX WARN: Code restructure failed: missing block: B:14:0x004e, code lost:
    
        if (r5 == false) goto L25;
     */
    /* JADX WARN: Code restructure failed: missing block: B:20:0x004d, code lost:
    
        r5 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:22:0x004b, code lost:
    
        if ((((b.g.n.e.b) r1.f696b).a(r1.f) - r3) >= r0) goto L18;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void E() {
        /*
            r8 = this;
            int r0 = r8.C
            r1 = 65600(0x10040, float:9.1925E-41)
            r1 = r1 & r0
            r2 = 65536(0x10000, float:9.18355E-41)
            if (r1 != r2) goto L62
            b.g.n.d r1 = r8.Z
            int r2 = r8.G
            r3 = 262144(0x40000, float:3.67342E-40)
            r0 = r0 & r3
            if (r0 == 0) goto L19
            int r0 = r8.d0
            int r3 = r8.e0
            int r0 = r0 + r3
            goto L1c
        L19:
            int r0 = r8.e0
            int r0 = -r0
        L1c:
            int r3 = r1.g
            int r4 = r1.f
            if (r3 < r4) goto L5f
            if (r4 >= r2) goto L5f
            b.g.n.d$b r3 = r1.f696b
            b.g.n.e$b r3 = (b.g.n.e.b) r3
            int r3 = r3.b(r4)
            boolean r4 = r1.f697c
            r5 = 0
            r6 = 1
            if (r4 != 0) goto L40
            b.g.n.d$b r4 = r1.f696b
            int r7 = r1.f
            b.g.n.e$b r4 = (b.g.n.e.b) r4
            int r4 = r4.a(r7)
            int r4 = r4 + r3
            if (r4 > r0) goto L4e
            goto L4d
        L40:
            b.g.n.d$b r4 = r1.f696b
            int r7 = r1.f
            b.g.n.e$b r4 = (b.g.n.e.b) r4
            int r4 = r4.a(r7)
            int r4 = r4 - r3
            if (r4 < r0) goto L4e
        L4d:
            r5 = 1
        L4e:
            if (r5 == 0) goto L5f
            b.g.n.d$b r3 = r1.f696b
            int r4 = r1.f
            b.g.n.e$b r3 = (b.g.n.e.b) r3
            r3.c(r4)
            int r3 = r1.f
            int r3 = r3 + r6
            r1.f = r3
            goto L1c
        L5f:
            r1.b()
        L62:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.n.e.E():void");
    }

    public final void F() {
        int d2 = d();
        for (int i = 0; i < d2; i++) {
            w(c(i));
        }
    }

    public void G() {
        int i = 0;
        if (d() > 0) {
            i = this.Z.f - ((d) c(0).getLayoutParams()).b();
        }
        this.x = i;
    }

    public final void H() {
        int i = (this.C & (-1025)) | (b(false) ? 1024 : 0);
        this.C = i;
        if ((i & 1024) != 0) {
            b.d.k.l.a(this.t, this.i0);
        }
    }

    public void I() {
        int i;
        int i2;
        int a2;
        int i3;
        int i4;
        int i5;
        if (this.w.a() == 0) {
            return;
        }
        if ((this.C & 262144) == 0) {
            i3 = this.Z.g;
            int a3 = this.w.a() - 1;
            i = this.Z.f;
            i2 = a3;
            a2 = 0;
        } else {
            b.g.n.d dVar = this.Z;
            int i6 = dVar.f;
            i = dVar.g;
            i2 = 0;
            a2 = this.w.a() - 1;
            i3 = i6;
        }
        if (i3 < 0 || i < 0) {
            return;
        }
        boolean z = i3 == i2;
        boolean z2 = i == a2;
        if (z || !this.b0.f678d.c() || z2 || !this.b0.f678d.d()) {
            int i7 = Integer.MAX_VALUE;
            if (z) {
                i7 = this.Z.a(true, l0);
                View b2 = b(l0[1]);
                i4 = p(b2);
                int[] iArr = ((d) b2.getLayoutParams()).k;
                if (iArr != null && iArr.length > 0) {
                    i4 = (iArr[iArr.length - 1] - iArr[0]) + i4;
                }
            } else {
                i4 = Integer.MAX_VALUE;
            }
            int i8 = Integer.MIN_VALUE;
            if (z2) {
                i8 = this.Z.b(false, l0);
                i5 = p(b(l0[1]));
            } else {
                i5 = Integer.MIN_VALUE;
            }
            this.b0.f678d.a(i8, i7, i5, i4);
        }
    }

    public final void J() {
        a0.a aVar = this.b0.e;
        int i = aVar.j - this.N;
        int x = x() + i;
        aVar.a(i, x, i, x);
    }

    @Override // b.j.c.t.l
    public int a(int i, t.r rVar, t.w wVar) {
        if ((this.C & IMediaList.Event.ItemAdded) == 0 || !A()) {
            return 0;
        }
        d(rVar, wVar);
        this.C = (this.C & (-4)) | 2;
        int n = this.u == 0 ? n(i) : o(i);
        B();
        this.C &= -4;
        return n;
    }

    public int a(boolean z, int i) {
        b.g.n.d dVar = this.Z;
        if (dVar == null) {
            return i;
        }
        int i2 = this.G;
        int d2 = i2 != -1 ? dVar.d(i2) : -1;
        View view = null;
        int d3 = d();
        for (int i3 = 0; i3 < d3 && i != 0; i3++) {
            int i4 = i > 0 ? i3 : (d3 - 1) - i3;
            View c2 = c(i4);
            if (k(c2)) {
                int i5 = i(i4);
                int d4 = this.Z.d(i5);
                if (d2 == -1) {
                    i2 = i5;
                    view = c2;
                    d2 = d4;
                } else if (d4 == d2 && ((i > 0 && i5 > i2) || (i < 0 && i5 < i2))) {
                    i = i > 0 ? i - 1 : i + 1;
                    i2 = i5;
                    view = c2;
                }
            }
        }
        if (view != null) {
            if (z) {
                if (n()) {
                    this.C |= 32;
                    view.requestFocus();
                    this.C &= -33;
                }
                this.G = i2;
                this.H = 0;
            } else {
                a(view, true);
            }
        }
        return i;
    }

    /* JADX WARN: Removed duplicated region for block: B:30:0x00ca A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:31:0x00cb  */
    @Override // b.j.c.t.l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.view.View a(android.view.View r8, int r9) {
        /*
            Method dump skipped, instructions count: 222
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.n.e.a(android.view.View, int):android.view.View");
    }

    @Override // b.j.c.t.l
    public t.m a(Context context, AttributeSet attributeSet) {
        return new d(context, attributeSet);
    }

    @Override // b.j.c.t.l
    public t.m a(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof d ? new d((d) layoutParams) : layoutParams instanceof t.m ? new d((t.m) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new d((ViewGroup.MarginLayoutParams) layoutParams) : new d(layoutParams);
    }

    @Override // b.j.c.t.l
    public void a(int i, int i2, t.w wVar, t.l.c cVar) {
        try {
            d(null, wVar);
            if (this.u != 0) {
                i = i2;
            }
            if (d() != 0 && i != 0) {
                this.Z.a(i < 0 ? -this.e0 : this.d0 + this.e0, i, cVar);
            }
        } finally {
            B();
        }
    }

    @Override // b.j.c.t.l
    public void a(int i, t.l.c cVar) {
        int i2 = this.t.Q0;
        if (i == 0 || i2 == 0) {
            return;
        }
        int max = Math.max(0, Math.min(this.G - ((i2 - 1) / 2), i - i2));
        for (int i3 = max; i3 < i && i3 < max + i2; i3++) {
            ((m.b) cVar).a(i3, 0);
        }
    }

    public void a(View view, boolean z, int i, int i2) {
        a(view, view == null ? null : view.findFocus(), z, i, i2);
    }

    @Override // b.j.c.t.l
    public void a(b.j.c.t tVar) {
        this.K = 0;
        this.g0.b();
    }

    @Override // b.j.c.t.l
    public void a(b.j.c.t tVar, int i, int i2, int i3) {
        int i4;
        int i5;
        int i6 = this.G;
        if (i6 != -1 && (i4 = this.K) != Integer.MIN_VALUE) {
            int i7 = i6 + i4;
            if (i > i7 || i7 >= i + i3) {
                if (i < i7 && i2 > i7 - i3) {
                    i5 = this.K - i3;
                } else if (i > i7 && i2 < i7) {
                    i5 = this.K + i3;
                }
                this.K = i5;
            } else {
                this.K = (i2 - i) + i4;
            }
        }
        this.g0.b();
    }

    public void a(b.j.c.t tVar, t.z zVar, int i, int i2) {
        ArrayList<o> arrayList = this.E;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            a.C0025a c0025a = (a.C0025a) this.E.get(size);
            if (c0025a == null) {
                throw null;
            }
            int indexOf = b.g.n.b0.a.this.f685d.indexOf(tVar);
            b.g.n.b0.a.this.a(indexOf, true);
            if (zVar != null) {
                b.g.n.b0.a.this.a(indexOf, b.g.n.b0.a.this.e.get(indexOf).f690b + i);
            }
        }
    }

    @Override // b.j.c.t.l
    public boolean a() {
        return this.u == 0 || this.X > 1;
    }

    @Override // b.j.c.t.l
    public boolean a(b.j.c.t tVar, View view, Rect rect, boolean z) {
        return false;
    }

    @Override // b.j.c.t.l
    public int b(int i, t.r rVar, t.w wVar) {
        if ((this.C & IMediaList.Event.ItemAdded) == 0 || !A()) {
            return 0;
        }
        this.C = (this.C & (-4)) | 2;
        d(rVar, wVar);
        int n = this.u == 1 ? n(i) : o(i);
        B();
        this.C &= -4;
        return n;
    }

    public void b(int i, int i2, boolean z, int i3) {
        if ((this.G == i || i == -1) && i2 == this.H && i3 == this.L) {
            return;
        }
        a(i, i2, z, i3);
    }

    @Override // b.j.c.t.l
    public void b(t.r rVar) {
        for (int d2 = d() - 1; d2 >= 0; d2--) {
            a(d2, rVar);
        }
    }

    public void b(b.j.c.t tVar, t.z zVar, int i, int i2) {
        ArrayList<o> arrayList = this.E;
        if (arrayList == null) {
            return;
        }
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            if (this.E.get(size) == null) {
                throw null;
            }
        }
    }

    @Override // b.j.c.t.l
    public boolean b() {
        return this.u == 1 || this.X > 1;
    }

    @Override // b.j.c.t.l
    public t.m c() {
        return new d(-2, -2);
    }

    @Override // b.j.c.t.l
    public void c(b.j.c.t tVar, int i, int i2) {
        int i3 = i2 + i;
        while (i < i3) {
            z zVar = this.g0;
            b.c.h<String, SparseArray<Parcelable>> hVar = zVar.f734c;
            if (hVar != null && hVar.b() != 0) {
                zVar.f734c.b(Integer.toString(i));
            }
            i++;
        }
    }

    @Override // b.j.c.t.l
    public int d(View view) {
        return super.d(view) - ((d) view.getLayoutParams()).h;
    }

    public final void d(t.r rVar, t.w wVar) {
        if (this.B != null || this.w != null) {
            Log.e("GridLayoutManager", "Recycler information was not released, bug!");
        }
        this.B = rVar;
        this.w = wVar;
        this.x = 0;
        this.y = 0;
    }

    @Override // b.j.c.t.l
    public int e(View view) {
        return super.e(view) + ((d) view.getLayoutParams()).e;
    }

    @Override // b.j.c.t.l
    public void g(t.w wVar) {
    }

    @Override // b.j.c.t.l
    public int h(View view) {
        return super.h(view) - ((d) view.getLayoutParams()).g;
    }

    @Override // b.j.c.t.l
    public void h(int i) {
        b(i, 0, false, 0);
    }

    public final int i(int i) {
        return l(c(i));
    }

    @Override // b.j.c.t.l
    public int i(View view) {
        return super.i(view) + ((d) view.getLayoutParams()).f;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0023 A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:8:0x001b A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final int j(int r10) {
        /*
            r9 = this;
            int r0 = r9.u
            r1 = 130(0x82, float:1.82E-43)
            r2 = 66
            r3 = 33
            r4 = 0
            r5 = 3
            r6 = 2
            r7 = 17
            r8 = 1
            if (r0 != 0) goto L2b
            r0 = 262144(0x40000, float:3.67342E-40)
            if (r10 == r7) goto L25
            if (r10 == r3) goto L23
            if (r10 == r2) goto L1d
            if (r10 == r1) goto L1b
            goto L46
        L1b:
            r4 = 3
            goto L48
        L1d:
            int r10 = r9.C
            r10 = r10 & r0
            if (r10 != 0) goto L48
            goto L38
        L23:
            r4 = 2
            goto L48
        L25:
            int r10 = r9.C
            r10 = r10 & r0
            if (r10 != 0) goto L38
            goto L48
        L2b:
            if (r0 != r8) goto L46
            r0 = 524288(0x80000, float:7.34684E-40)
            if (r10 == r7) goto L40
            if (r10 == r3) goto L48
            if (r10 == r2) goto L3a
            if (r10 == r1) goto L38
            goto L46
        L38:
            r4 = 1
            goto L48
        L3a:
            int r10 = r9.C
            r10 = r10 & r0
            if (r10 != 0) goto L23
            goto L1b
        L40:
            int r10 = r9.C
            r10 = r10 & r0
            if (r10 != 0) goto L1b
            goto L23
        L46:
            r4 = 17
        L48:
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.n.e.j(int):int");
    }

    public final int k(int i) {
        int i2 = this.P;
        if (i2 != 0) {
            return i2;
        }
        int[] iArr = this.Q;
        if (iArr == null) {
            return 0;
        }
        return iArr[i];
    }

    public boolean k(View view) {
        return view.getVisibility() == 0 && (!n() || view.hasFocusable());
    }

    public int l(int i) {
        int i2 = 0;
        if ((this.C & 524288) != 0) {
            for (int i3 = this.X - 1; i3 > i; i3--) {
                i2 += k(i3) + this.V;
            }
            return i2;
        }
        int i4 = 0;
        while (i2 < i) {
            i4 += k(i2) + this.V;
            i2++;
        }
        return i4;
    }

    public final int l(View view) {
        d dVar;
        if (view == null || (dVar = (d) view.getLayoutParams()) == null || dVar.d()) {
            return -1;
        }
        return dVar.a();
    }

    public int m(View view) {
        d dVar = (d) view.getLayoutParams();
        return f(view) + ((ViewGroup.MarginLayoutParams) dVar).topMargin + ((ViewGroup.MarginLayoutParams) dVar).bottomMargin;
    }

    public boolean m(int i) {
        t.z a2 = this.t.a(i);
        return a2 != null && a2.f865a.getLeft() >= 0 && a2.f865a.getRight() <= this.t.getWidth() && a2.f865a.getTop() >= 0 && a2.f865a.getBottom() <= this.t.getHeight();
    }

    public final int n(int i) {
        int i2;
        int i3 = this.C;
        if ((i3 & 64) == 0 && (i3 & 3) != 1 && (i <= 0 ? !(i >= 0 || this.b0.f678d.d() || i >= (i2 = this.b0.f678d.f682d)) : !(this.b0.f678d.c() || i <= (i2 = this.b0.f678d.f681c)))) {
            i = i2;
        }
        if (i == 0) {
            return 0;
        }
        int i4 = -i;
        int d2 = d();
        if (this.u == 1) {
            for (int i5 = 0; i5 < d2; i5++) {
                c(i5).offsetTopAndBottom(i4);
            }
        } else {
            for (int i6 = 0; i6 < d2; i6++) {
                c(i6).offsetLeftAndRight(i4);
            }
        }
        if ((this.C & 3) == 1) {
            I();
            return i;
        }
        int d3 = d();
        if ((this.C & 262144) == 0 ? i >= 0 : i <= 0) {
            u();
        } else {
            C();
        }
        boolean z = d() > d3;
        int d4 = d();
        if ((262144 & this.C) == 0 ? i >= 0 : i <= 0) {
            E();
        } else {
            D();
        }
        if (z | (d() < d4)) {
            H();
        }
        this.t.invalidate();
        I();
        return i;
    }

    public int n(View view) {
        d dVar = (d) view.getLayoutParams();
        return g(view) + ((ViewGroup.MarginLayoutParams) dVar).leftMargin + ((ViewGroup.MarginLayoutParams) dVar).rightMargin;
    }

    public final int o(View view) {
        return this.b0.e.a(this.u == 0 ? r(view) : q(view));
    }

    public final int p(View view) {
        return this.u == 0 ? q(view) : r(view);
    }

    public void p(int i) {
        a0.a aVar;
        if (i == 0 || i == 1) {
            this.u = i;
            this.v = b.j.c.s.a(this, i);
            a0 a0Var = this.b0;
            a0Var.f675a = i;
            if (i == 0) {
                a0Var.f678d = a0Var.f677c;
                aVar = a0Var.f676b;
            } else {
                a0Var.f678d = a0Var.f676b;
                aVar = a0Var.f677c;
            }
            a0Var.e = aVar;
            i iVar = this.c0;
            iVar.f704a = i;
            iVar.f707d = i == 0 ? iVar.f706c : iVar.f705b;
            this.C |= 256;
        }
    }

    public final int q(View view) {
        d dVar = (d) view.getLayoutParams();
        if (dVar != null) {
            return view.getLeft() + dVar.e + dVar.i;
        }
        throw null;
    }

    public void q(int i) {
        if (i < 0 && i != -2) {
            throw new IllegalArgumentException(c.a.b.a.a.a("Invalid row height: ", i));
        }
        this.O = i;
    }

    public final int r(View view) {
        d dVar = (d) view.getLayoutParams();
        if (dVar != null) {
            return view.getTop() + dVar.f + dVar.j;
        }
        throw null;
    }

    public int s(View view) {
        return this.v.a(view);
    }

    public int t(View view) {
        return this.v.d(view);
    }

    @Override // b.j.c.t.l
    public boolean t() {
        return true;
    }

    public int u(View view) {
        b(view, k0);
        return this.u == 0 ? k0.width() : k0.height();
    }

    public final void u() {
        this.Z.a((this.C & 262144) != 0 ? (-this.e0) - this.y : this.d0 + this.e0 + this.y, false);
    }

    public void v() {
        if (this.D == null) {
            ArrayList<o> arrayList = this.E;
            if (!(arrayList != null && arrayList.size() > 0)) {
                return;
            }
        }
        int i = this.G;
        View b2 = i == -1 ? null : b(i);
        if (b2 != null) {
            t.z c2 = this.t.c(b2);
            n nVar = this.D;
            if (nVar != null) {
                nVar.a(this.t, b2, this.G, c2 == null ? -1L : c2.e);
            }
            a(this.t, c2, this.G, this.H);
        } else {
            n nVar2 = this.D;
            if (nVar2 != null) {
                nVar2.a(this.t, null, -1, -1L);
            }
            a(this.t, (t.z) null, -1, 0);
        }
        if ((this.C & 3) == 1 || this.t.isLayoutRequested()) {
            return;
        }
        int d2 = d();
        for (int i2 = 0; i2 < d2; i2++) {
            if (c(i2).isLayoutRequested()) {
                b.d.k.l.a(this.t, this.i0);
                return;
            }
        }
    }

    public void v(View view) {
        int childMeasureSpec;
        int i;
        d dVar = (d) view.getLayoutParams();
        a(view, k0);
        int i2 = ((ViewGroup.MarginLayoutParams) dVar).leftMargin + ((ViewGroup.MarginLayoutParams) dVar).rightMargin;
        Rect rect = k0;
        int i3 = i2 + rect.left + rect.right;
        int i4 = ((ViewGroup.MarginLayoutParams) dVar).topMargin + ((ViewGroup.MarginLayoutParams) dVar).bottomMargin + rect.top + rect.bottom;
        int makeMeasureSpec = this.O == -2 ? View.MeasureSpec.makeMeasureSpec(0, 0) : View.MeasureSpec.makeMeasureSpec(this.P, 1073741824);
        int i5 = this.u;
        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
        if (i5 == 0) {
            childMeasureSpec = ViewGroup.getChildMeasureSpec(makeMeasureSpec2, i3, ((ViewGroup.MarginLayoutParams) dVar).width);
            i = ViewGroup.getChildMeasureSpec(makeMeasureSpec, i4, ((ViewGroup.MarginLayoutParams) dVar).height);
        } else {
            int childMeasureSpec2 = ViewGroup.getChildMeasureSpec(makeMeasureSpec2, i4, ((ViewGroup.MarginLayoutParams) dVar).height);
            childMeasureSpec = ViewGroup.getChildMeasureSpec(makeMeasureSpec, i3, ((ViewGroup.MarginLayoutParams) dVar).width);
            i = childMeasureSpec2;
        }
        view.measure(childMeasureSpec, i);
    }

    public void w() {
        ArrayList<o> arrayList = this.E;
        if (arrayList != null && arrayList.size() > 0) {
            int i = this.G;
            View b2 = i == -1 ? null : b(i);
            if (b2 != null) {
                b(this.t, this.t.c(b2), this.G, this.H);
                return;
            }
            n nVar = this.D;
            if (nVar != null) {
                nVar.a(this.t, null, -1, -1L);
            }
            b(this.t, (t.z) null, -1, 0);
        }
    }

    public final int x() {
        int i = (this.C & 524288) != 0 ? 0 : this.X - 1;
        return k(i) + l(i);
    }

    public boolean y() {
        return f() == 0 || this.t.a(0) != null;
    }

    public boolean z() {
        int f2 = f();
        return f2 == 0 || this.t.a(f2 - 1) != null;
    }

    /* loaded from: classes.dex */
    public abstract class c extends b.j.c.o {
        public boolean n;

        public c() {
            super(e.this.t.getContext());
        }

        @Override // b.j.c.o, b.j.c.t.v
        public void a() {
            this.m = 0;
            this.l = 0;
            if (!this.n) {
                c();
            }
            e eVar = e.this;
            if (eVar.I == this) {
                eVar.I = null;
            }
            e eVar2 = e.this;
            if (eVar2.J == this) {
                eVar2.J = null;
            }
        }

        @Override // b.j.c.o
        public int c(int i) {
            int c2 = super.c(i);
            int i2 = e.this.b0.f678d.i;
            if (i2 <= 0) {
                return c2;
            }
            float f = (30.0f / i2) * i;
            return ((float) c2) < f ? (int) f : c2;
        }

        @Override // b.j.c.t.v
        public void a(View view, t.w wVar, t.v.a aVar) {
            int i;
            int i2;
            if (e.this.a(view, (View) null, e.l0)) {
                if (e.this.u == 0) {
                    int[] iArr = e.l0;
                    i2 = iArr[0];
                    i = iArr[1];
                } else {
                    int[] iArr2 = e.l0;
                    int i3 = iArr2[1];
                    i = iArr2[0];
                    i2 = i3;
                }
                int ceil = (int) Math.ceil(c((int) Math.sqrt((i * i) + (i2 * i2))) / 0.3356d);
                DecelerateInterpolator decelerateInterpolator = this.j;
                aVar.f854a = i2;
                aVar.f855b = i;
                aVar.f856c = ceil;
                aVar.e = decelerateInterpolator;
                aVar.f = true;
            }
        }

        public void c() {
            View b2 = b(this.f850a);
            if (b2 == null) {
                int i = this.f850a;
                if (i >= 0) {
                    e.this.a(i, 0, false, 0);
                    return;
                }
                return;
            }
            e eVar = e.this;
            int i2 = eVar.G;
            int i3 = this.f850a;
            if (i2 != i3) {
                eVar.G = i3;
            }
            if (e.this.n()) {
                e.this.C |= 32;
                b2.requestFocus();
                e.this.C &= -33;
            }
            e.this.v();
            e.this.w();
        }
    }

    @Override // b.j.c.t.l
    public void b(View view, Rect rect) {
        b.j.c.t.a(view, rect);
        d dVar = (d) view.getLayoutParams();
        rect.left += dVar.e;
        rect.top += dVar.f;
        rect.right -= dVar.g;
        rect.bottom -= dVar.h;
    }

    public final void w(View view) {
        d dVar = (d) view.getLayoutParams();
        j jVar = dVar.l;
        if (jVar == null) {
            i.a aVar = this.c0.f706c;
            dVar.i = k.a(view, aVar, aVar.f);
        } else {
            int i = this.u;
            j.a[] aVarArr = jVar.f708a;
            int[] iArr = dVar.k;
            if (iArr == null || iArr.length != aVarArr.length) {
                dVar.k = new int[aVarArr.length];
            }
            for (int i2 = 0; i2 < aVarArr.length; i2++) {
                dVar.k[i2] = k.a(view, aVarArr[i2], i);
            }
            int[] iArr2 = dVar.k;
            if (i == 0) {
                dVar.i = iArr2[0];
            } else {
                dVar.j = iArr2[0];
            }
            if (this.u != 0) {
                i.a aVar2 = this.c0.f706c;
                dVar.i = k.a(view, aVar2, aVar2.f);
                return;
            }
        }
        i.a aVar3 = this.c0.f705b;
        dVar.j = k.a(view, aVar3, aVar3.f);
    }

    @Override // b.j.c.t.l
    public int a(t.r rVar, t.w wVar) {
        b.g.n.d dVar;
        if (this.u == 1 && (dVar = this.Z) != null) {
            return dVar.e;
        }
        return super.a(rVar, wVar);
    }

    @Override // b.j.c.t.l
    public int b(t.r rVar, t.w wVar) {
        b.g.n.d dVar;
        if (this.u == 0 && (dVar = this.Z) != null) {
            return dVar.e;
        }
        return super.b(rVar, wVar);
    }

    /*  JADX ERROR: JadxRuntimeException in pass: BlockProcessor
        jadx.core.utils.exceptions.JadxRuntimeException: CFG modification limit reached, blocks count: 427
        	at jadx.core.dex.visitors.blocks.BlockProcessor.processBlocksTree(BlockProcessor.java:64)
        	at jadx.core.dex.visitors.blocks.BlockProcessor.visit(BlockProcessor.java:44)
        */
    @Override // b.j.c.t.l
    public void c(b.j.c.t.r r24, b.j.c.t.w r25) {
        /*
            Method dump skipped, instructions count: 1590
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.n.e.c(b.j.c.t$r, b.j.c.t$w):void");
    }

    @Override // b.j.c.t.l
    public Parcelable q() {
        Bundle bundle;
        f fVar = new f();
        fVar.f702b = this.G;
        z zVar = this.g0;
        b.c.h<String, SparseArray<Parcelable>> hVar = zVar.f734c;
        if (hVar == null || hVar.b() == 0) {
            bundle = null;
        } else {
            Map<String, SparseArray<Parcelable>> c2 = zVar.f734c.c();
            bundle = new Bundle();
            for (Map.Entry entry : ((LinkedHashMap) c2).entrySet()) {
                bundle.putSparseParcelableArray((String) entry.getKey(), (SparseArray) entry.getValue());
            }
        }
        int d2 = d();
        for (int i = 0; i < d2; i++) {
            View c3 = c(i);
            int l = l(c3);
            if (l != -1 && this.g0.f732a != 0) {
                String num = Integer.toString(l);
                SparseArray<Parcelable> sparseArray = new SparseArray<>();
                c3.saveHierarchyState(sparseArray);
                if (bundle == null) {
                    bundle = new Bundle();
                }
                bundle.putSparseParcelableArray(num, sparseArray);
            }
        }
        fVar.f703c = bundle;
        return fVar;
    }

    public final int o(int i) {
        int i2 = 0;
        if (i == 0) {
            return 0;
        }
        int i3 = -i;
        int d2 = d();
        if (this.u == 0) {
            while (i2 < d2) {
                c(i2).offsetTopAndBottom(i3);
                i2++;
            }
        } else {
            while (i2 < d2) {
                c(i2).offsetLeftAndRight(i3);
                i2++;
            }
        }
        this.N += i;
        J();
        this.t.invalidate();
        return i;
    }

    /* JADX WARN: Removed duplicated region for block: B:38:0x0100  */
    /* JADX WARN: Removed duplicated region for block: B:45:0x0102  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean a(android.view.View r12, android.view.View r13, int[] r14) {
        /*
            Method dump skipped, instructions count: 275
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.n.e.a(android.view.View, android.view.View, int[]):boolean");
    }

    @Override // b.j.c.t.l
    public void b(b.j.c.t tVar, int i, int i2) {
        b.g.n.d dVar;
        int i3;
        int i4;
        int i5 = this.G;
        if (i5 != -1 && (dVar = this.Z) != null && dVar.f >= 0 && (i3 = this.K) != Integer.MIN_VALUE && i <= (i4 = i5 + i3)) {
            if (i + i2 > i4) {
                int i6 = (i - i4) + i3;
                this.K = i6;
                this.G = i5 + i6;
                this.K = Integer.MIN_VALUE;
            } else {
                this.K = i3 - i2;
            }
        }
        this.g0.b();
    }

    public final boolean b(boolean z) {
        if (this.P != 0 || this.Q == null) {
            return false;
        }
        b.g.n.d dVar = this.Z;
        b.c.e[] a2 = dVar == null ? null : dVar.a(dVar.f, dVar.g);
        boolean z2 = false;
        int i = -1;
        for (int i2 = 0; i2 < this.X; i2++) {
            b.c.e eVar = a2 == null ? null : a2[i2];
            int a3 = eVar == null ? 0 : eVar.a();
            int i3 = -1;
            for (int i4 = 0; i4 < a3; i4 += 2) {
                int b2 = eVar.b(i4 + 1);
                for (int b3 = eVar.b(i4); b3 <= b2; b3++) {
                    View b4 = b(b3 - this.x);
                    if (b4 != null) {
                        if (z) {
                            v(b4);
                        }
                        int m = this.u == 0 ? m(b4) : n(b4);
                        if (m > i3) {
                            i3 = m;
                        }
                    }
                }
            }
            int a4 = this.w.a();
            if (!this.t.s && z && i3 < 0 && a4 > 0) {
                if (i < 0) {
                    int i5 = this.G;
                    if (i5 < 0) {
                        i5 = 0;
                    } else if (i5 >= a4) {
                        i5 = a4 - 1;
                    }
                    if (d() > 0) {
                        int d2 = this.t.c(c(0)).d();
                        int d3 = this.t.c(c(d() - 1)).d();
                        if (i5 >= d2 && i5 <= d3) {
                            i5 = i5 - d2 <= d3 - i5 ? d2 - 1 : d3 + 1;
                            if (i5 < 0 && d3 < a4 - 1) {
                                i5 = d3 + 1;
                            } else if (i5 >= a4 && d2 > 0) {
                                i5 = d2 - 1;
                            }
                        }
                    }
                    if (i5 >= 0 && i5 < a4) {
                        int makeMeasureSpec = View.MeasureSpec.makeMeasureSpec(0, 0);
                        int makeMeasureSpec2 = View.MeasureSpec.makeMeasureSpec(0, 0);
                        int[] iArr = this.f0;
                        View view = this.B.a(i5, false, Long.MAX_VALUE).f865a;
                        if (view != null) {
                            d dVar2 = (d) view.getLayoutParams();
                            a(view, k0);
                            int i6 = ((ViewGroup.MarginLayoutParams) dVar2).leftMargin + ((ViewGroup.MarginLayoutParams) dVar2).rightMargin;
                            Rect rect = k0;
                            view.measure(ViewGroup.getChildMeasureSpec(makeMeasureSpec, l() + k() + i6 + rect.left + rect.right, ((ViewGroup.MarginLayoutParams) dVar2).width), ViewGroup.getChildMeasureSpec(makeMeasureSpec2, j() + m() + ((ViewGroup.MarginLayoutParams) dVar2).topMargin + ((ViewGroup.MarginLayoutParams) dVar2).bottomMargin + rect.top + rect.bottom, ((ViewGroup.MarginLayoutParams) dVar2).height));
                            iArr[0] = n(view);
                            iArr[1] = m(view);
                            this.B.a(view);
                        }
                        i = this.u == 0 ? this.f0[1] : this.f0[0];
                    }
                }
                if (i >= 0) {
                    i3 = i;
                }
            }
            if (i3 < 0) {
                i3 = 0;
            }
            int[] iArr2 = this.Q;
            if (iArr2[i2] != i3) {
                iArr2[i2] = i3;
                z2 = true;
            }
        }
        return z2;
    }

    /* loaded from: classes.dex */
    public class b implements d.b {
        public b() {
        }

        public int a() {
            return e.this.w.a() + e.this.x;
        }

        public int a(int i) {
            e eVar = e.this;
            View b2 = eVar.b(i - eVar.x);
            e eVar2 = e.this;
            return (eVar2.C & 262144) != 0 ? eVar2.s(b2) : eVar2.t(b2);
        }

        public void a(Object obj, int i, int i2, int i3, int i4) {
            int i5;
            int i6;
            C0026e c0026e;
            int i7;
            View view = (View) obj;
            if (i4 == Integer.MIN_VALUE || i4 == Integer.MAX_VALUE) {
                e eVar = e.this;
                boolean z = eVar.Z.f697c;
                a0 a0Var = eVar.b0;
                if (!z) {
                    i4 = a0Var.f678d.j;
                } else {
                    a0.a aVar = a0Var.f678d;
                    i4 = aVar.i - aVar.k;
                }
            }
            if (!e.this.Z.f697c) {
                i6 = i2 + i4;
                i5 = i4;
            } else {
                i5 = i4 - i2;
                i6 = i4;
            }
            int l = e.this.l(i3);
            e eVar2 = e.this;
            int i8 = (l + eVar2.b0.e.j) - eVar2.N;
            z zVar = eVar2.g0;
            if (zVar.f734c != null) {
                SparseArray<Parcelable> b2 = zVar.f734c.b(Integer.toString(i));
                if (b2 != null) {
                    view.restoreHierarchyState(b2);
                }
            }
            e.this.a(i3, view, i5, i6, i8);
            e eVar3 = e.this;
            if (!eVar3.w.g) {
                eVar3.I();
            }
            e eVar4 = e.this;
            if ((eVar4.C & 3) != 1 && (c0026e = eVar4.J) != null) {
                if (c0026e.p && (i7 = c0026e.q) != 0) {
                    c0026e.q = e.this.a(true, i7);
                }
                int i9 = c0026e.q;
                if (i9 == 0 || ((i9 > 0 && e.this.z()) || (c0026e.q < 0 && e.this.y()))) {
                    c0026e.f850a = e.this.G;
                    c0026e.b();
                }
            }
            e eVar5 = e.this;
            if (eVar5.F != null) {
                t.z c2 = eVar5.t.c(view);
                e eVar6 = e.this;
                eVar6.F.a(eVar6.t, view, i, c2 == null ? -1L : c2.e);
            }
        }

        public int b(int i) {
            e eVar = e.this;
            return eVar.u(eVar.b(i - eVar.x));
        }

        public void c(int i) {
            e eVar = e.this;
            View b2 = eVar.b(i - eVar.x);
            e eVar2 = e.this;
            if ((eVar2.C & 3) == 1) {
                eVar2.a(b2, eVar2.B);
            } else {
                eVar2.b(b2, eVar2.B);
            }
        }

        /* JADX WARN: Code restructure failed: missing block: B:60:0x0108, code lost:
        
            if (r12.J == null) goto L86;
         */
        /* JADX WARN: Multi-variable type inference failed */
        /* JADX WARN: Removed duplicated region for block: B:33:0x009e  */
        /* JADX WARN: Removed duplicated region for block: B:37:0x00ae  */
        /* JADX WARN: Removed duplicated region for block: B:44:0x00ca  */
        /* JADX WARN: Removed duplicated region for block: B:46:0x00c4 A[SYNTHETIC] */
        /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:43:0x00c4 -> B:29:0x00c6). Please report as a decompilation issue!!! */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct add '--show-bad-code' argument
        */
        public int a(int r9, boolean r10, java.lang.Object[] r11, boolean r12) {
            /*
                Method dump skipped, instructions count: 343
                To view this dump add '--comments-level debug' option
            */
            throw new UnsupportedOperationException("Method not decompiled: b.g.n.e.b.a(int, boolean, java.lang.Object[], boolean):int");
        }
    }

    public int a(View view, View view2) {
        j jVar;
        if (view == null || view2 == null || (jVar = ((d) view.getLayoutParams()).l) == null) {
            return 0;
        }
        j.a[] aVarArr = jVar.f708a;
        if (aVarArr.length <= 1) {
            return 0;
        }
        while (view2 != view) {
            int id = view2.getId();
            if (id != -1) {
                for (int i = 1; i < aVarArr.length; i++) {
                    j.a aVar = aVarArr[i];
                    int i2 = aVar.f710b;
                    if (i2 == -1) {
                        i2 = aVar.f709a;
                    }
                    if (i2 == id) {
                        return i;
                    }
                }
            }
            view2 = (View) view2.getParent();
        }
        return 0;
    }

    public void a(int i, View view, int i2, int i3, int i4) {
        int k;
        int m = this.u == 0 ? m(view) : n(view);
        int i5 = this.P;
        if (i5 > 0) {
            m = Math.min(m, i5);
        }
        int i6 = this.W;
        int i7 = i6 & b.a.j.AppCompatTheme_tooltipForegroundColor;
        int absoluteGravity = (this.C & 786432) != 0 ? Gravity.getAbsoluteGravity(i6 & 8388615, 1) : i6 & 7;
        if ((this.u != 0 || i7 != 48) && (this.u != 1 || absoluteGravity != 3)) {
            if ((this.u == 0 && i7 == 80) || (this.u == 1 && absoluteGravity == 5)) {
                k = k(i) - m;
            } else if ((this.u == 0 && i7 == 16) || (this.u == 1 && absoluteGravity == 1)) {
                k = (k(i) - m) / 2;
            }
            i4 += k;
        }
        int i8 = m + i4;
        if (this.u != 0) {
            int i9 = i4;
            i4 = i2;
            i2 = i9;
            i8 = i3;
            i3 = i8;
        }
        d dVar = (d) view.getLayoutParams();
        a(view, i2, i4, i3, i8);
        b.j.c.t.a(view, k0);
        Rect rect = k0;
        int i10 = i2 - rect.left;
        int i11 = i4 - rect.top;
        int i12 = rect.right - i3;
        int i13 = rect.bottom - i8;
        dVar.e = i10;
        dVar.f = i11;
        dVar.g = i12;
        dVar.h = i13;
        w(view);
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // b.j.c.t.l
    public void a(t.d dVar, t.d dVar2) {
        if (dVar != null) {
            this.Z = null;
            this.Q = null;
            this.C &= -1025;
            this.G = -1;
            this.K = 0;
            this.g0.b();
        }
        if (dVar2 instanceof b.g.n.c) {
            this.h0 = (b.g.n.c) dVar2;
        } else {
            this.h0 = null;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:54:0x00c2  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x00cd  */
    @Override // b.j.c.t.l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean a(b.j.c.t r18, java.util.ArrayList<android.view.View> r19, int r20, int r21) {
        /*
            Method dump skipped, instructions count: 409
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.n.e.a(b.j.c.t, java.util.ArrayList, int, int):boolean");
    }

    @Override // b.j.c.t.l
    public void a(t.r rVar, t.w wVar, b.d.k.r.b bVar) {
        int b2;
        int a2;
        b.g.n.d dVar;
        b.g.n.d dVar2;
        d(rVar, wVar);
        int a3 = wVar.a();
        boolean z = (this.C & 262144) != 0;
        if (a3 > 1 && !m(0)) {
            if (Build.VERSION.SDK_INT >= 23) {
                bVar.a(this.u == 0 ? z ? b.a.g : b.a.e : b.a.f643d);
            } else {
                bVar.f640a.addAction(8192);
            }
            bVar.f640a.setScrollable(true);
        }
        if (a3 > 1 && !m(a3 - 1)) {
            if (Build.VERSION.SDK_INT >= 23) {
                bVar.a(this.u == 0 ? z ? b.a.e : b.a.g : b.a.f);
            } else {
                bVar.f640a.addAction(4096);
            }
            bVar.f640a.setScrollable(true);
        }
        if (this.u == 0 && (dVar2 = this.Z) != null) {
            b2 = dVar2.e;
        } else {
            b2 = super.b(rVar, wVar);
        }
        if (this.u == 1 && (dVar = this.Z) != null) {
            a2 = dVar.e;
        } else {
            a2 = super.a(rVar, wVar);
        }
        bVar.f640a.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(b2, a2, false, 0));
        B();
    }

    @Override // b.j.c.t.l
    public void a(t.r rVar, t.w wVar, View view, b.d.k.r.b bVar) {
        int i;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (this.Z == null || !(layoutParams instanceof d)) {
            return;
        }
        int a2 = ((d) layoutParams).a();
        int d2 = a2 >= 0 ? this.Z.d(a2) : -1;
        if (d2 < 0) {
            return;
        }
        int i2 = a2 / this.Z.e;
        if (this.u == 0) {
            i = d2;
            d2 = i2;
        } else {
            i = i2;
        }
        bVar.a(b.C0019b.a(i, 1, d2, 1, false, false));
    }

    @Override // b.j.c.t.l
    public void a(b.j.c.t tVar, int i, int i2) {
        b.g.n.d dVar;
        int i3;
        int i4 = this.G;
        if (i4 != -1 && (dVar = this.Z) != null && dVar.f >= 0 && (i3 = this.K) != Integer.MIN_VALUE && i <= i4 + i3) {
            this.K = i3 + i2;
        }
        this.g0.b();
    }

    @Override // b.j.c.t.l
    public void a(t.r rVar, t.w wVar, int i, int i2) {
        int size;
        int size2;
        int mode;
        int k;
        int l;
        int i3;
        d(rVar, wVar);
        if (this.u == 0) {
            size2 = View.MeasureSpec.getSize(i);
            size = View.MeasureSpec.getSize(i2);
            mode = View.MeasureSpec.getMode(i2);
            k = m();
            l = j();
        } else {
            size = View.MeasureSpec.getSize(i);
            size2 = View.MeasureSpec.getSize(i2);
            mode = View.MeasureSpec.getMode(i);
            k = k();
            l = l();
        }
        int i4 = l + k;
        this.R = size;
        int i5 = this.O;
        if (i5 == -2) {
            int i6 = this.Y;
            if (i6 == 0) {
                i6 = 1;
            }
            this.X = i6;
            this.P = 0;
            int[] iArr = this.Q;
            if (iArr == null || iArr.length != i6) {
                this.Q = new int[this.X];
            }
            if (this.w.g) {
                G();
            }
            b(true);
            if (mode == Integer.MIN_VALUE) {
                size = Math.min(x() + i4, this.R);
            } else if (mode == 0) {
                i3 = x();
                size = i3 + i4;
            } else {
                if (mode != 1073741824) {
                    throw new IllegalStateException("wrong spec");
                }
                size = this.R;
            }
        } else {
            if (mode != Integer.MIN_VALUE) {
                if (mode == 0) {
                    if (i5 == 0) {
                        i5 = size - i4;
                    }
                    this.P = i5;
                    int i7 = this.Y;
                    if (i7 == 0) {
                        i7 = 1;
                    }
                    this.X = i7;
                    i3 = ((i7 - 1) * this.V) + (this.P * i7);
                    size = i3 + i4;
                } else if (mode != 1073741824) {
                    throw new IllegalStateException("wrong spec");
                }
            }
            if (this.Y == 0 && this.O == 0) {
                this.X = 1;
                this.P = size - i4;
            } else {
                int i8 = this.Y;
                if (i8 == 0) {
                    int i9 = this.O;
                    this.P = i9;
                    int i10 = this.V;
                    this.X = (size + i10) / (i9 + i10);
                } else {
                    int i11 = this.O;
                    this.X = i8;
                    if (i11 == 0) {
                        i11 = ((size - i4) - ((i8 - 1) * this.V)) / i8;
                    }
                    this.P = i11;
                }
            }
            if (mode == Integer.MIN_VALUE) {
                int i12 = this.P;
                int i13 = this.X;
                int i14 = ((i13 - 1) * this.V) + (i12 * i13) + i4;
                if (i14 < size) {
                    size = i14;
                }
            }
        }
        if (this.u == 0) {
            this.f825b.setMeasuredDimension(size2, size);
        } else {
            this.f825b.setMeasuredDimension(size, size2);
        }
        B();
    }

    @Override // b.j.c.t.l
    public boolean a(b.j.c.t tVar, View view, View view2) {
        if ((this.C & 32768) == 0 && l(view) != -1 && (this.C & 35) == 0) {
            a(view, view2, true, 0, 0);
        }
        return true;
    }

    @Override // b.j.c.t.l
    public void a(Parcelable parcelable) {
        if (parcelable instanceof f) {
            f fVar = (f) parcelable;
            this.G = fVar.f702b;
            this.K = 0;
            z zVar = this.g0;
            Bundle bundle = fVar.f703c;
            b.c.h<String, SparseArray<Parcelable>> hVar = zVar.f734c;
            if (hVar != null && bundle != null) {
                hVar.a(-1);
                for (String str : bundle.keySet()) {
                    zVar.f734c.a(str, bundle.getSparseParcelableArray(str));
                }
            }
            this.C |= 256;
            r();
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:16:0x0032, code lost:
    
        if (r5 != false) goto L19;
     */
    /* JADX WARN: Code restructure failed: missing block: B:17:0x0034, code lost:
    
        r7 = 4096;
     */
    /* JADX WARN: Code restructure failed: missing block: B:21:0x0042, code lost:
    
        if (r5 != false) goto L20;
     */
    /* JADX WARN: Code restructure failed: missing block: B:25:0x0054, code lost:
    
        if (r7 == b.d.k.r.b.a.f.a()) goto L19;
     */
    @Override // b.j.c.t.l
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean a(b.j.c.t.r r5, b.j.c.t.w r6, int r7, android.os.Bundle r8) {
        /*
            r4 = this;
            int r8 = r4.C
            r0 = 131072(0x20000, float:1.83671E-40)
            r8 = r8 & r0
            r0 = 0
            r1 = 1
            if (r8 == 0) goto Lb
            r8 = 1
            goto Lc
        Lb:
            r8 = 0
        Lc:
            if (r8 != 0) goto Lf
            return r1
        Lf:
            r4.d(r5, r6)
            int r5 = r4.C
            r6 = 262144(0x40000, float:3.67342E-40)
            r5 = r5 & r6
            if (r5 == 0) goto L1b
            r5 = 1
            goto L1c
        L1b:
            r5 = 0
        L1c:
            int r6 = android.os.Build.VERSION.SDK_INT
            r8 = 23
            r2 = 8192(0x2000, float:1.14794E-41)
            r3 = 4096(0x1000, float:5.74E-42)
            if (r6 < r8) goto L57
            int r6 = r4.u
            if (r6 != 0) goto L45
            b.d.k.r.b$a r6 = b.d.k.r.b.a.e
            int r6 = r6.a()
            if (r7 != r6) goto L3a
            if (r5 == 0) goto L37
        L34:
            r7 = 4096(0x1000, float:5.74E-42)
            goto L57
        L37:
            r7 = 8192(0x2000, float:1.14794E-41)
            goto L57
        L3a:
            b.d.k.r.b$a r6 = b.d.k.r.b.a.g
            int r6 = r6.a()
            if (r7 != r6) goto L57
            if (r5 == 0) goto L34
            goto L37
        L45:
            b.d.k.r.b$a r5 = b.d.k.r.b.a.f643d
            int r5 = r5.a()
            if (r7 != r5) goto L4e
            goto L37
        L4e:
            b.d.k.r.b$a r5 = b.d.k.r.b.a.f
            int r5 = r5.a()
            if (r7 != r5) goto L57
            goto L34
        L57:
            if (r7 == r3) goto L64
            if (r7 == r2) goto L5c
            goto L6a
        L5c:
            r4.a(r0)
            r5 = -1
            r4.a(r0, r5)
            goto L6a
        L64:
            r4.a(r1)
            r4.a(r0, r1)
        L6a:
            r4.B()
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.n.e.a(b.j.c.t$r, b.j.c.t$w, int, android.os.Bundle):boolean");
    }

    public final void a(boolean z) {
        if (z) {
            if (z()) {
                return;
            }
        } else if (y()) {
            return;
        }
        C0026e c0026e = this.J;
        if (c0026e == null) {
            this.t.v();
            C0026e c0026e2 = new C0026e(z ? 1 : -1, this.X > 1);
            this.K = 0;
            a(c0026e2);
            return;
        }
        if (z) {
            int i = c0026e.q;
            if (i < e.this.s) {
                c0026e.q = i + 1;
                return;
            }
            return;
        }
        int i2 = c0026e.q;
        if (i2 > (-e.this.s)) {
            c0026e.q = i2 - 1;
        }
    }

    public void a(int i, int i2, boolean z, int i3) {
        this.L = i3;
        View b2 = b(i);
        boolean z2 = !p();
        if (!z2 || this.t.isLayoutRequested() || b2 == null || l(b2) != i) {
            int i4 = this.C;
            if ((i4 & IMediaList.Event.ItemAdded) == 0 || (i4 & 64) != 0) {
                this.G = i;
                this.H = i2;
                this.K = Integer.MIN_VALUE;
                return;
            }
            if (z && !this.t.isLayoutRequested()) {
                this.G = i;
                this.H = i2;
                this.K = Integer.MIN_VALUE;
                if (!A()) {
                    StringBuilder a2 = c.a.b.a.a.a("GridLayoutManager:");
                    a2.append(this.t.getId());
                    Log.w(a2.toString(), "setSelectionSmooth should not be called before first layout pass");
                    return;
                }
                b.g.n.f fVar = new b.g.n.f(this);
                fVar.f850a = i;
                a(fVar);
                int i5 = fVar.f850a;
                if (i5 != this.G) {
                    this.G = i5;
                    this.H = 0;
                    return;
                }
                return;
            }
            if (!z2) {
                c cVar = this.I;
                if (cVar != null) {
                    cVar.n = true;
                }
                this.t.v();
            }
            if (this.t.isLayoutRequested() || b2 == null || l(b2) != i) {
                this.G = i;
                this.H = i2;
                this.K = Integer.MIN_VALUE;
                this.C |= 256;
                r();
                return;
            }
        }
        this.C |= 32;
        a(b2, z);
        this.C &= -33;
    }

    public final void a(View view, View view2, boolean z, int i, int i2) {
        if ((this.C & 64) != 0) {
            return;
        }
        int l = l(view);
        int a2 = a(view, view2);
        if (l != this.G || a2 != this.H) {
            this.G = l;
            this.H = a2;
            this.K = 0;
            if ((this.C & 3) != 1) {
                v();
            }
            if (this.t.x()) {
                this.t.invalidate();
            }
        }
        if (view == null) {
            return;
        }
        if (!view.hasFocus() && this.t.hasFocus()) {
            view.requestFocus();
        }
        if ((this.C & 131072) == 0 && z) {
            return;
        }
        if (!a(view, view2, l0) && i == 0 && i2 == 0) {
            return;
        }
        int[] iArr = l0;
        int i3 = iArr[0] + i;
        int i4 = iArr[1] + i2;
        if ((this.C & 3) == 1) {
            n(i3);
            o(i4);
            return;
        }
        if (this.u != 0) {
            i3 = i4;
            i4 = i3;
        }
        if (z) {
            this.t.d(i3, i4);
        } else {
            this.t.scrollBy(i3, i4);
            w();
        }
    }

    public void a(View view, boolean z) {
        a(view, view == null ? null : view.findFocus(), z, 0, 0);
    }

    public void a(t.v vVar) {
        c cVar = this.I;
        if (cVar != null) {
            cVar.n = true;
        }
        t.v vVar2 = this.g;
        if (vVar2 != null && vVar != vVar2 && vVar2.e) {
            vVar2.b();
        }
        this.g = vVar;
        b.j.c.t tVar = this.f825b;
        if (vVar.h) {
            StringBuilder a2 = c.a.b.a.a.a("An instance of ");
            a2.append(vVar.getClass().getSimpleName());
            a2.append(" was started ");
            a2.append("more than once. Each instance of");
            a2.append(vVar.getClass().getSimpleName());
            a2.append(" ");
            a2.append("is intended to only be used once. You should create a new instance for ");
            a2.append("each use.");
            Log.w("RecyclerView", a2.toString());
        }
        vVar.f851b = tVar;
        vVar.f852c = this;
        int i = vVar.f850a;
        if (i != -1) {
            tVar.g0.f858a = i;
            vVar.e = true;
            vVar.f853d = true;
            vVar.f = vVar.b(i);
            vVar.f851b.d0.a();
            vVar.h = true;
            if (vVar.e && (vVar instanceof c)) {
                c cVar2 = (c) vVar;
                this.I = cVar2;
                if (cVar2 instanceof C0026e) {
                    this.J = (C0026e) cVar2;
                    return;
                }
            } else {
                this.I = null;
            }
            this.J = null;
            return;
        }
        throw new IllegalArgumentException("Invalid target position");
    }
}
