package b.g.n;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public abstract class q {

    /* renamed from: a, reason: collision with root package name */
    public final List<Object> f721a = new ArrayList(2);

    /* renamed from: b, reason: collision with root package name */
    public final List<r> f722b;

    public q() {
        new ArrayList(2);
        new ArrayList(2);
        this.f722b = new ArrayList(4);
    }

    public abstract Number a(p pVar);

    public abstract float b(p pVar);
}
