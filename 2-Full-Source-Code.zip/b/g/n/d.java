package b.g.n;

import b.j.c.t;

/* loaded from: classes.dex */
public abstract class d {

    /* renamed from: b, reason: collision with root package name */
    public b f696b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f697c;

    /* renamed from: d, reason: collision with root package name */
    public int f698d;
    public int e;
    public b.c.e[] h;

    /* renamed from: a, reason: collision with root package name */
    public Object[] f695a = new Object[1];
    public int f = -1;
    public int g = -1;
    public int i = -1;

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public int f699a;

        public a(int i) {
            this.f699a = i;
        }
    }

    /* loaded from: classes.dex */
    public interface b {
    }

    public abstract int a(boolean z, int i, int[] iArr);

    public final int a(boolean z, int[] iArr) {
        return a(z, this.f697c ? this.f : this.g, iArr);
    }

    public void a(int i, int i2, t.l.c cVar) {
    }

    public boolean a() {
        return a(this.f697c ? Integer.MAX_VALUE : Integer.MIN_VALUE, true);
    }

    public final boolean a(int i) {
        if (this.g < 0) {
            return false;
        }
        if (this.f697c) {
            if (b(true, (int[]) null) > i + this.f698d) {
                return false;
            }
        } else if (a(false, (int[]) null) < i - this.f698d) {
            return false;
        }
        return true;
    }

    public abstract boolean a(int i, boolean z);

    public abstract b.c.e[] a(int i, int i2);

    public abstract int b(boolean z, int i, int[] iArr);

    public final int b(boolean z, int[] iArr) {
        return b(z, this.f697c ? this.g : this.f, iArr);
    }

    public final void b() {
        if (this.g < this.f) {
            this.g = -1;
            this.f = -1;
        }
    }

    public final boolean b(int i) {
        if (this.g < 0) {
            return false;
        }
        if (this.f697c) {
            if (a(false, (int[]) null) < i - this.f698d) {
                return false;
            }
        } else if (b(true, (int[]) null) > i + this.f698d) {
            return false;
        }
        return true;
    }

    public abstract boolean b(int i, boolean z);

    public abstract a c(int i);

    public final int d(int i) {
        a c2 = c(i);
        if (c2 == null) {
            return -1;
        }
        return c2.f699a;
    }

    public void e(int i) {
        int i2;
        if (i >= 0 && (i2 = this.g) >= 0) {
            if (i2 >= i) {
                this.g = i - 1;
            }
            b();
            if (this.f < 0) {
                this.i = i;
            }
        }
    }

    public void f(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException();
        }
        if (this.e == i) {
            return;
        }
        this.e = i;
        this.h = new b.c.e[i];
        for (int i2 = 0; i2 < this.e; i2++) {
            this.h[i2] = new b.c.e();
        }
    }
}
