package b.g.n.b0;

import java.text.DateFormatSymbols;
import java.util.Calendar;
import java.util.Locale;

/* loaded from: classes.dex */
public class c {

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public final Locale f693a;

        /* renamed from: b, reason: collision with root package name */
        public final String[] f694b;

        public a(Locale locale) {
            this.f693a = locale;
            this.f694b = DateFormatSymbols.getInstance(locale).getShortMonths();
            Calendar calendar = Calendar.getInstance(locale);
            int minimum = calendar.getMinimum(5);
            int maximum = calendar.getMaximum(5);
            String[] strArr = new String[(maximum - minimum) + 1];
            for (int i = minimum; i <= maximum; i++) {
                strArr[i - minimum] = String.format("%02d", Integer.valueOf(i));
            }
        }
    }

    public static Calendar a(Calendar calendar, Locale locale) {
        if (calendar == null) {
            return Calendar.getInstance(locale);
        }
        long timeInMillis = calendar.getTimeInMillis();
        Calendar calendar2 = Calendar.getInstance(locale);
        calendar2.setTimeInMillis(timeInMillis);
        return calendar2;
    }
}
