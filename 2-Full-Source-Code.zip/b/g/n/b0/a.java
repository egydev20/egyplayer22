package b.g.n.b0;

import android.content.Context;
import android.graphics.Rect;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.FrameLayout;
import android.widget.TextView;
import androidx.leanback.widget.VerticalGridView;
import b.g.f;
import b.g.h;
import b.g.n.o;
import b.j.c.t;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.videolan.libvlc.media.MediaPlayer;

/* loaded from: classes.dex */
public class a extends FrameLayout {

    /* renamed from: b, reason: collision with root package name */
    public ViewGroup f683b;

    /* renamed from: c, reason: collision with root package name */
    public ViewGroup f684c;

    /* renamed from: d, reason: collision with root package name */
    public final List<VerticalGridView> f685d;
    public ArrayList<b.g.n.b0.b> e;
    public float f;
    public float g;
    public float h;
    public float i;
    public int j;
    public Interpolator k;
    public float l;
    public float m;
    public int n;
    public List<CharSequence> o;
    public int p;
    public int q;
    public final o r;

    /* renamed from: b.g.n.b0.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class C0025a extends o {
        public C0025a() {
        }
    }

    /* loaded from: classes.dex */
    public class b extends t.d<c> {

        /* renamed from: c, reason: collision with root package name */
        public final int f687c;

        /* renamed from: d, reason: collision with root package name */
        public final int f688d;
        public final int e;
        public b.g.n.b0.b f;

        public b(int i, int i2, int i3) {
            this.f687c = i;
            this.f688d = i3;
            this.e = i2;
            this.f = a.this.e.get(i3);
        }

        @Override // b.j.c.t.d
        public int a() {
            b.g.n.b0.b bVar = this.f;
            if (bVar == null) {
                return 0;
            }
            return (bVar.f691c - bVar.f690b) + 1;
        }
    }

    /* loaded from: classes.dex */
    public static class c extends t.z {
        public final TextView t;

        public c(View view, TextView textView) {
            super(view);
            this.t = textView;
        }
    }

    public a(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f685d = new ArrayList();
        this.l = 3.0f;
        this.m = 1.0f;
        this.n = 0;
        this.o = new ArrayList();
        this.p = h.lb_picker_item;
        this.q = 0;
        this.r = new C0025a();
        setEnabled(true);
        setDescendantFocusability(262144);
        this.g = 1.0f;
        this.f = 1.0f;
        this.h = 0.5f;
        this.i = 0.0f;
        this.j = MediaPlayer.MEDIA_ERROR_NOT_VALID_FOR_PROGRESSIVE_PLAYBACK;
        this.k = new DecelerateInterpolator(2.5f);
        new AccelerateInterpolator(2.5f);
        ViewGroup viewGroup = (ViewGroup) LayoutInflater.from(getContext()).inflate(h.lb_picker, (ViewGroup) this, true);
        this.f683b = viewGroup;
        this.f684c = (ViewGroup) viewGroup.findViewById(f.picker);
    }

    public final void a() {
        for (int i = 0; i < getColumnsCount(); i++) {
            a(this.f685d.get(i));
        }
    }

    public void a(int i, int i2) {
        b.g.n.b0.b bVar = this.e.get(i);
        if (bVar.f689a != i2) {
            bVar.f689a = i2;
        }
    }

    public void a(int i, boolean z) {
        VerticalGridView verticalGridView = this.f685d.get(i);
        int selectedPosition = verticalGridView.getSelectedPosition();
        int i2 = 0;
        while (i2 < verticalGridView.getAdapter().a()) {
            View b2 = verticalGridView.getLayoutManager().b(i2);
            if (b2 != null) {
                a(b2, selectedPosition == i2, i, z);
            }
            i2++;
        }
    }

    public final void a(View view, boolean z, float f, float f2, Interpolator interpolator) {
        view.animate().cancel();
        if (!z) {
            view.setAlpha(f);
            return;
        }
        if (f2 >= 0.0f) {
            view.setAlpha(f2);
        }
        view.animate().alpha(f).setDuration(this.j).setInterpolator(interpolator).start();
    }

    public void a(View view, boolean z, int i, boolean z2) {
        boolean z3 = i == this.n || !hasFocus();
        a(view, z2, z ? z3 ? this.g : this.f : z3 ? this.h : this.i, -1.0f, this.k);
    }

    public final void a(VerticalGridView verticalGridView) {
        ViewGroup.LayoutParams layoutParams = verticalGridView.getLayoutParams();
        float activatedVisibleItemCount = isActivated() ? getActivatedVisibleItemCount() : getVisibleItemCount();
        layoutParams.height = (int) (((activatedVisibleItemCount - 1.0f) * verticalGridView.getVerticalSpacing()) + (getPickerItemHeightPixels() * activatedVisibleItemCount));
        verticalGridView.setLayoutParams(layoutParams);
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (!isActivated()) {
            return super.dispatchKeyEvent(keyEvent);
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyCode != 23 && keyCode != 66) {
            return super.dispatchKeyEvent(keyEvent);
        }
        if (keyEvent.getAction() == 1) {
            performClick();
        }
        return true;
    }

    public float getActivatedVisibleItemCount() {
        return this.l;
    }

    public int getColumnsCount() {
        ArrayList<b.g.n.b0.b> arrayList = this.e;
        if (arrayList == null) {
            return 0;
        }
        return arrayList.size();
    }

    public int getPickerItemHeightPixels() {
        return getContext().getResources().getDimensionPixelSize(b.g.c.picker_item_height);
    }

    public final int getPickerItemLayoutId() {
        return this.p;
    }

    public final int getPickerItemTextViewId() {
        return this.q;
    }

    public int getSelectedColumn() {
        return this.n;
    }

    public final CharSequence getSeparator() {
        return this.o.get(0);
    }

    public final List<CharSequence> getSeparators() {
        return this.o;
    }

    public float getVisibleItemCount() {
        return 1.0f;
    }

    @Override // android.view.ViewGroup
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        int selectedColumn = getSelectedColumn();
        if (selectedColumn < this.f685d.size()) {
            return this.f685d.get(selectedColumn).requestFocus(i, rect);
        }
        return false;
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public void requestChildFocus(View view, View view2) {
        super.requestChildFocus(view, view2);
        for (int i = 0; i < this.f685d.size(); i++) {
            if (this.f685d.get(i).hasFocus()) {
                setSelectedColumn(i);
            }
        }
    }

    @Override // android.view.View
    public void setActivated(boolean z) {
        boolean isActivated = isActivated();
        super.setActivated(z);
        if (z == isActivated) {
            return;
        }
        boolean hasFocus = hasFocus();
        int selectedColumn = getSelectedColumn();
        setDescendantFocusability(131072);
        if (!z && hasFocus && isFocusable()) {
            requestFocus();
        }
        for (int i = 0; i < getColumnsCount(); i++) {
            this.f685d.get(i).setFocusable(z);
        }
        a();
        boolean isActivated2 = isActivated();
        for (int i2 = 0; i2 < getColumnsCount(); i2++) {
            VerticalGridView verticalGridView = this.f685d.get(i2);
            for (int i3 = 0; i3 < verticalGridView.getChildCount(); i3++) {
                verticalGridView.getChildAt(i3).setFocusable(isActivated2);
            }
        }
        if (z && hasFocus && selectedColumn >= 0) {
            this.f685d.get(selectedColumn).requestFocus();
        }
        setDescendantFocusability(262144);
    }

    public void setActivatedVisibleItemCount(float f) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException();
        }
        if (this.l != f) {
            this.l = f;
            if (isActivated()) {
                a();
            }
        }
    }

    public void setColumns(List<b.g.n.b0.b> list) {
        if (this.o.size() == 0) {
            StringBuilder a2 = c.a.b.a.a.a("Separators size is: ");
            a2.append(this.o.size());
            a2.append(". At least one separator must be provided");
            throw new IllegalStateException(a2.toString());
        }
        if (this.o.size() == 1) {
            CharSequence charSequence = this.o.get(0);
            this.o.clear();
            this.o.add("");
            for (int i = 0; i < list.size() - 1; i++) {
                this.o.add(charSequence);
            }
            this.o.add("");
        } else if (this.o.size() != list.size() + 1) {
            StringBuilder a3 = c.a.b.a.a.a("Separators size: ");
            a3.append(this.o.size());
            a3.append(" must");
            a3.append("equal the size of columns: ");
            a3.append(list.size());
            a3.append(" + 1");
            throw new IllegalStateException(a3.toString());
        }
        this.f685d.clear();
        this.f684c.removeAllViews();
        ArrayList<b.g.n.b0.b> arrayList = new ArrayList<>(list);
        this.e = arrayList;
        if (this.n > arrayList.size() - 1) {
            this.n = this.e.size() - 1;
        }
        LayoutInflater from = LayoutInflater.from(getContext());
        int columnsCount = getColumnsCount();
        if (!TextUtils.isEmpty(this.o.get(0))) {
            TextView textView = (TextView) from.inflate(h.lb_picker_separator, this.f684c, false);
            textView.setText(this.o.get(0));
            this.f684c.addView(textView);
        }
        int i2 = 0;
        while (i2 < columnsCount) {
            VerticalGridView verticalGridView = (VerticalGridView) from.inflate(h.lb_picker_column, this.f684c, false);
            a(verticalGridView);
            verticalGridView.setWindowAlignment(0);
            verticalGridView.setHasFixedSize(false);
            verticalGridView.setFocusable(isActivated());
            verticalGridView.setItemViewCacheSize(0);
            this.f685d.add(verticalGridView);
            this.f684c.addView(verticalGridView);
            int i3 = i2 + 1;
            if (!TextUtils.isEmpty(this.o.get(i3))) {
                TextView textView2 = (TextView) from.inflate(h.lb_picker_separator, this.f684c, false);
                textView2.setText(this.o.get(i3));
                this.f684c.addView(textView2);
            }
            getContext();
            verticalGridView.setAdapter(new b(getPickerItemLayoutId(), getPickerItemTextViewId(), i2));
            verticalGridView.setOnChildViewHolderSelectedListener(this.r);
            i2 = i3;
        }
    }

    public final void setPickerItemTextViewId(int i) {
        this.q = i;
    }

    public void setSelectedColumn(int i) {
        if (this.n != i) {
            this.n = i;
            for (int i2 = 0; i2 < this.f685d.size(); i2++) {
                a(i2, true);
            }
        }
    }

    public final void setSeparator(CharSequence charSequence) {
        setSeparators(Arrays.asList(charSequence));
    }

    public final void setSeparators(List<CharSequence> list) {
        this.o.clear();
        this.o.addAll(list);
    }

    public void setVisibleItemCount(float f) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException();
        }
        if (this.m != f) {
            this.m = f;
            if (isActivated()) {
                return;
            }
            a();
        }
    }

    public void a(int i, b.g.n.b0.b bVar) {
        this.e.set(i, bVar);
        VerticalGridView verticalGridView = this.f685d.get(i);
        b bVar2 = (b) verticalGridView.getAdapter();
        if (bVar2 != null) {
            bVar2.f815a.a();
        }
        verticalGridView.setSelectedPosition(bVar.f689a - bVar.f690b);
    }
}
