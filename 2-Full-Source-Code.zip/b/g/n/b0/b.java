package b.g.n.b0;

/* loaded from: classes.dex */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public int f689a;

    /* renamed from: b, reason: collision with root package name */
    public int f690b;

    /* renamed from: c, reason: collision with root package name */
    public int f691c;

    /* renamed from: d, reason: collision with root package name */
    public CharSequence[] f692d;
    public String e;
}
