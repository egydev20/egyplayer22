package b.g.n;

import b.g.n.e;
import b.g.n.v;

/* loaded from: classes.dex */
public final class w extends v {
    public final int a(boolean z) {
        boolean z2 = false;
        if (z) {
            for (int i = this.g; i >= this.f; i--) {
                int i2 = c(i).f699a;
                if (i2 == 0) {
                    z2 = true;
                } else if (z2 && i2 == this.e - 1) {
                    return i;
                }
            }
            return -1;
        }
        for (int i3 = this.f; i3 <= this.g; i3++) {
            int i4 = c(i3).f699a;
            if (i4 == this.e - 1) {
                z2 = true;
            } else if (z2 && i4 == 0) {
                return i3;
            }
        }
        return -1;
    }

    @Override // b.g.n.d
    public int a(boolean z, int i, int[] iArr) {
        int i2;
        int a2 = ((e.b) this.f696b).a(i);
        v.a c2 = c(i);
        int i3 = c2.f699a;
        if (this.f697c) {
            i2 = i3;
            int i4 = i2;
            int i5 = 1;
            int i6 = a2;
            for (int i7 = i + 1; i5 < this.e && i7 <= this.g; i7++) {
                v.a c3 = c(i7);
                i6 += c3.f724b;
                int i8 = c3.f699a;
                if (i8 != i4) {
                    i5++;
                    if (!z ? i6 >= a2 : i6 <= a2) {
                        i4 = i8;
                    } else {
                        a2 = i6;
                        i = i7;
                        i2 = i8;
                        i4 = i2;
                    }
                }
            }
        } else {
            int i9 = 1;
            int i10 = i3;
            v.a aVar = c2;
            int i11 = a2;
            a2 = ((e.b) this.f696b).b(i) + a2;
            i2 = i10;
            for (int i12 = i - 1; i9 < this.e && i12 >= this.f; i12--) {
                i11 -= aVar.f724b;
                aVar = c(i12);
                int i13 = aVar.f699a;
                if (i13 != i10) {
                    i9++;
                    int b2 = ((e.b) this.f696b).b(i12) + i11;
                    if (!z ? b2 >= a2 : b2 <= a2) {
                        i10 = i13;
                    } else {
                        a2 = b2;
                        i = i12;
                        i2 = i13;
                        i10 = i2;
                    }
                }
            }
        }
        if (iArr != null) {
            iArr[0] = i2;
            iArr[1] = i;
        }
        return a2;
    }

    @Override // b.g.n.d
    public int b(boolean z, int i, int[] iArr) {
        int i2;
        int a2 = ((e.b) this.f696b).a(i);
        v.a c2 = c(i);
        int i3 = c2.f699a;
        if (this.f697c) {
            int i4 = 1;
            i2 = a2 - ((e.b) this.f696b).b(i);
            int i5 = i3;
            for (int i6 = i - 1; i4 < this.e && i6 >= this.f; i6--) {
                a2 -= c2.f724b;
                c2 = c(i6);
                int i7 = c2.f699a;
                if (i7 != i5) {
                    i4++;
                    int b2 = a2 - ((e.b) this.f696b).b(i6);
                    if (!z ? b2 >= i2 : b2 <= i2) {
                        i5 = i7;
                    } else {
                        i2 = b2;
                        i = i6;
                        i3 = i7;
                        i5 = i3;
                    }
                }
            }
        } else {
            int i8 = i3;
            int i9 = i8;
            int i10 = 1;
            int i11 = a2;
            for (int i12 = i + 1; i10 < this.e && i12 <= this.g; i12++) {
                v.a c3 = c(i12);
                i11 += c3.f724b;
                int i13 = c3.f699a;
                if (i13 != i9) {
                    i10++;
                    if (!z ? i11 >= a2 : i11 <= a2) {
                        i9 = i13;
                    } else {
                        a2 = i11;
                        i = i12;
                        i8 = i13;
                        i9 = i8;
                    }
                }
            }
            i2 = a2;
            i3 = i8;
        }
        if (iArr != null) {
            iArr[0] = i3;
            iArr[1] = i;
        }
        return i2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:43:0x0148, code lost:
    
        return r9;
     */
    /* JADX WARN: Code restructure failed: missing block: B:51:0x00c2, code lost:
    
        if (r13.f697c != false) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:52:0x00c4, code lost:
    
        r10 = -r13.f698d;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x0130, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:75:0x0131, code lost:
    
        r6 = r10;
     */
    /* JADX WARN: Code restructure failed: missing block: B:86:0x00c8, code lost:
    
        r10 = r13.f698d;
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x00e7, code lost:
    
        if (r13.f697c != false) goto L66;
     */
    /* JADX WARN: Removed duplicated region for block: B:56:0x0101 A[LOOP:2: B:56:0x0101->B:70:0x0125, LOOP_START, PHI: r6 r9 r10
      0x0101: PHI (r6v13 int) = (r6v6 int), (r6v18 int) binds: [B:55:0x00ff, B:70:0x0125] A[DONT_GENERATE, DONT_INLINE]
      0x0101: PHI (r9v20 int) = (r9v18 int), (r9v21 int) binds: [B:55:0x00ff, B:70:0x0125] A[DONT_GENERATE, DONT_INLINE]
      0x0101: PHI (r10v5 int) = (r10v4 int), (r10v7 int) binds: [B:55:0x00ff, B:70:0x0125] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:81:0x0133  */
    @Override // b.g.n.v
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean d(int r14, boolean r15) {
        /*
            Method dump skipped, instructions count: 349
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.n.w.d(int, boolean):boolean");
    }

    /* JADX WARN: Code restructure failed: missing block: B:41:0x013d, code lost:
    
        return r8;
     */
    /* JADX WARN: Code restructure failed: missing block: B:49:0x00b8, code lost:
    
        if (r12.f697c != false) goto L64;
     */
    /* JADX WARN: Code restructure failed: missing block: B:50:0x00ba, code lost:
    
        r9 = r12.f698d;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x0125, code lost:
    
        return true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:84:0x00bd, code lost:
    
        r9 = -r12.f698d;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x00da, code lost:
    
        if (r12.f697c != false) goto L64;
     */
    /* JADX WARN: Removed duplicated region for block: B:54:0x00f6 A[LOOP:2: B:54:0x00f6->B:68:0x011a, LOOP_START, PHI: r5 r8 r9
      0x00f6: PHI (r5v13 int) = (r5v6 int), (r5v19 int) binds: [B:53:0x00f4, B:68:0x011a] A[DONT_GENERATE, DONT_INLINE]
      0x00f6: PHI (r8v19 int) = (r8v17 int), (r8v20 int) binds: [B:53:0x00f4, B:68:0x011a] A[DONT_GENERATE, DONT_INLINE]
      0x00f6: PHI (r9v5 int) = (r9v4 int), (r9v7 int) binds: [B:53:0x00f4, B:68:0x011a] A[DONT_GENERATE, DONT_INLINE]] */
    /* JADX WARN: Removed duplicated region for block: B:79:0x0128  */
    @Override // b.g.n.v
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean f(int r13, boolean r14) {
        /*
            Method dump skipped, instructions count: 340
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.g.n.w.f(int, boolean):boolean");
    }

    public int g(int i) {
        v.a c2;
        int i2 = this.f;
        if (i2 < 0) {
            return Integer.MIN_VALUE;
        }
        if (this.f697c) {
            int a2 = ((e.b) this.f696b).a(i2);
            if (c(this.f).f699a == i) {
                return a2;
            }
            int i3 = this.f;
            do {
                i3++;
                if (i3 <= c()) {
                    c2 = c(i3);
                    a2 += c2.f724b;
                }
            } while (c2.f699a != i);
            return a2;
        }
        int a3 = ((e.b) this.f696b).a(this.g);
        v.a c3 = c(this.g);
        if (c3.f699a != i) {
            int i4 = this.g;
            do {
                i4--;
                if (i4 >= this.k) {
                    a3 -= c3.f724b;
                    c3 = c(i4);
                }
            } while (c3.f699a != i);
        }
        return a3 + c3.f725c;
        return Integer.MIN_VALUE;
    }

    public int h(int i) {
        v.a c2;
        int i2 = this.f;
        if (i2 < 0) {
            return Integer.MAX_VALUE;
        }
        if (!this.f697c) {
            int a2 = ((e.b) this.f696b).a(i2);
            if (c(this.f).f699a == i) {
                return a2;
            }
            int i3 = this.f;
            do {
                i3++;
                if (i3 <= c()) {
                    c2 = c(i3);
                    a2 += c2.f724b;
                }
            } while (c2.f699a != i);
            return a2;
        }
        int a3 = ((e.b) this.f696b).a(this.g);
        v.a c3 = c(this.g);
        if (c3.f699a != i) {
            int i4 = this.g;
            do {
                i4--;
                if (i4 >= this.k) {
                    a3 -= c3.f724b;
                    c3 = c(i4);
                }
            } while (c3.f699a != i);
        }
        return a3 - c3.f725c;
        return Integer.MAX_VALUE;
    }
}
