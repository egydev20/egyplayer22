package b.g.n;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.SparseArray;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import b.g.n.a0;
import b.g.n.i;
import b.j.c.t;
import java.util.ArrayList;
import org.videolan.libvlc.interfaces.IMediaList;

/* loaded from: classes.dex */
public abstract class a extends b.j.c.t {
    public final b.g.n.e H0;
    public boolean I0;
    public boolean J0;
    public t.i K0;
    public d L0;
    public c M0;
    public b N0;
    public t.s O0;
    public e P0;
    public int Q0;

    /* renamed from: b.g.n.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public class C0024a implements t.s {
        public C0024a() {
        }

        public void a(t.z zVar) {
            b.g.n.e eVar = a.this.H0;
            if (eVar != null) {
                int c2 = zVar.c();
                if (c2 != -1) {
                    z zVar2 = eVar.g0;
                    View view = zVar.f865a;
                    int i = zVar2.f732a;
                    if (i != 1) {
                        if ((i == 2 || i == 3) && zVar2.f734c != null) {
                            String num = Integer.toString(c2);
                            SparseArray<Parcelable> sparseArray = new SparseArray<>();
                            view.saveHierarchyState(sparseArray);
                            zVar2.f734c.a(num, sparseArray);
                        }
                    } else {
                        b.c.h<String, SparseArray<Parcelable>> hVar = zVar2.f734c;
                        if (hVar != null && hVar.b() != 0) {
                            zVar2.f734c.b(Integer.toString(c2));
                        }
                    }
                }
                t.s sVar = a.this.O0;
                if (sVar != null) {
                    ((C0024a) sVar).a(zVar);
                    return;
                }
                return;
            }
            throw null;
        }
    }

    /* loaded from: classes.dex */
    public interface b {
        boolean a(KeyEvent keyEvent);
    }

    /* loaded from: classes.dex */
    public interface c {
        boolean a(MotionEvent motionEvent);
    }

    /* loaded from: classes.dex */
    public interface d {
        boolean a(MotionEvent motionEvent);
    }

    /* loaded from: classes.dex */
    public interface e {
        boolean a(KeyEvent keyEvent);
    }

    public a(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.I0 = true;
        this.J0 = true;
        this.Q0 = 4;
        b.g.n.e eVar = new b.g.n.e(this);
        this.H0 = eVar;
        setLayoutManager(eVar);
        setPreserveFocusAfterLayout(false);
        setDescendantFocusability(262144);
        setHasFixedSize(true);
        setChildrenDrawingOrderEnabled(true);
        setWillNotDraw(true);
        setOverScrollMode(2);
        ((b.j.c.x) getItemAnimator()).g = false;
        super.setRecyclerListener(new C0024a());
    }

    public void a(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, b.g.l.lbBaseGridView);
        boolean z = obtainStyledAttributes.getBoolean(b.g.l.lbBaseGridView_focusOutFront, false);
        boolean z2 = obtainStyledAttributes.getBoolean(b.g.l.lbBaseGridView_focusOutEnd, false);
        b.g.n.e eVar = this.H0;
        eVar.C = (z ? 2048 : 0) | (eVar.C & (-6145)) | (z2 ? 4096 : 0);
        boolean z3 = obtainStyledAttributes.getBoolean(b.g.l.lbBaseGridView_focusOutSideStart, true);
        boolean z4 = obtainStyledAttributes.getBoolean(b.g.l.lbBaseGridView_focusOutSideEnd, true);
        b.g.n.e eVar2 = this.H0;
        eVar2.C = (z3 ? 8192 : 0) | (eVar2.C & (-24577)) | (z4 ? 16384 : 0);
        b.g.n.e eVar3 = this.H0;
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(b.g.l.lbBaseGridView_android_verticalSpacing, obtainStyledAttributes.getDimensionPixelSize(b.g.l.lbBaseGridView_verticalMargin, 0));
        int i = eVar3.u;
        eVar3.T = dimensionPixelSize;
        if (i == 1) {
            eVar3.U = dimensionPixelSize;
        } else {
            eVar3.V = dimensionPixelSize;
        }
        b.g.n.e eVar4 = this.H0;
        int dimensionPixelSize2 = obtainStyledAttributes.getDimensionPixelSize(b.g.l.lbBaseGridView_android_horizontalSpacing, obtainStyledAttributes.getDimensionPixelSize(b.g.l.lbBaseGridView_horizontalMargin, 0));
        int i2 = eVar4.u;
        eVar4.S = dimensionPixelSize2;
        if (i2 == 0) {
            eVar4.U = dimensionPixelSize2;
        } else {
            eVar4.V = dimensionPixelSize2;
        }
        if (obtainStyledAttributes.hasValue(b.g.l.lbBaseGridView_android_gravity)) {
            setGravity(obtainStyledAttributes.getInt(b.g.l.lbBaseGridView_android_gravity, 0));
        }
        obtainStyledAttributes.recycle();
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchGenericFocusedEvent(MotionEvent motionEvent) {
        c cVar = this.M0;
        if (cVar == null || !cVar.a(motionEvent)) {
            return super.dispatchGenericFocusedEvent(motionEvent);
        }
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        b bVar = this.N0;
        if ((bVar != null && bVar.a(keyEvent)) || super.dispatchKeyEvent(keyEvent)) {
            return true;
        }
        e eVar = this.P0;
        return eVar != null && eVar.a(keyEvent);
    }

    @Override // android.view.ViewGroup, android.view.View
    public boolean dispatchTouchEvent(MotionEvent motionEvent) {
        d dVar = this.L0;
        if (dVar == null || !dVar.a(motionEvent)) {
            return super.dispatchTouchEvent(motionEvent);
        }
        return true;
    }

    @Override // android.view.View
    public View focusSearch(int i) {
        if (isFocused()) {
            b.g.n.e eVar = this.H0;
            View b2 = eVar.b(eVar.G);
            if (b2 != null) {
                return focusSearch(b2, i);
            }
        }
        return super.focusSearch(i);
    }

    @Override // b.j.c.t, android.view.ViewGroup
    public int getChildDrawingOrder(int i, int i2) {
        int indexOfChild;
        b.g.n.e eVar = this.H0;
        View b2 = eVar.b(eVar.G);
        if (b2 == null || i2 < (indexOfChild = indexOfChild(b2))) {
            return i2;
        }
        if (i2 < i - 1) {
            indexOfChild = ((indexOfChild + i) - 1) - i2;
        }
        return indexOfChild;
    }

    public int getExtraLayoutSpace() {
        return this.H0.e0;
    }

    public int getFocusScrollStrategy() {
        return this.H0.a0;
    }

    @Deprecated
    public int getHorizontalMargin() {
        return this.H0.S;
    }

    public int getHorizontalSpacing() {
        return this.H0.S;
    }

    public int getInitialPrefetchItemCount() {
        return this.Q0;
    }

    public int getItemAlignmentOffset() {
        return this.H0.c0.f707d.f711c;
    }

    public float getItemAlignmentOffsetPercent() {
        return this.H0.c0.f707d.f712d;
    }

    public int getItemAlignmentViewId() {
        return this.H0.c0.f707d.f709a;
    }

    public e getOnUnhandledKeyListener() {
        return this.P0;
    }

    public final int getSaveChildrenLimitNumber() {
        return this.H0.g0.f733b;
    }

    public final int getSaveChildrenPolicy() {
        return this.H0.g0.f732a;
    }

    public int getSelectedPosition() {
        return this.H0.G;
    }

    public int getSelectedSubPosition() {
        return this.H0.H;
    }

    @Deprecated
    public int getVerticalMargin() {
        return this.H0.T;
    }

    public int getVerticalSpacing() {
        return this.H0.T;
    }

    public int getWindowAlignment() {
        return this.H0.b0.f678d.f;
    }

    public int getWindowAlignmentOffset() {
        return this.H0.b0.f678d.g;
    }

    public float getWindowAlignmentOffsetPercent() {
        return this.H0.b0.f678d.h;
    }

    @Override // android.view.View
    public boolean hasOverlappingRendering() {
        return this.J0;
    }

    @Override // android.view.View
    public void onFocusChanged(boolean z, int i, Rect rect) {
        super.onFocusChanged(z, i, rect);
        b.g.n.e eVar = this.H0;
        if (eVar == null) {
            throw null;
        }
        if (!z) {
            return;
        }
        int i2 = eVar.G;
        while (true) {
            View b2 = eVar.b(i2);
            if (b2 == null) {
                return;
            }
            if (b2.getVisibility() == 0 && b2.hasFocusable()) {
                b2.requestFocus();
                return;
            }
            i2++;
        }
    }

    @Override // b.j.c.t, android.view.ViewGroup
    public boolean onRequestFocusInDescendants(int i, Rect rect) {
        int i2;
        b.g.n.e eVar = this.H0;
        int i3 = eVar.a0;
        if (i3 != 1 && i3 != 2) {
            View b2 = eVar.b(eVar.G);
            if (b2 != null) {
                return b2.requestFocus(i, rect);
            }
            return false;
        }
        int d2 = eVar.d();
        int i4 = -1;
        if ((i & 2) != 0) {
            i2 = 0;
            i4 = 1;
        } else {
            i2 = d2 - 1;
            d2 = -1;
        }
        a0.a aVar = eVar.b0.f678d;
        int i5 = aVar.j;
        int b3 = aVar.b() + i5;
        while (i2 != d2) {
            View c2 = eVar.c(i2);
            if (c2.getVisibility() == 0 && eVar.v.d(c2) >= i5 && eVar.v.a(c2) <= b3 && c2.requestFocus(i, rect)) {
                return true;
            }
            i2 += i4;
        }
        return false;
    }

    @Override // android.view.View
    public void onRtlPropertiesChanged(int i) {
        int i2;
        b.g.n.e eVar = this.H0;
        if (eVar.u == 0) {
            if (i == 1) {
                i2 = 262144;
            }
            i2 = 0;
        } else {
            if (i == 1) {
                i2 = 524288;
            }
            i2 = 0;
        }
        int i3 = eVar.C;
        if ((786432 & i3) == i2) {
            return;
        }
        int i4 = i2 | (i3 & (-786433));
        eVar.C = i4;
        eVar.C = i4 | 256;
        eVar.b0.f677c.l = i == 1;
    }

    public void setAnimateChildLayout(boolean z) {
        t.i iVar;
        if (this.I0 != z) {
            this.I0 = z;
            if (z) {
                iVar = this.K0;
            } else {
                this.K0 = getItemAnimator();
                iVar = null;
            }
            super.setItemAnimator(iVar);
        }
    }

    public void setChildrenVisibility(int i) {
        b.g.n.e eVar = this.H0;
        eVar.M = i;
        if (i != -1) {
            int d2 = eVar.d();
            for (int i2 = 0; i2 < d2; i2++) {
                eVar.c(i2).setVisibility(eVar.M);
            }
        }
    }

    public void setExtraLayoutSpace(int i) {
        b.g.n.e eVar = this.H0;
        int i2 = eVar.e0;
        if (i2 == i) {
            return;
        }
        if (i2 < 0) {
            throw new IllegalArgumentException("ExtraLayoutSpace must >= 0");
        }
        eVar.e0 = i;
        eVar.r();
    }

    public void setFocusDrawingOrderEnabled(boolean z) {
        super.setChildrenDrawingOrderEnabled(z);
    }

    public void setFocusScrollStrategy(int i) {
        if (i != 0 && i != 1 && i != 2) {
            throw new IllegalArgumentException("Invalid scrollStrategy");
        }
        this.H0.a0 = i;
        requestLayout();
    }

    public final void setFocusSearchDisabled(boolean z) {
        setDescendantFocusability(z ? 393216 : 262144);
        b.g.n.e eVar = this.H0;
        eVar.C = (z ? 32768 : 0) | (eVar.C & (-32769));
    }

    public void setGravity(int i) {
        this.H0.W = i;
        requestLayout();
    }

    public void setHasOverlappingRendering(boolean z) {
        this.J0 = z;
    }

    @Deprecated
    public void setHorizontalMargin(int i) {
        setHorizontalSpacing(i);
    }

    public void setHorizontalSpacing(int i) {
        b.g.n.e eVar = this.H0;
        int i2 = eVar.u;
        eVar.S = i;
        if (i2 == 0) {
            eVar.U = i;
        } else {
            eVar.V = i;
        }
        requestLayout();
    }

    public void setInitialPrefetchItemCount(int i) {
        this.Q0 = i;
    }

    public void setItemAlignmentOffset(int i) {
        b.g.n.e eVar = this.H0;
        eVar.c0.f707d.f711c = i;
        eVar.F();
        requestLayout();
    }

    public void setItemAlignmentOffsetPercent(float f) {
        b.g.n.e eVar = this.H0;
        i.a aVar = eVar.c0.f707d;
        if (aVar == null) {
            throw null;
        }
        if ((f >= 0.0f && f <= 100.0f) || f == -1.0f) {
            aVar.f712d = f;
            eVar.F();
            requestLayout();
            return;
        }
        throw new IllegalArgumentException();
    }

    public void setItemAlignmentOffsetWithPadding(boolean z) {
        b.g.n.e eVar = this.H0;
        eVar.c0.f707d.e = z;
        eVar.F();
        requestLayout();
    }

    public void setItemAlignmentViewId(int i) {
        b.g.n.e eVar = this.H0;
        eVar.c0.f707d.f709a = i;
        eVar.F();
    }

    @Deprecated
    public void setItemMargin(int i) {
        setItemSpacing(i);
    }

    public void setItemSpacing(int i) {
        b.g.n.e eVar = this.H0;
        eVar.S = i;
        eVar.T = i;
        eVar.V = i;
        eVar.U = i;
        requestLayout();
    }

    public void setLayoutEnabled(boolean z) {
        b.g.n.e eVar = this.H0;
        int i = eVar.C;
        int i2 = IMediaList.Event.ItemAdded;
        if (((i & IMediaList.Event.ItemAdded) != 0) != z) {
            int i3 = eVar.C & (-513);
            if (!z) {
                i2 = 0;
            }
            eVar.C = i3 | i2;
            eVar.r();
        }
    }

    public void setOnChildLaidOutListener(m mVar) {
        this.H0.F = mVar;
    }

    public void setOnChildSelectedListener(n nVar) {
        this.H0.D = nVar;
    }

    public void setOnChildViewHolderSelectedListener(o oVar) {
        b.g.n.e eVar = this.H0;
        if (oVar == null) {
            eVar.E = null;
            return;
        }
        ArrayList<o> arrayList = eVar.E;
        if (arrayList == null) {
            eVar.E = new ArrayList<>();
        } else {
            arrayList.clear();
        }
        eVar.E.add(oVar);
    }

    public void setOnKeyInterceptListener(b bVar) {
        this.N0 = bVar;
    }

    public void setOnMotionInterceptListener(c cVar) {
        this.M0 = cVar;
    }

    public void setOnTouchInterceptListener(d dVar) {
        this.L0 = dVar;
    }

    public void setOnUnhandledKeyListener(e eVar) {
        this.P0 = eVar;
    }

    public void setPruneChild(boolean z) {
        b.g.n.e eVar = this.H0;
        if (((eVar.C & 65536) != 0) != z) {
            eVar.C = (eVar.C & (-65537)) | (z ? 65536 : 0);
            if (z) {
                eVar.r();
            }
        }
    }

    @Override // b.j.c.t
    public void setRecyclerListener(t.s sVar) {
        this.O0 = sVar;
    }

    public final void setSaveChildrenLimitNumber(int i) {
        z zVar = this.H0.g0;
        zVar.f733b = i;
        zVar.a();
    }

    public final void setSaveChildrenPolicy(int i) {
        z zVar = this.H0.g0;
        zVar.f732a = i;
        zVar.a();
    }

    public void setScrollEnabled(boolean z) {
        int i;
        b.g.n.e eVar = this.H0;
        if (((eVar.C & 131072) != 0) != z) {
            int i2 = (eVar.C & (-131073)) | (z ? 131072 : 0);
            eVar.C = i2;
            if ((i2 & 131072) == 0 || eVar.a0 != 0 || (i = eVar.G) == -1) {
                return;
            }
            eVar.a(i, eVar.H, true, eVar.L);
        }
    }

    public void setSelectedPosition(int i) {
        this.H0.b(i, 0, false, 0);
    }

    public void setSelectedPositionSmooth(int i) {
        this.H0.b(i, 0, true, 0);
    }

    @Deprecated
    public void setVerticalMargin(int i) {
        setVerticalSpacing(i);
    }

    public void setVerticalSpacing(int i) {
        b.g.n.e eVar = this.H0;
        int i2 = eVar.u;
        eVar.T = i;
        if (i2 == 1) {
            eVar.U = i;
        } else {
            eVar.V = i;
        }
        requestLayout();
    }

    public void setWindowAlignment(int i) {
        this.H0.b0.f678d.f = i;
        requestLayout();
    }

    public void setWindowAlignmentOffset(int i) {
        this.H0.b0.f678d.g = i;
        requestLayout();
    }

    public void setWindowAlignmentOffsetPercent(float f) {
        a0.a aVar = this.H0.b0.f678d;
        if (aVar == null) {
            throw null;
        }
        if ((f >= 0.0f && f <= 100.0f) || f == -1.0f) {
            aVar.h = f;
            requestLayout();
            return;
        }
        throw new IllegalArgumentException();
    }

    public void setWindowAlignmentPreferKeyLineOverHighEdge(boolean z) {
        a0.a aVar = this.H0.b0.f678d;
        aVar.e = z ? aVar.e | 2 : aVar.e & (-3);
        requestLayout();
    }

    public void setWindowAlignmentPreferKeyLineOverLowEdge(boolean z) {
        a0.a aVar = this.H0.b0.f678d;
        aVar.e = z ? aVar.e | 1 : aVar.e & (-2);
        requestLayout();
    }

    public final boolean x() {
        return isChildrenDrawingOrderEnabled();
    }
}
