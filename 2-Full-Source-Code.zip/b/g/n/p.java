package b.g.n;

import android.util.Property;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public abstract class p<PropertyT extends Property> {

    /* renamed from: a, reason: collision with root package name */
    public final List<PropertyT> f717a;

    /* renamed from: b, reason: collision with root package name */
    public int[] f718b;

    /* renamed from: c, reason: collision with root package name */
    public float[] f719c;

    /* renamed from: d, reason: collision with root package name */
    public final List<q> f720d;

    public p() {
        ArrayList arrayList = new ArrayList();
        this.f717a = arrayList;
        Collections.unmodifiableList(arrayList);
        this.f718b = new int[4];
        this.f719c = new float[4];
        this.f720d = new ArrayList(4);
    }

    public final float a(int i) {
        return this.f719c[i];
    }

    public void a() {
        for (int i = 0; i < this.f720d.size(); i++) {
            q qVar = this.f720d.get(i);
            if (qVar.f721a.size() >= 2) {
                b();
                Number number = null;
                boolean z = false;
                for (int i2 = 0; i2 < qVar.f722b.size(); i2++) {
                    r rVar = qVar.f722b.get(i2);
                    if (rVar.b()) {
                        if (number == null) {
                            number = qVar.a(this);
                        }
                        rVar.a();
                    } else {
                        if (!z) {
                            qVar.b(this);
                            z = true;
                        }
                        rVar.c();
                    }
                }
            }
        }
    }

    public final void b() {
        if (this.f717a.size() < 2) {
            return;
        }
        float a2 = a(0);
        int i = 1;
        while (i < this.f717a.size()) {
            float a3 = a(i);
            if (a3 < a2) {
                int i2 = i - 1;
                throw new IllegalStateException(String.format("Parallax Property[%d]\"%s\" is smaller than Property[%d]\"%s\"", Integer.valueOf(i), this.f717a.get(i).getName(), Integer.valueOf(i2), this.f717a.get(i2).getName()));
            }
            if (a2 == -3.4028235E38f && a3 == Float.MAX_VALUE) {
                int i3 = i - 1;
                throw new IllegalStateException(String.format("Parallax Property[%d]\"%s\" is UNKNOWN_BEFORE and Property[%d]\"%s\" is UNKNOWN_AFTER", Integer.valueOf(i3), this.f717a.get(i3).getName(), Integer.valueOf(i), this.f717a.get(i).getName()));
            }
            i++;
            a2 = a3;
        }
    }
}
