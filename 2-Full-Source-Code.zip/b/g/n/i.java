package b.g.n;

import b.g.n.j;

/* loaded from: classes.dex */
public class i {

    /* renamed from: a, reason: collision with root package name */
    public int f704a = 0;

    /* renamed from: b, reason: collision with root package name */
    public final a f705b = new a(1);

    /* renamed from: c, reason: collision with root package name */
    public final a f706c;

    /* renamed from: d, reason: collision with root package name */
    public a f707d;

    /* loaded from: classes.dex */
    public static final class a extends j.a {
        public int f;

        public a(int i) {
            this.f = i;
        }
    }

    public i() {
        a aVar = new a(0);
        this.f706c = aVar;
        this.f707d = aVar;
    }
}
