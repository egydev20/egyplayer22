package b.g.n;

import android.view.View;

/* loaded from: classes.dex */
public interface g {
    void a(View view);
}
