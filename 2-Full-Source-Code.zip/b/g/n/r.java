package b.g.n;

/* loaded from: classes.dex */
public abstract class r {
    public void a() {
    }

    public boolean b() {
        return false;
    }

    public void c() {
    }
}
