package b.g.n;

import android.view.View;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public interface m {
    void a(ViewGroup viewGroup, View view, int i, long j);
}
