package b.g.n;

@Deprecated
/* loaded from: classes.dex */
public interface u {
    void a();
}
