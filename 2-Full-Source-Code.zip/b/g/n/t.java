package b.g.n;

import b.g.n.d;
import b.g.n.e;
import b.j.c.m;
import b.j.c.t;

/* loaded from: classes.dex */
public class t extends d {
    public final d.a j = new d.a(0);

    public t() {
        f(1);
    }

    @Override // b.g.n.d
    public final int a(boolean z, int i, int[] iArr) {
        if (iArr != null) {
            iArr[0] = 0;
            iArr[1] = i;
        }
        return this.f697c ? ((e.b) this.f696b).a(i) : ((e.b) this.f696b).a(i) + ((e.b) this.f696b).b(i);
    }

    @Override // b.g.n.d
    public void a(int i, int i2, t.l.c cVar) {
        int d2;
        int a2;
        if (!this.f697c ? i2 < 0 : i2 > 0) {
            if (this.f == 0) {
                return;
            }
            d2 = d();
            a2 = ((e.b) this.f696b).a(this.f) + (this.f697c ? this.f698d : -this.f698d);
        } else {
            if (this.g == ((e.b) this.f696b).a() - 1) {
                return;
            }
            d2 = c();
            int b2 = ((e.b) this.f696b).b(this.g) + this.f698d;
            int a3 = ((e.b) this.f696b).a(this.g);
            if (this.f697c) {
                b2 = -b2;
            }
            a2 = b2 + a3;
        }
        ((m.b) cVar).a(d2, Math.abs(a2 - i));
    }

    @Override // b.g.n.d
    public final boolean a(int i, boolean z) {
        int i2;
        if (((e.b) this.f696b).a() == 0) {
            return false;
        }
        if (!z && a(i)) {
            return false;
        }
        int c2 = c();
        boolean z2 = false;
        while (c2 < ((e.b) this.f696b).a()) {
            int a2 = ((e.b) this.f696b).a(c2, true, this.f695a, false);
            if (this.f < 0 || this.g < 0) {
                i2 = this.f697c ? Integer.MAX_VALUE : Integer.MIN_VALUE;
                this.f = c2;
            } else if (this.f697c) {
                int i3 = c2 - 1;
                i2 = (((e.b) this.f696b).a(i3) - ((e.b) this.f696b).b(i3)) - this.f698d;
            } else {
                int i4 = c2 - 1;
                i2 = this.f698d + ((e.b) this.f696b).b(i4) + ((e.b) this.f696b).a(i4);
            }
            this.g = c2;
            ((e.b) this.f696b).a(this.f695a[0], c2, a2, 0, i2);
            if (z || a(i)) {
                return true;
            }
            c2++;
            z2 = true;
        }
        return z2;
    }

    @Override // b.g.n.d
    public final int b(boolean z, int i, int[] iArr) {
        if (iArr != null) {
            iArr[0] = 0;
            iArr[1] = i;
        }
        return this.f697c ? ((e.b) this.f696b).a(i) - ((e.b) this.f696b).b(i) : ((e.b) this.f696b).a(i);
    }

    @Override // b.g.n.d
    public final boolean b(int i, boolean z) {
        int i2;
        if (((e.b) this.f696b).a() == 0) {
            return false;
        }
        if (!z && b(i)) {
            return false;
        }
        int i3 = e.this.x;
        int d2 = d();
        boolean z2 = false;
        while (d2 >= i3) {
            int a2 = ((e.b) this.f696b).a(d2, false, this.f695a, false);
            if (this.f < 0 || this.g < 0) {
                i2 = this.f697c ? Integer.MIN_VALUE : Integer.MAX_VALUE;
                this.f = d2;
                this.g = d2;
            } else {
                i2 = this.f697c ? ((e.b) this.f696b).a(d2 + 1) + this.f698d + a2 : (((e.b) this.f696b).a(d2 + 1) - this.f698d) - a2;
                this.f = d2;
            }
            ((e.b) this.f696b).a(this.f695a[0], d2, a2, 0, i2);
            if (z || b(i)) {
                return true;
            }
            d2--;
            z2 = true;
        }
        return z2;
    }

    public int c() {
        int i = this.g;
        if (i >= 0) {
            return i + 1;
        }
        int i2 = this.i;
        if (i2 != -1) {
            return Math.min(i2, ((e.b) this.f696b).a() - 1);
        }
        return 0;
    }

    @Override // b.g.n.d
    public final d.a c(int i) {
        return this.j;
    }

    public int d() {
        int i = this.f;
        if (i >= 0) {
            return i - 1;
        }
        int i2 = this.i;
        return i2 != -1 ? Math.min(i2, ((e.b) this.f696b).a() - 1) : ((e.b) this.f696b).a() - 1;
    }

    @Override // b.g.n.d
    public final b.c.e[] a(int i, int i2) {
        b.c.e[] eVarArr = this.h;
        b.c.e eVar = eVarArr[0];
        eVar.f494c = eVar.f493b;
        eVarArr[0].a(i);
        this.h[0].a(i2);
        return this.h;
    }
}
