package b.g.n;

/* loaded from: classes.dex */
public abstract class o {
}
