package b.g.n;

import android.R;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.util.AttributeSet;
import android.widget.LinearLayout;

/* loaded from: classes.dex */
public class l extends LinearLayout {

    /* renamed from: b, reason: collision with root package name */
    public Drawable f714b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f715c;

    /* renamed from: d, reason: collision with root package name */
    public final Rect f716d;

    public l(Context context) {
        this(context, null);
    }

    public l(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public l(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f716d = new Rect();
        if (context.getApplicationInfo().targetSdkVersion < 23 || Build.VERSION.SDK_INT < 23) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, new int[]{R.attr.foreground});
            Drawable drawable = obtainStyledAttributes.getDrawable(0);
            if (drawable != null) {
                int i2 = Build.VERSION.SDK_INT;
                if (i2 >= 23) {
                    if (i2 >= 23) {
                        setForeground(drawable);
                    }
                } else if (this.f714b != drawable) {
                    this.f714b = drawable;
                    this.f715c = true;
                    setWillNotDraw(false);
                    this.f714b.setCallback(this);
                    if (this.f714b.isStateful()) {
                        this.f714b.setState(getDrawableState());
                    }
                }
            }
            obtainStyledAttributes.recycle();
        }
    }

    @Override // android.view.View
    public void draw(Canvas canvas) {
        super.draw(canvas);
        Drawable drawable = this.f714b;
        if (drawable != null) {
            if (this.f715c) {
                this.f715c = false;
                Rect rect = this.f716d;
                rect.set(0, 0, getRight() - getLeft(), getBottom() - getTop());
                drawable.setBounds(rect);
            }
            drawable.draw(canvas);
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable drawable = this.f714b;
        if (drawable == null || !drawable.isStateful()) {
            return;
        }
        this.f714b.setState(getDrawableState());
    }

    @Override // android.view.View
    public boolean hasOverlappingRendering() {
        return false;
    }

    @Override // android.view.ViewGroup, android.view.View
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        Drawable drawable = this.f714b;
        if (drawable != null) {
            drawable.jumpToCurrentState();
        }
    }

    @Override // android.widget.LinearLayout, android.view.ViewGroup, android.view.View
    public void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.f715c = z | this.f715c;
    }

    @Override // android.view.View
    public boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f714b;
    }
}
