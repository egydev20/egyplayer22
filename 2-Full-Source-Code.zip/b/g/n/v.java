package b.g.n;

import b.g.n.d;
import b.g.n.e;

/* loaded from: classes.dex */
public abstract class v extends d {
    public b.c.d<a> j = new b.c.d<>(64);
    public int k = -1;
    public Object l;
    public int m;

    /* loaded from: classes.dex */
    public static class a extends d.a {

        /* renamed from: b, reason: collision with root package name */
        public int f724b;

        /* renamed from: c, reason: collision with root package name */
        public int f725c;

        public a(int i, int i2, int i3) {
            super(i);
            this.f724b = i2;
            this.f725c = i3;
        }
    }

    public final int a(int i, int i2, int i3) {
        int a2;
        boolean z;
        int i4 = this.g;
        if (i4 >= 0 && (i4 != c() || this.g != i - 1)) {
            throw new IllegalStateException();
        }
        int i5 = this.g;
        if (i5 >= 0) {
            a2 = i3 - ((e.b) this.f696b).a(i5);
        } else if (this.j.b() <= 0 || i != c() + 1) {
            a2 = 0;
        } else {
            int c2 = c();
            while (true) {
                if (c2 < this.k) {
                    z = false;
                    break;
                }
                if (c(c2).f699a == i2) {
                    z = true;
                    break;
                }
                c2--;
            }
            if (!z) {
                c2 = c();
            }
            a2 = this.f697c ? (-c(c2).f725c) - this.f698d : c(c2).f725c + this.f698d;
            for (int i6 = c2 + 1; i6 <= c(); i6++) {
                a2 -= c(i6).f724b;
            }
        }
        a aVar = new a(i2, a2, 0);
        b.c.d<a> dVar = this.j;
        a[] aVarArr = dVar.f488a;
        int i7 = dVar.f490c;
        aVarArr[i7] = aVar;
        int i8 = dVar.f491d & (i7 + 1);
        dVar.f490c = i8;
        if (i8 == dVar.f489b) {
            dVar.a();
        }
        Object obj = this.l;
        if (obj != null) {
            aVar.f725c = this.m;
            this.l = null;
        } else {
            aVar.f725c = ((e.b) this.f696b).a(i, true, this.f695a, false);
            obj = this.f695a[0];
        }
        Object obj2 = obj;
        if (this.j.b() == 1) {
            this.g = i;
            this.f = i;
            this.k = i;
        } else {
            int i9 = this.g;
            if (i9 < 0) {
                this.g = i;
                this.f = i;
            } else {
                this.g = i9 + 1;
            }
        }
        ((e.b) this.f696b).a(obj2, i, aVar.f725c, i2, i3);
        return aVar.f725c;
    }

    @Override // b.g.n.d
    public final boolean a(int i, boolean z) {
        boolean d2;
        if (((e.b) this.f696b).a() == 0) {
            return false;
        }
        if (!z && a(i)) {
            return false;
        }
        try {
            if (c(i, z)) {
                d2 = true;
                this.f695a[0] = null;
            } else {
                d2 = d(i, z);
                this.f695a[0] = null;
            }
            this.l = null;
            return d2;
        } catch (Throwable th) {
            this.f695a[0] = null;
            this.l = null;
            throw th;
        }
    }

    public final int b(int i, int i2, int i3) {
        int i4 = this.f;
        if (i4 >= 0 && (i4 != this.k || i4 != i + 1)) {
            throw new IllegalStateException();
        }
        int i5 = this.k;
        a c2 = i5 >= 0 ? c(i5) : null;
        int a2 = ((e.b) this.f696b).a(this.k);
        a aVar = new a(i2, 0, 0);
        b.c.d<a> dVar = this.j;
        int i6 = (dVar.f489b - 1) & dVar.f491d;
        dVar.f489b = i6;
        dVar.f488a[i6] = aVar;
        if (i6 == dVar.f490c) {
            dVar.a();
        }
        Object obj = this.l;
        if (obj != null) {
            aVar.f725c = this.m;
            this.l = null;
        } else {
            aVar.f725c = ((e.b) this.f696b).a(i, false, this.f695a, false);
            obj = this.f695a[0];
        }
        Object obj2 = obj;
        this.f = i;
        this.k = i;
        if (this.g < 0) {
            this.g = i;
        }
        int i7 = !this.f697c ? i3 - aVar.f725c : i3 + aVar.f725c;
        if (c2 != null) {
            c2.f724b = a2 - i7;
        }
        ((e.b) this.f696b).a(obj2, i, aVar.f725c, i2, i7);
        return aVar.f725c;
    }

    @Override // b.g.n.d
    public final boolean b(int i, boolean z) {
        boolean f;
        if (((e.b) this.f696b).a() == 0) {
            return false;
        }
        if (!z && b(i)) {
            return false;
        }
        try {
            if (e(i, z)) {
                f = true;
                this.f695a[0] = null;
            } else {
                f = f(i, z);
                this.f695a[0] = null;
            }
            this.l = null;
            return f;
        } catch (Throwable th) {
            this.f695a[0] = null;
            this.l = null;
            throw th;
        }
    }

    public final int c() {
        return (this.j.b() + this.k) - 1;
    }

    public final boolean c(int i, boolean z) {
        int i2;
        int i3;
        int i4;
        if (this.j.b() == 0) {
            return false;
        }
        int a2 = ((e.b) this.f696b).a();
        int i5 = this.g;
        if (i5 >= 0) {
            i2 = i5 + 1;
            i3 = ((e.b) this.f696b).a(i5);
        } else {
            int i6 = this.i;
            i2 = i6 != -1 ? i6 : 0;
            if (i2 <= c() + 1 && i2 >= this.k) {
                if (i2 > c()) {
                    return false;
                }
                i3 = Integer.MAX_VALUE;
            } else {
                b.c.d<a> dVar = this.j;
                dVar.b(dVar.b());
                return false;
            }
        }
        int c2 = c();
        int i7 = i2;
        while (i7 < a2 && i7 <= c2) {
            a c3 = c(i7);
            if (i3 != Integer.MAX_VALUE) {
                i3 += c3.f724b;
            }
            int i8 = c3.f699a;
            int a3 = ((e.b) this.f696b).a(i7, true, this.f695a, false);
            if (a3 != c3.f725c) {
                c3.f725c = a3;
                this.j.a(c2 - i7);
                i4 = i7;
            } else {
                i4 = c2;
            }
            this.g = i7;
            if (this.f < 0) {
                this.f = i7;
            }
            ((e.b) this.f696b).a(this.f695a[0], i7, a3, i8, i3);
            if (!z && a(i)) {
                return true;
            }
            if (i3 == Integer.MAX_VALUE) {
                i3 = ((e.b) this.f696b).a(i7);
            }
            if (i8 == this.e - 1 && z) {
                return true;
            }
            i7++;
            c2 = i4;
        }
        return false;
    }

    public abstract boolean d(int i, boolean z);

    @Override // b.g.n.d
    public void e(int i) {
        super.e(i);
        this.j.a((c() - i) + 1);
        if (this.j.b() == 0) {
            this.k = -1;
        }
    }

    public final boolean e(int i, boolean z) {
        int i2;
        int i3;
        int i4;
        if (this.j.b() == 0) {
            return false;
        }
        int i5 = this.f;
        if (i5 < 0) {
            i2 = Integer.MAX_VALUE;
            int i6 = this.i;
            i3 = i6 != -1 ? i6 : 0;
            if (i3 <= c()) {
                int i7 = this.k;
                if (i3 >= i7 - 1) {
                    if (i3 < i7) {
                        return false;
                    }
                    i4 = 0;
                }
            }
            b.c.d<a> dVar = this.j;
            dVar.b(dVar.b());
            return false;
        }
        i2 = ((e.b) this.f696b).a(i5);
        i4 = c(this.f).f724b;
        i3 = this.f - 1;
        int max = Math.max(e.this.x, this.k);
        while (i3 >= max) {
            a c2 = c(i3);
            int i8 = c2.f699a;
            int a2 = ((e.b) this.f696b).a(i3, false, this.f695a, false);
            if (a2 != c2.f725c) {
                this.j.b((i3 + 1) - this.k);
                this.k = this.f;
                this.l = this.f695a[0];
                this.m = a2;
                return false;
            }
            this.f = i3;
            if (this.g < 0) {
                this.g = i3;
            }
            ((e.b) this.f696b).a(this.f695a[0], i3, a2, i8, i2 - i4);
            if (!z && b(i)) {
                return true;
            }
            i2 = ((e.b) this.f696b).a(i3);
            i4 = c2.f724b;
            if (i8 == 0 && z) {
                return true;
            }
            i3--;
        }
        return false;
    }

    public abstract boolean f(int i, boolean z);

    @Override // b.g.n.d
    public final a c(int i) {
        int i2 = i - this.k;
        if (i2 < 0 || i2 >= this.j.b()) {
            return null;
        }
        b.c.d<a> dVar = this.j;
        if (dVar == null) {
            throw null;
        }
        if (i2 >= 0 && i2 < dVar.b()) {
            return dVar.f488a[dVar.f491d & (dVar.f489b + i2)];
        }
        throw new ArrayIndexOutOfBoundsException();
    }

    @Override // b.g.n.d
    public final b.c.e[] a(int i, int i2) {
        for (int i3 = 0; i3 < this.e; i3++) {
            b.c.e eVar = this.h[i3];
            eVar.f494c = eVar.f493b;
        }
        if (i >= 0) {
            while (i <= i2) {
                b.c.e eVar2 = this.h[c(i).f699a];
                if (eVar2.a() > 0) {
                    int i4 = eVar2.f493b;
                    int i5 = eVar2.f494c;
                    if (i4 == i5) {
                        throw new ArrayIndexOutOfBoundsException();
                    }
                    int[] iArr = eVar2.f492a;
                    int i6 = (i5 - 1) & eVar2.f495d;
                    if (iArr[i6] == i - 1) {
                        if (i4 == i5) {
                            throw new ArrayIndexOutOfBoundsException();
                        }
                        int i7 = iArr[i6];
                        eVar2.f494c = i6;
                        eVar2.a(i);
                        i++;
                    }
                }
                eVar2.a(i);
                eVar2.a(i);
                i++;
            }
        }
        return this.h;
    }
}
