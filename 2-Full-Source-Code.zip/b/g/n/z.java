package b.g.n;

import android.os.Parcelable;
import android.util.SparseArray;

/* loaded from: classes.dex */
public class z {

    /* renamed from: a, reason: collision with root package name */
    public int f732a = 0;

    /* renamed from: b, reason: collision with root package name */
    public int f733b = 100;

    /* renamed from: c, reason: collision with root package name */
    public b.c.h<String, SparseArray<Parcelable>> f734c;

    public void a() {
        b.c.h<String, SparseArray<Parcelable>> hVar;
        int i = this.f732a;
        if (i == 2) {
            if (this.f733b <= 0) {
                throw new IllegalArgumentException();
            }
            b.c.h<String, SparseArray<Parcelable>> hVar2 = this.f734c;
            if (hVar2 != null && hVar2.a() == this.f733b) {
                return;
            } else {
                hVar = new b.c.h<>(this.f733b);
            }
        } else if (i == 3 || i == 1) {
            b.c.h<String, SparseArray<Parcelable>> hVar3 = this.f734c;
            if (hVar3 != null && hVar3.a() == Integer.MAX_VALUE) {
                return;
            } else {
                hVar = new b.c.h<>(Integer.MAX_VALUE);
            }
        } else {
            hVar = null;
        }
        this.f734c = hVar;
    }

    public void b() {
        b.c.h<String, SparseArray<Parcelable>> hVar = this.f734c;
        if (hVar != null) {
            hVar.a(-1);
        }
    }
}
