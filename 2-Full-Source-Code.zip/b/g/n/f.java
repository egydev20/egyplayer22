package b.g.n;

import android.graphics.PointF;
import b.g.n.e;

/* loaded from: classes.dex */
public class f extends e.c {
    public final /* synthetic */ e p;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public f(e eVar) {
        super();
        this.p = eVar;
    }

    @Override // b.j.c.t.v
    public PointF a(int i) {
        if (this.f851b.m.d() == 0) {
            return null;
        }
        e eVar = this.p;
        boolean z = false;
        int j = eVar.j(eVar.c(0));
        if ((this.p.C & 262144) == 0 ? i < j : i > j) {
            z = true;
        }
        int i2 = z ? -1 : 1;
        return this.p.u == 0 ? new PointF(i2, 0.0f) : new PointF(0.0f, i2);
    }
}
