package b.g.n;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.text.style.ReplacementSpan;
import android.util.AttributeSet;
import android.util.Property;
import android.view.ActionMode;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.EditText;
import java.util.Random;
import java.util.regex.Pattern;

/* loaded from: classes.dex */
public class x extends EditText {
    public static final Pattern g = Pattern.compile("\\S+");
    public static final Property<x, Integer> h = new a(Integer.class, "streamPosition");

    /* renamed from: b, reason: collision with root package name */
    public final Random f726b;

    /* renamed from: c, reason: collision with root package name */
    public Bitmap f727c;

    /* renamed from: d, reason: collision with root package name */
    public Bitmap f728d;
    public int e;
    public ObjectAnimator f;

    /* loaded from: classes.dex */
    public static class a extends Property<x, Integer> {
        public a(Class cls, String str) {
            super(cls, str);
        }

        @Override // android.util.Property
        public Integer get(x xVar) {
            return Integer.valueOf(xVar.getStreamPosition());
        }

        @Override // android.util.Property
        public void set(x xVar, Integer num) {
            xVar.setStreamPosition(num.intValue());
        }
    }

    /* loaded from: classes.dex */
    public class b extends ReplacementSpan {

        /* renamed from: b, reason: collision with root package name */
        public final int f729b;

        /* renamed from: c, reason: collision with root package name */
        public final int f730c;

        public b(int i, int i2) {
            this.f729b = i;
            this.f730c = i2;
        }

        @Override // android.text.style.ReplacementSpan
        public void draw(Canvas canvas, CharSequence charSequence, int i, int i2, float f, int i3, int i4, int i5, Paint paint) {
            int measureText = (int) paint.measureText(charSequence, i, i2);
            int width = x.this.f727c.getWidth();
            int i6 = width * 2;
            int i7 = measureText / i6;
            int i8 = (measureText % i6) / 2;
            boolean z = 1 == x.this.getLayoutDirection();
            x.this.f726b.setSeed(this.f729b);
            int alpha = paint.getAlpha();
            for (int i9 = 0; i9 < i7 && this.f730c + i9 < x.this.e; i9++) {
                float f2 = (width / 2) + (i9 * i6) + i8;
                float f3 = z ? ((f + measureText) - f2) - width : f + f2;
                paint.setAlpha((x.this.f726b.nextInt(4) + 1) * 63);
                canvas.drawBitmap(x.this.f726b.nextBoolean() ? x.this.f728d : x.this.f727c, f3, i4 - r12.getHeight(), paint);
            }
            paint.setAlpha(alpha);
        }

        @Override // android.text.style.ReplacementSpan
        public int getSize(Paint paint, CharSequence charSequence, int i, int i2, Paint.FontMetricsInt fontMetricsInt) {
            return (int) paint.measureText(charSequence, i, i2);
        }
    }

    public x(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f726b = new Random();
    }

    public x(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f726b = new Random();
    }

    public final Bitmap a(int i, float f) {
        return Bitmap.createScaledBitmap(BitmapFactory.decodeResource(getResources(), i), (int) (r3.getWidth() * f), (int) (r3.getHeight() * f), false);
    }

    public int getStreamPosition() {
        return this.e;
    }

    @Override // android.view.View
    public void onFinishInflate() {
        super.onFinishInflate();
        this.f727c = a(b.g.d.lb_text_dot_one, 1.3f);
        this.f728d = a(b.g.d.lb_text_dot_two, 1.3f);
        this.e = -1;
        ObjectAnimator objectAnimator = this.f;
        if (objectAnimator != null) {
            objectAnimator.cancel();
        }
        setText("");
    }

    @Override // android.view.View
    public void onInitializeAccessibilityNodeInfo(AccessibilityNodeInfo accessibilityNodeInfo) {
        super.onInitializeAccessibilityNodeInfo(accessibilityNodeInfo);
        accessibilityNodeInfo.setClassName(x.class.getCanonicalName());
    }

    @Override // android.widget.TextView
    public void setCustomSelectionActionModeCallback(ActionMode.Callback callback) {
        super.setCustomSelectionActionModeCallback(a.a.a.a.a.a(this, callback));
    }

    public void setFinalRecognizedText(CharSequence charSequence) {
        setText(charSequence);
        bringPointIntoView(length());
    }

    public void setStreamPosition(int i) {
        this.e = i;
        invalidate();
    }
}
