package b.g.n;

/* loaded from: classes.dex */
public final class j {

    /* renamed from: a, reason: collision with root package name */
    public a[] f708a = {new a()};

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: a, reason: collision with root package name */
        public int f709a = -1;

        /* renamed from: b, reason: collision with root package name */
        public int f710b = -1;

        /* renamed from: c, reason: collision with root package name */
        public int f711c = 0;

        /* renamed from: d, reason: collision with root package name */
        public float f712d = 50.0f;
        public boolean e = false;
    }
}
