package b.g.n;

import android.view.KeyEvent;
import android.widget.EditText;

/* loaded from: classes.dex */
public interface h {
    boolean a(EditText editText, int i, KeyEvent keyEvent);
}
