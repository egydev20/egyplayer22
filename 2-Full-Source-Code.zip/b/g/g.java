package b.g;

/* loaded from: classes.dex */
public final class g {
    public static final int cancel_button_image_alpha = 2131361794;
    public static final int lb_browse_headers_transition_delay = 2131361798;
    public static final int lb_browse_headers_transition_duration = 2131361799;
    public static final int lb_browse_rows_anim_duration = 2131361800;
    public static final int lb_card_activated_animation_duration = 2131361801;
    public static final int lb_card_selected_animation_delay = 2131361802;
    public static final int lb_card_selected_animation_duration = 2131361803;
    public static final int lb_details_description_body_max_lines = 2131361804;
    public static final int lb_details_description_body_min_lines = 2131361805;
    public static final int lb_details_description_subtitle_max_lines = 2131361806;
    public static final int lb_details_description_title_max_lines = 2131361807;
    public static final int lb_error_message_max_lines = 2131361808;
    public static final int lb_guidedactions_item_animation_duration = 2131361809;
    public static final int lb_guidedactions_item_description_min_lines = 2131361810;
    public static final int lb_guidedactions_item_title_max_lines = 2131361811;
    public static final int lb_guidedactions_item_title_min_lines = 2131361812;
    public static final int lb_guidedstep_activity_background_fade_duration_ms = 2131361813;
    public static final int lb_onboarding_header_description_delay = 2131361814;
    public static final int lb_onboarding_header_title_delay = 2131361815;
    public static final int lb_playback_bg_fade_in_ms = 2131361816;
    public static final int lb_playback_bg_fade_out_ms = 2131361817;
    public static final int lb_playback_controls_fade_in_ms = 2131361818;
    public static final int lb_playback_controls_fade_out_ms = 2131361819;
    public static final int lb_playback_controls_show_time_ms = 2131361820;
    public static final int lb_playback_controls_tickle_timeout_ms = 2131361821;
    public static final int lb_playback_description_fade_in_ms = 2131361822;
    public static final int lb_playback_description_fade_out_ms = 2131361823;
    public static final int lb_playback_rows_fade_delay_ms = 2131361824;
    public static final int lb_playback_rows_fade_in_ms = 2131361825;
    public static final int lb_playback_rows_fade_out_ms = 2131361826;
    public static final int lb_search_bar_speech_mode_background_alpha = 2131361827;
    public static final int lb_search_bar_text_mode_background_alpha = 2131361828;
    public static final int lb_search_orb_pulse_duration_ms = 2131361829;
    public static final int lb_search_orb_scale_duration_ms = 2131361830;
    public static final int slideEdgeEnd = 2131361831;
    public static final int slideEdgeStart = 2131361832;
    public static final int status_bar_notification_info_maxnum = 2131361833;
}
