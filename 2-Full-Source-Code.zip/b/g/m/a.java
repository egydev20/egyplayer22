package b.g.m;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.transition.Transition;
import android.view.View;
import b.g.f;

/* loaded from: classes.dex */
public class a extends AnimatorListenerAdapter implements Transition.TransitionListener {

    /* renamed from: a, reason: collision with root package name */
    public final View f670a;

    /* renamed from: b, reason: collision with root package name */
    public final View f671b;

    /* renamed from: c, reason: collision with root package name */
    public final int f672c;

    /* renamed from: d, reason: collision with root package name */
    public final int f673d;
    public int[] e;
    public float f;
    public float g;
    public final float h;
    public final float i;

    public a(View view, View view2, int i, int i2, float f, float f2) {
        this.f671b = view;
        this.f670a = view2;
        this.f672c = i - Math.round(view.getTranslationX());
        this.f673d = i2 - Math.round(this.f671b.getTranslationY());
        this.h = f;
        this.i = f2;
        int[] iArr = (int[]) this.f670a.getTag(f.transitionPosition);
        this.e = iArr;
        if (iArr != null) {
            this.f670a.setTag(f.transitionPosition, null);
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationCancel(Animator animator) {
        if (this.e == null) {
            this.e = new int[2];
        }
        this.e[0] = Math.round(this.f671b.getTranslationX() + this.f672c);
        this.e[1] = Math.round(this.f671b.getTranslationY() + this.f673d);
        this.f670a.setTag(f.transitionPosition, this.e);
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public void onAnimationEnd(Animator animator) {
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorPauseListener
    public void onAnimationPause(Animator animator) {
        this.f = this.f671b.getTranslationX();
        this.g = this.f671b.getTranslationY();
        this.f671b.setTranslationX(this.h);
        this.f671b.setTranslationY(this.i);
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorPauseListener
    public void onAnimationResume(Animator animator) {
        this.f671b.setTranslationX(this.f);
        this.f671b.setTranslationY(this.g);
    }

    @Override // android.transition.Transition.TransitionListener
    public void onTransitionCancel(Transition transition) {
    }

    @Override // android.transition.Transition.TransitionListener
    public void onTransitionEnd(Transition transition) {
        this.f671b.setTranslationX(this.h);
        this.f671b.setTranslationY(this.i);
    }

    @Override // android.transition.Transition.TransitionListener
    public void onTransitionPause(Transition transition) {
    }

    @Override // android.transition.Transition.TransitionListener
    public void onTransitionResume(Transition transition) {
    }

    @Override // android.transition.Transition.TransitionListener
    public void onTransitionStart(Transition transition) {
    }
}
