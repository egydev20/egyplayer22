package b.g;

/* loaded from: classes.dex */
public final class i {
    public static final int lb_voice_failure = 2131623936;
    public static final int lb_voice_no_input = 2131623937;
    public static final int lb_voice_open = 2131623938;
    public static final int lb_voice_success = 2131623939;
}
