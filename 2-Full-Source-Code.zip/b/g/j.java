package b.g;

/* loaded from: classes.dex */
public final class j {
    public static final int lb_control_display_fast_forward_multiplier = 2131689557;
    public static final int lb_control_display_rewind_multiplier = 2131689558;
    public static final int lb_guidedaction_continue_title = 2131689559;
    public static final int lb_guidedaction_finish_title = 2131689560;
    public static final int lb_media_player_error = 2131689561;
    public static final int lb_navigation_menu_contentDescription = 2131689562;
    public static final int lb_onboarding_accessibility_next = 2131689563;
    public static final int lb_onboarding_get_started = 2131689564;
    public static final int lb_playback_controls_closed_captioning_disable = 2131689565;
    public static final int lb_playback_controls_closed_captioning_enable = 2131689566;
    public static final int lb_playback_controls_fast_forward = 2131689567;
    public static final int lb_playback_controls_fast_forward_multiplier = 2131689568;
    public static final int lb_playback_controls_hidden = 2131689569;
    public static final int lb_playback_controls_high_quality_disable = 2131689570;
    public static final int lb_playback_controls_high_quality_enable = 2131689571;
    public static final int lb_playback_controls_more_actions = 2131689572;
    public static final int lb_playback_controls_pause = 2131689573;
    public static final int lb_playback_controls_picture_in_picture = 2131689574;
    public static final int lb_playback_controls_play = 2131689575;
    public static final int lb_playback_controls_repeat_all = 2131689576;
    public static final int lb_playback_controls_repeat_none = 2131689577;
    public static final int lb_playback_controls_repeat_one = 2131689578;
    public static final int lb_playback_controls_rewind = 2131689579;
    public static final int lb_playback_controls_rewind_multiplier = 2131689580;
    public static final int lb_playback_controls_shown = 2131689581;
    public static final int lb_playback_controls_shuffle_disable = 2131689582;
    public static final int lb_playback_controls_shuffle_enable = 2131689583;
    public static final int lb_playback_controls_skip_next = 2131689584;
    public static final int lb_playback_controls_skip_previous = 2131689585;
    public static final int lb_playback_controls_thumb_down = 2131689586;
    public static final int lb_playback_controls_thumb_down_outline = 2131689587;
    public static final int lb_playback_controls_thumb_up = 2131689588;
    public static final int lb_playback_controls_thumb_up_outline = 2131689589;
    public static final int lb_playback_time_separator = 2131689590;
    public static final int lb_search_bar_hint = 2131689591;
    public static final int lb_search_bar_hint_speech = 2131689592;
    public static final int lb_search_bar_hint_with_title = 2131689593;
    public static final int lb_search_bar_hint_with_title_speech = 2131689594;
    public static final int orb_search_action = 2131689595;
    public static final int status_bar_notification_info_overflow = 2131689597;
}
