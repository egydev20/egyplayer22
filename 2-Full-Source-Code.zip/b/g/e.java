package b.g;

/* loaded from: classes.dex */
public final class e {
    public static final int lb_browse_header_unselect_alpha = 2131230720;
    public static final int lb_browse_rows_scale = 2131230721;
    public static final int lb_focus_zoom_factor_large = 2131230722;
    public static final int lb_focus_zoom_factor_medium = 2131230723;
    public static final int lb_focus_zoom_factor_small = 2131230724;
    public static final int lb_focus_zoom_factor_xsmall = 2131230725;
    public static final int lb_search_bar_speech_orb_max_level_zoom = 2131230726;
    public static final int lb_search_orb_focused_zoom = 2131230727;
    public static final int lb_view_active_level = 2131230728;
    public static final int lb_view_dimmed_level = 2131230729;
}
