package b.b.a.b;

import java.util.Map;

/* loaded from: classes.dex */
public class a<K, V> implements Iterable<Map.Entry<K, V>> {
    public V a(K k, V v) {
        throw null;
    }
}
