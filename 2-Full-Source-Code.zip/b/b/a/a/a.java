package b.b.a.a;

/* loaded from: classes.dex */
public class a extends c {

    /* renamed from: c, reason: collision with root package name */
    public static volatile a f477c;

    /* renamed from: a, reason: collision with root package name */
    public c f478a;

    /* renamed from: b, reason: collision with root package name */
    public c f479b;

    public a() {
        b bVar = new b();
        this.f479b = bVar;
        this.f478a = bVar;
    }

    public static a b() {
        if (f477c != null) {
            return f477c;
        }
        synchronized (a.class) {
            if (f477c == null) {
                f477c = new a();
            }
        }
        return f477c;
    }

    @Override // b.b.a.a.c
    public boolean a() {
        return this.f478a.a();
    }
}
