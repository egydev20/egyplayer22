package b.d.g.a;

import android.view.Menu;

/* loaded from: classes.dex */
public interface a extends Menu {
}
