package b.d.e.b;

/* loaded from: classes.dex */
public final class e implements b {

    /* renamed from: a, reason: collision with root package name */
    public final b.d.h.a f541a;

    /* renamed from: b, reason: collision with root package name */
    public final int f542b;

    /* renamed from: c, reason: collision with root package name */
    public final int f543c;

    public e(b.d.h.a aVar, int i, int i2) {
        this.f541a = aVar;
        this.f543c = i;
        this.f542b = i2;
    }
}
