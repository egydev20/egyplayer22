package b.d.e.b;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public final String f537a;

    /* renamed from: b, reason: collision with root package name */
    public int f538b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f539c;

    /* renamed from: d, reason: collision with root package name */
    public String f540d;
    public int e;
    public int f;

    public d(String str, int i, boolean z, String str2, int i2, int i3) {
        this.f537a = str;
        this.f538b = i;
        this.f539c = z;
        this.f540d = str2;
        this.e = i2;
        this.f = i3;
    }
}
