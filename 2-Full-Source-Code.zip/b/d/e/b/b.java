package b.d.e.b;

/* loaded from: classes.dex */
public interface b {
}
