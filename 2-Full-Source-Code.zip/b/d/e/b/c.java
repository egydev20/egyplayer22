package b.d.e.b;

/* loaded from: classes.dex */
public final class c implements b {

    /* renamed from: a, reason: collision with root package name */
    public final d[] f536a;

    public c(d[] dVarArr) {
        this.f536a = dVarArr;
    }
}
