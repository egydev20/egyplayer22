package b.d.e.b;

import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import b.a.p.m;

/* loaded from: classes.dex */
public abstract class g {

    /* loaded from: classes.dex */
    public class a implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ Typeface f546b;

        public a(Typeface typeface) {
            this.f546b = typeface;
        }

        @Override // java.lang.Runnable
        public void run() {
            g.this.a(this.f546b);
        }
    }

    /* loaded from: classes.dex */
    public class b implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ int f548b;

        public b(int i) {
            this.f548b = i;
        }

        @Override // java.lang.Runnable
        public void run() {
            if (((m.a) g.this) == null) {
                throw null;
            }
        }
    }

    public final void a(int i, Handler handler) {
        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
        }
        handler.post(new b(i));
    }

    public abstract void a(Typeface typeface);

    public final void a(Typeface typeface, Handler handler) {
        if (handler == null) {
            handler = new Handler(Looper.getMainLooper());
        }
        handler.post(new a(typeface));
    }
}
