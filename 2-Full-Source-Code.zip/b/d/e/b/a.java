package b.d.e.b;

import android.content.res.ColorStateList;
import android.graphics.Shader;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final Shader f533a;

    /* renamed from: b, reason: collision with root package name */
    public final ColorStateList f534b;

    /* renamed from: c, reason: collision with root package name */
    public int f535c;

    public a(Shader shader, ColorStateList colorStateList, int i) {
        this.f533a = shader;
        this.f534b = colorStateList;
        this.f535c = i;
    }

    /* JADX WARN: Code restructure failed: missing block: B:73:0x014f, code lost:
    
        throw new org.xmlpull.v1.XmlPullParserException(r2.getPositionDescription() + ": <item> tag requires a 'color' attribute and a 'offset' attribute!");
     */
    /* JADX WARN: Type inference failed for: r11v3, types: [java.util.List, java.util.ArrayList, float] */
    /* JADX WARN: Type inference failed for: r7v13 */
    /* JADX WARN: Type inference failed for: r7v14, types: [float, android.content.res.Resources] */
    /* JADX WARN: Type inference failed for: r7v15 */
    /* JADX WARN: Type inference failed for: r7v16 */
    /* JADX WARN: Type inference failed for: r7v21 */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static b.d.e.b.a a(android.content.res.Resources r26, int r27, android.content.res.Resources.Theme r28) {
        /*
            Method dump skipped, instructions count: 571
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.d.e.b.a.a(android.content.res.Resources, int, android.content.res.Resources$Theme):b.d.e.b.a");
    }

    public boolean a() {
        return this.f533a != null;
    }

    public boolean a(int[] iArr) {
        if (b()) {
            ColorStateList colorStateList = this.f534b;
            int colorForState = colorStateList.getColorForState(iArr, colorStateList.getDefaultColor());
            if (colorForState != this.f535c) {
                this.f535c = colorForState;
                return true;
            }
        }
        return false;
    }

    public boolean b() {
        ColorStateList colorStateList;
        return this.f533a == null && (colorStateList = this.f534b) != null && colorStateList.isStateful();
    }
}
