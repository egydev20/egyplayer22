package b.d;

/* loaded from: classes.dex */
public final class a {
    public static final int alpha = 2130903082;
    public static final int font = 2130903222;
    public static final int fontProviderAuthority = 2130903224;
    public static final int fontProviderCerts = 2130903225;
    public static final int fontProviderFetchStrategy = 2130903226;
    public static final int fontProviderFetchTimeout = 2130903227;
    public static final int fontProviderPackage = 2130903228;
    public static final int fontProviderQuery = 2130903229;
    public static final int fontStyle = 2130903230;
    public static final int fontVariationSettings = 2130903231;
    public static final int fontWeight = 2130903232;
    public static final int ttcIndex = 2130903541;
}
