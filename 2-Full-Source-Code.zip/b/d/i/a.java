package b.d.i;

import android.os.Build;
import android.text.PrecomputedText;
import android.text.Spannable;
import android.text.TextDirectionHeuristic;
import android.text.TextPaint;
import android.text.TextUtils;
import android.text.style.MetricAffectingSpan;
import java.util.Objects;

/* loaded from: classes.dex */
public class a implements Spannable {

    /* renamed from: b.d.i.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static final class C0017a {

        /* renamed from: a, reason: collision with root package name */
        public final TextPaint f604a;

        /* renamed from: b, reason: collision with root package name */
        public final TextDirectionHeuristic f605b;

        /* renamed from: c, reason: collision with root package name */
        public final int f606c;

        /* renamed from: d, reason: collision with root package name */
        public final int f607d;
        public final PrecomputedText.Params e = null;

        public C0017a(PrecomputedText.Params params) {
            this.f604a = params.getTextPaint();
            this.f605b = params.getTextDirection();
            this.f606c = params.getBreakStrategy();
            this.f607d = params.getHyphenationFrequency();
        }

        public C0017a(TextPaint textPaint, TextDirectionHeuristic textDirectionHeuristic, int i, int i2) {
            this.f604a = textPaint;
            this.f605b = textDirectionHeuristic;
            this.f606c = i;
            this.f607d = i2;
        }

        public boolean a(C0017a c0017a) {
            PrecomputedText.Params params = this.e;
            if (params != null) {
                return params.equals(c0017a.e);
            }
            if ((Build.VERSION.SDK_INT >= 23 && (this.f606c != c0017a.f606c || this.f607d != c0017a.f607d)) || this.f604a.getTextSize() != c0017a.f604a.getTextSize() || this.f604a.getTextScaleX() != c0017a.f604a.getTextScaleX() || this.f604a.getTextSkewX() != c0017a.f604a.getTextSkewX() || this.f604a.getLetterSpacing() != c0017a.f604a.getLetterSpacing() || !TextUtils.equals(this.f604a.getFontFeatureSettings(), c0017a.f604a.getFontFeatureSettings()) || this.f604a.getFlags() != c0017a.f604a.getFlags()) {
                return false;
            }
            if (Build.VERSION.SDK_INT >= 24) {
                if (!this.f604a.getTextLocales().equals(c0017a.f604a.getTextLocales())) {
                    return false;
                }
            } else if (!this.f604a.getTextLocale().equals(c0017a.f604a.getTextLocale())) {
                return false;
            }
            return this.f604a.getTypeface() == null ? c0017a.f604a.getTypeface() == null : this.f604a.getTypeface().equals(c0017a.f604a.getTypeface());
        }

        public boolean equals(Object obj) {
            if (obj == this) {
                return true;
            }
            if (!(obj instanceof C0017a)) {
                return false;
            }
            C0017a c0017a = (C0017a) obj;
            return a(c0017a) && this.f605b == c0017a.f605b;
        }

        public int hashCode() {
            if (Build.VERSION.SDK_INT >= 24) {
                return Objects.hash(Float.valueOf(this.f604a.getTextSize()), Float.valueOf(this.f604a.getTextScaleX()), Float.valueOf(this.f604a.getTextSkewX()), Float.valueOf(this.f604a.getLetterSpacing()), Integer.valueOf(this.f604a.getFlags()), this.f604a.getTextLocales(), this.f604a.getTypeface(), Boolean.valueOf(this.f604a.isElegantTextHeight()), this.f605b, Integer.valueOf(this.f606c), Integer.valueOf(this.f607d));
            }
            return Objects.hash(Float.valueOf(this.f604a.getTextSize()), Float.valueOf(this.f604a.getTextScaleX()), Float.valueOf(this.f604a.getTextSkewX()), Float.valueOf(this.f604a.getLetterSpacing()), Integer.valueOf(this.f604a.getFlags()), this.f604a.getTextLocale(), this.f604a.getTypeface(), Boolean.valueOf(this.f604a.isElegantTextHeight()), this.f605b, Integer.valueOf(this.f606c), Integer.valueOf(this.f607d));
        }

        public String toString() {
            StringBuilder a2;
            Object textLocale;
            StringBuilder sb = new StringBuilder("{");
            StringBuilder a3 = c.a.b.a.a.a("textSize=");
            a3.append(this.f604a.getTextSize());
            sb.append(a3.toString());
            sb.append(", textScaleX=" + this.f604a.getTextScaleX());
            sb.append(", textSkewX=" + this.f604a.getTextSkewX());
            sb.append(", letterSpacing=" + this.f604a.getLetterSpacing());
            sb.append(", elegantTextHeight=" + this.f604a.isElegantTextHeight());
            if (Build.VERSION.SDK_INT >= 24) {
                a2 = c.a.b.a.a.a(", textLocale=");
                textLocale = this.f604a.getTextLocales();
            } else {
                a2 = c.a.b.a.a.a(", textLocale=");
                textLocale = this.f604a.getTextLocale();
            }
            a2.append(textLocale);
            sb.append(a2.toString());
            StringBuilder a4 = c.a.b.a.a.a(", typeface=");
            a4.append(this.f604a.getTypeface());
            sb.append(a4.toString());
            if (Build.VERSION.SDK_INT >= 26) {
                StringBuilder a5 = c.a.b.a.a.a(", variationSettings=");
                a5.append(this.f604a.getFontVariationSettings());
                sb.append(a5.toString());
            }
            StringBuilder a6 = c.a.b.a.a.a(", textDir=");
            a6.append(this.f605b);
            sb.append(a6.toString());
            sb.append(", breakStrategy=" + this.f606c);
            sb.append(", hyphenationFrequency=" + this.f607d);
            sb.append("}");
            return sb.toString();
        }
    }

    @Override // java.lang.CharSequence
    public char charAt(int i) {
        throw null;
    }

    @Override // android.text.Spanned
    public int getSpanEnd(Object obj) {
        throw null;
    }

    @Override // android.text.Spanned
    public int getSpanFlags(Object obj) {
        throw null;
    }

    @Override // android.text.Spanned
    public int getSpanStart(Object obj) {
        throw null;
    }

    @Override // android.text.Spanned
    public <T> T[] getSpans(int i, int i2, Class<T> cls) {
        throw null;
    }

    @Override // java.lang.CharSequence
    public int length() {
        throw null;
    }

    @Override // android.text.Spanned
    public int nextSpanTransition(int i, int i2, Class cls) {
        throw null;
    }

    @Override // android.text.Spannable
    public void removeSpan(Object obj) {
        if (!(obj instanceof MetricAffectingSpan)) {
            throw null;
        }
        throw new IllegalArgumentException("MetricAffectingSpan can not be removed from PrecomputedText.");
    }

    @Override // android.text.Spannable
    public void setSpan(Object obj, int i, int i2, int i3) {
        if (!(obj instanceof MetricAffectingSpan)) {
            throw null;
        }
        throw new IllegalArgumentException("MetricAffectingSpan can not be set to PrecomputedText.");
    }

    @Override // java.lang.CharSequence
    public CharSequence subSequence(int i, int i2) {
        throw null;
    }

    @Override // java.lang.CharSequence
    public String toString() {
        throw null;
    }
}
