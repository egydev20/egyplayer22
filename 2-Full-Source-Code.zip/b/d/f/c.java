package b.d.f;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.Handler;
import android.util.Log;

/* loaded from: classes.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    public static final h f552a;

    /* renamed from: b, reason: collision with root package name */
    public static final b.c.h<String, Typeface> f553b;

    static {
        h dVar;
        int i = Build.VERSION.SDK_INT;
        if (i >= 28) {
            dVar = new g();
        } else if (i >= 26) {
            dVar = new f();
        } else {
            if (i >= 24) {
                if (e.f559d == null) {
                    Log.w("TypefaceCompatApi24Impl", "Unable to collect necessary private methods.Fallback to legacy implementation.");
                }
                if (e.f559d != null) {
                    dVar = new e();
                }
            }
            dVar = new d();
        }
        f552a = dVar;
        f553b = new b.c.h<>(16);
    }

    public static Typeface a(Context context, Resources resources, int i, String str, int i2) {
        Typeface a2 = f552a.a(context, resources, i, str, i2);
        if (a2 != null) {
            f553b.a(a(resources, i, i2), a2);
        }
        return a2;
    }

    public static Typeface a(Context context, Typeface typeface, int i) {
        if (context != null) {
            return Typeface.create(typeface, i);
        }
        throw new IllegalArgumentException("Context cannot be null");
    }

    public static Typeface a(Context context, b.d.e.b.b bVar, Resources resources, int i, int i2, b.d.e.b.g gVar, Handler handler, boolean z) {
        Typeface a2;
        if (bVar instanceof b.d.e.b.e) {
            b.d.e.b.e eVar = (b.d.e.b.e) bVar;
            boolean z2 = false;
            if (!z ? gVar == null : eVar.f543c == 0) {
                z2 = true;
            }
            a2 = b.d.h.b.a(context, eVar.f541a, gVar, handler, z2, z ? eVar.f542b : -1, i2);
        } else {
            a2 = f552a.a(context, (b.d.e.b.c) bVar, resources, i2);
            if (gVar != null) {
                if (a2 != null) {
                    gVar.a(a2, handler);
                } else {
                    gVar.a(-3, handler);
                }
            }
        }
        if (a2 != null) {
            f553b.a(a(resources, i, i2), a2);
        }
        return a2;
    }

    public static String a(Resources resources, int i, int i2) {
        return resources.getResourcePackageName(i) + "-" + i + "-" + i2;
    }
}
