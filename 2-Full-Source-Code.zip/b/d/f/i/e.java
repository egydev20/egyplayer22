package b.d.f.i;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
public final class e extends Drawable.ConstantState {

    /* renamed from: a, reason: collision with root package name */
    public int f564a;

    /* renamed from: b, reason: collision with root package name */
    public Drawable.ConstantState f565b;

    /* renamed from: c, reason: collision with root package name */
    public ColorStateList f566c;

    /* renamed from: d, reason: collision with root package name */
    public PorterDuff.Mode f567d;

    public e(e eVar) {
        this.f566c = null;
        this.f567d = c.h;
        if (eVar != null) {
            this.f564a = eVar.f564a;
            this.f565b = eVar.f565b;
            this.f566c = eVar.f566c;
            this.f567d = eVar.f567d;
        }
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public int getChangingConfigurations() {
        int i = this.f564a;
        Drawable.ConstantState constantState = this.f565b;
        return i | (constantState != null ? constantState.getChangingConfigurations() : 0);
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public Drawable newDrawable() {
        return new d(this, null);
    }

    @Override // android.graphics.drawable.Drawable.ConstantState
    public Drawable newDrawable(Resources resources) {
        return new d(this, resources);
    }
}
