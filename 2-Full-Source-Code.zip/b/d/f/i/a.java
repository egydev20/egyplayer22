package b.d.f.i;

/* loaded from: classes.dex */
public interface a {
}
