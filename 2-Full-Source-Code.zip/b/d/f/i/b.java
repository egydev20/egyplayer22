package b.d.f.i;

import android.graphics.drawable.Drawable;

/* loaded from: classes.dex */
public interface b {
    Drawable a();
}
