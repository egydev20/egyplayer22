package b.d.f;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import b.d.h.b;
import java.io.File;
import java.io.InputStream;
import java.util.concurrent.ConcurrentHashMap;
import org.videolan.libvlc.media.MediaPlayer;

/* loaded from: classes.dex */
public class h {

    /* renamed from: a, reason: collision with root package name */
    public ConcurrentHashMap<Long, b.d.e.b.c> f560a = new ConcurrentHashMap<>();

    public Typeface a(Context context, Resources resources, int i, String str, int i2) {
        File b2 = a.a.a.a.a.b(context);
        if (b2 == null) {
            return null;
        }
        try {
            if (a.a.a.a.a.a(b2, resources, i)) {
                return Typeface.createFromFile(b2.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            b2.delete();
        }
    }

    public Typeface a(Context context, CancellationSignal cancellationSignal, b.f[] fVarArr, int i) {
        throw null;
    }

    public Typeface a(Context context, b.d.e.b.c cVar, Resources resources, int i) {
        throw null;
    }

    public Typeface a(Context context, InputStream inputStream) {
        File b2 = a.a.a.a.a.b(context);
        if (b2 == null) {
            return null;
        }
        try {
            if (a.a.a.a.a.a(b2, inputStream)) {
                return Typeface.createFromFile(b2.getPath());
            }
            return null;
        } catch (RuntimeException unused) {
            return null;
        } finally {
            b2.delete();
        }
    }

    public b.f a(b.f[] fVarArr, int i) {
        int i2 = (i & 1) == 0 ? 400 : MediaPlayer.MEDIA_INFO_VIDEO_TRACK_LAGGING;
        boolean z = (i & 2) != 0;
        b.f fVar = null;
        int i3 = Integer.MAX_VALUE;
        for (b.f fVar2 : fVarArr) {
            int abs = (Math.abs(fVar2.f587c - i2) * 2) + (fVar2.f588d == z ? 0 : 1);
            if (fVar == null || i3 > abs) {
                fVar = fVar2;
                i3 = abs;
            }
        }
        return fVar;
    }
}
