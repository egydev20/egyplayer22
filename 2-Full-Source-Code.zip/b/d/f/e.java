package b.d.f;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.util.Log;
import b.c.j;
import b.d.h.b;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.List;

/* loaded from: classes.dex */
public class e extends h {

    /* renamed from: b, reason: collision with root package name */
    public static final Class f557b;

    /* renamed from: c, reason: collision with root package name */
    public static final Constructor f558c;

    /* renamed from: d, reason: collision with root package name */
    public static final Method f559d;
    public static final Method e;

    static {
        Class<?> cls;
        Method method;
        Method method2;
        Constructor<?> constructor = null;
        try {
            cls = Class.forName("android.graphics.FontFamily");
            Constructor<?> constructor2 = cls.getConstructor(new Class[0]);
            method2 = cls.getMethod("addFontWeightStyle", ByteBuffer.class, Integer.TYPE, List.class, Integer.TYPE, Boolean.TYPE);
            method = Typeface.class.getMethod("createFromFamiliesWithDefault", Array.newInstance(cls, 1).getClass());
            constructor = constructor2;
        } catch (ClassNotFoundException | NoSuchMethodException e2) {
            Log.e("TypefaceCompatApi24Impl", e2.getClass().getName(), e2);
            cls = null;
            method = null;
            method2 = null;
        }
        f558c = constructor;
        f557b = cls;
        f559d = method2;
        e = method;
    }

    public static Typeface a(Object obj) {
        try {
            Object newInstance = Array.newInstance((Class<?>) f557b, 1);
            Array.set(newInstance, 0, obj);
            return (Typeface) e.invoke(null, newInstance);
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return null;
        }
    }

    public static boolean a(Object obj, ByteBuffer byteBuffer, int i, int i2, boolean z) {
        try {
            return ((Boolean) f559d.invoke(obj, byteBuffer, Integer.valueOf(i), null, Integer.valueOf(i2), Boolean.valueOf(z))).booleanValue();
        } catch (IllegalAccessException | InvocationTargetException unused) {
            return false;
        }
    }

    @Override // b.d.f.h
    public Typeface a(Context context, b.d.e.b.c cVar, Resources resources, int i) {
        Object obj;
        MappedByteBuffer mappedByteBuffer;
        FileInputStream fileInputStream;
        try {
            obj = f558c.newInstance(new Object[0]);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            obj = null;
        }
        if (obj == null) {
            return null;
        }
        for (b.d.e.b.d dVar : cVar.f536a) {
            int i2 = dVar.f;
            File b2 = a.a.a.a.a.b(context);
            if (b2 != null) {
                try {
                    if (a.a.a.a.a.a(b2, resources, i2)) {
                        try {
                            fileInputStream = new FileInputStream(b2);
                        } catch (IOException unused2) {
                            mappedByteBuffer = null;
                        }
                        try {
                            FileChannel channel = fileInputStream.getChannel();
                            mappedByteBuffer = channel.map(FileChannel.MapMode.READ_ONLY, 0L, channel.size());
                            fileInputStream.close();
                            if (mappedByteBuffer != null || !a(obj, mappedByteBuffer, dVar.e, dVar.f538b, dVar.f539c)) {
                                return null;
                            }
                        } catch (Throwable th) {
                            try {
                                throw th;
                                break;
                            } finally {
                                break;
                            }
                        }
                    }
                } finally {
                    b2.delete();
                }
            }
            mappedByteBuffer = null;
            if (mappedByteBuffer != null) {
                return null;
            }
        }
        return a(obj);
    }

    @Override // b.d.f.h
    public Typeface a(Context context, CancellationSignal cancellationSignal, b.f[] fVarArr, int i) {
        Object obj;
        try {
            obj = f558c.newInstance(new Object[0]);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException unused) {
            obj = null;
        }
        if (obj == null) {
            return null;
        }
        j jVar = new j();
        for (b.f fVar : fVarArr) {
            Uri uri = fVar.f585a;
            ByteBuffer byteBuffer = (ByteBuffer) jVar.get(uri);
            if (byteBuffer == null) {
                byteBuffer = a.a.a.a.a.a(context, cancellationSignal, uri);
                jVar.put(uri, byteBuffer);
            }
            if (byteBuffer == null || !a(obj, byteBuffer, fVar.f586b, fVar.f587c, fVar.f588d)) {
                return null;
            }
        }
        Typeface a2 = a(obj);
        if (a2 == null) {
            return null;
        }
        return Typeface.create(a2, i);
    }
}
