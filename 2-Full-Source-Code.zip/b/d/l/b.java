package b.d.l;

import android.os.Build;

/* loaded from: classes.dex */
public interface b {

    /* renamed from: a, reason: collision with root package name */
    public static final boolean f657a;

    static {
        f657a = Build.VERSION.SDK_INT >= 27;
    }
}
