package b.d.d;

import android.os.Bundle;

/* loaded from: classes.dex */
public class d {

    /* renamed from: a, reason: collision with root package name */
    public static final Object f531a = new Object();

    public static Bundle a(b bVar) {
        Bundle bundle = new Bundle();
        if (bVar == null) {
            throw null;
        }
        bundle.putInt("icon", 0);
        bundle.putCharSequence("title", null);
        bundle.putParcelable("actionIntent", null);
        Bundle bundle2 = new Bundle();
        bundle2.putBoolean("android.support.allowGeneratedReplies", false);
        bundle.putBundle("extras", bundle2);
        bundle.putParcelableArray("remoteInputs", a((e[]) null));
        bundle.putBoolean("showsUserInterface", false);
        bundle.putInt("semanticAction", 0);
        return bundle;
    }

    public static Bundle[] a(e[] eVarArr) {
        if (eVarArr == null) {
            return null;
        }
        Bundle[] bundleArr = new Bundle[eVarArr.length];
        if (eVarArr.length <= 0) {
            return bundleArr;
        }
        e eVar = eVarArr[0];
        new Bundle();
        throw null;
    }
}
