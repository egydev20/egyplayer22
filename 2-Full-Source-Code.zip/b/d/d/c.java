package b.d.d;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Bundle;
import android.widget.RemoteViews;
import java.util.ArrayList;

/* loaded from: classes.dex */
public class c {
    public Bundle A;
    public Notification D;
    public RemoteViews E;
    public RemoteViews F;
    public RemoteViews G;
    public String H;
    public String J;
    public long K;
    public Notification M;

    @Deprecated
    public ArrayList<String> N;

    /* renamed from: a, reason: collision with root package name */
    public Context f527a;

    /* renamed from: d, reason: collision with root package name */
    public CharSequence f530d;
    public CharSequence e;
    public PendingIntent f;
    public PendingIntent g;
    public RemoteViews h;
    public Bitmap i;
    public CharSequence j;
    public int k;
    public int l;
    public boolean n;
    public CharSequence o;
    public CharSequence[] p;
    public int q;
    public int r;
    public boolean s;
    public String t;
    public boolean u;
    public String v;
    public boolean x;
    public boolean y;
    public String z;

    /* renamed from: b, reason: collision with root package name */
    public ArrayList<b> f528b = new ArrayList<>();

    /* renamed from: c, reason: collision with root package name */
    public ArrayList<b> f529c = new ArrayList<>();
    public boolean m = true;
    public boolean w = false;
    public int B = 0;
    public int C = 0;
    public int I = 0;
    public int L = 0;

    public c(Context context, String str) {
        Notification notification = new Notification();
        this.M = notification;
        this.f527a = context;
        this.H = str;
        notification.when = System.currentTimeMillis();
        this.M.audioStreamType = -1;
        this.l = 0;
        this.N = new ArrayList<>();
    }

    /* JADX WARN: Code restructure failed: missing block: B:100:0x0279, code lost:
    
        if (r12 == 1) goto L118;
     */
    /* JADX WARN: Code restructure failed: missing block: B:101:0x02bd, code lost:
    
        r1.sound = null;
        r1.vibrate = null;
        r2 = r1.defaults & (-2);
        r1.defaults = r2;
        r1.defaults = r2 & (-3);
     */
    /* JADX WARN: Code restructure failed: missing block: B:122:0x02bb, code lost:
    
        if (r12 == 1) goto L118;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public android.app.Notification a() {
        /*
            Method dump skipped, instructions count: 722
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.d.d.c.a():android.app.Notification");
    }

    public c a(Uri uri) {
        Notification notification = this.M;
        notification.sound = uri;
        notification.audioStreamType = -1;
        notification.audioAttributes = new AudioAttributes.Builder().setContentType(4).setUsage(5).build();
        return this;
    }

    public c b(CharSequence charSequence) {
        if (charSequence != null && charSequence.length() > 5120) {
            charSequence = charSequence.subSequence(0, 5120);
        }
        this.f530d = charSequence;
        return this;
    }

    public c a(boolean z) {
        Notification notification;
        int i;
        if (z) {
            notification = this.M;
            i = notification.flags | 16;
        } else {
            notification = this.M;
            i = notification.flags & (-17);
        }
        notification.flags = i;
        return this;
    }

    public c a(CharSequence charSequence) {
        if (charSequence != null && charSequence.length() > 5120) {
            charSequence = charSequence.subSequence(0, 5120);
        }
        this.e = charSequence;
        return this;
    }
}
