package b.d.d;

import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

/* loaded from: classes.dex */
public class a extends b.d.e.a {

    /* renamed from: b.d.d.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class RunnableC0014a implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ String[] f524b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ Activity f525c;

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ int f526d;

        public RunnableC0014a(String[] strArr, Activity activity, int i) {
            this.f524b = strArr;
            this.f525c = activity;
            this.f526d = i;
        }

        @Override // java.lang.Runnable
        public void run() {
            int[] iArr = new int[this.f524b.length];
            PackageManager packageManager = this.f525c.getPackageManager();
            String packageName = this.f525c.getPackageName();
            int length = this.f524b.length;
            for (int i = 0; i < length; i++) {
                iArr[i] = packageManager.checkPermission(this.f524b[i], packageName);
            }
            ((b) this.f525c).a(this.f526d, this.f524b, iArr);
        }
    }

    /* loaded from: classes.dex */
    public interface b {
        void a(int i, String[] strArr, int[] iArr);
    }

    /* loaded from: classes.dex */
    public interface c {
        void a(int i);
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static void a(Activity activity, String[] strArr, int i) {
        if (Build.VERSION.SDK_INT >= 23) {
            if (activity instanceof c) {
                ((c) activity).a(i);
            }
            activity.requestPermissions(strArr, i);
        } else if (activity instanceof b) {
            new Handler(Looper.getMainLooper()).post(new RunnableC0014a(strArr, activity, i));
        }
    }
}
