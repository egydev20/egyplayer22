package b.d.j;

/* loaded from: classes.dex */
public class a<T> {

    /* renamed from: a, reason: collision with root package name */
    public final Object[] f608a;

    /* renamed from: b, reason: collision with root package name */
    public int f609b;

    public a(int i) {
        if (i <= 0) {
            throw new IllegalArgumentException("The max pool size must be > 0");
        }
        this.f608a = new Object[i];
    }

    public T a() {
        int i = this.f609b;
        if (i <= 0) {
            return null;
        }
        int i2 = i - 1;
        Object[] objArr = this.f608a;
        T t = (T) objArr[i2];
        objArr[i2] = null;
        this.f609b = i - 1;
        return t;
    }

    public boolean a(T t) {
        boolean z;
        int i = 0;
        while (true) {
            if (i >= this.f609b) {
                z = false;
                break;
            }
            if (this.f608a[i] == t) {
                z = true;
                break;
            }
            i++;
        }
        if (z) {
            throw new IllegalStateException("Already in the pool!");
        }
        int i2 = this.f609b;
        Object[] objArr = this.f608a;
        if (i2 >= objArr.length) {
            return false;
        }
        objArr[i2] = t;
        this.f609b = i2 + 1;
        return true;
    }
}
