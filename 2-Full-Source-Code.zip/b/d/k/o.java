package b.d.k;

import android.view.View;

/* loaded from: classes.dex */
public interface o {
    void a(View view);

    void b(View view);

    void c(View view);
}
