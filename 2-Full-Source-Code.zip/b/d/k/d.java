package b.d.k;

/* loaded from: classes.dex */
public interface d extends c {
}
