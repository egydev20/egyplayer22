package b.d.k;

import android.util.Log;
import android.view.View;
import android.view.ViewParent;

/* loaded from: classes.dex */
public class e {

    /* renamed from: a, reason: collision with root package name */
    public ViewParent f615a;

    /* renamed from: b, reason: collision with root package name */
    public ViewParent f616b;

    /* renamed from: c, reason: collision with root package name */
    public final View f617c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f618d;
    public int[] e;

    public e(View view) {
        this.f617c = view;
    }

    public final ViewParent a(int i) {
        if (i == 0) {
            return this.f615a;
        }
        if (i != 1) {
            return null;
        }
        return this.f616b;
    }

    public boolean a(float f, float f2, boolean z) {
        ViewParent a2;
        if (!this.f618d || (a2 = a(0)) == null) {
            return false;
        }
        try {
            return a2.onNestedFling(this.f617c, f, f2, z);
        } catch (AbstractMethodError e) {
            Log.e("ViewParentCompat", "ViewParent " + a2 + " does not implement interface method onNestedFling", e);
            return false;
        }
    }

    public boolean a(int i, int i2, int i3, int i4, int[] iArr) {
        return a(i, i2, i3, i4, iArr, 0, null);
    }

    public boolean b(int i) {
        return a(i) != null;
    }

    public void c(int i) {
        ViewParent a2 = a(i);
        if (a2 != null) {
            View view = this.f617c;
            if (a2 instanceof f) {
                ((f) a2).a(view, i);
            } else if (i == 0) {
                try {
                    a2.onStopNestedScroll(view);
                } catch (AbstractMethodError e) {
                    Log.e("ViewParentCompat", "ViewParent " + a2 + " does not implement interface method onStopNestedScroll", e);
                }
            }
            if (i == 0) {
                this.f615a = null;
            } else {
                if (i != 1) {
                    return;
                }
                this.f616b = null;
            }
        }
    }

    public boolean a(float f, float f2) {
        ViewParent a2;
        if (!this.f618d || (a2 = a(0)) == null) {
            return false;
        }
        try {
            return a2.onNestedPreFling(this.f617c, f, f2);
        } catch (AbstractMethodError e) {
            Log.e("ViewParentCompat", "ViewParent " + a2 + " does not implement interface method onNestedPreFling", e);
            return false;
        }
    }

    public boolean a(int i, int i2, int[] iArr, int[] iArr2, int i3) {
        ViewParent a2;
        int i4;
        int i5;
        int[] iArr3;
        if (!this.f618d || (a2 = a(i3)) == null) {
            return false;
        }
        if (i == 0 && i2 == 0) {
            if (iArr2 == null) {
                return false;
            }
            iArr2[0] = 0;
            iArr2[1] = 0;
            return false;
        }
        if (iArr2 != null) {
            this.f617c.getLocationInWindow(iArr2);
            i4 = iArr2[0];
            i5 = iArr2[1];
        } else {
            i4 = 0;
            i5 = 0;
        }
        if (iArr == null) {
            if (this.e == null) {
                this.e = new int[2];
            }
            iArr3 = this.e;
        } else {
            iArr3 = iArr;
        }
        iArr3[0] = 0;
        iArr3[1] = 0;
        View view = this.f617c;
        if (a2 instanceof f) {
            ((f) a2).a(view, i, i2, iArr3, i3);
        } else if (i3 == 0) {
            try {
                a2.onNestedPreScroll(view, i, i2, iArr3);
            } catch (AbstractMethodError e) {
                Log.e("ViewParentCompat", "ViewParent " + a2 + " does not implement interface method onNestedPreScroll", e);
            }
        }
        if (iArr2 != null) {
            this.f617c.getLocationInWindow(iArr2);
            iArr2[0] = iArr2[0] - i4;
            iArr2[1] = iArr2[1] - i5;
        }
        return (iArr3[0] == 0 && iArr3[1] == 0) ? false : true;
    }

    public final boolean a(int i, int i2, int i3, int i4, int[] iArr, int i5, int[] iArr2) {
        ViewParent a2;
        int i6;
        int i7;
        int[] iArr3;
        if (!this.f618d || (a2 = a(i5)) == null) {
            return false;
        }
        if (i == 0 && i2 == 0 && i3 == 0 && i4 == 0) {
            if (iArr != null) {
                iArr[0] = 0;
                iArr[1] = 0;
            }
            return false;
        }
        if (iArr != null) {
            this.f617c.getLocationInWindow(iArr);
            i6 = iArr[0];
            i7 = iArr[1];
        } else {
            i6 = 0;
            i7 = 0;
        }
        if (iArr2 == null) {
            if (this.e == null) {
                this.e = new int[2];
            }
            int[] iArr4 = this.e;
            iArr4[0] = 0;
            iArr4[1] = 0;
            iArr3 = iArr4;
        } else {
            iArr3 = iArr2;
        }
        View view = this.f617c;
        if (a2 instanceof g) {
            ((g) a2).a(view, i, i2, i3, i4, i5, iArr3);
        } else {
            iArr3[0] = iArr3[0] + i3;
            iArr3[1] = iArr3[1] + i4;
            if (a2 instanceof f) {
                ((f) a2).a(view, i, i2, i3, i4, i5);
            } else if (i5 == 0) {
                try {
                    a2.onNestedScroll(view, i, i2, i3, i4);
                } catch (AbstractMethodError e) {
                    Log.e("ViewParentCompat", "ViewParent " + a2 + " does not implement interface method onNestedScroll", e);
                }
            }
        }
        if (iArr != null) {
            this.f617c.getLocationInWindow(iArr);
            iArr[0] = iArr[0] - i6;
            iArr[1] = iArr[1] - i7;
        }
        return true;
    }

    public boolean a(int i, int i2) {
        boolean onStartNestedScroll;
        if (a(i2) != null) {
            return true;
        }
        if (this.f618d) {
            View view = this.f617c;
            for (ViewParent parent = this.f617c.getParent(); parent != null; parent = parent.getParent()) {
                View view2 = this.f617c;
                boolean z = parent instanceof f;
                if (z) {
                    onStartNestedScroll = ((f) parent).b(view, view2, i, i2);
                } else {
                    if (i2 == 0) {
                        try {
                            onStartNestedScroll = parent.onStartNestedScroll(view, view2, i);
                        } catch (AbstractMethodError e) {
                            Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onStartNestedScroll", e);
                        }
                    }
                    onStartNestedScroll = false;
                }
                if (onStartNestedScroll) {
                    if (i2 == 0) {
                        this.f615a = parent;
                    } else if (i2 == 1) {
                        this.f616b = parent;
                    }
                    View view3 = this.f617c;
                    if (z) {
                        ((f) parent).a(view, view3, i, i2);
                    } else if (i2 == 0) {
                        try {
                            parent.onNestedScrollAccepted(view, view3, i);
                        } catch (AbstractMethodError e2) {
                            Log.e("ViewParentCompat", "ViewParent " + parent + " does not implement interface method onNestedScrollAccepted", e2);
                        }
                    }
                    return true;
                }
                if (parent instanceof View) {
                    view = parent;
                }
            }
        }
        return false;
    }
}
