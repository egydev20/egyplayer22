package b.d.k;

import android.os.Build;
import android.os.Bundle;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import b.d.k.r.b;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/* loaded from: classes.dex */
public class a {

    /* renamed from: c, reason: collision with root package name */
    public static final View.AccessibilityDelegate f610c = new View.AccessibilityDelegate();

    /* renamed from: a, reason: collision with root package name */
    public final View.AccessibilityDelegate f611a = f610c;

    /* renamed from: b, reason: collision with root package name */
    public final View.AccessibilityDelegate f612b = new C0018a(this);

    /* renamed from: b.d.k.a$a, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static final class C0018a extends View.AccessibilityDelegate {

        /* renamed from: a, reason: collision with root package name */
        public final a f613a;

        public C0018a(a aVar) {
            this.f613a = aVar;
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean dispatchPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            return this.f613a.f611a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public AccessibilityNodeProvider getAccessibilityNodeProvider(View view) {
            AccessibilityNodeProvider accessibilityNodeProvider = this.f613a.f611a.getAccessibilityNodeProvider(view);
            b.d.k.r.c cVar = accessibilityNodeProvider != null ? new b.d.k.r.c(accessibilityNodeProvider) : null;
            if (cVar != null) {
                return (AccessibilityNodeProvider) cVar.f648a;
            }
            return null;
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f613a.a(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfo accessibilityNodeInfo) {
            int i;
            b.d.k.r.b bVar = new b.d.k.r.b(accessibilityNodeInfo);
            boolean m = l.m(view);
            if (Build.VERSION.SDK_INT >= 28) {
                bVar.f640a.setScreenReaderFocusable(m);
            } else {
                bVar.a(1, m);
            }
            Boolean b2 = new k(b.d.b.tag_accessibility_heading, Boolean.class, 28).b(view);
            boolean booleanValue = b2 == null ? false : b2.booleanValue();
            if (Build.VERSION.SDK_INT >= 28) {
                bVar.f640a.setHeading(booleanValue);
            } else {
                bVar.a(2, booleanValue);
            }
            CharSequence b3 = new j(b.d.b.tag_accessibility_pane_title, CharSequence.class, 8, 28).b(view);
            if (Build.VERSION.SDK_INT >= 28) {
                bVar.f640a.setPaneTitle(b3);
            } else {
                bVar.f640a.getExtras().putCharSequence("androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY", b3);
            }
            this.f613a.a(view, bVar);
            CharSequence text = accessibilityNodeInfo.getText();
            if (Build.VERSION.SDK_INT < 26) {
                bVar.f640a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY");
                bVar.f640a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
                bVar.f640a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
                bVar.f640a.getExtras().remove("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
                SparseArray sparseArray = (SparseArray) view.getTag(b.d.b.tag_accessibility_clickable_spans);
                if (sparseArray != null) {
                    ArrayList arrayList = new ArrayList();
                    for (int i2 = 0; i2 < sparseArray.size(); i2++) {
                        if (((WeakReference) sparseArray.valueAt(i2)).get() == null) {
                            arrayList.add(Integer.valueOf(i2));
                        }
                    }
                    for (int i3 = 0; i3 < arrayList.size(); i3++) {
                        sparseArray.remove(((Integer) arrayList.get(i3)).intValue());
                    }
                }
                ClickableSpan[] a2 = b.d.k.r.b.a(text);
                if (a2 != null && a2.length > 0) {
                    bVar.a().putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY", b.d.b.accessibility_action_clickable_span);
                    SparseArray sparseArray2 = (SparseArray) view.getTag(b.d.b.tag_accessibility_clickable_spans);
                    if (sparseArray2 == null) {
                        sparseArray2 = new SparseArray();
                        view.setTag(b.d.b.tag_accessibility_clickable_spans, sparseArray2);
                    }
                    for (int i4 = 0; i4 < a2.length; i4++) {
                        ClickableSpan clickableSpan = a2[i4];
                        int i5 = 0;
                        while (true) {
                            if (i5 >= sparseArray2.size()) {
                                i = b.d.k.r.b.f639d;
                                b.d.k.r.b.f639d = i + 1;
                                break;
                            } else {
                                if (clickableSpan.equals((ClickableSpan) ((WeakReference) sparseArray2.valueAt(i5)).get())) {
                                    i = sparseArray2.keyAt(i5);
                                    break;
                                }
                                i5++;
                            }
                        }
                        sparseArray2.put(i, new WeakReference(a2[i4]));
                        ClickableSpan clickableSpan2 = a2[i4];
                        Spanned spanned = (Spanned) text;
                        bVar.a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY").add(Integer.valueOf(spanned.getSpanStart(clickableSpan2)));
                        bVar.a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY").add(Integer.valueOf(spanned.getSpanEnd(clickableSpan2)));
                        bVar.a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY").add(Integer.valueOf(spanned.getSpanFlags(clickableSpan2)));
                        bVar.a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY").add(Integer.valueOf(i));
                    }
                }
            }
            List list = (List) view.getTag(b.d.b.tag_accessibility_actions);
            if (list == null) {
                list = Collections.emptyList();
            }
            for (int i6 = 0; i6 < list.size(); i6++) {
                bVar.a((b.a) list.get(i6));
            }
        }

        @Override // android.view.View.AccessibilityDelegate
        public void onPopulateAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            this.f613a.f611a.onPopulateAccessibilityEvent(view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean onRequestSendAccessibilityEvent(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
            return this.f613a.f611a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
        }

        @Override // android.view.View.AccessibilityDelegate
        public boolean performAccessibilityAction(View view, int i, Bundle bundle) {
            return this.f613a.a(view, i, bundle);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void sendAccessibilityEvent(View view, int i) {
            this.f613a.f611a.sendAccessibilityEvent(view, i);
        }

        @Override // android.view.View.AccessibilityDelegate
        public void sendAccessibilityEventUnchecked(View view, AccessibilityEvent accessibilityEvent) {
            this.f613a.f611a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
        }
    }

    public void a(View view, AccessibilityEvent accessibilityEvent) {
        this.f611a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void a(View view, b.d.k.r.b bVar) {
        this.f611a.onInitializeAccessibilityNodeInfo(view, bVar.f640a);
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x0072  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public boolean a(android.view.View r9, int r10, android.os.Bundle r11) {
        /*
            r8 = this;
            int r0 = b.d.b.tag_accessibility_actions
            java.lang.Object r0 = r9.getTag(r0)
            java.util.List r0 = (java.util.List) r0
            if (r0 != 0) goto Le
            java.util.List r0 = java.util.Collections.emptyList()
        Le:
            r1 = 0
            r2 = 0
        L10:
            int r3 = r0.size()
            if (r2 >= r3) goto L6f
            java.lang.Object r3 = r0.get(r2)
            b.d.k.r.b$a r3 = (b.d.k.r.b.a) r3
            int r4 = r3.a()
            if (r4 != r10) goto L6c
            b.d.k.r.d r0 = r3.f646c
            if (r0 == 0) goto L6f
            java.lang.Class<? extends b.d.k.r.d$a> r0 = r3.f645b
            r2 = 0
            if (r0 == 0) goto L65
            java.lang.Class[] r4 = new java.lang.Class[r1]     // Catch: java.lang.Exception -> L3f
            java.lang.reflect.Constructor r0 = r0.getDeclaredConstructor(r4)     // Catch: java.lang.Exception -> L3f
            java.lang.Object[] r4 = new java.lang.Object[r1]     // Catch: java.lang.Exception -> L3f
            java.lang.Object r0 = r0.newInstance(r4)     // Catch: java.lang.Exception -> L3f
            b.d.k.r.d$a r0 = (b.d.k.r.d.a) r0     // Catch: java.lang.Exception -> L3f
            if (r0 == 0) goto L3c
            goto L64
        L3c:
            throw r2     // Catch: java.lang.Exception -> L3d
        L3d:
            r2 = move-exception
            goto L43
        L3f:
            r0 = move-exception
            r7 = r2
            r2 = r0
            r0 = r7
        L43:
            java.lang.Class<? extends b.d.k.r.d$a> r4 = r3.f645b
            if (r4 != 0) goto L4a
            java.lang.String r4 = "null"
            goto L4e
        L4a:
            java.lang.String r4 = r4.getName()
        L4e:
            java.lang.StringBuilder r5 = new java.lang.StringBuilder
            r5.<init>()
            java.lang.String r6 = "Failed to execute command with argument class ViewCommandArgument: "
            r5.append(r6)
            r5.append(r4)
            java.lang.String r4 = r5.toString()
            java.lang.String r5 = "A11yActionCompat"
            android.util.Log.e(r5, r4, r2)
        L64:
            r2 = r0
        L65:
            b.d.k.r.d r0 = r3.f646c
            boolean r0 = r0.a(r9, r2)
            goto L70
        L6c:
            int r2 = r2 + 1
            goto L10
        L6f:
            r0 = 0
        L70:
            if (r0 != 0) goto L78
            android.view.View$AccessibilityDelegate r0 = r8.f611a
            boolean r0 = r0.performAccessibilityAction(r9, r10, r11)
        L78:
            if (r0 != 0) goto Lc7
            int r2 = b.d.b.accessibility_action_clickable_span
            if (r10 != r2) goto Lc7
            r10 = -1
            java.lang.String r0 = "ACCESSIBILITY_CLICKABLE_SPAN_ID"
            int r10 = r11.getInt(r0, r10)
            int r11 = b.d.b.tag_accessibility_clickable_spans
            java.lang.Object r11 = r9.getTag(r11)
            android.util.SparseArray r11 = (android.util.SparseArray) r11
            r0 = 1
            if (r11 == 0) goto Lc6
            java.lang.Object r10 = r11.get(r10)
            java.lang.ref.WeakReference r10 = (java.lang.ref.WeakReference) r10
            if (r10 == 0) goto Lc6
            java.lang.Object r10 = r10.get()
            android.text.style.ClickableSpan r10 = (android.text.style.ClickableSpan) r10
            if (r10 == 0) goto Lbf
            android.view.accessibility.AccessibilityNodeInfo r11 = r9.createAccessibilityNodeInfo()
            java.lang.CharSequence r11 = r11.getText()
            android.text.style.ClickableSpan[] r11 = b.d.k.r.b.a(r11)
            r2 = 0
        Lad:
            if (r11 == 0) goto Lbf
            int r3 = r11.length
            if (r2 >= r3) goto Lbf
            r3 = r11[r2]
            boolean r3 = r10.equals(r3)
            if (r3 == 0) goto Lbc
            r11 = 1
            goto Lc0
        Lbc:
            int r2 = r2 + 1
            goto Lad
        Lbf:
            r11 = 0
        Lc0:
            if (r11 == 0) goto Lc6
            r10.onClick(r9)
            r1 = 1
        Lc6:
            r0 = r1
        Lc7:
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: b.d.k.a.a(android.view.View, int, android.os.Bundle):boolean");
    }
}
