package b.d.k.r;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

/* loaded from: classes.dex */
public final class a extends ClickableSpan {

    /* renamed from: b, reason: collision with root package name */
    public final int f636b;

    /* renamed from: c, reason: collision with root package name */
    public final b f637c;

    /* renamed from: d, reason: collision with root package name */
    public final int f638d;

    public a(int i, b bVar, int i2) {
        this.f636b = i;
        this.f637c = bVar;
        this.f638d = i2;
    }

    @Override // android.text.style.ClickableSpan
    public void onClick(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.f636b);
        b bVar = this.f637c;
        bVar.f640a.performAction(this.f638d, bundle);
    }
}
