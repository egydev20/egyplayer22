package b.d.k.r;

/* loaded from: classes.dex */
public class c {

    /* renamed from: a, reason: collision with root package name */
    public final Object f648a;

    public c(Object obj) {
        this.f648a = obj;
    }
}
