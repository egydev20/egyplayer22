package b.d.k.r;

import android.os.Bundle;
import android.view.View;

/* loaded from: classes.dex */
public interface d {

    /* loaded from: classes.dex */
    public static abstract class a {
        static {
            new Bundle();
        }
    }

    /* loaded from: classes.dex */
    public static final class b extends a {
    }

    /* loaded from: classes.dex */
    public static final class c extends a {
    }

    /* renamed from: b.d.k.r.d$d, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static final class C0020d extends a {
    }

    /* loaded from: classes.dex */
    public static final class e extends a {
    }

    /* loaded from: classes.dex */
    public static final class f extends a {
    }

    /* loaded from: classes.dex */
    public static final class g extends a {
    }

    /* loaded from: classes.dex */
    public static final class h extends a {
    }

    boolean a(View view, a aVar);
}
