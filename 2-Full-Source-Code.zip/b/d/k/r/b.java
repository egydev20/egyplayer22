package b.d.k.r;

import android.R;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.style.ClickableSpan;
import android.view.accessibility.AccessibilityNodeInfo;
import b.d.k.r.d;
import java.util.ArrayList;
import java.util.List;
import org.videolan.libvlc.interfaces.IMediaList;

/* loaded from: classes.dex */
public class b {

    /* renamed from: d, reason: collision with root package name */
    public static int f639d;

    /* renamed from: a, reason: collision with root package name */
    public final AccessibilityNodeInfo f640a;

    /* renamed from: b, reason: collision with root package name */
    public int f641b = -1;

    /* renamed from: c, reason: collision with root package name */
    public int f642c = -1;

    /* loaded from: classes.dex */
    public static class a {

        /* renamed from: d, reason: collision with root package name */
        public static final a f643d;
        public static final a e;
        public static final a f;
        public static final a g;

        /* renamed from: a, reason: collision with root package name */
        public final Object f644a;

        /* renamed from: b, reason: collision with root package name */
        public final Class<? extends d.a> f645b;

        /* renamed from: c, reason: collision with root package name */
        public final d f646c;

        static {
            new a(1, null);
            new a(2, null);
            new a(4, null);
            new a(8, null);
            new a(16, null);
            new a(32, null);
            new a(64, null);
            new a(128, null);
            new a(256, null, d.b.class);
            new a(IMediaList.Event.ItemAdded, null, d.b.class);
            new a(1024, null, d.c.class);
            new a(2048, null, d.c.class);
            new a(4096, null);
            new a(8192, null);
            new a(16384, null);
            new a(32768, null);
            new a(65536, null);
            new a(131072, null, d.g.class);
            new a(262144, null);
            new a(524288, null);
            new a(1048576, null);
            new a(2097152, null, d.h.class);
            new a(Build.VERSION.SDK_INT >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_ON_SCREEN : null, R.id.accessibilityActionShowOnScreen, null, null, null);
            new a(Build.VERSION.SDK_INT >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_TO_POSITION : null, R.id.accessibilityActionScrollToPosition, null, null, d.e.class);
            f643d = new a(Build.VERSION.SDK_INT >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_UP : null, R.id.accessibilityActionScrollUp, null, null, null);
            e = new a(Build.VERSION.SDK_INT >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_LEFT : null, R.id.accessibilityActionScrollLeft, null, null, null);
            f = new a(Build.VERSION.SDK_INT >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_DOWN : null, R.id.accessibilityActionScrollDown, null, null, null);
            g = new a(Build.VERSION.SDK_INT >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SCROLL_RIGHT : null, R.id.accessibilityActionScrollRight, null, null, null);
            new a(Build.VERSION.SDK_INT >= 23 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_CONTEXT_CLICK : null, R.id.accessibilityActionContextClick, null, null, null);
            new a(Build.VERSION.SDK_INT >= 24 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SET_PROGRESS : null, R.id.accessibilityActionSetProgress, null, null, d.f.class);
            new a(Build.VERSION.SDK_INT >= 26 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_MOVE_WINDOW : null, R.id.accessibilityActionMoveWindow, null, null, d.C0020d.class);
            new a(Build.VERSION.SDK_INT >= 28 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_SHOW_TOOLTIP : null, R.id.accessibilityActionShowTooltip, null, null, null);
            new a(Build.VERSION.SDK_INT >= 28 ? AccessibilityNodeInfo.AccessibilityAction.ACTION_HIDE_TOOLTIP : null, R.id.accessibilityActionHideTooltip, null, null, null);
        }

        public a(int i, CharSequence charSequence) {
            this(null, i, charSequence, null, null);
        }

        public a(int i, CharSequence charSequence, Class<? extends d.a> cls) {
            this(null, i, charSequence, null, cls);
        }

        public a(Object obj, int i, CharSequence charSequence, d dVar, Class<? extends d.a> cls) {
            this.f646c = dVar;
            this.f644a = obj == null ? new AccessibilityNodeInfo.AccessibilityAction(i, charSequence) : obj;
            this.f645b = cls;
        }

        public int a() {
            return ((AccessibilityNodeInfo.AccessibilityAction) this.f644a).getId();
        }
    }

    /* renamed from: b.d.k.r.b$b, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0019b {

        /* renamed from: a, reason: collision with root package name */
        public final Object f647a;

        public C0019b(Object obj) {
            this.f647a = obj;
        }

        public static C0019b a(int i, int i2, int i3, int i4, boolean z, boolean z2) {
            return new C0019b(AccessibilityNodeInfo.CollectionItemInfo.obtain(i, i2, i3, i4, z, z2));
        }
    }

    public b(AccessibilityNodeInfo accessibilityNodeInfo) {
        this.f640a = accessibilityNodeInfo;
    }

    public static ClickableSpan[] a(CharSequence charSequence) {
        if (charSequence instanceof Spanned) {
            return (ClickableSpan[]) ((Spanned) charSequence).getSpans(0, charSequence.length(), ClickableSpan.class);
        }
        return null;
    }

    public Bundle a() {
        return this.f640a.getExtras();
    }

    public final List<Integer> a(String str) {
        ArrayList<Integer> integerArrayList = this.f640a.getExtras().getIntegerArrayList(str);
        if (integerArrayList != null) {
            return integerArrayList;
        }
        ArrayList<Integer> arrayList = new ArrayList<>();
        this.f640a.getExtras().putIntegerArrayList(str, arrayList);
        return arrayList;
    }

    public final void a(int i, boolean z) {
        Bundle a2 = a();
        if (a2 != null) {
            int i2 = a2.getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", 0) & (~i);
            if (!z) {
                i = 0;
            }
            a2.putInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY", i | i2);
        }
    }

    public void a(a aVar) {
        this.f640a.addAction((AccessibilityNodeInfo.AccessibilityAction) aVar.f644a);
    }

    public void a(Object obj) {
        this.f640a.setCollectionItemInfo(obj == null ? null : (AccessibilityNodeInfo.CollectionItemInfo) ((C0019b) obj).f647a);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || b.class != obj.getClass()) {
            return false;
        }
        b bVar = (b) obj;
        AccessibilityNodeInfo accessibilityNodeInfo = this.f640a;
        if (accessibilityNodeInfo == null) {
            if (bVar.f640a != null) {
                return false;
            }
        } else if (!accessibilityNodeInfo.equals(bVar.f640a)) {
            return false;
        }
        return this.f642c == bVar.f642c && this.f641b == bVar.f641b;
    }

    public int hashCode() {
        AccessibilityNodeInfo accessibilityNodeInfo = this.f640a;
        if (accessibilityNodeInfo == null) {
            return 0;
        }
        return accessibilityNodeInfo.hashCode();
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r0v0, types: [java.lang.StringBuilder] */
    /* JADX WARN: Type inference failed for: r6v0, types: [java.lang.CharSequence] */
    /* JADX WARN: Type inference failed for: r6v1, types: [java.lang.CharSequence] */
    /* JADX WARN: Type inference failed for: r6v2, types: [android.text.SpannableString] */
    public String toString() {
        ?? text;
        String str;
        ?? sb = new StringBuilder();
        sb.append(super.toString());
        Rect rect = new Rect();
        this.f640a.getBoundsInParent(rect);
        sb.append("; boundsInParent: " + rect);
        this.f640a.getBoundsInScreen(rect);
        sb.append("; boundsInScreen: " + rect);
        sb.append("; packageName: ");
        sb.append(this.f640a.getPackageName());
        sb.append("; className: ");
        sb.append(this.f640a.getClassName());
        sb.append("; text: ");
        if (!a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY").isEmpty()) {
            List<Integer> a2 = a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY");
            List<Integer> a3 = a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY");
            List<Integer> a4 = a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY");
            List<Integer> a5 = a("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY");
            text = new SpannableString(TextUtils.substring(this.f640a.getText(), 0, this.f640a.getText().length()));
            for (int i = 0; i < a2.size(); i++) {
                text.setSpan(new b.d.k.r.a(a5.get(i).intValue(), this, a().getInt("androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY")), a2.get(i).intValue(), a3.get(i).intValue(), a4.get(i).intValue());
            }
        } else {
            text = this.f640a.getText();
        }
        sb.append(text);
        sb.append("; contentDescription: ");
        sb.append(this.f640a.getContentDescription());
        sb.append("; viewId: ");
        sb.append(this.f640a.getViewIdResourceName());
        sb.append("; checkable: ");
        sb.append(this.f640a.isCheckable());
        sb.append("; checked: ");
        sb.append(this.f640a.isChecked());
        sb.append("; focusable: ");
        sb.append(this.f640a.isFocusable());
        sb.append("; focused: ");
        sb.append(this.f640a.isFocused());
        sb.append("; selected: ");
        sb.append(this.f640a.isSelected());
        sb.append("; clickable: ");
        sb.append(this.f640a.isClickable());
        sb.append("; longClickable: ");
        sb.append(this.f640a.isLongClickable());
        sb.append("; enabled: ");
        sb.append(this.f640a.isEnabled());
        sb.append("; password: ");
        sb.append(this.f640a.isPassword());
        sb.append("; scrollable: " + this.f640a.isScrollable());
        sb.append("; [");
        int actions = this.f640a.getActions();
        while (actions != 0) {
            int numberOfTrailingZeros = 1 << Integer.numberOfTrailingZeros(actions);
            actions &= ~numberOfTrailingZeros;
            if (numberOfTrailingZeros == 1) {
                str = "ACTION_FOCUS";
            } else if (numberOfTrailingZeros != 2) {
                switch (numberOfTrailingZeros) {
                    case 4:
                        str = "ACTION_SELECT";
                        break;
                    case 8:
                        str = "ACTION_CLEAR_SELECTION";
                        break;
                    case 16:
                        str = "ACTION_CLICK";
                        break;
                    case 32:
                        str = "ACTION_LONG_CLICK";
                        break;
                    case 64:
                        str = "ACTION_ACCESSIBILITY_FOCUS";
                        break;
                    case 128:
                        str = "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
                        break;
                    case 256:
                        str = "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
                        break;
                    case IMediaList.Event.ItemAdded /* 512 */:
                        str = "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
                        break;
                    case 1024:
                        str = "ACTION_NEXT_HTML_ELEMENT";
                        break;
                    case 2048:
                        str = "ACTION_PREVIOUS_HTML_ELEMENT";
                        break;
                    case 4096:
                        str = "ACTION_SCROLL_FORWARD";
                        break;
                    case 8192:
                        str = "ACTION_SCROLL_BACKWARD";
                        break;
                    case 16384:
                        str = "ACTION_COPY";
                        break;
                    case 32768:
                        str = "ACTION_PASTE";
                        break;
                    case 65536:
                        str = "ACTION_CUT";
                        break;
                    case 131072:
                        str = "ACTION_SET_SELECTION";
                        break;
                    default:
                        str = "ACTION_UNKNOWN";
                        break;
                }
            } else {
                str = "ACTION_CLEAR_FOCUS";
            }
            sb.append(str);
            if (actions != 0) {
                sb.append(", ");
            }
        }
        sb.append("]");
        return sb.toString();
    }
}
