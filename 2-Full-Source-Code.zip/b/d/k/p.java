package b.d.k;

import android.view.View;

/* loaded from: classes.dex */
public class p implements o {
    @Override // b.d.k.o
    public void c(View view) {
    }
}
