package b.d.k;

import android.annotation.SuppressLint;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.Display;
import android.view.View;
import b.d.k.a;
import java.lang.reflect.Field;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
public class l {

    /* renamed from: a, reason: collision with root package name */
    public static WeakHashMap<View, n> f621a;

    /* renamed from: b, reason: collision with root package name */
    public static Field f622b;

    /* renamed from: c, reason: collision with root package name */
    public static boolean f623c;

    /* loaded from: classes.dex */
    public static abstract class a<T> {

        /* renamed from: a, reason: collision with root package name */
        public final int f624a;

        /* renamed from: b, reason: collision with root package name */
        public final Class<T> f625b;

        /* renamed from: c, reason: collision with root package name */
        public final int f626c;

        public a(int i, Class<T> cls, int i2) {
            this.f624a = i;
            this.f625b = cls;
            this.f626c = i2;
        }

        public a(int i, Class<T> cls, int i2, int i3) {
            this.f624a = i;
            this.f625b = cls;
            this.f626c = i3;
        }

        public abstract T a(View view);

        public T b(View view) {
            if (Build.VERSION.SDK_INT >= this.f626c) {
                return a(view);
            }
            T t = (T) view.getTag(this.f624a);
            if (this.f625b.isInstance(t)) {
                return t;
            }
            return null;
        }
    }

    static {
        new AtomicInteger(1);
        f621a = null;
        f623c = false;
        new WeakHashMap();
    }

    public static n a(View view) {
        if (f621a == null) {
            f621a = new WeakHashMap<>();
        }
        n nVar = f621a.get(view);
        if (nVar != null) {
            return nVar;
        }
        n nVar2 = new n(view);
        f621a.put(view, nVar2);
        return nVar2;
    }

    public static void a(View view, float f) {
        view.setZ(f);
    }

    public static void a(View view, int i) {
        view.setImportantForAccessibility(i);
    }

    public static void a(View view, ColorStateList colorStateList) {
        view.setBackgroundTintList(colorStateList);
        if (Build.VERSION.SDK_INT == 21) {
            Drawable background = view.getBackground();
            boolean z = (view.getBackgroundTintList() == null && view.getBackgroundTintMode() == null) ? false : true;
            if (background == null || !z) {
                return;
            }
            if (background.isStateful()) {
                background.setState(view.getDrawableState());
            }
            view.setBackground(background);
        }
    }

    public static void a(View view, PorterDuff.Mode mode) {
        view.setBackgroundTintMode(mode);
        if (Build.VERSION.SDK_INT == 21) {
            Drawable background = view.getBackground();
            boolean z = (view.getBackgroundTintList() == null && view.getBackgroundTintMode() == null) ? false : true;
            if (background == null || !z) {
                return;
            }
            if (background.isStateful()) {
                background.setState(view.getDrawableState());
            }
            view.setBackground(background);
        }
    }

    public static void a(View view, Drawable drawable) {
        view.setBackground(drawable);
    }

    public static void a(View view, b.d.k.a aVar) {
        if (aVar == null && (b(view) instanceof a.C0018a)) {
            aVar = new b.d.k.a();
        }
        view.setAccessibilityDelegate(aVar == null ? null : aVar.f612b);
    }

    public static void a(View view, Runnable runnable) {
        view.postOnAnimation(runnable);
    }

    public static void a(View view, Runnable runnable, long j) {
        view.postOnAnimationDelayed(runnable, j);
    }

    public static View.AccessibilityDelegate b(View view) {
        if (f623c) {
            return null;
        }
        if (f622b == null) {
            try {
                Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                f622b = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable unused) {
                f623c = true;
                return null;
            }
        }
        try {
            Object obj = f622b.get(view);
            if (obj instanceof View.AccessibilityDelegate) {
                return (View.AccessibilityDelegate) obj;
            }
            return null;
        } catch (Throwable unused2) {
            f623c = true;
            return null;
        }
    }

    public static ColorStateList c(View view) {
        return view.getBackgroundTintList();
    }

    public static Display d(View view) {
        return view.getDisplay();
    }

    public static int e(View view) {
        return view.getImportantForAccessibility();
    }

    @SuppressLint({"InlinedApi"})
    public static int f(View view) {
        if (Build.VERSION.SDK_INT >= 26) {
            return view.getImportantForAutofill();
        }
        return 0;
    }

    public static int g(View view) {
        return view.getLayoutDirection();
    }

    public static int h(View view) {
        return view.getMinimumHeight();
    }

    public static int i(View view) {
        return view.getMinimumWidth();
    }

    public static int j(View view) {
        return view.getWindowSystemUiVisibility();
    }

    public static boolean k(View view) {
        return view.hasTransientState();
    }

    public static boolean l(View view) {
        return view.isAttachedToWindow();
    }

    public static boolean m(View view) {
        Boolean b2 = new i(b.d.b.tag_screen_reader_focusable, Boolean.class, 28).b(view);
        if (b2 == null) {
            return false;
        }
        return b2.booleanValue();
    }

    public static void n(View view) {
        view.postInvalidateOnAnimation();
    }

    public static void o(View view) {
        view.requestApplyInsets();
    }

    public static void p(View view) {
        view.stopNestedScroll();
    }
}
