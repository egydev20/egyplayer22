package b.d.k;

import android.view.View;
import b.d.k.l;

/* loaded from: classes.dex */
public final class k extends l.a<Boolean> {
    public k(int i, Class cls, int i2) {
        super(i, cls, i2);
    }

    @Override // b.d.k.l.a
    public Boolean a(View view) {
        return Boolean.valueOf(view.isAccessibilityHeading());
    }
}
