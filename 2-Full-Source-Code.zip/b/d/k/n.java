package b.d.k;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.view.View;
import b.a.k.g;
import java.lang.ref.WeakReference;

/* loaded from: classes.dex */
public final class n {

    /* renamed from: a, reason: collision with root package name */
    public WeakReference<View> f628a;

    /* renamed from: b, reason: collision with root package name */
    public Runnable f629b = null;

    /* renamed from: c, reason: collision with root package name */
    public Runnable f630c = null;

    /* renamed from: d, reason: collision with root package name */
    public int f631d = -1;

    /* loaded from: classes.dex */
    public class a extends AnimatorListenerAdapter {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ o f632a;

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ View f633b;

        public a(n nVar, o oVar, View view) {
            this.f632a = oVar;
            this.f633b = view;
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationCancel(Animator animator) {
            this.f632a.c(this.f633b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationEnd(Animator animator) {
            this.f632a.a(this.f633b);
        }

        @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
        public void onAnimationStart(Animator animator) {
            this.f632a.b(this.f633b);
        }
    }

    /* loaded from: classes.dex */
    public class b implements ValueAnimator.AnimatorUpdateListener {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ q f634a;

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ View f635b;

        public b(n nVar, q qVar, View view) {
            this.f634a = qVar;
            this.f635b = view;
        }

        @Override // android.animation.ValueAnimator.AnimatorUpdateListener
        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            ((View) ((g.a) this.f634a).f258a.f255b.getParent()).invalidate();
        }
    }

    public n(View view) {
        this.f628a = new WeakReference<>(view);
    }

    public n a(float f) {
        View view = this.f628a.get();
        if (view != null) {
            view.animate().translationY(f);
        }
        return this;
    }

    public n a(long j) {
        View view = this.f628a.get();
        if (view != null) {
            view.animate().setDuration(j);
        }
        return this;
    }

    public n a(o oVar) {
        View view = this.f628a.get();
        if (view != null) {
            a(view, oVar);
        }
        return this;
    }

    public n a(q qVar) {
        View view = this.f628a.get();
        if (view != null) {
            view.animate().setUpdateListener(qVar != null ? new b(this, qVar, view) : null);
        }
        return this;
    }

    public void a() {
        View view = this.f628a.get();
        if (view != null) {
            view.animate().cancel();
        }
    }

    public final void a(View view, o oVar) {
        if (oVar != null) {
            view.animate().setListener(new a(this, oVar, view));
        } else {
            view.animate().setListener(null);
        }
    }
}
