package b.d.k;

/* loaded from: classes.dex */
public class h {

    /* renamed from: a, reason: collision with root package name */
    public int f619a;

    /* renamed from: b, reason: collision with root package name */
    public int f620b;
}
