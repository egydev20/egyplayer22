package b.d.k;

import android.view.View;

/* loaded from: classes.dex */
public interface g extends f {
    void a(View view, int i, int i2, int i3, int i4, int i5, int[] iArr);
}
