package b.d.k;

/* loaded from: classes.dex */
public interface q {
}
