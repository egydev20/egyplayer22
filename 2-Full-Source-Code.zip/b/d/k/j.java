package b.d.k;

import android.view.View;
import b.d.k.l;

/* loaded from: classes.dex */
public final class j extends l.a<CharSequence> {
    public j(int i, Class cls, int i2, int i3) {
        super(i, cls, i2, i3);
    }

    @Override // b.d.k.l.a
    public CharSequence a(View view) {
        return view.getAccessibilityPaneTitle();
    }
}
