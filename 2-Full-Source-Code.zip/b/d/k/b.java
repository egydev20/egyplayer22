package b.d.k;

import android.content.Context;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import b.a.o.d.h;

/* loaded from: classes.dex */
public abstract class b {

    /* renamed from: a, reason: collision with root package name */
    public a f614a;

    /* loaded from: classes.dex */
    public interface a {
    }

    public b(Context context) {
    }

    public View a(MenuItem menuItem) {
        return ((h.a) this).f333b.onCreateActionView();
    }

    public void a(a aVar) {
        if (this.f614a != null && aVar != null) {
            StringBuilder a2 = c.a.b.a.a.a("setVisibilityListener: Setting a new ActionProvider.VisibilityListener when one is already set. Are you reusing this ");
            a2.append(getClass().getSimpleName());
            a2.append(" instance while it is still in use somewhere else?");
            Log.w("ActionProvider(support)", a2.toString());
        }
        this.f614a = aVar;
    }

    public boolean a() {
        return true;
    }

    public boolean b() {
        return false;
    }
}
