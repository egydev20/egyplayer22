package b.d.h;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.Handler;
import b.c.h;
import b.c.j;
import b.d.h.c;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public class b {

    /* renamed from: a, reason: collision with root package name */
    public static final h<String, Typeface> f572a = new h<>(16);

    /* renamed from: b, reason: collision with root package name */
    public static final b.d.h.c f573b = new b.d.h.c("fonts", 10, 10000);

    /* renamed from: c, reason: collision with root package name */
    public static final Object f574c = new Object();

    /* renamed from: d, reason: collision with root package name */
    public static final j<String, ArrayList<c.InterfaceC0016c<g>>> f575d = new j<>();
    public static final Comparator<byte[]> e = new d();

    /* loaded from: classes.dex */
    public static class a implements Callable<g> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ Context f576a;

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ b.d.h.a f577b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ int f578c;

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ String f579d;

        public a(Context context, b.d.h.a aVar, int i, String str) {
            this.f576a = context;
            this.f577b = aVar;
            this.f578c = i;
            this.f579d = str;
        }

        @Override // java.util.concurrent.Callable
        public g call() {
            g a2 = b.a(this.f576a, this.f577b, this.f578c);
            Typeface typeface = a2.f589a;
            if (typeface != null) {
                b.f572a.a(this.f579d, typeface);
            }
            return a2;
        }
    }

    /* renamed from: b.d.h.b$b, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public static class C0015b implements c.InterfaceC0016c<g> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ b.d.e.b.g f580a;

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ Handler f581b;

        public C0015b(b.d.e.b.g gVar, Handler handler) {
            this.f580a = gVar;
            this.f581b = handler;
        }

        @Override // b.d.h.c.InterfaceC0016c
        public void a(g gVar) {
            int i;
            b.d.e.b.g gVar2;
            g gVar3 = gVar;
            if (gVar3 == null) {
                gVar2 = this.f580a;
                i = 1;
            } else {
                i = gVar3.f590b;
                if (i == 0) {
                    this.f580a.a(gVar3.f589a, this.f581b);
                    return;
                }
                gVar2 = this.f580a;
            }
            gVar2.a(i, this.f581b);
        }
    }

    /* loaded from: classes.dex */
    public static class c implements c.InterfaceC0016c<g> {

        /* renamed from: a, reason: collision with root package name */
        public final /* synthetic */ String f582a;

        public c(String str) {
            this.f582a = str;
        }

        @Override // b.d.h.c.InterfaceC0016c
        public void a(g gVar) {
            synchronized (b.f574c) {
                ArrayList<c.InterfaceC0016c<g>> arrayList = b.f575d.get(this.f582a);
                if (arrayList == null) {
                    return;
                }
                b.f575d.remove(this.f582a);
                for (int i = 0; i < arrayList.size(); i++) {
                    arrayList.get(i).a(gVar);
                }
            }
        }
    }

    /* loaded from: classes.dex */
    public static class d implements Comparator<byte[]> {
        /* JADX WARN: Multi-variable type inference failed */
        @Override // java.util.Comparator
        public int compare(byte[] bArr, byte[] bArr2) {
            int i;
            int i2;
            byte[] bArr3 = bArr;
            byte[] bArr4 = bArr2;
            if (bArr3.length == bArr4.length) {
                for (int i3 = 0; i3 < bArr3.length; i3++) {
                    if (bArr3[i3] != bArr4[i3]) {
                        i = bArr3[i3];
                        i2 = bArr4[i3];
                    }
                }
                return 0;
            }
            i = bArr3.length;
            i2 = bArr4.length;
            return i - i2;
        }
    }

    /* loaded from: classes.dex */
    public static class e {

        /* renamed from: a, reason: collision with root package name */
        public final int f583a;

        /* renamed from: b, reason: collision with root package name */
        public final f[] f584b;

        public e(int i, f[] fVarArr) {
            this.f583a = i;
            this.f584b = fVarArr;
        }
    }

    /* loaded from: classes.dex */
    public static class f {

        /* renamed from: a, reason: collision with root package name */
        public final Uri f585a;

        /* renamed from: b, reason: collision with root package name */
        public final int f586b;

        /* renamed from: c, reason: collision with root package name */
        public final int f587c;

        /* renamed from: d, reason: collision with root package name */
        public final boolean f588d;
        public final int e;

        public f(Uri uri, int i, int i2, boolean z, int i3) {
            if (uri == null) {
                throw null;
            }
            this.f585a = uri;
            this.f586b = i;
            this.f587c = i2;
            this.f588d = z;
            this.e = i3;
        }
    }

    /* loaded from: classes.dex */
    public static final class g {

        /* renamed from: a, reason: collision with root package name */
        public final Typeface f589a;

        /* renamed from: b, reason: collision with root package name */
        public final int f590b;

        public g(Typeface typeface, int i) {
            this.f589a = typeface;
            this.f590b = i;
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:28:0x0092 A[LOOP:1: B:14:0x004d->B:28:0x0092, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:29:0x0096 A[EDGE_INSN: B:29:0x0096->B:30:0x0096 BREAK  A[LOOP:1: B:14:0x004d->B:28:0x0092], SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static b.d.h.b.e a(android.content.Context r20, android.os.CancellationSignal r21, b.d.h.a r22) {
        /*
            Method dump skipped, instructions count: 454
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b.d.h.b.a(android.content.Context, android.os.CancellationSignal, b.d.h.a):b.d.h.b$e");
    }

    public static g a(Context context, b.d.h.a aVar, int i) {
        try {
            e a2 = a(context, (CancellationSignal) null, aVar);
            int i2 = a2.f583a;
            if (i2 != 0) {
                return new g(null, i2 == 1 ? -2 : -3);
            }
            Typeface a3 = b.d.f.c.f552a.a(context, (CancellationSignal) null, a2.f584b, i);
            return new g(a3, a3 != null ? 0 : -3);
        } catch (PackageManager.NameNotFoundException unused) {
            return new g(null, -1);
        }
    }

    public static Typeface a(Context context, b.d.h.a aVar, b.d.e.b.g gVar, Handler handler, boolean z, int i, int i2) {
        String str = aVar.f + "-" + i2;
        Typeface a2 = f572a.a((h<String, Typeface>) str);
        if (a2 != null) {
            if (gVar != null) {
                gVar.a(a2);
            }
            return a2;
        }
        if (z && i == -1) {
            g a3 = a(context, aVar, i2);
            if (gVar != null) {
                int i3 = a3.f590b;
                if (i3 == 0) {
                    gVar.a(a3.f589a, handler);
                } else {
                    gVar.a(i3, handler);
                }
            }
            return a3.f589a;
        }
        a aVar2 = new a(context, aVar, i2, str);
        if (z) {
            try {
                return ((g) f573b.a(aVar2, i)).f589a;
            } catch (InterruptedException unused) {
                return null;
            }
        }
        C0015b c0015b = gVar == null ? null : new C0015b(gVar, handler);
        synchronized (f574c) {
            ArrayList<c.InterfaceC0016c<g>> orDefault = f575d.getOrDefault(str, null);
            if (orDefault != null) {
                if (c0015b != null) {
                    orDefault.add(c0015b);
                }
                return null;
            }
            if (c0015b != null) {
                ArrayList<c.InterfaceC0016c<g>> arrayList = new ArrayList<>();
                arrayList.add(c0015b);
                f575d.put(str, arrayList);
            }
            b.d.h.c cVar = f573b;
            c cVar2 = new c(str);
            if (cVar == null) {
                throw null;
            }
            cVar.b(new b.d.h.d(cVar, aVar2, new Handler(), cVar2));
            return null;
        }
    }

    public static Map<Uri, ByteBuffer> a(Context context, f[] fVarArr, CancellationSignal cancellationSignal) {
        HashMap hashMap = new HashMap();
        for (f fVar : fVarArr) {
            if (fVar.e == 0) {
                Uri uri = fVar.f585a;
                if (!hashMap.containsKey(uri)) {
                    hashMap.put(uri, a.a.a.a.a.a(context, cancellationSignal, uri));
                }
            }
        }
        return Collections.unmodifiableMap(hashMap);
    }
}
