package b.d.h;

import android.os.Handler;
import b.d.h.c;
import java.util.concurrent.Callable;

/* loaded from: classes.dex */
public class d implements Runnable {

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Callable f599b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Handler f600c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ c.InterfaceC0016c f601d;

    /* loaded from: classes.dex */
    public class a implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ Object f602b;

        public a(Object obj) {
            this.f602b = obj;
        }

        @Override // java.lang.Runnable
        public void run() {
            d.this.f601d.a(this.f602b);
        }
    }

    public d(c cVar, Callable callable, Handler handler, c.InterfaceC0016c interfaceC0016c) {
        this.f599b = callable;
        this.f600c = handler;
        this.f601d = interfaceC0016c;
    }

    @Override // java.lang.Runnable
    public void run() {
        Object obj;
        try {
            obj = this.f599b.call();
        } catch (Exception unused) {
            obj = null;
        }
        this.f600c.post(new a(obj));
    }
}
