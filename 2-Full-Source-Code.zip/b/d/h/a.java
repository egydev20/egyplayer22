package b.d.h;

import android.util.Base64;
import java.util.List;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final String f568a;

    /* renamed from: b, reason: collision with root package name */
    public final String f569b;

    /* renamed from: c, reason: collision with root package name */
    public final String f570c;

    /* renamed from: d, reason: collision with root package name */
    public final List<List<byte[]>> f571d;
    public final int e;
    public final String f;

    public a(String str, String str2, String str3, List<List<byte[]>> list) {
        if (str == null) {
            throw null;
        }
        this.f568a = str;
        if (str2 == null) {
            throw null;
        }
        this.f569b = str2;
        if (str3 == null) {
            throw null;
        }
        this.f570c = str3;
        if (list == null) {
            throw null;
        }
        this.f571d = list;
        this.e = 0;
        this.f = str + "-" + this.f569b + "-" + this.f570c;
    }

    public String toString() {
        StringBuilder sb = new StringBuilder();
        StringBuilder a2 = c.a.b.a.a.a("FontRequest {mProviderAuthority: ");
        a2.append(this.f568a);
        a2.append(", mProviderPackage: ");
        a2.append(this.f569b);
        a2.append(", mQuery: ");
        a2.append(this.f570c);
        a2.append(", mCertificates:");
        sb.append(a2.toString());
        for (int i = 0; i < this.f571d.size(); i++) {
            sb.append(" [");
            List<byte[]> list = this.f571d.get(i);
            for (int i2 = 0; i2 < list.size(); i2++) {
                sb.append(" \"");
                sb.append(Base64.encodeToString(list.get(i2), 0));
                sb.append("\"");
            }
            sb.append(" ]");
        }
        sb.append("}");
        sb.append("mCertificatesArray: " + this.e);
        return sb.toString();
    }
}
