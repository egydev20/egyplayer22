package b.d.h;

import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import java.util.concurrent.Callable;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.ReentrantLock;

/* loaded from: classes.dex */
public class c {

    /* renamed from: b, reason: collision with root package name */
    public HandlerThread f592b;

    /* renamed from: c, reason: collision with root package name */
    public Handler f593c;
    public final int f;
    public final int g;
    public final String h;

    /* renamed from: a, reason: collision with root package name */
    public final Object f591a = new Object();
    public Handler.Callback e = new a();

    /* renamed from: d, reason: collision with root package name */
    public int f594d = 0;

    /* loaded from: classes.dex */
    public class a implements Handler.Callback {
        public a() {
        }

        @Override // android.os.Handler.Callback
        public boolean handleMessage(Message message) {
            int i = message.what;
            if (i == 0) {
                c.this.a();
                return true;
            }
            if (i != 1) {
                return true;
            }
            c.this.a((Runnable) message.obj);
            return true;
        }
    }

    /* loaded from: classes.dex */
    public class b implements Runnable {

        /* renamed from: b, reason: collision with root package name */
        public final /* synthetic */ AtomicReference f596b;

        /* renamed from: c, reason: collision with root package name */
        public final /* synthetic */ Callable f597c;

        /* renamed from: d, reason: collision with root package name */
        public final /* synthetic */ ReentrantLock f598d;
        public final /* synthetic */ AtomicBoolean e;
        public final /* synthetic */ Condition f;

        public b(c cVar, AtomicReference atomicReference, Callable callable, ReentrantLock reentrantLock, AtomicBoolean atomicBoolean, Condition condition) {
            this.f596b = atomicReference;
            this.f597c = callable;
            this.f598d = reentrantLock;
            this.e = atomicBoolean;
            this.f = condition;
        }

        @Override // java.lang.Runnable
        public void run() {
            try {
                this.f596b.set(this.f597c.call());
            } catch (Exception unused) {
            }
            this.f598d.lock();
            try {
                this.e.set(false);
                this.f.signal();
            } finally {
                this.f598d.unlock();
            }
        }
    }

    /* renamed from: b.d.h.c$c, reason: collision with other inner class name */
    /* loaded from: classes.dex */
    public interface InterfaceC0016c<T> {
        void a(T t);
    }

    public c(String str, int i, int i2) {
        this.h = str;
        this.g = i;
        this.f = i2;
    }

    public <T> T a(Callable<T> callable, int i) {
        ReentrantLock reentrantLock = new ReentrantLock();
        Condition newCondition = reentrantLock.newCondition();
        AtomicReference atomicReference = new AtomicReference();
        AtomicBoolean atomicBoolean = new AtomicBoolean(true);
        b(new b(this, atomicReference, callable, reentrantLock, atomicBoolean, newCondition));
        reentrantLock.lock();
        try {
            if (!atomicBoolean.get()) {
                return (T) atomicReference.get();
            }
            long nanos = TimeUnit.MILLISECONDS.toNanos(i);
            do {
                try {
                    nanos = newCondition.awaitNanos(nanos);
                } catch (InterruptedException unused) {
                }
                if (!atomicBoolean.get()) {
                    return (T) atomicReference.get();
                }
            } while (nanos > 0);
            throw new InterruptedException("timeout");
        } finally {
            reentrantLock.unlock();
        }
    }

    public void a() {
        synchronized (this.f591a) {
            if (this.f593c.hasMessages(1)) {
                return;
            }
            this.f592b.quit();
            this.f592b = null;
            this.f593c = null;
        }
    }

    public void a(Runnable runnable) {
        runnable.run();
        synchronized (this.f591a) {
            this.f593c.removeMessages(0);
            this.f593c.sendMessageDelayed(this.f593c.obtainMessage(0), this.f);
        }
    }

    public final void b(Runnable runnable) {
        synchronized (this.f591a) {
            if (this.f592b == null) {
                HandlerThread handlerThread = new HandlerThread(this.h, this.g);
                this.f592b = handlerThread;
                handlerThread.start();
                this.f593c = new Handler(this.f592b.getLooper(), this.e);
                this.f594d++;
            }
            this.f593c.removeMessages(0);
            this.f593c.sendMessage(this.f593c.obtainMessage(1, runnable));
        }
    }
}
