package b.i;

import b.l.c;

/* loaded from: classes.dex */
public interface a extends c {
}
